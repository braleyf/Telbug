﻿using MetroFastPayLibrary;
using Newtonsoft.Json;
using RestSharp;
using RestSharp.Authenticators;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Twilio;
using Twilio.Rest.Api.V2010.Account;

namespace MetroFastPay
{

    public partial class GetConf : System.Web.UI.Page
    {
        User oUser = new User();
        UserDAO oUserDAO = new UserDAO();
        Payment oPaySID = new Payment();
        private HttpClient _Client = new HttpClient();

        protected async void Page_Load(object sender, EventArgs e)
        {
           await gettimerworking();
        }
        public async Task gettimerworking()
        {
            oPaySID = oUserDAO.RetrieveSIDbyPaymentID(Convert.ToInt32(Request.QueryString["paymentid"].ToString()));
            DateTime paymentTime;
            
            if(oPaySID.IsManual == true)
            {
                lbInfo.Text = "This payment was made manually";
                lbConf.Text = "";
                btnReprocessPayment.Enabled = false;
                btnIsManual.Enabled = false;
                return;
            }
            else
            {
                if (Request.QueryString["time"].Contains("%"))
                {
                    paymentTime = Convert.ToDateTime(WebUtility.UrlDecode(Request.QueryString["time"]));
                }
                else
                {
                    paymentTime = Convert.ToDateTime(Request.QueryString["time"]);
                }

                paymentTime = paymentTime.AddMinutes(4);

                //if (!IsPostBack)
                //{
                //    Session["timer"] = paymentTime;
                //}

                if (paymentTime < DateTime.Now)
                {
                    DateTime sidTime = oPaySID.CreatedDate;
                    sidTime = sidTime.AddMinutes(4);
                    if (sidTime < DateTime.Now)
                    {
                        if (Request.Url.ToString().Contains("CAsid"))
                        {
                            await getRecodingSIDRestSharp();
                        }
                    }
                    else
                    {
                        lbConf.Text = "Payment is being reprocessed, should post in 4 min";
                        btnReprocessPayment.Enabled = false;
                        btnIsManual.Enabled = false;
                        return;
                    }

                }
                else
                {

                    btnReprocessPayment.Enabled = false;
                    btnIsManual.Enabled = false;
                    lbConf.Text = "4 minutes are not up yet...";
                }
            }
          
        }
        async Task getRecodingSIDRestSharp()
        {
            try
            {
                _Client = new HttpClient();
                _Client.BaseAddress = new Uri("https://api.twilio.com/");
                _Client.DefaultRequestHeaders.Accept.Clear();
                _Client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(System.Text.ASCIIEncoding.ASCII.GetBytes(string.Format("{0}:{1}", "ACf68d6c4ff981f1ff8962f266f81ced48", "6550fa15290f0b119b3a4ab7466200f9"))));

                HttpResponseMessage response = await _Client.GetAsync("https://api.twilio.com/2010-04-01/Accounts/ACf68d6c4ff981f1ff8962f266f81ced48/Calls/"+ Request.QueryString["CAsid"].ToString() + "/Recordings.json");
                response.EnsureSuccessStatusCode();

                string resonseBody = await response.Content.ReadAsStringAsync();


                if (resonseBody.Contains("recordings"))
                {
                    string REsid = getBetween(resonseBody, "\"sid\": \"", "\", \"price\":");

                    await getTranscriptionSIDRestSharp(REsid);
                }
                else
                {
                    lbConf.Text = "Payment needs to be reprocessed";
                }
            }
            catch (Exception ex)
            {
                lbConf.Text = "Payment needs to be reprocessed";

            }
        }
        async Task getTranscriptionSIDRestSharp(string REsid)
        {
            try
            {
                _Client = new HttpClient();
                _Client.BaseAddress = new Uri("https://api.twilio.com/");
                _Client.DefaultRequestHeaders.Accept.Clear();
                _Client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(System.Text.ASCIIEncoding.ASCII.GetBytes(string.Format("{0}:{1}", "ACf68d6c4ff981f1ff8962f266f81ced48", "6550fa15290f0b119b3a4ab7466200f9"))));

                HttpResponseMessage response = await _Client.GetAsync("https://api.twilio.com/2010-04-01/Accounts/ACf68d6c4ff981f1ff8962f266f81ced48/Recordings/"+ REsid  + "/Transcriptions.json");
                response.EnsureSuccessStatusCode();

                string resonseBody = await response.Content.ReadAsStringAsync();

                if (resonseBody.Contains("transcriptions"))
                {
                    string transcroptionText = getBetween(resonseBody, "confirmation number is", "would you like");
                    if (transcroptionText == "")
                    {
                        if (resonseBody.Contains("customer service skills"))
                        {
                            lbConf.Text = "Bad number, cant reprocessed";
                            btnReprocessPayment.Enabled = false;
                            return;
                        }
                        else if(resonseBody.Contains("Sure to find out your phone number"))
                        {
                            lbConf.Text = "Payment needs to be reprocessed";
                            btnReprocessPayment2.Visible = true;
                            btnReprocessPayment.Visible  = false;
                            return;
                        }
                        else
                        {
                            lbConf.Text = "Payment needs to be reprocessed";
                            btnReprocessPayment.Enabled = true;
                            return;
                        }

                    }
                    else
                    {
                        lbConf.Text = "<b>User:</b> " + Request.QueryString["user"].ToString() + "<br /><b>Number:</b> " + Request.QueryString["number"].ToString() + "<br /><b>Amount:</b> " + Request.QueryString["amount"].ToString() + "<br /><b>The real conf is:</b>" + transcroptionText;
                        btnReprocessPayment.Enabled = false;
                        btnIsManual.Enabled = false;
                        return;
                    }


                }
                else
                {
                    lbConf.Text = "Payment needs to be reprocessed";
                }
            }
            catch (Exception ex)
            {
                lbConf.Text = "Payment needs to be reprocessed";
            }
        }
        public static string getBetween(string strSource, string strStart, string strEnd)
        {
            int Start, End;
            if (strSource.Contains(strStart) && strSource.Contains(strEnd))
            {
                Start = strSource.IndexOf(strStart, 0) + strStart.Length;
                End = strSource.IndexOf(strEnd, Start);
                return strSource.Substring(Start, End - Start);
            }
            else
            {
                return "";
            }
        }

        protected void btnReprocessPayment_Click(object sender, EventArgs e)
        {
            try
            {
                string paymentid = Request.QueryString["paymentid"].ToString();
                Payment oPaySID = new Payment();
                oPaySID = oUserDAO.DeleteSID(paymentid);

                CC oCC = new CC();
                oCC = oUserDAO.RetrieveCC();
                CC oCC2 = new CC();
                oCC2 = oUserDAO.RetrieveCC2();
                CC oCC3 = new CC();
                oCC3 = oUserDAO.RetrieveCC3();


                string thecc = "";
                string thecvv = "";
                string expDate = "";
                string ZIP = "";

                if (oCC.Used != null)
                {
                    string cc = oCC.CCNumber;
                    Session["cc"] = cc;
                    thecc = DAO.Decrypt(oCC.CCNumber, ConfigurationManager.AppSettings["encryptionKey"]).Trim();
                    thecvv = oCC.CVV.Trim();
                    expDate = oCC.ExpDate;
                    ZIP = oCC.ZIP;
                    
                }
                else if (oCC2.Used != null)
                {
                    string cc = oCC2.CCNumber;
                    Session["cc"] = cc;
                    thecc = DAO.Decrypt(oCC2.CCNumber, ConfigurationManager.AppSettings["encryptionKey"]).Trim();
                    thecvv = oCC2.CVV.Trim();
                    expDate = oCC2.ExpDate;
                    ZIP = oCC2.ZIP;
                    
                }
                else if (oCC3.Used != null)
                {
                    string cc = oCC3.CCNumber;
                    Session["cc"] = cc;
                    thecc = DAO.Decrypt(oCC3.CCNumber, ConfigurationManager.AppSettings["encryptionKey"]).Trim();
                    thecvv = oCC3.CVV.Trim();
                    expDate = oCC3.ExpDate;
                    ZIP = oCC3.ZIP;                  
                }

                if (oCC3.Used == null && oCC2.Used == null && oCC.Used == null)
                {
                    lbInfo.Text = "No cards in the system to reprocess the payment, please add cc";
                }
                ServicePointManager.Expect100Continue = true;
                ServicePointManager.DefaultConnectionLimit = 9999;
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12 | SecurityProtocolType.Ssl3;
                string phone = Request.QueryString["number"].ToString();
                string amount = Request.QueryString["amount"].ToString();
                expDate = expDate.Replace("/", "");
                var client = new RestClient("http://orqclasea.com/api/products/MakeMetroPaymentByCall/" + phone + "/" + amount + "/" + thecc + "/" + expDate + "/" + thecvv + "/JXdXJnLPToP7nHEaVp8yYQ==/W36LMly02eDkS9QY9J149RomrFVdR4SC2fSE35oZX-M=");
                var request = new RestRequest(Method.POST);
                request.AddHeader("postman-token", "f83362a9-f459-cfea-da6c-9f51266621ce");
                request.AddHeader("cache-control", "no-cache");
                IRestResponse response = client.Execute(request);
                string s = response.Content;


                if (s.Contains("Payment Processing..."))
                {

                    if (oCC.Used != null)
                    {
                        //update card used
                        int used = Convert.ToInt16(oCC.Used) + 1;
                        oUserDAO.UpdateCCUsage(Convert.ToString(used), oCC.CCNumber);

                    }
                    else if (oCC2.Used != null)
                    {
                        //update card used
                        int used = Convert.ToInt16(oCC2.Used) + 1;
                        oUserDAO.UpdateCCUsage(Convert.ToString(used), oCC2.CCNumber);


                        //CC oDisCC = new CC();
                        //oDisCC = oUserDAO.DisableCard(oCC2.CCNumber, false);
                    }
                    else if (oCC3.Used != null)
                    {
                        //update card used
                        int used = Convert.ToInt16(oCC3.Used) + 1;
                        oUserDAO.UpdateCCUsage(Convert.ToString(used), oCC3.CCNumber);

                        CC oDisCC = new CC();
                        oDisCC = oUserDAO.DisableCard(oCC3.CCNumber, false);


                    }



                    lbInfo.Text = "Payment is being reprocessed, should post in 4 minutes";
                    lbConf.Text = "";
                    btnReprocessPayment.Enabled = false;
                    btnIsManual.Enabled = false;
                }
                else
                {


                    lbInfo.Text = "Payment not processed, might be no cards in system";
                }

            }
            catch (Exception ex)
            {
                lbInfo.Text = "Something went wrong: " + ex.ToString();
            }
        }
        protected void btnReprocessPayment2_Click(object sender, EventArgs e)
        {
            try
            {
                string paymentid = Request.QueryString["paymentid"].ToString();
                Payment oPaySID = new Payment();
                oPaySID = oUserDAO.DeleteSID(paymentid);

                CC oCC = new CC();
                oCC = oUserDAO.RetrieveCC();
                CC oCC2 = new CC();
                oCC2 = oUserDAO.RetrieveCC2();
                CC oCC3 = new CC();
                oCC3 = oUserDAO.RetrieveCC3();


                string thecc = "";
                string thecvv = "";
                string expDate = "";
                string ZIP = "";

                if (oCC.Used != null)
                {
                    string cc = oCC.CCNumber;
                    Session["cc"] = cc;
                    thecc = DAO.Decrypt(oCC.CCNumber, ConfigurationManager.AppSettings["encryptionKey"]).Trim();
                    thecvv = oCC.CVV.Trim();
                    expDate = oCC.ExpDate;
                    ZIP = oCC.ZIP;

                }
                else if (oCC2.Used != null)
                {
                    string cc = oCC2.CCNumber;
                    Session["cc"] = cc;
                    thecc = DAO.Decrypt(oCC2.CCNumber, ConfigurationManager.AppSettings["encryptionKey"]).Trim();
                    thecvv = oCC2.CVV.Trim();
                    expDate = oCC2.ExpDate;
                    ZIP = oCC2.ZIP;

                }
                else if (oCC3.Used != null)
                {
                    string cc = oCC3.CCNumber;
                    Session["cc"] = cc;
                    thecc = DAO.Decrypt(oCC3.CCNumber, ConfigurationManager.AppSettings["encryptionKey"]).Trim();
                    thecvv = oCC3.CVV.Trim();
                    expDate = oCC3.ExpDate;
                    ZIP = oCC3.ZIP;
                }

                if (oCC3.Used == null && oCC2.Used == null && oCC.Used == null)
                {
                    lbInfo.Text = "No cards in the system to reprocess the payment, please add cc";
                }
                ServicePointManager.Expect100Continue = true;
                ServicePointManager.DefaultConnectionLimit = 9999;
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12 | SecurityProtocolType.Ssl3;
                string phone = Request.QueryString["number"].ToString();
                string amount = Request.QueryString["amount"].ToString();
                expDate = expDate.Replace("/", "");
                var client = new RestClient("http://orqclasea.com/api/products/MakeMetroPaymentByCall2/" + phone + "/" + amount + "/" + thecc + "/" + expDate + "/" + thecvv + "/JXdXJnLPToP7nHEaVp8yYQ==/W36LMly02eDkS9QY9J149RomrFVdR4SC2fSE35oZX-M=");
                var request = new RestRequest(Method.POST);
                request.AddHeader("postman-token", "f83362a9-f459-cfea-da6c-9f51266621ce");
                request.AddHeader("cache-control", "no-cache");
                IRestResponse response = client.Execute(request);
                string s = response.Content;


                if (s.Contains("Payment Processing..."))
                {

                    if (oCC.Used != null)
                    {
                        //update card used
                        int used = Convert.ToInt16(oCC.Used) + 1;
                        oUserDAO.UpdateCCUsage(Convert.ToString(used), oCC.CCNumber);

                    }
                    else if (oCC2.Used != null)
                    {
                        //update card used
                        int used = Convert.ToInt16(oCC2.Used) + 1;
                        oUserDAO.UpdateCCUsage(Convert.ToString(used), oCC2.CCNumber);


                        //CC oDisCC = new CC();
                        //oDisCC = oUserDAO.DisableCard(oCC2.CCNumber, false);
                    }
                    else if (oCC3.Used != null)
                    {
                        //update card used
                        int used = Convert.ToInt16(oCC3.Used) + 1;
                        oUserDAO.UpdateCCUsage(Convert.ToString(used), oCC3.CCNumber);

                        CC oDisCC = new CC();
                        oDisCC = oUserDAO.DisableCard(oCC3.CCNumber, false);


                    }



                    lbInfo.Text = "Payment is being reprocessed, should post in 4 minutes";
                    lbConf.Text = "";
                    btnReprocessPayment2.Enabled = false;
                    btnIsManual.Enabled = false;
                }
                else
                {


                    lbInfo.Text = "Payment not processed, might be no cards in system";
                }

            }
            catch (Exception ex)
            {
                lbInfo.Text = "Something went wrong: " + ex.ToString();
            }
        }
        //protected void Timer_Tick(object sender, EventArgs e)
        //{
        //    TimeSpan time1 = new TimeSpan();
        //    time1 = (DateTime)Session["timer"] - DateTime.Now;
        //    if (ScriptManager1.IsInAsyncPostBack)
        //    {

        //        string thecountDown = time1.Minutes.ToString() + ":" + time1.Seconds.ToString();
        //        lbcounter.Text = thecountDown;
        //        UpdatePanel1.Update();
        //    }

        //}

        protected void btnIsManual_Click(object sender, EventArgs e)
        {
            try
            {  
                string sid = Request.QueryString["CAsid"].ToString();
                Payment oPaySID = new Payment();
                if (sid == "")
                {
                    lbInfo.ForeColor = Color.Red;
                    lbInfo.Text = "Payment needs to be reprocessed before marking as manual";
                }
                else
                {
                    oUserDAO.UpdateSidIsManual(sid, true);
                    btnReprocessPayment.Enabled = false;
                    btnIsManual.Enabled = false;
                    lbConf.Text = "";
                    lbInfo.ForeColor = Color.Black;
                    lbInfo.Text = "Marked as manual, it cannot be reprocessed";
                }

            }
            catch (Exception ex)
            {
                lbInfo.Text = "Something went wrong: " + ex.ToString();
            }
}
    }

}