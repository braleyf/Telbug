﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net.Mail;
using System.Configuration;
using System.Web.UI.HtmlControls;
using System.Drawing;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using System.Net;
using MetroFastPayLibrary;
using System.Text;
using System.Security.Cryptography;
using System.Data.OleDb;
using RestSharp;
using System.Net.Http;
using System.Threading.Tasks;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using Twilio;
using Twilio.Rest.Api.V2010.Account;

namespace MetroFastPay
{
    public partial class MyAccount : System.Web.UI.Page
    {
        User oUser = new User();
        UserDAO oUserDAO = new UserDAO();
        User oFee = new User();
        CC oUsercc = new CC();
        string thecc;
        MetroFastPayLibrary.Account oAccount = new MetroFastPayLibrary.Account();
        string dbCon = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
        System.Web.HttpCookie UserCookie = HttpContext.Current.Request.Cookies["UserNameCookie"];
        protected void Page_Load(object sender, EventArgs e)
        {

            if (Request.Cookies["UserNameCookie"] == null)
            {
                //Session.Abandon();
                //UserCookie.Expires = DateTime.Now.AddYears(-1);
                //Response.Cookies.Add(UserCookie);
                Response.Redirect("out.aspx");

            }
            else
            {
                try
                {


                    oUser = oUserDAO.RetrieveUserByUserID(UserCookie.Value);
                    oFee = oUserDAO.RetrieveFeebyUserID(UserCookie.Value);
                    lbUser.Text = oUser.FullName;
                    txtAmount.Attributes.Add("onkeyup", "ErrorHandler();");
                    oAccount = oUserDAO.RetrieveAccount(UserCookie.Value);
                    lbCredit.Text = "| Balance: $" + string.Format("{0:0.00}", oAccount.Credit);
                     
                    if (oAccount.Active == false)
                    {
                        divCredit.Attributes.Add("style", "display:none");
                        lbCreditDenied.Text = "This account is not authorized to load debit/credit, for more information call 561-860-5276";
                    }
                    else
                    {
                        divCredit.Attributes.Add("style", "display:block");
                        lbCreditDenied.Text = "";
                    }
                    string fullName = oUser.FullName;
                    var names = fullName.Split(' ');
                    string firstName = names[0];
                    string lastName = txtLastNameUser.Text;
                    if (fullName.Contains(" "))
                    {
                        lastName = names[1];
                    }

                    if (!Page.IsPostBack)
                    {
                        txtFirstNameUser.Text = firstName;
                        txtLastNameUser.Text = lastName;
                        txtPhoneNumber.Text = oUser.PhoneNumber;
                        txtEmail.Text = oUser.Email;
                        txtBusinessName.Text = oUser.BusinessName;
                        txtBusinessAddress.Text = oUser.BusinessAddress;
                        txtBusinessCity.Text = oUser.City;
                        ddBusinessState.SelectedItem.Text = oUser.State;
                        txtBusinessZip.Text = oUser.Zip;
                        ddFee.SelectedItem.Text = oFee.Fee;
                        txtResale.Text = oUser.ResaleCert;
                        txtEIN.Text = oUser.EIN;

                    }
                    DataTable dt = new DataTable();
                    BindGrid(dt, oUser.Post);

                    oUsercc = oUserDAO.RetrieveUserCC(UserCookie.Value);
                    if(!IsPostBack)
                    {
                        if (oUsercc.FirstName != null && oUsercc.Active != false)
                        {
                            btnUserCC.Visible = true;
                            txtFirstName.Text = oUsercc.FirstName;
                            txtLastName.Text = oUsercc.LastName;
                            txtAddress.Text = oUsercc.Address;
                            txtCity.Text = oUsercc.City;
                            ddState.SelectedValue = oUsercc.State;
                            txtZip.Text = oUsercc.ZIP;
                            thecc =  DAO.Decrypt(oUsercc.CCNumber, ConfigurationManager.AppSettings["encryptionKey"]);                       
                            txtCC.Text = string.Format("************{0}", thecc.Trim().Substring(12, 4));
                            txtExpDate.Text = oUsercc.ExpDate;
                            txtCVV.Text = oUsercc.CVV;

                            chkCC.Checked = oUsercc.Active;
                        

                        }
                        else
                        {
                            btnUserCC.Visible = false;
                        }
                    }
                    
                    
                }
                catch (Exception ex)
                {
                    Response.Redirect("login.aspx");
                }
            }
        }

        private void BindGrid(DataTable dt, string post)

        {
            DataTable dtCount = new DataTable();
            List<MetroFastPayLibrary.Account> aList = new List<MetroFastPayLibrary.Account>();
            aList = new List<MetroFastPayLibrary.Account>();

            aList = oUserDAO.PopulateAccountTransactionByPost(post);

            dtCount = new DataTable();
            dt.Columns.AddRange(new DataColumn[3] {new DataColumn("Amount"), new DataColumn("TransactionID"), new DataColumn("Date Added") });
            foreach (MetroFastPayLibrary.Account oAccount in aList)
            {

                dt.Rows.Add(string.Format("{0:0.00}", Convert.ToDecimal(oAccount.Amount)), oAccount.TransactionID, oAccount.CreatedDate);

            }
            if (aList.Count == 0)
            {
                divTrans.Attributes.Add("style", "display:none");
            }
            gvTrans.DataSource = dt;
            gvTrans.DataBind();
        }
        //protected void Chk_Click(object sender, System.EventArgs e)
        //{
        //    if (!Page.IsPostBack)
        //    {
        //        if (chkCC.Checked)
        //            {
        //                if(txtCC.Text !="")
        //                {
        //                    oUserDAO.InsertUserCC(UserCookie.Value, txtFirstName.Text, txtLastName.Text, txtCity.Text, ddState.SelectedItem.Value, txtAddress.Text, txtZip.Text, DAO.Encrypt(txtCC.Text, ConfigurationManager.AppSettings["encryptionKey"]), txtExpDate.Text, txtCVV.Text, true);
        //                }
                   
        //            }
        //            else
        //            {
        //            oUserDAO.InsertUserCC(UserCookie.Value, txtFirstName.Text, txtLastName.Text, txtCity.Text, ddState.SelectedItem.Value, txtAddress.Text, txtZip.Text, DAO.Encrypt(txtCC.Text, ConfigurationManager.AppSettings["encryptionKey"]), txtExpDate.Text, txtCVV.Text, false);

        //            txtFirstName.Text = "";
        //            txtLastName.Text = "";
        //            txtAddress.Text = "";
        //            txtCity.Text = "";
        //            ddState.SelectedValue = "State";
        //            txtZip.Text = "";
        //            txtCC.Text = "";
        //            txtExpDate.Text = "";
        //            txtCVV.Text = "";
        //        }          
        //    }
               

           

        //}
        protected void CC2_Click(object sender, System.EventArgs e)
        {
            if (txtFirstName.Text == "" || txtLastName.Text == "" || txtAddress.Text == "" || txtCity.Text == "" || txtZip.Text == "" || txtCC.Text == "" || txtExpDate.Text == "" || txtAmount.Text == "" || ddState.SelectedItem.Value == "State")
            {
                lblAuthNetCode.Text = "All fields have to be filled out";
                txtAmount.Text = "";
            }
            else
            {

                if (txtCC.Text.Length == 16)
                {

                    if (txtCC.Text.Contains("*") && thecc != null)
                    {
                      AuthorizePayment(txtFirstName.Text, txtLastName.Text, txtAddress.Text, txtCity.Text, ddState.SelectedItem.Value, txtZip.Text, "USA", Convert.ToDouble(txtAmount.Text), thecc, txtExpDate.Text, txtCVV.Text);
                    }
                    else
                    {
                       AuthorizePayment(txtFirstName.Text, txtLastName.Text, txtAddress.Text, txtCity.Text, ddState.SelectedItem.Value, txtZip.Text, "USA", Convert.ToDouble(txtAmount.Text), txtCC.Text, txtExpDate.Text, txtCVV.Text);
                    }

                    if (chkCC.Checked)
                    {
                        if (oUsercc.FirstName != null)
                        {
                            oUserDAO.UpdateUserCC(UserCookie.Value, txtFirstName.Text, txtLastName.Text, txtAddress.Text, txtCity.Text, ddState.SelectedItem.Value, txtZip.Text, DAO.Encrypt(thecc, ConfigurationManager.AppSettings["encryptionKey"]), txtExpDate.Text, txtCVV.Text, true);
                        }
                        else
                        {
                            oUserDAO.InsertUserCC(UserCookie.Value, txtFirstName.Text, txtLastName.Text, txtCity.Text, ddState.SelectedItem.Value, txtAddress.Text, txtZip.Text, DAO.Encrypt(txtCC.Text, ConfigurationManager.AppSettings["encryptionKey"]), txtExpDate.Text, txtCVV.Text, true);

                            ////send text msg
                            //MailMessage message = new MailMessage();
                            //SmtpClient smtpClient = new SmtpClient();
                            //string msg = string.Empty;

                            //MailAddress fromAddress = new MailAddress("info@telbug.com", "TelBug");
                            //const string SERVER = "smtp.gmail.com";
                            //MailMessage oMail = new System.Net.Mail.MailMessage();
                            //oMail.From = fromAddress;
                            //oMail.To.Add("5612012168@mymetropcs.com, 5616674346@mymetropcs.com");
                            //oMail.Subject = "Telbug credit added";
                            //oMail.IsBodyHtml = true;
                            //oMail.Body = UserCookie.Value + " enrolled into automatic recharge";
                            //smtpClient.Host = SERVER;
                            //smtpClient.Port = 587;
                            //smtpClient.Credentials = new System.Net.NetworkCredential(DAO.Decrypt(ConfigurationManager.AppSettings["Email"], ConfigurationManager.AppSettings["encryptionKey"]), DAO.Decrypt(ConfigurationManager.AppSettings["pass"], ConfigurationManager.AppSettings["encryptionKey"]));
                            //smtpClient.EnableSsl = true;
                            //smtpClient.Send(oMail);
                            //oMail = null;// free up resources

                            TextAndEmail("Telbug credit added", UserCookie.Value + " enrolled into automatic recharge", true);

                            btnUserCC.Visible = true;
                        }
                        
                    }
                    else
                    {
                        oUserDAO.DeleteUserCC(UserCookie.Value);


                        txtCC.Text = "";
                    }

                    oAccount = oUserDAO.RetrieveAccount(UserCookie.Value);
                    lbCredit.Text = oAccount.Credit.ToString();
                }
                else
                {
                    lblAuthNetCode.Text = "Credit card field needs to be 16 digits";
                }
            }
        }

        public void TextAndEmail(string subject, string body, bool textBraley)
        {
            try
            {


                var accountSid = "ACf68d6c4ff981f1ff8962f266f81ced48";
                var authToken = "6550fa15290f0b119b3a4ab7466200f9";

                TwilioClient.Init(accountSid, authToken);

                if (textBraley == true)
                {
                    var message = MessageResource.Create(
                   from: new Twilio.Types.PhoneNumber("+15612204243"),
                   body: subject + " - " + body,
                   to: new Twilio.Types.PhoneNumber("5616674346"));
                }


                var message2 = MessageResource.Create(
                    from: new Twilio.Types.PhoneNumber("+15612204243"),
                    body: subject + " - " + body,
                    to: new Twilio.Types.PhoneNumber("5612012168")
                );
            }
            catch (Exception ex)
            {
                oUserDAO.LogError("Portal TexT Error", "5616674346", "0", "Twilio Emails are failing, fix asap Braley");
            }


        }
        private bool AuthorizePayment(string FirstName, string LastName, string Address, string City, string State, string ZIP, string Country, double Amount, string CC, string expDate, string CCV)
        {
            //get card type (debit or credit)
            ServicePointManager.Expect100Continue = true;
            ServicePointManager.DefaultConnectionLimit = 9999;
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12 | SecurityProtocolType.Ssl3;
            string cardFirstEight = CC.Remove(8);
            var client = new RestClient("https://lookup.binlist.net/" + cardFirstEight);
            var request = new RestRequest(Method.POST);
            IRestResponse response = client.Execute(request);
            string CardType = "";
            string mycontent = response.Content;
            if (mycontent.Contains("number"))
            {
                CardType = getBetween(mycontent, "type\":\"", "\",\"brand\"");
                //if (CardType == "debit")
                //{
                //    //card is debit good to go
                //}
                //else
                //{
                //    lblAuthNetCode.ForeColor = Color.Red;
                //    lblAuthNetCode.Text = "Card must be a debit card.";
                //    return false;
                //}

            }
            else
            {
                lblAuthNetCode.ForeColor = Color.Red;
                lblAuthNetCode.Text = "Please call 561-860-5276, an issue occured.";
                return false;
            }


            string AuthNetVersion = "3.1"; // Contains CCV support
            string AuthNetLoginID = ConfigurationManager.AppSettings["AuthNetLoginID"];
            //string AuthNetPassword = DAO.Decrypt(ConfigurationManager.AppSettings["AuthNetPassword"], true);
            // Get this from your authorize.net merchant interface
            string AuthNetTransKey = DAO.Decrypt(ConfigurationManager.AppSettings["AuthNetTransKey"], ConfigurationManager.AppSettings["encryptionKey"]);

            WebClient objRequest = new WebClient();
            System.Collections.Specialized.NameValueCollection objInf = new System.Collections.Specialized.NameValueCollection(30);
            System.Collections.Specialized.NameValueCollection objRetInf = new System.Collections.Specialized.NameValueCollection(30);
            byte[] objRetBytes;
            string[] objRetVals;
            string strError;

            objInf.Add("x_version", AuthNetVersion);
            objInf.Add("x_delim_data", "True");
            objInf.Add("x_login", AuthNetLoginID);
            //objInf.Add("x_password", AuthNetPassword);
            objInf.Add("x_tran_key", AuthNetTransKey);
            objInf.Add("x_relay_response", "True");

            // Switch this to False once you go live
            objInf.Add("x_test_request", "False");

            objInf.Add("x_delim_char", ",");
            objInf.Add("x_encap_char", "|");

            // Billing Address
            objInf.Add("x_first_name", FirstName);
            objInf.Add("x_last_name", LastName);
            objInf.Add("x_address", Address);
            objInf.Add("x_city", City);
            objInf.Add("x_state", State);
            objInf.Add("x_zip", ZIP);
            objInf.Add("x_country", Country);

            objInf.Add("x_description", "Adding value in telbug");

            // Card Details
            objInf.Add("x_card_num", CC);
            objInf.Add("x_exp_date", expDate.Trim());

            // Authorisation code of the card (CCV)
            objInf.Add("x_card_code", CCV.Trim());

            objInf.Add("x_method", "CC");
            objInf.Add("x_type", "AUTH_CAPTURE");

            double fee;
            double totalAmount;
            if (CardType == "debit")
            {
                totalAmount = Amount;
            }
            else
            {
                 fee = Amount * .02;
                 totalAmount = Amount + fee;
            }
                 var amountOfRechage = String.Format("{0:0.00}", totalAmount.ToString());
            objInf.Add("x_amount", amountOfRechage);

            // Currency setting. Check the guide for other supported currencies
            objInf.Add("x_currency_code", "USD");

            try
            {
                // Pure Test Server
                //objRequest.BaseAddress = "https://test.authorize.net/gateway/transact.dll";

                // Actual Server
                //(uncomment the following line and also set above Testmode=off to go live)
                objRequest.BaseAddress = "https://secure2.authorize.net/gateway/transact.dll";

                objRetBytes =
                  objRequest.UploadValues(objRequest.BaseAddress, "POST", objInf);
                objRetVals =
                  System.Text.Encoding.ASCII.GetString(objRetBytes).Split(",".ToCharArray());

                if (objRetVals[0].Trim(char.Parse("|")) == "1" || Convert.ToInt32(objRetVals[6].Trim(char.Parse("|"))) > 9)
                {
                    // Returned Authorisation Code

                    this.lblAuthNetCode.Text = "";
                    // Returned Transaction ID
                    this.lblAuthNetTransID.Text = "You Transaction ID is " + objRetVals[6].Trim(char.Parse("|"));

                    //update credit line
                    oUserDAO.InsertCredit(oUser.UserID, oUser.Post, objRetVals[6].Trim(char.Parse("|")), Convert.ToDecimal(txtAmount.Text));
                    oAccount = oUserDAO.RetrieveAccount(UserCookie.Value);
                    oUserDAO.UpdateAccountbyPost(oAccount.Credit + Convert.ToDecimal(txtAmount.Text), oUser.Post);


                    DataTable dt = new DataTable();
                    BindGrid(dt, oUser.Post);

                    //MailMessage message = new MailMessage();
                    //SmtpClient smtpClient = new SmtpClient();
                    //string msg = string.Empty;

                    //MailAddress fromAddress = new MailAddress("info@telbug.com", "TelBug");
                    //const string SERVER = "smtp.gmail.com";
                    //MailMessage oMail = new System.Net.Mail.MailMessage();
                    //oMail.From = fromAddress;
                    //oMail.To.Add("5612012168@mymetropcs.com, 5616674346@mymetropcs.com");
                    //oMail.Subject = "Telbug credit added";
                    //oMail.IsBodyHtml = true;
                    //oMail.Body = UserCookie.Value + " added $" + txtAmount.Text + " to their account.";
                    //smtpClient.Host = SERVER;
                    //smtpClient.Port = 587;
                    //smtpClient.Credentials = new System.Net.NetworkCredential(DAO.Decrypt(ConfigurationManager.AppSettings["Email"], ConfigurationManager.AppSettings["encryptionKey"]), DAO.Decrypt(ConfigurationManager.AppSettings["pass"], ConfigurationManager.AppSettings["encryptionKey"]));
                    //smtpClient.EnableSsl = true;
                    //smtpClient.Send(oMail);
                    //oMail = null;// free up resources

                    TextAndEmail("Telbug credit added", UserCookie.Value + " added $" + txtAmount.Text + " to their account.", true);

                    txtAmount.Text = "";


                    return true;
                }
                else
                {
                    // Error!
                    strError = objRetVals[3].Trim(char.Parse("|")) + " (" +
                      objRetVals[2].Trim(char.Parse("|")) + ")";

                    if (objRetVals[2].Trim(char.Parse("|")) == "44")
                    {
                        // CCV transaction decline
                        strError += "Our Card Code Verification (CCV) returned " +
                          "the following error: ";

                        switch (objRetVals[38].Trim(char.Parse("|")))
                        {
                            case "N":
                                strError += "Card Code does not match.";
                                break;
                            case "P":
                                strError += "Card Code was not processed.";
                                break;
                            case "S":
                                strError += "Card Code should be on card but was not indicated.";
                                break;
                            case "U":
                                strError += "Issuer was not certified for Card Code.";
                                break;
                        }
                    }

                    if (objRetVals[2].Trim(char.Parse("|")) == "45")
                    {
                        if (strError.Length > 1)
                            strError += "<br />n";

                        // AVS transaction decline
                        strError += "Our Address Verification System (AVS) " +
                          "returned the following error: ";

                        switch (objRetVals[5].Trim(char.Parse("|")))
                        {
                            case "A":
                                strError += " the zip code entered does not match " +
                                  "the billing address.";
                                break;
                            case "B":
                                strError += " no information was provided for the AVS check.";
                                break;
                            case "E":
                                strError += " a general error occurred in the AVS system.";
                                break;
                            case "G":
                                strError += " the credit card was issued by a non-US bank.";
                                break;
                            case "N":
                                strError += " neither the entered street address nor zip " +
                                  "code matches the billing address.";
                                break;
                            case "P":
                                strError += " AVS is not applicable for this transaction.";
                                break;
                            case "R":
                                strError += " please retry the transaction; the AVS system " +
                                  "was unavailable or timed out.";
                                break;
                            case "S":
                                strError += " the AVS service is not supported by your " +
                                  "credit card issuer.";
                                break;
                            case "U":
                                strError += " address information is unavailable for the " +
                                  "credit card.";
                                break;
                            case "W":
                                strError += " the 9 digit zip code matches, but the " +
                                  "street address does not.";
                                break;
                            case "Z":
                                strError += " the zip code matches, but the address does not.";
                                break;
                        }
                    }

                    // strError contains the actual error

                    txtAmount.Text = "";
                    if (strError.Contains("Int32"))
                    {
                        lblAuthNetCode.Text = "ENG: The address associated with the card is incorrect | SPN: La dirección asociada a la tarjeta es incorrecta.";
                    }
                    else
                    {
                        lblAuthNetCode.Text = strError;
                    }

                    return true;
                }
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("Int32"))
                {
                    lblAuthNetCode.Text = "ENG: The address associated with the card is incorrect | SPN: La dirección asociada a la tarjeta es incorrecta.";
                }
                else
                {
                    lblAuthNetCode.Text = ex.Message;
                }
                
                return false;
            }
        }

        protected void Update_Click(object sender, System.EventArgs e)
        {
            try
            {

                oUserDAO.UpdateUser(UserCookie.Value, txtFirstNameUser.Text + " " + txtLastNameUser.Text, txtPhoneNumber.Text, txtEmail.Text, txtBusinessName.Text, txtBusinessAddress.Text, true, txtBusinessCity.Text, ddBusinessState.SelectedItem.Text, txtBusinessZip.Text, txtResale.Text, txtEIN.Text);

                oUserDAO.UpdateFee(ddFee.SelectedItem.Text, UserCookie.Value);

                lbDesc.Text = "Account has been updated!";


            }
            catch (Exception ex)
            {
                lbDesc.ForeColor = Color.Red;
                lbDesc.Text = ex.Message;
            }
        }
        protected void DeleteuserCC_Click(object sender, System.EventArgs e)
        {
            try
            {

                oUserDAO.DeleteUserCC(UserCookie.Value);
                btnUserCC.Visible = false;
                lbInfo.ForeColor = Color.Green;
                lbInfo.Text = "Your card has been removed from the system.";

                txtFirstName.Text = "";
                txtLastName.Text = "";
                txtAddress.Text = "";
                txtCity.Text = "";
                ddState.SelectedValue = "State";
                txtZip.Text = "";
                txtCC.Text = "";
                txtExpDate.Text = "";
                txtCVV.Text = "";
                txtAmount.Text = "";
                chkCC.Checked = false;


            }
            catch (Exception ex)
            {
                lbDesc.ForeColor = Color.Red;
                lbDesc.Text = ex.Message;
            }
        }

        public static string getBetween(string strSource, string strStart, string strEnd)
        {
            int Start, End;
            if (strSource.Contains(strStart) && strSource.Contains(strEnd))
            {
                Start = strSource.IndexOf(strStart, 0) + strStart.Length;
                End = strSource.IndexOf(strEnd, Start);
                return strSource.Substring(Start, End - Start);
            }
            else
            {
                return "";
            }
        }
        protected void LogOut_Click(object sender, System.EventArgs e)
        {
            try
            {
                Session.Abandon();

                System.Web.HttpCookie UserCookie = new System.Web.HttpCookie("UserNameCookie");
                UserCookie.Expires = DateTime.Now.AddYears(-1);
                Response.Cookies.Add(UserCookie);
                Response.Redirect("login.aspx");
            }
            catch
            {
            }
        }
    }
}