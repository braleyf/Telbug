﻿using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Security.Principal;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.AspNet.Identity;
using System.Net.Mail;
using System.Configuration;
using System.Web.UI.HtmlControls;
using System.Drawing;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using System.Net;
using MetroFastPayLibrary;
using System.Text;
using System.Security.Cryptography;
using System.Runtime.InteropServices;
using System.ComponentModel;
using System.Web.Services;
using System.Diagnostics;
using System.Management.Automation;
using System.Net.Http;
using System.Threading.Tasks;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using RestSharp;
using MetroFastPay.com.dollarphone.www;
using System.Security.Policy;
using Twilio;
using Twilio.Rest.Api.V2010.Account;

namespace MetroFastPay
{
    class ResourceBalanceInfo
    {
        public string status_code { get; set; }
        public string domestic_credit { get; set; }
        public string international_credit { get; set; }
    }
    public partial class TextSMS : System.Web.UI.Page
    {
        User oUser = new User();
        UserDAO oUserDAO = new UserDAO();
        System.Web.HttpCookie UserCookie = HttpContext.Current.Request.Cookies["UserNameCookie"];
        System.Web.HttpCookie GuatePinUserCookie = HttpContext.Current.Request.Cookies["GuatePinUser"];
        private HttpClient _Client = new HttpClient();
        string dbCon = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
        protected async void Page_Load(object sender, EventArgs e)
        {
            if (Request.Cookies["UserNameCookie"] == null)
            {
                System.Web.HttpCookie UserCookie = HttpContext.Current.Request.Cookies["UserNameCookie"];
                Session.Abandon();
                UserCookie.Expires = DateTime.Now.AddYears(-1);
                Response.Cookies.Add(UserCookie);
                Response.Redirect("login.aspx");
            }
            else
            {
                try
                {
                   // await getSSBalance();
                }
                catch (Exception ex)
                {
                    Response.Redirect("login.aspx");
                }

            }
        }
        protected void cboUserFilter_OnSelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (Request.Cookies["UserNameCookie"] == null)
                {
                    Response.Redirect("login.aspx");
                }
                //DataTable dt = new DataTable();
                //BindGrid(dt, ddPost.SelectedItem.Value);
            }
            catch (Exception ex)
            {
                Response.Redirect("login.aspx");
            }
        }
        protected void cboProviderFilter_OnSelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (Request.Cookies["UserNameCookie"] == null)
                {
                    Response.Redirect("login.aspx");
                }
                lbinfo.ForeColor = Color.DarkBlue;
                lbinfo.Text = getNumberCount(ddUser.SelectedItem.Value, ddProvider.SelectedItem.Value).ToString() + " phone numbers for " + ddProvider.SelectedItem.Value;
                //if(ddProvider.SelectedIndex == 0)
                //{
                //    btnSendText.Enabled = false;
                //}
                //else
                //{
                    btnSendText.Enabled = true;
                //}
                if(txtFrom.Text.Length != 0 && txtTo.Text.Length != 0)
                {
                    lbinfo.Text = getNumberCount(ddUser.SelectedItem.Value, ddProvider.SelectedItem.Value).ToString() + " phone numbers for " + ddProvider.SelectedItem.Value;
                }
                    
            }
            catch (Exception ex)
            {
                Response.Redirect("login.aspx");
            }
        }
        public decimal getNumberCount(string user, string provider)
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                if (txtFrom.Text.Length == 0 && txtTo.Text.Length == 0)
                {
                    cmd.CommandText = @"select count(distinct phonenumber) from payments where userid ='" + user + "' and provider like '%" + provider + "%'";
                }
                else if(provider != "--Select Provider--")
                {
                    cmd.CommandText = @"select count(distinct phonenumber) from payments where userid ='" + user + "' and provider like '%" + provider + "%' and createddate between '" + txtFrom.Text + "' and  DATEADD(DAY, 1, '" + txtTo.Text + "' )";
                }
                else
                {
                    cmd.CommandText = @"select count(distinct phonenumber) from payments where userid ='" + user + "' and createddate between '" + txtFrom.Text + "' and  DATEADD(DAY, 1, '" + txtTo.Text + "' )";
                }

            
                decimal Num = Convert.ToDecimal(cmd.ExecuteScalar());
                conn.Dispose();
                conn.Close();
                return Num;

            }

        }
        public decimal getNumber(string user, string provider)
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                if (txtFrom.Text.Length == 0 && txtTo.Text.Length == 0)
                {
                    cmd.CommandText = @"select distinct phonenumber from payments where userid ='" + user + "' and provider like '%" + provider + "%'";
                }
                else
                {
                    cmd.CommandText = @"select distinct phonenumber from payments where userid ='" + user + "' and provider like '%" + provider + "%' and createddate between '" + txtFrom.Text + "' and  DATEADD(DAY, 1, '" + txtTo.Text + "' )";
                }

                decimal Num = Convert.ToDecimal(cmd.ExecuteScalar());
                conn.Dispose();
                conn.Close();
                return Num;

            }

        }
        protected async void SendSMS_Click(object sender, System.EventArgs e)
        {
            try
            {
                    if (txtBody.InnerText != "")
                    {
                     decimal num = getNumberCount(ddUser.SelectedItem.Value, ddProvider.SelectedItem.Value);

                    Payment oPayment = new Payment();
                    List<Payment> oList = new List<Payment>();

                    using (SqlConnection con = new SqlConnection(DAO.sDBConn))
                    {
                        using (SqlCommand cmd = new SqlCommand("select distinct phonenumber from payments where userid ='" + ddUser.SelectedItem.Value + "' and provider like '%" + ddProvider.SelectedItem.Value + "%' and createddate between '" + txtFrom.Text + "' and  DATEADD(DAY, 1, '" + txtTo.Text + "' )", con))
                        {
                            con.Open();
                            using (SqlDataReader rdr = cmd.ExecuteReader())
                            {

                                while (rdr.Read())
                                {
                                    oPayment.PhoneNumber = rdr["PhoneNumber"].ToString();
                                    if (oPayment.PhoneNumber != "" | oPayment.PhoneNumber != null)
                                    {
                                        await sendShortCodes(oPayment.PhoneNumber, txtBody.Value);
                                    }
                                    
                                }
                                rdr.Close();

                            }
                        }
                        con.Dispose();
                        con.Close();
                    }

                    lbinfo.ForeColor = Color.Green;
                    lbinfo.Text = "Sent all " + num + " messages";
                
                    btnSendText.Enabled = false;
                    //await getSSBalance();
                }
                else
                {
                    lbinfo.ForeColor = Color.Red;
                    lbinfo.Text = "Body cannot be empty";
                }
               
            }
            catch (Exception ex)
            {
                lbinfo.ForeColor = Color.Red;
                lbinfo.Text = ex.Message;
            }
        }
        async Task sendShortCodes(string number, string body)
        {

            var accountSid = "ACf68d6c4ff981f1ff8962f266f81ced48";
            var authToken = "6550fa15290f0b119b3a4ab7466200f9";

            TwilioClient.Init(accountSid, authToken);

            var message = MessageResource.Create(
                from: new Twilio.Types.PhoneNumber("+15612204243"),
                body: body,
                to: new Twilio.Types.PhoneNumber(number)
            );
        }
        async Task getSSBalance()
        {

            ServicePointManager.Expect100Continue = true;
            using (var client = new HttpClient())
            {
                var apikey = "e4d74191b6211d1fc9167ab0b921cc5f";

                client.BaseAddress = new Uri("http://api.trumpia.com");
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Add("X-Apikey", string.Format("{0}", apikey));

                var username = "fnfweb87";

                //GET
                HttpResponseMessage response = await client.GetAsync(string.Format("/rest/v1/{0}/balance/credit", username));
                if (response.IsSuccessStatusCode)
                {
                    ResourceBalanceInfo resourceBalanceInfo = await response.Content.ReadAsAsync<ResourceBalanceInfo>();
                    string json = JsonConvert.SerializeObject(resourceBalanceInfo);
                    lbCredit.Text = " Credit:" + resourceBalanceInfo.domestic_credit;
                    Console.WriteLine(json);
                }
            }
        }
        protected void Reset_Click(object sender, System.EventArgs e)
        {
            ddProvider.SelectedIndex = 0;
            ddUser.SelectedIndex = 0;
            txtFrom.Text = "";
            txtTo.Text = "";
            lbinfo.Text = "";
            btnSendText.Enabled = false;
        }
    }
}