﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MetroFastPayLibrary;
using System.Text;
using RestSharp;
using MetroFastPay.com.dollarphone.www;
using System.Configuration;
using System.Net.Http;
using System.Threading.Tasks;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using System.Net;

namespace MetroFastPay
{

   
    public partial class SinPinBalance : System.Web.UI.Page
    {
        User oUser = new User();
        UserDAO oUserDAO = new UserDAO();
        System.Web.HttpCookie UserCookie = HttpContext.Current.Request.Cookies["UserNameCookie"];
        private HttpClient _Client = new HttpClient();
        [Serializable]
        public class RetievePin
        {

            public RetievePin()
            {

                idField = "mdn";

            }

            public string idField { get; set; }
            public string pin { get; set; }
            public string scope { get; set; }

        }
        protected async void Page_Load(object sender, EventArgs e)
        {

            if (Request.Cookies["UserNameCookie"] == null)
            {
                //Session.Abandon();
                //UserCookie.Expires = DateTime.Now.AddYears(-1);
                //Response.Cookies.Add(UserCookie);
                Response.Redirect("out.aspx");

            }
            else
            {
                if (Request.Url.ToString().Contains("DP"))
                {
                    using (PinManager pm = new PinManager())
                    {
                        pm.Credentials = new System.Net.NetworkCredential(ConfigurationManager.AppSettings["dpUser"], ConfigurationManager.AppSettings["dpPass"]);
                        string prefix = Request.QueryString["DP"];
                        prefix = prefix.Replace("(", "");
                        prefix = prefix.Replace(")", "");
                        prefix = prefix.Replace("-", "");

                        string dpBalance = pm.GetAccountInfoByAniOffering(prefix, 30030280).Balance.ToString();
                        lbBalance.Text = string.Format("{0:0.00}", dpBalance).Trim();
                    }

                }
                else if (Request.Url.ToString().Contains("GuatePin"))
                {
                    using (PinManager pm = new PinManager())
                    {
                        pm.Credentials = new System.Net.NetworkCredential(ConfigurationManager.AppSettings["dpUser"], ConfigurationManager.AppSettings["dpPass"]);
                        string prefix = Request.QueryString["GuatePin"];
                        prefix = prefix.Replace("(", "");
                        prefix = prefix.Replace(")", "");
                        prefix = prefix.Replace("-", "");


                        string dpBalance = pm.GetAccountInfoByAniOffering(prefix, 30178480).Balance.ToString();
                        lbBalance.Text = string.Format("{0:0.00}", dpBalance).Trim();
                    }
                }
                //else if (Request.Url.ToString().Contains("ReupBalance"))
                //{
                //    _Client = new HttpClient();
                //    _Client.BaseAddress = new Uri("https://api.reupmobile.com/");
                //    _Client.DefaultRequestHeaders.Accept.Clear();
                //    _Client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(System.Text.ASCIIEncoding.ASCII.GetBytes(string.Format("{0}:{1}", "ffweb-api-user", "c@tczy4q6Ox4x9V0zpm7UV"))));
                //    _Client.DefaultRequestHeaders.Add("dealer-id", "39881");
                //    _Client.DefaultRequestHeaders.Add("ContentType", "application/json");

                //    var response = await _Client.GetAsync("https://api.reupmobile.com/api/query/balances");
                //    HttpContent content = response.Content;
                //    string mycontent3 = await content.ReadAsStringAsync();
                //    if (response.IsSuccessStatusCode)
                //    {

                //        lbBalance.Text = getBetween(mycontent3.ToString(), "\"airtimeBalance\":\"", "\",\"spiffBalance\"");
                //    }
                //}
                else if (Request.Url.ToString().Contains("boost"))
                {
                    if(Request.QueryString["Boost"].ToString() != null)
                    {
                        //await GetBoostViewState();
                        GetBoostPin(Request.QueryString["Boost"].ToString());
                    }
                }
                else
                {
                    if (Request.QueryString["phone"].ToString() != null)
                    {
                        System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls12;
                        string url = "https://webservice.sinpin.com/Agent/accountbalance/?Username=fandf.webapi&Password=Marcos2168!PB_561*!&apiKey=9e8roNDqY4Ssx6A607TxwYoJI0y246Ph&PHONE=" + Request.QueryString["phone"].ToString();
                        var client = new RestClient(url);
                        var request = new RestRequest(Method.POST);
                        IRestResponse response = client.Execute(request);
                        lbBalance.Text = string.Format("{0:0.00}", response.Content);

                        if (response.Content.Contains("Success"))
                        {
                            lbBalance.Text = string.Format("{0:0.00}", response.Content);

                        }

                        else
                        {
                            lbBalance.Text = string.Format("{0:0.00}", response.Content);
                        }
                    }
                    
                }


            }
        }
        async Task GetBoostViewState()
        {
            try
            {
                System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;        
                var client = new RestClient("https://sales.prepaid.sprint.com/boost-sales-portal/faces/login.jsp");
                var request = new RestRequest(Method.POST);
                IRestResponse response = client.Execute(request);

                string mycontent = response.Content;
                if (mycontent.Contains("javax.faces.ViewState"))
                {
                    string ViewState = getBetween(mycontent, "javax.faces.ViewState", "autocomplete=");
                    string ViewState2 = getBetween(ViewState, "id=\"javax.faces.ViewState\" value=\"", "\" ");
                    await LogginToBoostPortal(ViewState2);
        

                }
                else
                {
                    lbBalance.ForeColor = System.Drawing.Color.Red;
                    lbBalance.Text = "Number is not correct | El número no es correcto";
                }
            }
            catch (Exception ex)
            {

                Response.Redirect("Error.aspx");
            }
        }
        async Task LogginToBoostPortal(string ViewState)
        {
            try
            {
                System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3;
                string url = "https://sales.prepaid.sprint.com/boost-sales-portal/faces/login.jsp?loginform=loginform&loginform:USER=goldenwireless6&loginform:PASSWORD=Boostmobile7731&loginform:Login=SIGN+IN&javax.faces.ViewState=" + ViewState;
                var client = new RestClient(url);
                var request = new RestRequest(Method.POST);
                request.AddHeader("postman-token", "8da2cb14-7840-4802-3c4d-2115c8d7192d");
                request.AddHeader("cache-control", "no-cache");
                IRestResponse response = client.Execute(request);

                string mycontent = response.Content;
                if (mycontent.Contains("PASSWORD"))
                {
                    lbBalance.ForeColor = System.Drawing.Color.Green;
                    lbBalance.Text = "Text sent to customer | Texto enviado al cliente";

                }
                else
                {
                    //await GetBoostViewState();
                }
            }
            catch (Exception ex)
            {

                Response.Redirect("Error.aspx");
            }
        }
       public void GetBoostPin(string number)
        {
            try
            {
                var client = new RestClient("http://orqclasea.com/api/products/SendPin/"+number+"");
                var request = new RestRequest(Method.POST);
                request.AddHeader("postman-token", "6a10c15f-3fa8-401e-2224-7fe96eb29ef8");
                request.AddHeader("cache-control", "no-cache");
                IRestResponse response = client.Execute(request);

                string mycontent = response.Content;
                lbBalance.Text = "Error: call 5618605276";
                if (mycontent.Length > 0)
                {
                    lbBalance.Text = mycontent;
                    if (mycontent.Contains("PIN sent"))
                    {
                        lbBalance.ForeColor = System.Drawing.Color.Green;
                    }
                    else
                    {
                        lbBalance.ForeColor = System.Drawing.Color.Red;
                    }
                }
                }
                
            catch (Exception ex)
            {

                Response.Redirect("Error.aspx");
            }
        }
        public static string getBetween(string strSource, string strStart, string strEnd)
        {
            int Start, End;
            if (strSource.Contains(strStart) && strSource.Contains(strEnd))
            {
                Start = strSource.IndexOf(strStart, 0) + strStart.Length;
                End = strSource.IndexOf(strEnd, Start);
                return strSource.Substring(Start, End - Start);
            }
            else
            {
                return "";
            }
        }
    }
    }
  
