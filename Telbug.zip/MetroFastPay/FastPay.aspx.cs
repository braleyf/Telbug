﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net.Mail;
using System.Configuration;
using System.Web.UI.HtmlControls;
using System.Drawing;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using System.Net;
using MetroFastPayLibrary;
using System.Text;
using System.Security.Cryptography;
using System.Web.Security;
using System.Security.Principal;
using System.Runtime.InteropServices;
using System.ComponentModel;
using System.Web.Services;
using System.Diagnostics;
using System.Management.Automation;
using System.Net.Http;
using System.Threading.Tasks;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using RestSharp;
using MetroFastPay.com.dollarphone.www;
using System.Threading;
using Twilio;
using Twilio.Rest.Api.V2010.Account;

namespace MetroFastPay
{

    public partial class FastPay : System.Web.UI.Page
    {
        User oUser = new User();
        UserDAO oUserDAO = new UserDAO();
        string dbCon = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
        bool MoneyWentThru;
        CC oCC = new CC();
        CC oCC2 = new CC();
        CC oCC3 = new CC();
        //int counter = 0;
        bool usesShortCode = false;
        System.Web.HttpCookie UserCookie = HttpContext.Current.Request.Cookies["UserNameCookie"];
        private HttpClient _Client = new HttpClient();
        MetroFastPayLibrary.MetroPCSSecurity oMetroPCSSecurity = new MetroFastPayLibrary.MetroPCSSecurity();
        [Serializable]
        public class CreditCardInfo
        {

            public CreditCardInfo(string Cricketcc, string Cricketcardname, string CricketcardExpirationDate, string CricketsecurityCode)
            {
                cardNumber = Cricketcc;
                cardName = Cricketcardname;
                cardExpirationDate = CricketcardExpirationDate;
                if (Cricketcc.StartsWith("5"))
                {
                    cardType = "MC";
                }
                else
                {
                    cardType = "VISA";
                }

                securityCode = CricketsecurityCode;
                paymentMethod = "CREDITCARD";
            }
            public string cardNumber { get; set; }
            public string cardName { get; set; }
            public string cardExpirationDate { get; set; }
            public string cardType { get; set; }
            public string securityCode { get; set; }
            public string paymentMethod { get; set; }
        }

        [Serializable]
        public class Data
        {
            public Data(string Cricketamount, string Cricketpostalcode, string Cricketctn, string Cricketcc, string Cricketcardname, string CricketcardExpirationDate, string CricketsecurityCode)
            {

                secureKey = "a697627915e1176cc642333d1f3b23f328a93ea64f1b8a3a82a7224c94e62f3a";
                amount = Cricketamount;
                postalCode = Cricketpostalcode;
                creditCardInfo = new CreditCardInfo(Cricketcc, Cricketcardname, CricketcardExpirationDate, CricketsecurityCode);
                ctn = Cricketctn;
                appId = "AMSS";

            }

            public string secureKey { get; set; }
            public string amount { get; set; }
            public string postalCode { get; set; }
            public CreditCardInfo creditCardInfo { get; set; }
            public string ctn { get; set; }
            public string appId { get; set; }
        }


        [Serializable]
        public class CreditCardInfoBoost
        {

            public CreditCardInfoBoost(string Boostcc, string Boostcardname, string BoostcardExpirationDate, string BoostsecurityCode)
            {
                adhoc = new adhoc(Boostcc, Boostcardname, BoostcardExpirationDate, BoostsecurityCode);
            }

            public adhoc adhoc { get; set; }

        }
        [Serializable]
        public class adhoc
        {

            public adhoc(string Boostcc, string Boostcardname, string BoostcardExpirationDate, string BoostsecurityCode)
            {
                cardNumber = Boostcc;
                expirationDate = BoostcardExpirationDate;
                cvv = BoostsecurityCode;
                name = Boostcardname;
                address = new BoostAddress();             
                if (Boostcc.StartsWith("5"))
                {
                    cardBrand = "MASTERCARD";
                }
                else
                {
                    cardBrand = "VISA";
                }
                cardType = "CREDIT";
            }
            public string cardNumber { get; set; }
            public string expirationDate { get; set; }
            public string cvv { get; set; }
            public string name { get; set; }
            public BoostAddress address { get; set; }
            public string cardBrand { get; set; }

            public string cardType { get; set; }



        }

        [Serializable]
        public class BoostAddress
        {


            public BoostAddress()
            {
                addressLine1 = "5047 Summit Blvd";
                addressLine2 = "";
                city = "West Palm Beach";
                state = "FL";
                zipCode = "33415";
                setAsMailingAddress = false;
            }

            public string addressLine1 { get; set; }
            public string addressLine2 { get; set; }
            public string city { get; set; }
            public string state { get; set; }
            public string zipCode { get; set; }
            public bool setAsMailingAddress { get; set; }

        }


        [Serializable]
        public class BoostautoPay
        {

            public BoostautoPay()
            {
                useForAutoPay = false;
            }

            public bool useForAutoPay { get; set; }


        }
        [Serializable]
        public class BoostData
        {

            public BoostData(double Boostamount, string Boostpostalcode, string Boostmnm, string Boostcc, string Boostcardname, string BoostcardExpirationDate, string BoostsecurityCode, string taxid)
            {

                idField = "mdn";
                creditCard = new CreditCardInfoBoost(Boostcc, Boostcardname, BoostcardExpirationDate, BoostsecurityCode);
                amount = Convert.ToDouble(Boostamount);
                isAuthenticated = true;
                taxAmount = 0.00;
                totalAmount = Convert.ToDouble(string.Format("{0:0.00}", Boostamount));
               // taxTxnId = taxid;
                registerCardUsedForPayment = false;
                autoPay = new BoostautoPay();
            }

            public string idField { get; set; }
            public CreditCardInfoBoost creditCard { get; set; }
            public double amount { get; set; }
            public bool isAuthenticated { get; set; }
            public double taxAmount { get; set; }
            public double totalAmount { get; set; }
            public string taxTxnId { get; set; }
            public bool registerCardUsedForPayment { get; set; }
            public BoostautoPay autoPay { get; set; }

        }
        [Serializable]
        public class BoostDataGift
        {

            public BoostDataGift(double Boostamount, string Boostpostalcode, string Boostmnm, string Boostcc, string Boostcardname, string BoostcardExpirationDate, string BoostsecurityCode)
            {

                idField = "mdn";
                creditCard = new CreditCardInfoBoost(Boostcc, Boostcardname, BoostcardExpirationDate, BoostsecurityCode);
                amount = Convert.ToDouble(Boostamount);
                isAuthenticated = true;
                totalAmount = Convert.ToDouble(string.Format("{0:0.00}", Boostamount));
                registerCardUsedForPayment = false;
                autoPay = new BoostautoPay();
            }

            public string idField { get; set; }
            public CreditCardInfoBoost creditCard { get; set; }
            public double amount { get; set; }
            public bool isAuthenticated { get; set; }
            public double totalAmount { get; set; }
            public bool registerCardUsedForPayment { get; set; }
            public BoostautoPay autoPay { get; set; }

        }
        [Serializable]
        public class getBoostLoginToken
        {

            public getBoostLoginToken(string number, string thepin)
            {

                mdn = number;
                pin = thepin;
                scope = "login_auth";

            }

            public string mdn { get; set; }
            public string pin { get; set; }
            public string scope { get; set; }

        }


        [Serializable]
        public class InternalDealerINFO
        {
            public InternalDealerINFO()
            {
                internalDealerId = "39881";
                dba = "Telbug";
                CompanyName = "Telbug";
                ContactName = "Marcos Fernandez";
                phone = "5618605276";
                email = "support@telbug.com";
            }
            public string internalDealerId { get; set; }
            public string dba { get; set; }
            public string CompanyName { get; set; }
            public string ContactName { get; set; }
            public string phone { get; set; }
            public string email { get; set; }


        }
        [Serializable]
        public class ReUpData
        {

            public ReUpData(int carrierid2, int planid2, string mdn2)
            {


                internalDealerInformation = new InternalDealerINFO();
                carrierid = carrierid2;
                planid = planid2;
                mdn = mdn2;

            }
            public InternalDealerINFO internalDealerInformation { get; set; }

            public int carrierid { get; set; }
            public int planid { get; set; }
            public string mdn { get; set; }

        }
        //public class Utilis
        //{
        //    public static IEnumerable<string> GetSequenceEntries(long maxValue)
        //    {
        //        yield return string.Empty;
        //        for(int i=0; i<=maxValue; i++)
        //        {
        //            if (i == 0)
        //            {
        //                yield return "Select Amount";
        //            }
        //            else
        //            {
        //                yield return i.ToString();
        //            }

        //        }
        //    }
        //}
        protected void Page_Load(object sender, EventArgs e)
        {
            //online users with no user name 
            if (Request.Url.ToString().Contains("?Online"))
            {
                oUserDAO.InsertIP("FastPay Online", GetIPAddress(), 0);
                System.Web.HttpCookie UserCookie = new System.Web.HttpCookie("UserNameCookie");
                UserCookie.Value = "FastPay Online";
                UserCookie.Expires = DateTime.Now.AddDays(1);
                Response.Cookies.Add(UserCookie);
            }
            else
            {
                if(UserCookie.Value == "FastPay Online")
                {
                    System.Web.HttpCookie UserCookie = HttpContext.Current.Request.Cookies["UserNameCookie"];
                    Session.Abandon();
                    UserCookie.Expires = DateTime.Now.AddYears(-1);
                    Response.Cookies.Add(UserCookie);
                    Response.Redirect("login.aspx");
                }
            }

            //users already logged in 
            if (Request.Cookies["UserNameCookie"] == null)
            {
                //Session.Abandon();
                //UserCookie.Expires = DateTime.Now.AddYears(-1);
                //Response.Cookies.Add(UserCookie);
                Response.Redirect("out.aspx");
            }
            else
            {
                try
                {
                    oUser = oUserDAO.RetrieveUserByUserID(UserCookie.Value);
                    lbUser.Text = oUser.FullName;
                    //ddAmount.SelectedIndex = 1;
                    //ddAmount.DataSource = Utilis.GetSequenceEntries(150);
                    //ddAmount.DataBind();

                    //for (int i = ddAmount.Items.Count - 1; i >= 2; i--)
                    //{
                    //        ddAmount.Items[i].Enabled = false;
                    //}



                    MetroFastPayLibrary.Account oAccount = new MetroFastPayLibrary.Account();
                    oAccount = oUserDAO.RetrieveAccount(UserCookie.Value);

                    User oFee = new User();
                    oFee = oUserDAO.RetrieveFeebyUserID(UserCookie.Value);


                    lbfee.Text = string.Format("{0:0.00}", Convert.ToDecimal(oFee.Fee));
                    hfFee.Value = string.Format("{0:0.00}", Convert.ToDecimal(oFee.Fee));
                    


                    //admin rights
                    if (oUser.UserType == "Admin")
                    {
                        lbControlPanel.Visible = true;
                        oUserDAO.RetrieveCC();
                    }
                    else
                    {
                        if (oAccount.Active == true)
                        {
                            lbControlPanel.Visible = false;
                            //ClientScript.RegisterStartupScript(this.GetType(), "alert", "EmailPopup();", true);
                        }

                    }

                    //announcement popup
                   // ClientScript.RegisterStartupScript(this.GetType(), "alert", "EmailPopup();", true);


                
                    //account is low popup
                    if (oAccount.Active == true)
                    {
                        lbAccount.Visible = true;
                        lbCredit.Text = "| Balance: $" + string.Format("{0:0.00}", oAccount.Credit);
                        //if (oAccount.Credit < 7)
                        //{
                        //    divButton.Attributes.Add("style", "display:none");
                        //    lbInfo.ForeColor = Color.Red;
                        //    lbInfo.Text = "Your Balance is: $" + string.Format("{0:0.00}", oAccount.Credit) +  " you do not have enough credit to make a payment. Please go to 'My Account' and add more funds";
                        //}

                        CC oUsercc = new CC();
                        oUsercc = oUserDAO.RetrieveUserCC(UserCookie.Value);

                        if (oAccount.Credit < 100)
                        {
                            if (oUsercc.FirstName != null && oUsercc.Active != false)
                            {
                                AuthorizePayment(oUsercc.FirstName, oUsercc.LastName, oUsercc.Address, oUsercc.City, oUsercc.State, oUsercc.ZIP, "USA", 100, DAO.Decrypt(oUsercc.CCNumber, ConfigurationManager.AppSettings["encryptionKey"]), oUsercc.ExpDate, oUsercc.CVV, "Automatically adding value in telbug", "Telbug credit added", " added $100 (Automatically) to their account.");
                            }
                            else
                            {
                                ClientScript.RegisterStartupScript(this.GetType(), "alert", "ShowPopup();", true);
                                lbAccountAmount.Text = string.Format("{0:0.00}", oAccount.Credit);
                                lbSpanishAccountAmount.Text = string.Format("{0:0.00}", oAccount.Credit);
                            }

                        }
                        if (oAccount.Credit < 100 && oUsercc.Active != false)
                        {
                            ClientScript.RegisterStartupScript(this.GetType(), "alert", "ShowPopup();", true);
                            lbAccountAmount.Text = string.Format("{0:0.00}", oAccount.Credit);
                            lbSpanishAccountAmount.Text = string.Format("{0:0.00}", oAccount.Credit);
                        }
                    }
                    else
                    {

                    }




                    User metro = oUserDAO.RetrieveServiceActivity(1);
                    User cricket = oUserDAO.RetrieveServiceActivity(2);
                    User Boost = oUserDAO.RetrieveServiceActivity(3);
                    User SinPin = oUserDAO.RetrieveServiceActivity(4);
                    User dp = oUserDAO.RetrieveServiceActivity(5);
                    User Simple = oUserDAO.RetrieveServiceActivity(6);
                    User H2O = oUserDAO.RetrieveServiceActivity(7);
                    User Ultra = oUserDAO.RetrieveServiceActivity(8);
                    User Lyca = oUserDAO.RetrieveServiceActivity(9);
                    User ATT = oUserDAO.RetrieveServiceActivity(10);
                    User TMobile = oUserDAO.RetrieveServiceActivity(11);
                    User Verison = oUserDAO.RetrieveServiceActivity(12);
                    User TigoGuate = oUserDAO.RetrieveServiceActivity(13);
                    User TigoSal = oUserDAO.RetrieveServiceActivity(14);
                    User TigoHon = oUserDAO.RetrieveServiceActivity(15);
                    User PacTigoGuate = oUserDAO.RetrieveServiceActivity(16);
                    User PacTigoSal = oUserDAO.RetrieveServiceActivity(17);
                    User PacTigoHon = oUserDAO.RetrieveServiceActivity(18);
                    User CubaCell = oUserDAO.RetrieveServiceActivity(20);
                    User Digicel = oUserDAO.RetrieveServiceActivity(21);
                    User Claro = oUserDAO.RetrieveServiceActivity(26);
                    User Flow = oUserDAO.RetrieveServiceActivity(32);
                    User GuatePin = oUserDAO.RetrieveServiceActivity(33);
                    User Net10 = oUserDAO.RetrieveServiceActivity(35);
                    User EasyGo = oUserDAO.RetrieveServiceActivity(36);
                    User GoSmart = oUserDAO.RetrieveServiceActivity(37);
                    User Natcom = oUserDAO.RetrieveServiceActivity(38);
                    User Telcel = oUserDAO.RetrieveServiceActivity(39);
                    User Liberty = oUserDAO.RetrieveServiceActivity(43);
                    if (metro.Active == true)
                    {
                        ImgMetro.Style.Add("width", "10%");
                        lbMetro.Text = "";
                    }
                    else
                    {
                        ImgMetro.Style.Add("width", "10%");
                        ImgMetro.Visible = false;
                        lbMetro.Text = "MetroPCS Under Maintenance";
                    }

                    if (cricket.Active == true)
                    {
                        ImgCricket.Style.Add("width", "10%");
                        lbCricket.Text = "";
                    }
                    else
                    {
                        ImgCricket.Style.Add("width", "10%");
                        ImgCricket.Visible = false;
                        lbCricket.Text = "Cricket Under Maintenance";
                    }

                    if (Boost.Active == true)
                    {
                        ImgBoost.Style.Add("width", "10%");
                        lbBoost.Text = "";
                    }
                    else
                    {
                        ImgBoost.Style.Add("width", "10%");
                        ImgBoost.Visible = false;
                        lbBoost.Text = "Boost Under Maintenance";
                    }
                    if (SinPin.Active == true)
                    {
                        ImgSinPin.Style.Add("width", "10%");
                        lbSinPin.Text = "";
                    }
                    else
                    {
                        ImgSinPin.Visible = false;
                        lbSinPin.Text = "";

                    }
                    if (dp.Active == true)
                    {
                        ImgDP.Style.Add("width", "10%");
                        lbdp.Text = "";
                    }
                    else
                    {
                        ImgDP.Visible = false;
                        lbdp.Text = "";

                    }
                    if (Simple.Active == true)
                    {
                        ImgSimple.Style.Add("width", "10%");
                        lbSimple.Text = "";
                    }
                    else
                    {
                        ImgSimple.Visible = false;
                        lbSimple.Text = "";

                    }
                    if (H2O.Active == true)
                    {
                        ImgH2O.Style.Add("width", "10%");
                        lbH2O.Text = "";
                    }
                    else
                    {
                        ImgH2O.Visible = false;
                        lbH2O.Text = "";

                    }
                    if (Ultra.Active == true)
                    {
                        ImgUltra.Style.Add("width", "10%");
                        lbUltra.Text = "";

                    }
                    else
                    {
                        ImgUltra.Visible = false;
                        lbUltra.Text = "";

                    }
                    if (Lyca.Active == true)
                    {
                        ImgLyca.Style.Add("width", "10%");
                        lbLyca.Text = "";

                    }
                    else
                    {
                        ImgLyca.Visible = false;
                        lbLyca.Text = "";

                    }

                    if (ATT.Active == true)
                    {
                        ImgATT.Style.Add("width", "10%");
                        lbatt.Text = "";
                    }
                    else
                    {
                        ImgATT.Visible = false;
                        lbLyca.Text = "";

                    }

                    if (TMobile.Active == true)
                    {
                        ImgTMobile.Style.Add("width", "10%");
                        lbtmobile.Text = "";
                    }
                    else
                    {
                        ImgTMobile.Visible = false;
                        lbtmobile.Text = "";

                    }

                    if (Verison.Active == true)
                    {
                        ImgVerison.Style.Add("width", "10%");
                        lbverison.Text = "";
                    }
                    else
                    {
                        ImgVerison.Visible = false;
                        lbverison.Text = "";

                    }
                    if (Net10.Active == true)
                    {

                        ImgNet10.Style.Add("width", "10%");
                        lbnet10.Text = "";
                    }
                    else
                    {
                        ImgNet10.Visible = false;
                        lbnet10.Text = "";
                    }
                    if (EasyGo.Active == true)
                    {
                        ImgEasyGo.Style.Add("width", "10%");
                        lbeasygo.Text = "";
                    }
                    else
                    {
                        ImgEasyGo.Visible = false;
                        lbeasygo.Text = "";
                    }
                    if (GoSmart.Active == true)
                    {
                        ImgGoSmart.Style.Add("width", "10%");
                        lbgosmart.Text = "";
                    }
                    else
                    {
                        ImgGoSmart.Visible = false;
                        lbgosmart.Text = "";
                    }
                    if (TigoGuate.Active == true)
                    {
                        ImgTigo.Style.Add("width", "10%");
                        lbTigo.Text = "";
                    }
                    else
                    {
                        ImgTigo.Visible = false;
                        lbTigo.Text = "";

                    }
                    if (CubaCell.Active == true)
                    {
                        ImgCubaCell.Style.Add("width", "10%");
                        lbCubaCell.Text = "";
                    }
                    else
                    {
                        ImgCubaCell.Visible = false;
                        lbCubaCell.Text = "";

                    }
                    if (Digicel.Active == true)
                    {
                        ImgDigicel.Style.Add("width", "10%");
                        lbDigicel.Text = "";
                    }
                    else
                    {
                        ImgDigicel.Visible = false;
                        lbDigicel.Text = "";

                    }
                    if (Claro.Active == true)
                    {
                        ImgClaro.Style.Add("width", "10%");
                        lbClaro.Text = "";
                    }
                    else
                    {
                        ImgClaro.Visible = false;
                        lbClaro.Text = "";

                    }

                    if (Flow.Active == true)
                    {
                        ImgFlow.Style.Add("width", "10%");
                        lbFlow.Text = "";
                    }
                    else
                    {
                        ImgFlow.Visible = false;
                        lbFlow.Text = "";

                    }
                    if (GuatePin.Active == true)
                    {
                        ImgGuatePin.Style.Add("width", "20%");
                        lbGuatePin.Text = "";
                    }
                    else
                    {
                        ImgGuatePin.Visible = false;
                        lbGuatePin.Text = "";

                    }
                    if (Natcom.Active == true)
                    {
                        ImgNatcom.Style.Add("width", "10%");
                        lbNatcom.Text = "";
                    }
                    else
                    {
                        ImgNatcom.Visible = false;
                        lbNatcom.Text = "";

                    }
                    if (Telcel.Active == true)
                    {
                        ImgTelcel.Style.Add("width", "10%");
                        lbTelcel.Text = "";
                    }
                    else
                    {
                        ImgTelcel.Visible = false;
                        lbTelcel.Text = "";

                    }
                    if (Liberty.Active == true)
                    {
                        ImgLiberty.Style.Add("width", "10%");
                        lbliberty.Text = "";
                    }
                    else
                    {
                        ImgLiberty.Visible = false;
                        lbliberty.Text = "";

                    }
                    if (Request.Url.ToString().Contains("?Online"))
                    {
                        //show cc input for online users
                        divFastPayOnline.Style.Add("display", "block");
                    }
                    else
                    {
                        divFastPayOnline.Style.Add("display", "none");
                        if (oUser.Active == false)
                        {
                            Response.Redirect("login.aspx", false);
                        }
                    }

                    txtPhone.Attributes.Add("onkeyup", "PhoneNumber(this);");
                    txtPhoneConf.Attributes.Add("onkeyup", "PhoneNumberConf(this);");
                    txtAmount.Attributes.Add("onkeyup", "Amount(this);");
                    txtUSNumber.Attributes.Add("onkeyup", "USNumber(this);");
                }
                catch (Exception ex)
                {
                    Response.Redirect("login.aspx", false);
                }

            }



        }

        protected void Submit_Click(object sender, System.EventArgs e)
        {
            if (Request.Cookies["UserNameCookie"] == null)
            {
                Response.Redirect("login.aspx", false);
            }
            try
            {
                User oDisUser = new User();

                //Services
                User metro = oUserDAO.RetrieveServiceActivity(1);
                User cricket = oUserDAO.RetrieveServiceActivity(2);
                User Boost = oUserDAO.RetrieveServiceActivity(3);
                User SinPin = oUserDAO.RetrieveServiceActivity(4);
                User dp = oUserDAO.RetrieveServiceActivity(5);
                User Simple = oUserDAO.RetrieveServiceActivity(6);
                User H2O = oUserDAO.RetrieveServiceActivity(7);
                User Ultra = oUserDAO.RetrieveServiceActivity(8);
                User Lyca = oUserDAO.RetrieveServiceActivity(9);
                User ATT = oUserDAO.RetrieveServiceActivity(10);
                User TMobile = oUserDAO.RetrieveServiceActivity(11);
                User Verison = oUserDAO.RetrieveServiceActivity(12);
                User TigoGuate = oUserDAO.RetrieveServiceActivity(13);
                User TigoSal = oUserDAO.RetrieveServiceActivity(14);
                User TigoHon = oUserDAO.RetrieveServiceActivity(15);
                User PacTigoGuate = oUserDAO.RetrieveServiceActivity(16);
                User PacTigoSal = oUserDAO.RetrieveServiceActivity(17);
                User PacTigoHon = oUserDAO.RetrieveServiceActivity(18);
                User IntTigoGuate = oUserDAO.RetrieveServiceActivity(19);
                User CubaCell = oUserDAO.RetrieveServiceActivity(20);
                User DigicelHaiti = oUserDAO.RetrieveServiceActivity(21);
                User DigicelElSalvador = oUserDAO.RetrieveServiceActivity(22);
                User DigicelJamaica = oUserDAO.RetrieveServiceActivity(23);
                User DigicelHaitiBundle = oUserDAO.RetrieveServiceActivity(24);
                User DigicelElSalvadorBundle = oUserDAO.RetrieveServiceActivity(25);
                User ClaroGuate = oUserDAO.RetrieveServiceActivity(26);
                User ClaroSal = oUserDAO.RetrieveServiceActivity(27);
                User ClaroHon = oUserDAO.RetrieveServiceActivity(28);
                User SuperPacGuate = oUserDAO.RetrieveServiceActivity(29);
                User SuperPacSal = oUserDAO.RetrieveServiceActivity(30);
                User SuperPacHon = oUserDAO.RetrieveServiceActivity(31);
                User Flow = oUserDAO.RetrieveServiceActivity(32);
                User GuatePin = oUserDAO.RetrieveServiceActivity(33);
                User Net10 = oUserDAO.RetrieveServiceActivity(35);
                User EasyGo = oUserDAO.RetrieveServiceActivity(36);
                User GoSmart = oUserDAO.RetrieveServiceActivity(37);
                User Natcom = oUserDAO.RetrieveServiceActivity(38);
                User Telcel = oUserDAO.RetrieveServiceActivity(39);
                User ClaGuateInt = oUserDAO.RetrieveServiceActivity(40);
                User ClaSalInt = oUserDAO.RetrieveServiceActivity(41);
                User ClaHonInt = oUserDAO.RetrieveServiceActivity(42);
                User Liberty = oUserDAO.RetrieveServiceActivity(43);

                //A call to SSPI failed FIX
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

                if (ddProviders.SelectedItem.Value == "1") //metropcs
                {
                    Session["providerText"] = "@mymetropcs.com"; // metropcs.sms.us

                    MetroFastPayLibrary.Account oAccount = new MetroFastPayLibrary.Account();
                    int doublepay = getPreviousPayment(txtPhone.Text.Replace("-", "").Replace("(", "").Replace(")", ""));
                    int prevAmountPaid = getPreviousPaymentAmount(txtPhone.Text.Replace("-", "").Replace("(", "").Replace(")", ""));
                    oAccount = oUserDAO.RetrieveAccount(UserCookie.Value);
                    if (oAccount.Active == true)
                    {
                        User oFee = new User();
                        oFee = oUserDAO.RetrieveFeebyUserID(UserCookie.Value);
                        lbAccount.Visible = true;
                        lbCredit.Text = oAccount.Credit.ToString();
                        if (doublepay >= 1)
                        {
                            if (doublepay == 3)
                            {
                                oDisUser = oUserDAO.DisableAccount(UserCookie.Value, false);
                                Response.Redirect("login.aspx", false);
                            }
                            if ((oAccount.Credit - (Convert.ToInt32(txtAmount.Text)) >= 0))
                            {
                                MetroPayment();
                            }
                            else
                            {
                                Response.Redirect("Splash.aspx?Phone=" + txtPhone.Text + "&error=CreditError", false);
                                HttpContext.Current.ApplicationInstance.CompleteRequest();

                            }
                        }
                        else
                        {

                            if ((oAccount.Credit - (Convert.ToInt32(txtAmount.Text) + (Convert.ToInt32(oFee.Fee) - 2))) >= 0)
                            {
                                MetroPayment();
                            }
                            else
                            {
                                Response.Redirect("Splash.aspx?Phone=" + txtPhone.Text + "&error=CreditError", false);
                                HttpContext.Current.ApplicationInstance.CompleteRequest();

                            }

                        }

                    }
                    else
                    {
                        if (doublepay >= 1 && prevAmountPaid.ToString() == txtAmount.Text)
                        {
                            lbInfo.ForeColor = Color.Red;
                            lbInfo.Text = txtPhone.Text + " has already been paid today for " + txtAmount.Text;
                            return;
                        }
                        MetroPayment();
                    }
                }
                else if (ddProviders.SelectedItem.Value == "2") //cricket
                {
                    Session["providerText"] = "@sms.mycricket.com"; // sms.mycricket.com
                    int doublepay = getPreviousPayment(txtPhone.Text.Replace("-", "").Replace("(", "").Replace(")", ""));
                    int prevAmountPaid = getPreviousPaymentAmount(txtPhone.Text.Replace("-", "").Replace("(", "").Replace(")", ""));
                    MetroFastPayLibrary.Account oAccount = new MetroFastPayLibrary.Account();
                    oAccount = oUserDAO.RetrieveAccount(UserCookie.Value);
                    if (oAccount.Active == true)
                    {
                        User oFee = new User();
                        oFee = oUserDAO.RetrieveFeebyUserID(UserCookie.Value);
                        lbAccount.Visible = true;
                        lbCredit.Text = oAccount.Credit.ToString();

                        if (doublepay >= 1)
                        {
                            if (doublepay == 3)
                            {
                                oDisUser = oUserDAO.DisableAccount(UserCookie.Value, false);
                                Response.Redirect("login.aspx", false);
                            }
                            if ((oAccount.Credit - (Convert.ToInt32(txtAmount.Text)) >= 0))
                            {
                                CricketPayment();
                            }
                            else
                            {
                                Response.Redirect("Splash.aspx?Phone=" + txtPhone.Text + "&error=CreditError", false);
                                HttpContext.Current.ApplicationInstance.CompleteRequest();

                            }
                        }
                        else
                        {
                            if ((oAccount.Credit - (Convert.ToInt32(txtAmount.Text) + (Convert.ToInt32(oFee.Fee) - 2))) >= 0)
                            {
                                CricketPayment();
                            }
                            else
                            {
                                Response.Redirect("Splash.aspx?Phone=" + txtPhone.Text + "&error=CreditError", false);
                                HttpContext.Current.ApplicationInstance.CompleteRequest();

                            }
                        }

                    }
                    else
                    {
                        if (doublepay >= 1 && prevAmountPaid.ToString() == txtAmount.Text)
                        {
                            lbInfo.ForeColor = Color.Red;
                            lbInfo.Text = txtPhone.Text + " has already been paid today for " + txtAmount.Text;
                            return;
                        }
                        CricketPayment();
                    }
                }
                else if (ddProviders.SelectedItem.Value == "3") //boost
                {
                    Session["providerText"] = "@myboostmobile.com"; // myboostmobile.com
                    int doublepay = getPreviousPayment(txtPhone.Text.Replace("-", "").Replace("(", "").Replace(")", ""));
                    int prevAmountPaid = getPreviousPaymentAmount(txtPhone.Text.Replace("-", "").Replace("(", "").Replace(")", ""));
                    MetroFastPayLibrary.Account oAccount = new MetroFastPayLibrary.Account();
                    oAccount = oUserDAO.RetrieveAccount(UserCookie.Value);
                    if (oAccount.Active == true)
                    {
                        User oFee = new User();
                        oFee = oUserDAO.RetrieveFeebyUserID(UserCookie.Value);
                        lbAccount.Visible = true;
                        lbCredit.Text = oAccount.Credit.ToString();
                        if (doublepay >= 1)
                        {
                            if (doublepay == 3)
                            {
                                oDisUser = oUserDAO.DisableAccount(UserCookie.Value, false);
                                Response.Redirect("login.aspx");
                            }
                            if ((oAccount.Credit - (Convert.ToInt32(txtAmount.Text)) >= 0))
                            {
                                BoostPayment();
                            }
                            else
                            {
                                Response.Redirect("Splash.aspx?Phone=" + txtPhone.Text + "&error=CreditError", false);
                                HttpContext.Current.ApplicationInstance.CompleteRequest();

                            }
                        }
                        else
                        {
                            if ((oAccount.Credit - (Convert.ToInt32(txtAmount.Text) + (Convert.ToInt32(oFee.Fee) - 2))) >= 0)
                            {
                                BoostPayment();
                            }
                            else
                            {
                                Response.Redirect("Splash.aspx?Phone=" + txtPhone.Text + "&error=CreditError", false);
                                HttpContext.Current.ApplicationInstance.CompleteRequest();

                            }
                        }

                    }
                    else
                    {
                        if (doublepay >= 1 && prevAmountPaid.ToString() == txtAmount.Text)
                        {
                            lbInfo.ForeColor = Color.Red;
                            lbInfo.Text = txtPhone.Text + " has already been paid today for " + txtAmount.Text;
                            return;
                        }
                        BoostPayment();
                    }
                }
                else if (ddProviders.SelectedItem.Value == "4") //SinPin
                {
                    Session["providerText"] = ""; // SinPin is not a cell provider, so NA

                    MetroFastPayLibrary.Account oAccount = new MetroFastPayLibrary.Account();
                    oAccount = oUserDAO.RetrieveAccount(UserCookie.Value);
                    if (oAccount.Active == true)
                    {
                        User oFee = new User();
                        oFee = oUserDAO.RetrieveFeebyUserID(UserCookie.Value);
                        lbAccount.Visible = true;
                        lbCredit.Text = oAccount.Credit.ToString();
                        int doublepay = getPreviousPayment(txtPhone.Text.Replace("-", "").Replace("(", "").Replace(")", ""));
                        if (doublepay >= 1)
                        {
                            if (doublepay == 3)
                            {
                                oDisUser = oUserDAO.DisableAccount(UserCookie.Value, false);
                                Response.Redirect("login.aspx", false);
                            }
                            if ((oAccount.Credit - (Convert.ToInt32(txtAmount.Text)) >= 0))
                            {
                                SinPinPayment();
                            }
                            else
                            {
                                Response.Redirect("Splash.aspx?Phone=" + txtPhone.Text + "&error=CreditError", false);
                                HttpContext.Current.ApplicationInstance.CompleteRequest();

                            }
                        }
                        else
                        {
                            if ((oAccount.Credit - (Convert.ToInt32(txtAmount.Text) + (Convert.ToInt32(oFee.Fee) - 2))) >= 0)
                            {
                                SinPinPayment();
                            }
                            else
                            {
                                Response.Redirect("Splash.aspx?Phone=" + txtPhone.Text + "&error=CreditError", false);
                                HttpContext.Current.ApplicationInstance.CompleteRequest();

                            }
                        }

                    }
                    else
                    {
                        SinPinPayment();
                    }
                }
                else if (ddProviders.SelectedItem.Value == "5" || ddProviders.SelectedItem.Value == "33") //dollar phone and GuatePin and ReupAPI
                {
                    Session["providerText"] = ""; // DollarPhone is not a cell provider, so NA
                    if (ddProviders.SelectedItem.Value == "33")
                    {
                        GuatePin = oUserDAO.RetrieveServiceActivity(GuatePin.ID, UserCookie.Value);
                        Session["offeringid"] = GuatePin.OfferingID;
                        Session["UserComm"] = GuatePin.UserCommission;
                    }
                    else
                    {
                        dp = oUserDAO.RetrieveServiceActivity(dp.ID, UserCookie.Value);
                        Session["offeringid"] = dp.OfferingID;
                        Session["UserComm"] = dp.UserCommission;
                    }

                    MetroFastPayLibrary.Account oAccount = new MetroFastPayLibrary.Account();
                    oAccount = oUserDAO.RetrieveAccount(UserCookie.Value);
                    if (oAccount.Active == true)
                    {
                        User oFee = new User();
                        oFee = oUserDAO.RetrieveFeebyUserID(UserCookie.Value);
                        lbAccount.Visible = true;
                        lbCredit.Text = oAccount.Credit.ToString();
                        int doublepay = getPreviousPayment(txtPhone.Text.Replace("-", "").Replace("(", "").Replace(")", ""));
                        if (doublepay >= 1)
                        {
                            if (doublepay == 3)
                            {
                                oDisUser = oUserDAO.DisableAccount(UserCookie.Value, false);
                                Response.Redirect("login.aspx");
                            }
                            if ((oAccount.Credit - (Convert.ToInt32(txtAmount.Text)) >= 0))
                            {
                                DollarPhonePayment();
                            }
                            else
                            {
                                Response.Redirect("Splash.aspx?Phone=" + txtPhone.Text + "&error=CreditError", false);
                                HttpContext.Current.ApplicationInstance.CompleteRequest();

                            }
                        }
                        else
                        {
                            if ((oAccount.Credit - (Convert.ToInt32(txtAmount.Text) + (Convert.ToInt32(oFee.Fee) - 2))) >= 0)
                            {
                                DollarPhonePayment();
                            }
                            else
                            {
                                Response.Redirect("Splash.aspx?Phone=" + txtPhone.Text + "&error=CreditError", false);
                                HttpContext.Current.ApplicationInstance.CompleteRequest();

                            }
                        }

                    }
                    else
                    {
                        DollarPhonePayment();

                    }
                }
                else if (ddProviders.SelectedItem.Value == "6" || ddProviders.SelectedItem.Value == "7" || ddProviders.SelectedItem.Value == "8" || ddProviders.SelectedItem.Value == "9"
                    || ddProviders.SelectedItem.Value == "10" || ddProviders.SelectedItem.Value == "11" || ddProviders.SelectedItem.Value == "12"
                    || ddProviders.SelectedItem.Value == "13" || ddProviders.SelectedItem.Value == "14" || ddProviders.SelectedItem.Value == "15" || ddProviders.SelectedItem.Value == "20"
                    || ddProviders.SelectedItem.Value == "21" || ddProviders.SelectedItem.Value == "22" || ddProviders.SelectedItem.Value == "23" || ddProviders.SelectedItem.Value == "24"
                    || ddProviders.SelectedItem.Value == "25" || ddProviders.SelectedItem.Value == "26" || ddProviders.SelectedItem.Value == "27" || ddProviders.SelectedItem.Value == "28"
                    || ddProviders.SelectedItem.Value == "29" || ddProviders.SelectedItem.Value == "30" || ddProviders.SelectedItem.Value == "31" || ddProviders.SelectedItem.Value == "32"
                    || ddProviders.SelectedItem.Value == "35" || ddProviders.SelectedItem.Value == "36" || ddProviders.SelectedItem.Value == "37" || ddProviders.SelectedItem.Value == "38"
                    || ddProviders.SelectedItem.Value == "39" || ddProviders.SelectedItem.Value == "43")

                {
                    if (ddProviders.SelectedItem.Value == Simple.ID.ToString()) //Simple Mobile
                    {
                        Session["providerText"] = "@smtext.com";
                        Session["offeringid"] = Simple.OfferingID.ToString();


                        if (txtAmount.Text == "75" || txtAmount.Text == "100")
                        {
                            Session["offeringid"] = "30180940";
                        }
                    }
                    else if (ddProviders.SelectedItem.Value == H2O.ID.ToString()) //H2O
                    {
                        Session["providerText"] = "@txt.att.net";
                        Session["offeringid"] = H2O.OfferingID.ToString();
                    }
                    else if (ddProviders.SelectedItem.Value == Ultra.ID.ToString()) //Ultra 
                    {
                        Session["providerText"] = "@tmomail.net";
                        Session["offeringid"] = Ultra.OfferingID.ToString();
                    }
                    else if (ddProviders.SelectedItem.Value == Lyca.ID.ToString()) //Lyca
                    {
                        Session["providerText"] = "@smtext.com";
                        Session["offeringid"] = Lyca.OfferingID.ToString();
                    }
                    else if (ddProviders.SelectedItem.Value == ATT.ID.ToString()) //ATT
                    {
                        Session["providerText"] = "@txt.att.net";
                        Session["offeringid"] = ATT.OfferingID.ToString(); // DP

                        //reup api 
                        //Session["offeringid"] = "2";

                        //int i = 0;
                        //if (txtAmount.Text == "10") { i = 1; }
                        //else if (txtAmount.Text == "15") { i = 2; }
                        //else if (txtAmount.Text == "20") { i = 3; }
                        //else if (txtAmount.Text == "25") { i = 4; }
                        //else if (txtAmount.Text == "30") { i = 5; }
                        //else if (txtAmount.Text == "35") { i = 6; }
                        //else if (txtAmount.Text == "40") { i = 7; }
                        //else if (txtAmount.Text == "45") { i = 8; }
                        //else if (txtAmount.Text == "50") { i = 9; }
                        //else if (txtAmount.Text == "60") { i = 10; }
                        //else if (txtAmount.Text == "65") { i = 11; }
                        //else if (txtAmount.Text == "75") { i = 12; }
                        //else if (txtAmount.Text == "80") { i = 13; }
                        //else if (txtAmount.Text == "85") { i = 14; }
                        //else if (txtAmount.Text == "100") { i = 15; }
                        //switch (i)
                        //{
                        //    case 1: Session["PlanID"] = "253"; break;
                        //    case 2: Session["PlanID"] = "255"; break;
                        //    case 3: Session["PlanID"] = "240"; break;
                        //    case 4: Session["PlanID"] = "7"; break;
                        //    case 5: Session["PlanID"] = "151"; break;
                        //    case 6: Session["PlanID"] = "258"; break;
                        //    case 7: Session["PlanID"] = "114"; break;
                        //    case 8: Session["PlanID"] = "9"; break;
                        //    case 9: Session["PlanID"] = "259"; break;
                        //    case 10: Session["PlanID"] = "16"; break;
                        //    case 11: Session["PlanID"] = "260"; break;
                        //    case 12: Session["PlanID"] = "261"; break;
                        //    case 13: Session["PlanID"] = "262"; break;
                        //    case 14: Session["PlanID"] = "672"; break;
                        //    case 15: Session["PlanID"] = "254"; break;
                        //}

                    }
                    else if (ddProviders.SelectedItem.Value == TMobile.ID.ToString()) //tmobile
                    {
                        Session["providerText"] = "@tmomail.net";
                        Session["offeringid"] = TMobile.OfferingID.ToString();
                    }
                    else if (ddProviders.SelectedItem.Value == Verison.ID.ToString()) //verison
                    {
                        Session["providerText"] = "@vtext.com";
                        Session["offeringid"] = Verison.OfferingID.ToString();
                    }
                    else if (this.ddProviders.SelectedItem.Value == Net10.ID.ToString()) // Net10
                    {
                        this.Session["providerText"] = "@vtext.com";
                        this.Session["offeringid"] = Net10.OfferingID.ToString();
                    }
                    else if (this.ddProviders.SelectedItem.Value == EasyGo.ID.ToString()) //easyGo
                    {
                        this.Session["providerText"] = "@txt.att.net";
                        this.Session["offeringid"] = EasyGo.OfferingID.ToString();
                    }
                    else if (ddProviders.SelectedItem.Value == GoSmart.ID.ToString()) //GoSmart
                    {
                        Session["providerText"] = "@smtext.com";
                        Session["offeringid"] = GoSmart.OfferingID.ToString();

                        if (txtAmount.Text == "25")
                        {
                            Session["offeringid"] = "30171340";
                        }
                    }
                    else if (ddProviders.SelectedItem.Value == Liberty.ID.ToString()) //Liberty
                    {
                        Session["providerText"] = "@smtext.com";
                        Session["offeringid"] = Liberty.OfferingID.ToString();

                        if (txtAmount.Text == "4.99" || txtAmount.Text == "9.99")
                        {
                            Session["offeringid"] = "30182680";
                        }
                    }
                    else if (ddProviders.SelectedItem.Value == TigoGuate.ID.ToString()) //Tigo Guatemala
                    {
                        if (ddOtherService.SelectedItem.Value == "1")
                        {
                            Session["providerText"] = "@sms.tigo.com.gt";
                            Session["offeringid"] = TigoGuate.OfferingID.ToString();
                            Session["OtherService"] = "";
                            usesShortCode = true;
                        }
                        else if (ddOtherService.SelectedItem.Value == "2") //PaqueTigo Guatemala
                        {
                            Session["providerText"] = "@sms.tigo.com.gt";
                            Session["offeringid"] = PacTigoGuate.OfferingID.ToString();
                            Session["OtherService"] = "PaqueTigo";
                            usesShortCode = true;
                        }
                        else if (ddOtherService.SelectedItem.Value == "3")// Internet Guatemala
                        {
                            Session["providerText"] = "@sms.tigo.com.gt";
                            Session["offeringid"] = IntTigoGuate.OfferingID.ToString();
                            Session["OtherService"] = "Internet";
                            usesShortCode = true;
                        }

                    }
                    else if (ddProviders.SelectedItem.Value == TigoSal.ID.ToString()) //Tigo El Salvador
                    {
                        if (ddOtherService.SelectedItem.Value == "1")
                        {
                            Session["providerText"] = "@sms.tigo.com.sv";
                            Session["offeringid"] = TigoSal.OfferingID.ToString();
                            Session["OtherService"] = "";
                            usesShortCode = true;
                        }
                        else if (ddOtherService.SelectedItem.Value == "2") //PaqueTigo El Salvador
                        {
                            Session["providerText"] = "@sms.tigo.com.sv";
                            Session["offeringid"] = PacTigoSal.OfferingID.ToString();
                            Session["OtherService"] = "PaqueTigo";
                            usesShortCode = true;
                        }

                    }
                    else if (ddProviders.SelectedItem.Value == TigoHon.ID.ToString()) //Tigo Honduras
                    {
                        if (ddOtherService.SelectedItem.Value == "1")
                        {
                            Session["providerText"] = "@sms.tigo.com.hn";
                            Session["offeringid"] = TigoHon.OfferingID.ToString();
                            Session["OtherService"] = "";
                            usesShortCode = true;
                        }
                        else if (ddOtherService.SelectedItem.Value == "2") //PaqueTigo Honduras
                        {
                            Session["providerText"] = "@sms.tigo.com.hn";
                            Session["offeringid"] = PacTigoHon.OfferingID.ToString();
                            Session["OtherService"] = "PaqueTigo";
                            usesShortCode = true;

                        }
                    }

                    else if (ddProviders.SelectedItem.Value == CubaCell.ID.ToString()) //Cuba Cell
                    {
                        Session["providerText"] = "@vtext.com";
                        Session["offeringid"] = CubaCell.OfferingID.ToString();
                        usesShortCode = true;
                    }
                    else if (ddProviders.SelectedItem.Value == DigicelHaiti.ID.ToString()) //Digicell Haiti
                    {
                        if (ddOtherService.SelectedItem.Value == "1")
                        {
                            Session["providerText"] = "@sms.digicel.com.ht";
                            Session["offeringid"] = DigicelHaiti.OfferingID.ToString();
                            Session["OtherService"] = "";
                            usesShortCode = true;
                        }
                        else if (ddOtherService.SelectedItem.Value == "2") //Bundle Haiti
                        {
                            Session["providerText"] = "@sms.digicel.com.ht";
                            Session["offeringid"] = DigicelHaitiBundle.OfferingID.ToString();
                            Session["OtherService"] = "Bundle";
                            usesShortCode = true;
                        }

                    }
                    else if (ddProviders.SelectedItem.Value == DigicelElSalvador.ID.ToString()) //Digicell El Salvador
                    {
                        if (ddOtherService.SelectedItem.Value == "1")
                        {
                            Session["providerText"] = "@sms.digicel.com.sv";
                            Session["offeringid"] = DigicelElSalvador.OfferingID.ToString();
                            Session["OtherService"] = "";
                            usesShortCode = true;
                        }
                        else if (ddOtherService.SelectedItem.Value == "2") //Bundle Haiti
                        {
                            Session["providerText"] = "@sms.digicel.com.sv";
                            Session["offeringid"] = DigicelElSalvadorBundle.OfferingID.ToString();
                            Session["OtherService"] = "Bundle";
                            usesShortCode = true;
                        }

                    }
                    else if (ddProviders.SelectedItem.Value == DigicelJamaica.ID.ToString()) //Digicell Jamaica
                    {

                        Session["providerText"] = "@sms.digicel.com.jm";
                        Session["offeringid"] = DigicelJamaica.OfferingID.ToString();
                        Session["OtherService"] = "";
                        usesShortCode = true;
                    }
                    else if (ddProviders.SelectedItem.Value == ClaroGuate.ID.ToString()) //Claro Guatemala
                    {
                        if (ddOtherService.SelectedItem.Value == "1")
                        {
                            Session["providerText"] = "@sms.claro.com.gt";
                            Session["offeringid"] = ClaroGuate.OfferingID.ToString();
                            Session["OtherService"] = "";
                            usesShortCode = true;
                        }
                        else if (ddOtherService.SelectedItem.Value == "2") //SuperPack Guatemala
                        {
                            Session["providerText"] = "@sms.claro.com.gt";
                            Session["offeringid"] = SuperPacGuate.OfferingID.ToString();
                            Session["OtherService"] = "SuperPack";
                            usesShortCode = true;
                        }
                        else if (ddOtherService.SelectedItem.Value == "3") //Claro Guatemala Internet
                        {
                                Session["providerText"] = "@sms.claro.com.gt";
                                Session["offeringid"] = ClaGuateInt.OfferingID.ToString();
                                Session["OtherService"] = "Internet";
                                usesShortCode = true;
                        }

                    }
                    else if (ddProviders.SelectedItem.Value == ClaroSal.ID.ToString()) //Claro El Salvador
                    {
                        if (ddOtherService.SelectedItem.Value == "1")
                        {
                            Session["providerText"] = "@sms.claro.com.sv";
                            Session["offeringid"] = ClaroSal.OfferingID.ToString();
                            Session["OtherService"] = "";
                            usesShortCode = true;
                        }
                        else if (ddOtherService.SelectedItem.Value == "2") //SuperPack El Salvador 
                        {
                            Session["providerText"] = "@sms.digicel.com.sv";
                            Session["offeringid"] = SuperPacSal.OfferingID.ToString();
                            Session["OtherService"] = "SuperPack";
                            usesShortCode = true;
                        }
                        else if (ddOtherService.SelectedItem.Value == "3") //Claro Internet El Salvador 
                        {
                            Session["providerText"] = "@sms.claro.com.gt";
                            Session["offeringid"] = ClaSalInt.OfferingID.ToString();
                            Session["OtherService"] = "Internet";
                            usesShortCode = true;
                        }
                    }
                    else if (ddProviders.SelectedItem.Value == ClaroHon.ID.ToString()) //Claro Honduras
                    {
                        if (ddOtherService.SelectedItem.Value == "1")
                        {
                            Session["providerText"] = "@sms.claro.com.sv";
                            Session["offeringid"] = ClaroHon.OfferingID.ToString();
                            Session["OtherService"] = "";
                            usesShortCode = true;
                        }
                        else if (ddOtherService.SelectedItem.Value == "2") //SuperPack Honduras
                        {
                            Session["providerText"] = "@sms.digicel.com.sv";
                            Session["offeringid"] = SuperPacHon.OfferingID.ToString();
                            Session["OtherService"] = "SuperPack";
                            usesShortCode = true;
                        }
                        else if (ddOtherService.SelectedItem.Value == "3") //Claro Internet Honduras
                        {
                            Session["providerText"] = "@sms.claro.com.gt";
                            Session["offeringid"] = ClaHonInt.OfferingID.ToString();
                            Session["OtherService"] = "Internet";
                            usesShortCode = true;
                        }
                    }
                    else if (ddProviders.SelectedItem.Value == Flow.ID.ToString()) //Flow Jamaica
                    {

                        Session["providerText"] = "@sms.Flow.com.jm";
                        Session["offeringid"] = Flow.OfferingID.ToString();
                        usesShortCode = true;
                    }
                    else if (ddProviders.SelectedItem.Value == Natcom.ID.ToString()) //Natcom
                    {

                        Session["providerText"] = "@sms.Natcom.com.jm";
                        Session["offeringid"] = Natcom.OfferingID.ToString();
                        usesShortCode = true;
                    }
                    else if (ddProviders.SelectedItem.Value == Telcel.ID.ToString()) //Telcel
                    {

                        Session["providerText"] = "@sms.Telcel.com.jm";
                        Session["offeringid"] = Telcel.OfferingID.ToString();
                        usesShortCode = true;
                    }
                    int doublepay = getPreviousPayment(txtPhone.Text.Replace("-", "").Replace("(", "").Replace(")", ""));
                    int prevAmountPaid = getPreviousPaymentAmount(txtPhone.Text.Replace("-", "").Replace("(", "").Replace(")", ""));

                    MetroFastPayLibrary.Account oAccount = new MetroFastPayLibrary.Account();
                    oAccount = oUserDAO.RetrieveAccount(UserCookie.Value);
                    if (oAccount.Active == true)
                    {
                        User oFee = new User();
                        oFee = oUserDAO.RetrieveFeebyUserID(UserCookie.Value);
                        lbAccount.Visible = true;
                        lbCredit.Text = oAccount.Credit.ToString();
                        if (doublepay >= 1)
                        {
                            if (doublepay == 3)
                            {
                                oDisUser = oUserDAO.DisableAccount(UserCookie.Value, false);
                                Response.Redirect("login.aspx", false);
                            }
                            if ((oAccount.Credit - (Convert.ToInt32(txtAmount.Text)) >= 0))
                            {
                                if (Session["offeringid"].ToString().Length >= 3)
                                {//DollarPhone APi
                                    DPMobilePayment();
                                }
                                else
                                {//Reup  API
                                    ReupPayments();
                                }

                            }
                            else
                            {
                                Response.Redirect("Splash.aspx?Phone=" + txtPhone.Text + "&error=CreditError", false);
                                HttpContext.Current.ApplicationInstance.CompleteRequest();

                            }
                        }
                        else
                        {
                            if ((oAccount.Credit - (Convert.ToInt32(txtAmount.Text) + (Convert.ToInt32(oFee.Fee) - 2))) >= 0)
                            {

                                if (Session["offeringid"].ToString().Length >= 8)
                                {//DollarPhone APi
                                    DPMobilePayment();
                                }
                                else
                                {//Reup  API
                                    ReupPayments();
                                }
                            }
                            else
                            {
                                Response.Redirect("Splash.aspx?Phone=" + txtPhone.Text + "&error=CreditError", false);
                                HttpContext.Current.ApplicationInstance.CompleteRequest();

                            }
                        }

                    }
                    else
                    {
                        if (doublepay >= 1 && prevAmountPaid.ToString() == txtAmount.Text)
                        {
                            lbInfo.ForeColor = Color.Red;
                            lbInfo.Text = txtPhone.Text + " has already been paid today for " + txtAmount.Text;
                            return;
                        }

                        if (Session["offeringid"].ToString().Length >= 8)
                        {//DollarPhone APi
                            DPMobilePayment();
                        }
                        else
                        {//Reup  API
                            ReupPayments();
                        }

                    }
                }
                else
                {
                    lbInfo.Text = "Nothing for " + ddProviders.SelectedItem.Text;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("logout.aspx");
            }

        }



        public async void MetroPayment()
        {
            try
            {
                Payment oPay = new Payment();
                oPay = oUserDAO.RetrieveLastPayment(UserCookie.Value);
                User oDisUser = new User();
                User oFee = new User();
                oFee = oUserDAO.RetrieveFeebyUserID(UserCookie.Value);
                if (oPay.AmountPaid == 204 && oPay.CreatedDate.ToString("dd/MM/yyyy") == DateTime.Now.ToString("dd/MM/yyyy"))
                {
                    oDisUser = oUserDAO.DisableAccount(UserCookie.Value, false);
                }


                string phone = "";
                decimal totalamount = 0;
                decimal provideramount = 0;
                if (txtAmount.Text == "")
                {
                    phone = Session["phone"].ToString();
                    totalamount = Convert.ToDecimal(Session["totalamount"]);
                    provideramount = Convert.ToDecimal(Session["provideramount"]);
                }
                else
                {
                    totalamount = decimal.Parse(txtAmount.Text) + Convert.ToInt32(oFee.Fee);
                    provideramount = decimal.Parse(txtAmount.Text);
                    if (provideramount.ToString().Contains("."))
                    {

                    }
                    else
                    {
                        provideramount = Convert.ToDecimal(string.Format("{0:0.00}", provideramount));
                    }

                    Session["totalamount"] = totalamount;
                    Session["providerAmount"] = provideramount;
                    Session["provider"] = ddProviders.SelectedItem.Text;
                    phone = txtPhone.Text.Replace("-", "").Replace("(", "").Replace(")", "");
                    Session["phone"] = phone;



                }

                //check number in DB
                //await CheckMetro("https://www.metropcs.com/apps/mpcs/servlet/genericservlet?inputReqParam={'serviceName':'profileManagementService','serviceProviderName':'applicationSpecific','requestParams':{'phoneNumber':'" + phone + "'},'componentId':'getLimitedCustomerInfo','applicationId':'metropcs','siteId':'metropcs'}");
                //await checkNumberinDB("https://www.metropcs.com/apps/mpcs/servlet/genericservlet?inputReqParam={'serviceName':'profileManagementService','serviceProviderName':'applicationSpecific','requestParams':{'phoneNumber':'" + phone + "'},'componentId':'getLimitedCustomerInfo','applicationId':'metropcs','siteId':'metropcs'}");
                //await CheckMetro(phone);

                //MetroFastPayLibrary.MetroPCSSecurity oMetroPCSSecurity = new MetroFastPayLibrary.MetroPCSSecurity();
                //oMetroPCSSecurity = oUserDAO.RetrieveMSbyA();

                //if (oMetroPCSSecurity.b == null)
                //{
                //    return;
                //}

                if (UserCookie.Value != "FastPay Online")
                {
                    CC oCC = new CC();
                    oCC = oUserDAO.RetrieveCC();
                    CC oCC2 = new CC();
                    oCC2 = oUserDAO.RetrieveCC2();
                    CC oCC3 = new CC();
                    oCC3 = oUserDAO.RetrieveCC3();


                    string thecc = "";
                    string thecvv = "";
                    string expDate = "";
                    string ZIP = "";
                    string metrocc = "";


                    if (oCC.Used != null)
                    {
                        string cc = oCC.CCNumber;
                        Session["cc"] = cc;
                        thecc = DAO.Decrypt(oCC.CCNumber, ConfigurationManager.AppSettings["encryptionKey"]).Trim();
                        thecvv = oCC.CVV.Trim();
                        expDate = oCC.ExpDate;
                        ZIP = oCC.ZIP;
                        metrocc = oCC.Address;
                    }
                    else if (oCC2.Used != null)
                    {
                        string cc = oCC2.CCNumber;
                        Session["cc"] = cc;
                        thecc = DAO.Decrypt(oCC2.CCNumber, ConfigurationManager.AppSettings["encryptionKey"]).Trim();
                        thecvv = oCC2.CVV.Trim();
                        expDate = oCC2.ExpDate;
                        ZIP = oCC2.ZIP;
                        metrocc = oCC2.Address;
                    }
                    else if (oCC3.Used != null)
                    {
                        string cc = oCC3.CCNumber;
                        Session["cc"] = cc;
                        thecc = DAO.Decrypt(oCC3.CCNumber, ConfigurationManager.AppSettings["encryptionKey"]).Trim();
                        thecvv = oCC3.CVV.Trim();
                        expDate = oCC3.ExpDate;
                        ZIP = oCC3.ZIP;
                        metrocc = oCC3.Address;
                    }

                    if (oCC3.Used == null && oCC2.Used == null && oCC.Used == null)
                    {
                        //text
                        Session["cc"] = "GAMFQB336+lBhwhfoORRfL4cmy+/N1nZSUmre8T4D/A+2KRc9KvmVwsSNLXxc4aY";
                        TextAndEmailNew("Telbug Error", "no cards in the system for metropcs, switched to manual payments", true);
                        //Turn manual payments on
                        // oUserDAO.UpdateServiceActivity(1, false);
                        //if (Session["error"].ToString() != "error1")
                       // {
                            //makes payment
                            ManualPayment();
                            return;
                       // }


                    }

                    if (oCC3.Used == null)
                    {
                        Response.Redirect("Splash.aspx?Phone=" + phone.Replace("-", "") + "&datepaid=" + DateTime.Now + "&provider=" + Session["provider"].ToString() + "&providerText=" + Session["providerText"].ToString() + "&cc=" + Session["cc"].ToString() + "&providerAmount=" + Session["providerAmount"].ToString() + "&error=" + Session["error"].ToString() + "&conf=" + Session["conf"].ToString() + "&amount=" + Session["totalamount"].ToString(), false);
                    }
                    //if (Session["error"].ToString() == "")
                    //{
                    //    //await MetroPostRequest("https://www.metropcs.com/apps/mpcs/servlet/paymentservlet?inputReqParam={'serviceName':'paymentManagementService','serviceProviderName':'applicationSpecific','expectedParams':{},'backupPaymentMode':'false','requestParams':{'authorizePaymentParams':{'mdn':'" + phone + "','FirstName':'" + GenerateName(5) + "','LastName':'" + GenerateName(6) + "','CardNumber':'" + thecc + "','ExpirationDate':'" + expDate + "','ZipCode':'" + ZIP + "','clientId':'TMOBILE','CardVerificationCode':'" + thecvv + "','confirmationEmailAddress':'9874559@gmail.com','ServicePaymentAmountSG':'" + provideramount + "','isDebitPreferred':'true','cardType':'VISA'},'mdn':'" + phone + "','subId':''},'componentId':'authorizePaymentAndSaveContact','applicationId':'metropcs','siteId':'metropcs'}");
                    //    //DateTime it = Convert.ToDateTime(expDate);
                    //    await MetroPostRequest("https://www.metrobyt-mobile.com/api/v1/billing/payment/authorize-anonymous", provideramount, thecc, GenerateName(5), GenerateName(6), expDate, thecvv, ZIP, phone, metrocc); 
                    //}

                    //make phone payment
                    ManualPaymentMetro(phone, txtAmount.Text, thecc, expDate, thecvv);
                    return;
                }
                else
                {
                    //splash page if no error for FastPay Online
                    if (Session["error"].ToString() == "")
                    {
                        await GetCityandState("http://www.zipcodeapi.com/rest/jMhIO8BPVggglYdeUPMraJHIL0gFiC4QH59rCBTlhr5UrjMMDxOaAlXpeaDihOtQ/info.json/" + txtZip.Text + "/radians");
                        Session["cc"] = "GAMFQB336+lBhwhfoORRfL4cmy+/N1nZSUmre8T4D/A+2KRc9KvmVwsSNLXxc4aY";
                        DateTime it = Convert.ToDateTime(txtExpDate.Text);
                        await MetroPostRequest("https://www.metrobyt-mobile.com/api/v1/billing/payment/authorize-anonymous", provideramount, txtCC.Text, GenerateName(5), GenerateName(6), it.ToString("MM/yyyy"), txtCVV.Text, txtZip.Text, phone, txtCC.Text);
                        AuthorizePayment(txtFirstName.Text, txtLastName.Text, "0987" + GenerateName(6) + "Rd", Session["City"].ToString(), Session["State"].ToString(), txtZip.Text, "USA", 3, txtCC.Text, txtExpDate.Text, txtCVV.Text, Session["provider"].ToString() + " payments made with FastPay Online", "FastPay Online ", Session["provider"].ToString() + " payment made for # " + phone + " in the amount of " + txtAmount.Text);
                    }
                }



                if (UserCookie.Value != "FastPay Online")
                {
                    if (Session["error"].ToString() == "error13")
                    {

                        if (oCC.Used != null)
                        {
                            oUserDAO.UpdateCConANDoff(oCC.FirstName, oCC.LastName, false);
                            TextAndEmail("Telbug Error", "Fraud on card " + oCC.FirstName + " " + oCC.LastName + " #:" + DAO.Decrypt(oCC.CCNumber, ConfigurationManager.AppSettings["encryptionKey"]).Trim(), true);
                            oUserDAO.DisableCard(oCC.CCNumber, false);
                        }
                        else if (oCC2.Used != null)
                        {
                            oUserDAO.UpdateCConANDoff(oCC2.FirstName, oCC2.LastName, false);
                            TextAndEmail("Telbug Error", "Fraud on card " + oCC2.FirstName + " " + oCC2.LastName + " #:" + DAO.Decrypt(oCC2.CCNumber, ConfigurationManager.AppSettings["encryptionKey"]).Trim(), true);
                            oUserDAO.DisableCard(oCC2.CCNumber, false);
                        }
                        else if (oCC3.Used != null)
                        {
                            oUserDAO.UpdateCConANDoff(oCC3.FirstName, oCC3.LastName, false);
                            TextAndEmail("Telbug Error", "Fraud on card " + oCC3.FirstName + " " + oCC3.LastName + " #:" + DAO.Decrypt(oCC3.CCNumber, ConfigurationManager.AppSettings["encryptionKey"]).Trim(), true);
                            oUserDAO.DisableCard(oCC3.CCNumber, false);
                        }

                        //back up 
                        //Session["cc"] = "06X2zNLCVp5Zu6fDJPImFxLXlUEJ+4RqWskK1y3vbBAj4H3IvdxFOpE013nbdNaD";
                        //thecc = DAO.Decrypt("06X2zNLCVp5Zu6fDJPImFxLXlUEJ+4RqWskK1y3vbBAj4H3IvdxFOpE013nbdNaD", ConfigurationManager.AppSettings["encryptionKey"]).Trim();
                        //thecvv = "169";
                        //expDate = "0820";
                        //ZIP = "33417";

                        //await PostRequest("https://www.metropcs.com/apps/mpcs/servlet/paymentservlet?inputReqParam={'serviceName':'paymentManagementService','serviceProviderName':'applicationSpecific','expectedParams':{},'backupPaymentMode':'false','requestParams':{'authorizePaymentParams':{'mdn':'" + phone + "','FirstName':'" + GenerateName(5) + "','LastName':'" + GenerateName(6) + "','CardNumber':'" + thecc + "','ExpirationDate':'" + expDate + "','ZipCode':'" + ZIP + "','clientId':'TMOBILE','CardVerificationCode':'" + thecvv + "','confirmationEmailAddress':'9874559@gmail.com','ServicePaymentAmountSG':'" + provideramount + "','isDebitPreferred':'true','cardType':'VISA'},'mdn':'" + phone + "','subId':''},'componentId':'authorizePaymentAndSaveContact','applicationId':'metropcs','siteId':'metropcs'}");
                    }
                }

                if (Session["error"].ToString().Contains("10000115") || Session["error"].ToString().Contains("10000013") || Session["error"].ToString().Contains("10000012") || Session["error"].ToString().Contains("false") || Session["error"].ToString().Contains("errorCode") || Session["error"].ToString().Contains("error4") || Session["error"].ToString().Contains("error99") || Session["error"].ToString().Contains("error5") || Session["error"].ToString().Contains("error18"))
                {
                    if (UserCookie.Value != "FastPay Online")
                    {
                        //if (oCC.Used != null)
                        //{
                        //   oUserDAO.DisableCard(oCC.CCNumber, false);
                        //}
                        if (oCC2.Used != null)
                        {
                            oUserDAO.DisableCard(oCC2.CCNumber, false);
                        }
                        else if (oCC3.Used != null)
                        {
                            oUserDAO.DisableCard(oCC3.CCNumber, false);
                        }
                    }

                    Response.Redirect("Splash.aspx?Phone=" + phone.Replace("-", "") + "&datepaid=" + DateTime.Now + "&provider=" + Session["provider"].ToString() + "&providerText=" + Session["providerText"].ToString() + "&cc=" + Session["cc"].ToString() + "&providerAmount=" + Session["providerAmount"].ToString() + "&error=" + Session["error"].ToString() + "&conf=" + Session["conf"].ToString() + "&amount=" + Session["totalamount"].ToString(), false);
                }


                ddProviders.SelectedValue = "0";
                txtPhone.Text = "";
                txtAmount.Text = "";
                lbInfo.Text = "";

                if (Session["conf"].ToString().Length > 4)
                {
                    Response.Redirect("Splash.aspx?Phone=" + phone.Replace("-", "") + "&datepaid=" + DateTime.Now + "&provider=" + Session["provider"].ToString() + "&providerText=" + Session["providerText"].ToString() + "&cc=" + Session["cc"].ToString() + "&providerAmount=" + Session["providerAmount"].ToString() + "&error=" + Session["error"].ToString() + "&conf=" + Session["conf"].ToString() + "&amount=" + Session["totalamount"].ToString(), false);
                }

                if (Session["error"].ToString() == "error1" || Session["error"].ToString() == "error3" || Session["error"].ToString() == "error13" || Session["error"].ToString() == "errorDup")
                {
                    Response.Redirect("Splash.aspx?Phone=" + phone.Replace("-", "") + "&datepaid=" + DateTime.Now + "&provider=" + Session["provider"].ToString() + "&providerText=" + Session["providerText"].ToString() + "&cc=" + Session["cc"].ToString() + "&providerAmount=" + Session["providerAmount"].ToString() + "&error=" + Session["error"].ToString() + "&conf=" + Session["conf"].ToString() + "&amount=" + Session["totalamount"].ToString(), false);
                }


            }

            catch (Exception ex)
            {
                TextAndEmail("Error: " + Session["provider"].ToString() + " might be down", ex + " try to make payment " + UserCookie.Value, true);
                oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), Session["cc"].ToString(), Session["provider"].ToString() + "($" + Session["provideramount"].ToString() + ") - " + ex.ToString());
                ScriptManager.RegisterStartupScript(this, typeof(string), "Alert", "alert('Metro is expiriencing technical difficulties, please call 561-860-5276');", true);
                lbInfo.Text = "Metro is expiriencing technical difficulties, please call 561-860-5276";
                lbInfo.ForeColor = Color.Red;

                // ManualPayment();
                //Session["providerText"] = "@mymetropcs.com";
                //Session["offeringid"] = "30164680";
                //usesShortCode = false;

                //DPMobilePayment();

            }
        }
        public void ManualPayment()
        {
            //update credit line
            MetroFastPayLibrary.Account oAccount = new MetroFastPayLibrary.Account();
            oAccount = oUserDAO.RetrieveAccount(UserCookie.Value);

            User oFee = new User();
            oFee = oUserDAO.RetrieveFeebyUserID(UserCookie.Value);
            int doublepay = getPreviousPayment(Session["Phone"].ToString());
            double conf = getConf(Session["provider"].ToString()) + 1;
            string cc = "jNgIidwGeXIvGWnBgyr+VPaSRZ328OYRTL7VUmuNRPTve8ieKoTjk7upoZ3oicBb";
            //if (Session["provider"].ToString() == "MetroPCS" || Session["provider"].ToString() == "Boost")
            //{
            //    cc = "jNgIidwGeXIvGWnBgyr+VPaSRZ328OYRTL7VUmuNRPTve8ieKoTjk7upoZ3oicBb";
            //}
            //else
            //{
            //    cc = "7nqjU73xlX7XUPPicl4to8urStzwUH2jwrI6R+XvB1I42EKi55cDaMwoyEJ/gB95";
            //}
            if (oAccount.Active == true)
            {

                if (doublepay >= 1)
                {
                    oUserDAO.UpdateAccountbyPost(oAccount.Credit - Convert.ToInt32(txtAmount.Text), oUser.Post);
                    oUserDAO.InsertPayments(UserCookie.Value, oUser.Post, Session["Phone"].ToString(), Convert.ToDecimal(Session["provideramount"].ToString()), 0, Session["provider"].ToString() + " - Conf#:" + conf, cc, DateTime.Now);

                }
                else
                {
                    oUserDAO.UpdateAccountbyPost(oAccount.Credit - (Convert.ToInt32(txtAmount.Text) + (Convert.ToInt32(oFee.Fee) - (Convert.ToInt32(oFee.Fee) - 2))), oUser.Post);
                    oUserDAO.InsertPayments(UserCookie.Value, oUser.Post, Session["Phone"].ToString(), Convert.ToDecimal(Session["provideramount"].ToString()), Convert.ToDecimal(oFee.Fee), Session["provider"].ToString() + " - Conf#:" + conf, cc, DateTime.Now);

                }
            }
            else
            {
                if (doublepay >= 1)
                {
                    //insert payments
                    oUserDAO.InsertPayments(UserCookie.Value, oUser.Post, Session["Phone"].ToString(), Convert.ToDecimal(Session["provideramount"].ToString()), 0, Session["provider"].ToString() + " - Conf#:" + conf, cc, DateTime.Now);

                }
                else
                {
                    //insert payments
                    oUserDAO.InsertPayments(UserCookie.Value, oUser.Post, Session["Phone"].ToString(), Convert.ToDecimal(Session["provideramount"].ToString()), Convert.ToDecimal(oFee.Fee), Session["provider"].ToString() + " - Conf#:" + conf, cc, DateTime.Now);

                }
            }

            //ip capture
            Payment oPayment = new Payment();
            oPayment = oUserDAO.RetrievePaymentbyConfID(conf.ToString());
            oUserDAO.InsertIP(UserCookie.Value, GetIPAddress(), oPayment.ID);
            if (Session["provider"].ToString() == "Boost")
            {
                oUserDAO.InsertUserPin(Session["Phone"].ToString(), txtPin.Text);
                TextAndEmailNew("Make Payment for " + Session["provider"].ToString(), "#: " + Session["Phone"].ToString() + "| Pin: " + txtPin.Text + "| Amount: " + Session["provideramount"].ToString() + "| User: " + UserCookie.Value, true);
            }
            else
            {
                TextAndEmailNew("Make Payment for " + Session["provider"].ToString(), "#: " + Session["Phone"].ToString() + "| Amount: " + Session["provideramount"].ToString() + "| User: " + UserCookie.Value, true);
            }
            Response.Redirect("Splash.aspx?Phone=" + Session["Phone"].ToString().Replace("-", "") + "&datepaid=" + DateTime.Now + "&provider=" + Session["provider"].ToString() + "&providerText=" + Session["providerText"].ToString() + "&cc=" + cc + "&providerAmount=" + Session["providerAmount"].ToString() + "&error=&conf=" + conf + "&amount=" + Session["totalamount"].ToString(), false);

        }
        public async void ManualPaymentMetro(string phone, string amount, string thecc, string expDate, string cvv)
        {
            //update credit line
            MetroFastPayLibrary.Account oAccount = new MetroFastPayLibrary.Account();
            oAccount = oUserDAO.RetrieveAccount(UserCookie.Value);

            User oFee = new User();
            oFee = oUserDAO.RetrieveFeebyUserID(UserCookie.Value);
            int doublepay = getPreviousPayment(Session["Phone"].ToString());
            double conf = getConf(Session["provider"].ToString()) + 1;
            string cc = thecc;
            cc = DAO.Encrypt(cc, ConfigurationManager.AppSettings["encryptionKey"]).Trim();
            
            if (oAccount.Active == true)
            {

                if (doublepay >= 1)
                {
                    oUserDAO.UpdateAccountbyPost(oAccount.Credit - Convert.ToInt32(txtAmount.Text), oUser.Post);
                    oUserDAO.InsertPayments(UserCookie.Value, oUser.Post, Session["Phone"].ToString(), Convert.ToDecimal(Session["provideramount"].ToString()), 0, Session["provider"].ToString() + " - Conf#:" + conf, cc, DateTime.Now);

                }
                else
                {
                    oUserDAO.UpdateAccountbyPost(oAccount.Credit - (Convert.ToInt32(txtAmount.Text) + (Convert.ToInt32(oFee.Fee) - (Convert.ToInt32(oFee.Fee) - 2))), oUser.Post);
                    oUserDAO.InsertPayments(UserCookie.Value, oUser.Post, Session["Phone"].ToString(), Convert.ToDecimal(Session["provideramount"].ToString()), Convert.ToDecimal(oFee.Fee), Session["provider"].ToString() + " - Conf#:" + conf, cc, DateTime.Now);

                }
            }
            else
            {
                if (doublepay >= 1)
                {
                    //insert payments
                    oUserDAO.InsertPayments(UserCookie.Value, oUser.Post, Session["Phone"].ToString(), Convert.ToDecimal(Session["provideramount"].ToString()), 0, Session["provider"].ToString() + " - Conf#:" + conf, cc, DateTime.Now);

                }
                else
                {
                    //insert payments
                    oUserDAO.InsertPayments(UserCookie.Value, oUser.Post, Session["Phone"].ToString(), Convert.ToDecimal(Session["provideramount"].ToString()), Convert.ToDecimal(oFee.Fee), Session["provider"].ToString() + " - Conf#:" + conf, cc, DateTime.Now);

                }
            }

            await payMetroByPhone(phone, txtAmount.Text, thecc, expDate, cvv);

            //ip capture
            Payment oPay = new Payment();
            oPay = oUserDAO.RetrievePaymentbyConfID(conf.ToString());
            oUserDAO.InsertIP(UserCookie.Value, GetIPAddress(), oPay.ID);

            Payment oPaySID = new Payment();
            oPaySID = oUserDAO.RetrieveSIDbyPaymentID(Convert.ToInt32(oPay.ID));
           
            string pageurl = "https://" + Request.Url.Authority + "/getconf.aspx?CAsid=" + oPaySID.SID + "&amount=" + oPay.AmountPaid + "&number=" + oPay.PhoneNumber + "&paymentid=" + oPay.ID + "&time=" + WebUtility.UrlEncode(oPay.CreatedDate.ToString()) + "&user=" + oPay.UserID;
            TextAndEmailNew("Payment made by phone for " + Session["provider"].ToString(), "#: " + Session["Phone"].ToString() + "| Amount: " + Session["provideramount"].ToString() + "| User: " + UserCookie.Value + " | View: " + pageurl , true);
            
            Response.Redirect("Splash.aspx?Phone=" + Session["Phone"].ToString().Replace("-", "") + "&datepaid=" + DateTime.Now + "&provider=" + Session["provider"].ToString() + "&providerText=" + Session["providerText"].ToString() + "&cc=" + cc + "&providerAmount=" + Session["providerAmount"].ToString() + "&error=&conf=" + conf + "&amount=" + Session["totalamount"].ToString(), false);

        }
        public void ManualBoost(string cc)
        {
            //update credit line
            MetroFastPayLibrary.Account oAccount = new MetroFastPayLibrary.Account();
            oAccount = oUserDAO.RetrieveAccount(UserCookie.Value);
            cc = DAO.Encrypt(cc, ConfigurationManager.AppSettings["encryptionKey"]).Trim();
            User oFee = new User();
            oFee = oUserDAO.RetrieveFeebyUserID(UserCookie.Value);
            int doublepay = getPreviousPayment(Session["Phone"].ToString());
            double conf = getConf(Session["provider"].ToString()) + 1;
            //string cc = "jNgIidwGeXIvGWnBgyr+VOC/awsJU/q/ZU+44bSA9HnniST6FHiyUHMF4BPBBIQa";
            //if (Session["provider"].ToString() == "MetroPCS" || Session["provider"].ToString() == "Boost")
            //{
            //    cc = "jNgIidwGeXIvGWnBgyr+VPaSRZ328OYRTL7VUmuNRPTve8ieKoTjk7upoZ3oicBb";
            //}
            //else
            //{
            //    cc = "7nqjU73xlX7XUPPicl4to8urStzwUH2jwrI6R+XvB1I42EKi55cDaMwoyEJ/gB95";
            //}
            if (oAccount.Active == true)
            {

                if (doublepay >= 1)
                {
                    oUserDAO.UpdateAccountbyPost(oAccount.Credit - Convert.ToInt32(txtAmount.Text), oUser.Post);
                    oUserDAO.InsertPayments(UserCookie.Value, oUser.Post, Session["Phone"].ToString(), Convert.ToDecimal(Session["provideramount"].ToString()), 0, Session["provider"].ToString() + " - Conf#:" + conf, cc, DateTime.Now);

                }
                else
                {
                    oUserDAO.UpdateAccountbyPost(oAccount.Credit - (Convert.ToInt32(txtAmount.Text) + (Convert.ToInt32(oFee.Fee) - (Convert.ToInt32(oFee.Fee) - 2))), oUser.Post);
                    oUserDAO.InsertPayments(UserCookie.Value, oUser.Post, Session["Phone"].ToString(), Convert.ToDecimal(Session["provideramount"].ToString()), Convert.ToDecimal(oFee.Fee), Session["provider"].ToString() + " - Conf#:" + conf, cc, DateTime.Now);

                }
            }
            else
            {
                if (doublepay >= 1)
                {
                    //insert payments
                    oUserDAO.InsertPayments(UserCookie.Value, oUser.Post, Session["Phone"].ToString(), Convert.ToDecimal(Session["provideramount"].ToString()), 0, Session["provider"].ToString() + " - Conf#:" + conf, cc, DateTime.Now);

                }
                else
                {
                    //insert payments
                    oUserDAO.InsertPayments(UserCookie.Value, oUser.Post, Session["Phone"].ToString(), Convert.ToDecimal(Session["provideramount"].ToString()), Convert.ToDecimal(oFee.Fee), Session["provider"].ToString() + " - Conf#:" + conf, cc, DateTime.Now);

                }
            }

            //ip capture
            Payment oPayment = new Payment();
            oPayment = oUserDAO.RetrievePaymentbyConfID(conf.ToString());
            oUserDAO.InsertIP(UserCookie.Value, GetIPAddress(), oPayment.ID);
            oUserDAO.InsertUserPin(Session["Phone"].ToString(), txtPin.Text);
            TextAndEmail("Payment being made by phone for " + Session["provider"].ToString(), "#: " + Session["Phone"].ToString() + "| Pin: " + txtPin.Text + "| Amount: " + Session["provideramount"].ToString() + "| User: " + UserCookie.Value, true);

            Response.Redirect("Splash.aspx?Phone=" + Session["Phone"].ToString().Replace("-", "") + "&datepaid=" + DateTime.Now + "&provider=" + Session["provider"].ToString() + "&providerText=" + Session["providerText"].ToString() + "&cc=" + cc + "&providerAmount=" + Session["providerAmount"].ToString() + "&error=&conf=" + conf + "&amount=" + Session["totalamount"].ToString(), false);

        }
        public async void CricketPayment()
        {
            try
            {
                Payment oPay = new Payment();
                oPay = oUserDAO.RetrieveLastPayment(UserCookie.Value);
                User oDisUser = new User();
                User oFee = new User();
                oFee = oUserDAO.RetrieveFeebyUserID(UserCookie.Value);
                if (oPay.AmountPaid == 204 && oPay.CreatedDate.ToString("dd/MM/yyyy") == DateTime.Now.ToString("dd/MM/yyyy"))
                {
                    oDisUser = oUserDAO.DisableAccount(UserCookie.Value, false);
                }

                CC oCC = new CC();
                oCC = oUserDAO.RetrieveCricketCC();
                CC oCC2 = new CC();
                oCC2 = oUserDAO.RetrieveCricketCC();
                CC oCC3 = new CC();
                oCC3 = oUserDAO.RetrieveCricketCC();



                string phone = "";
                decimal totalamount = 0;
                decimal provideramount = 0;
                if (txtAmount.Text == "")
                {
                    phone = Session["phone"].ToString();
                    totalamount = Convert.ToDecimal(Session["totalamount"]);
                    provideramount = Convert.ToDecimal(Session["provideramount"]);
                }
                else
                {
                    totalamount = decimal.Parse(txtAmount.Text) + Convert.ToInt32(oFee.Fee);
                    provideramount = decimal.Parse(txtAmount.Text);
                    if (provideramount.ToString().Contains("."))
                    {

                    }
                    else
                    {
                        provideramount = Convert.ToDecimal(string.Format("{0:0.00}", provideramount));
                    }

                    Session["totalamount"] = totalamount;
                    Session["providerAmount"] = provideramount;
                    Session["provider"] = ddProviders.SelectedItem.Text;
                    phone = txtPhone.Text.Replace("-", "").Replace("(", "").Replace(")", "");
                    Session["phone"] = phone;


                }

                if (UserCookie.Value != "FastPay Online")
                {

                    string thecc = "";
                    string thecvv = "";
                    string expDate = "";
                    string ZIP = "";
                    if (oCC.Used != null)
                    {
                        string cc = oCC.CCNumber;
                        Session["cc"] = cc;
                        thecc = DAO.Decrypt(oCC.CCNumber, ConfigurationManager.AppSettings["encryptionKey"]).Trim();
                        thecvv = oCC.CVV.Trim();
                        expDate = oCC.ExpDate;
                        ZIP = oCC.ZIP;
                    }
                    else if (oCC2.Used != null)
                    {
                        string cc = oCC2.CCNumber;
                        Session["cc"] = cc;
                        thecc = DAO.Decrypt(oCC2.CCNumber, ConfigurationManager.AppSettings["encryptionKey"]).Trim();
                        thecvv = oCC2.CVV.Trim();
                        expDate = oCC2.ExpDate;
                        ZIP = oCC2.ZIP;

                    }
                    else if (oCC3.Used != null)
                    {
                        string cc = oCC3.CCNumber;
                        Session["cc"] = cc;
                        thecc = DAO.Decrypt(oCC3.CCNumber, ConfigurationManager.AppSettings["encryptionKey"]).Trim();
                        thecvv = oCC3.CVV.Trim();
                        expDate = oCC3.ExpDate;
                        ZIP = oCC3.ZIP;

                    }
                    if (oCC3.Used == null && oCC2.Used == null && oCC.Used == null)
                    {
                        //text
                        TextAndEmail("Telbug Error", "no cards in the system for cricket, switched to manual payments", true);
                        //Turn manual payments on
                        //oUserDAO.UpdateServiceActivity(2, false);
                        //makes manual payment
                        //User cricket = oUserDAO.RetrieveServiceActivity(2);
                        // if (cricket.Active == false)
                        //{
                        ManualPayment();
                        return;
                        //}

                    }

                    if (oCC3.Used == null)
                    {
                        Response.Redirect("Splash.aspx?Phone=" + phone.Replace("-", "") + "&datepaid=" + DateTime.Now + "&provider=" + Session["provider"].ToString() + "&providerText=" + Session["providerText"].ToString() + "&cc=" + Session["cc"].ToString() + "&providerAmount=" + Session["providerAmount"].ToString() + "&error=" + Session["error"].ToString() + "&conf=" + Session["conf"].ToString() + "&amount=" + Session["totalamount"].ToString(), false);
                    }

                    ////splash page if no error
                    //if (Session["error"].ToString() == "")
                    //{
                    string newexp = expDate.Replace("/", "");
                   // await paycriket(txtAmount.Text, ZIP, phone, thecc, GenerateName(6), newexp, thecvv);
                    await payCricketAPI(txtAmount.Text, phone, thecc, thecvv, newexp);
                    // }
                }
                else
                {
                    //FastPay online
                        await GetCityandState("http://www.zipcodeapi.com/rest/jMhIO8BPVggglYdeUPMraJHIL0gFiC4QH59rCBTlhr5UrjMMDxOaAlXpeaDihOtQ/info.json/" + txtZip.Text + "/radians");
                        Session["cc"] = "GAMFQB336+lBhwhfoORRfL4cmy+/N1nZSUmre8T4D/A+2KRc9KvmVwsSNLXxc4aY";
                         string newexp = txtExpDate.Text.Replace("/", "");
                        await paycriket(txtAmount.Text, txtZip.Text, phone, txtCC.Text, txtFirstName.Text + " " + txtLastName.Text, newexp, txtCVV.Text);
                        AuthorizePayment(txtFirstName.Text, txtLastName.Text, "0987" + GenerateName(6) + "Rd", Session["City"].ToString(), Session["State"].ToString(), txtZip.Text, "USA", 3, txtCC.Text, txtExpDate.Text, txtCVV.Text, Session["provider"].ToString() + " payments made with FastPay Online", "FastPay Online ", Session["provider"].ToString() + " payment made for # " + phone + " in the amount of " + txtAmount.Text);

                }
                //if (UserCookie.Value != "FastPay Online")
                //{
                //    if (Session["error"].ToString().Contains("error"))
                //    {
                //        string Cricketcc = DAO.Decrypt("JON3ludockZL+OfWGKrxV5Qx8J0KlaelHmTFakiDxcDQbZeog6gG8wBHx++fgaR/", ConfigurationManager.AppSettings["encryptionKey"]).Trim();
                //        string CricketcardExpirationDate = "0920";
                //        string cvv = "285";
                //        string zip = "33463";
                //        Session["cc"] = "JON3ludockZL+OfWGKrxV5Qx8J0KlaelHmTFakiDxcDQbZeog6gG8wBHx++fgaR/";
                //        await paycriket(txtAmount.Text, zip, phone, Cricketcc, GenerateName(6), CricketcardExpirationDate, cvv);
                //    }
                //}

                if (Session["error"].ToString().Contains("10000115"))
                {
                    Session["error"] = "error2";
                    Response.Redirect("Splash.aspx?Phone=" + phone.Replace("-", "") + "&datepaid=" + DateTime.Now + "&provider=" + Session["provider"].ToString() + "&providerText=" + Session["providerText"].ToString() + "&cc=" + Session["cc"].ToString() + "&providerAmount=" + Session["providerAmount"].ToString() + "&error=" + Session["error"].ToString() + "&conf=" + Session["conf"].ToString() + "&amount=" + Session["totalamount"].ToString(), false);
                }

                if (UserCookie.Value != "FastPay Online")
                {
                    if (Session["error"].ToString().Contains("error") || Session["error"].ToString().Contains("error3") || Session["error"].ToString().Contains("error6"))
                    {

                        //if (oCC.Used != null)
                        //{
                        //    oUserDAO.DisableCard(oCC.CCNumber, false);
                        //}
                        //else if (oCC2.Used != null)
                        //{
                        //    oUserDAO.DisableCard(oCC2.CCNumber, false);
                        //}
                        //else if (oCC3.Used != null)
                        //{
                        //    oUserDAO.DisableCard(oCC3.CCNumber, false);
                        //}

                        Response.Redirect("Splash.aspx?Phone=" + phone.Replace("-", "") + "&datepaid=" + DateTime.Now + "&provider=" + Session["provider"].ToString() + "&providerText=" + Session["providerText"].ToString() + "&cc=" + Session["cc"].ToString() + "&providerAmount=" + Session["providerAmount"].ToString() + "&error=" + Session["error"].ToString() + "&conf=" + Session["conf"].ToString() + "&amount=" + Session["totalamount"].ToString(), false);
                    }
                }

                ddProviders.SelectedValue = "0";
                txtPhone.Text = "";
                txtAmount.Text = "";
                lbInfo.Text = "";

                if (Session["error"].ToString() == "error1" || Session["error"].ToString() == "errorLockedAccount")
                {
                    Response.Redirect("Splash.aspx?Phone=" + phone.Replace("-", "") + "&datepaid=" + DateTime.Now + "&provider=" + Session["provider"].ToString() + "&providerText=" + Session["providerText"].ToString() + "&cc=" + Session["cc"].ToString() + "&providerAmount=" + Session["providerAmount"].ToString() + "&error=" + Session["error"].ToString() + "&conf=" + Session["conf"].ToString() + "&amount=" + Session["totalamount"].ToString(), false);
                }

                if (Session["conf"].ToString().Length > 8)
                {
                    Response.Redirect("Splash.aspx?Phone=" + phone.Replace("-", "") + "&datepaid=" + DateTime.Now + "&provider=" + Session["provider"].ToString() + "&providerText=" + Session["providerText"].ToString() + "&cc=" + Session["cc"].ToString() + "&providerAmount=" + Session["providerAmount"].ToString() + "&error=" + Session["error"].ToString() + "&conf=" + Session["conf"].ToString() + "&amount=" + Session["totalamount"].ToString(), false);
                }
            }
            catch (Exception ex)
            {
                TextAndEmail("Error: " + Session["provider"].ToString() + " might be down", ex + " try to make payment " + UserCookie.Value, true);
                oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), Session["cc"].ToString(), Session["provider"].ToString() + "($" + Session["provideramount"].ToString() + ") - " + ex.ToString());
                lbInfo.Text = "Cricket is experiencing technical difficulties, please call 561-860-5276";
                lbInfo.ForeColor = Color.Red;
            }
        }

        public async void BoostPayment()
        {
            try
            {
                Payment oPay = new Payment();
                oPay = oUserDAO.RetrieveLastPayment(UserCookie.Value);
                User oDisUser = new User();
                User oFee = new User();
                oFee = oUserDAO.RetrieveFeebyUserID(UserCookie.Value);
                if (oPay.AmountPaid == 204 && oPay.CreatedDate.ToString("dd/MM/yyyy") == DateTime.Now.ToString("dd/MM/yyyy"))
                {
                    oDisUser = oUserDAO.DisableAccount(UserCookie.Value, false);
                }

                CC oCC = new CC();
                oCC = oUserDAO.RetrieveBoostCC();
                CC oCC2 = new CC();
                oCC2 = oUserDAO.RetrieveBoostCC2();
                CC oCC3 = new CC();
                oCC3 = oUserDAO.RetrieveBoostCC3();

                string phone = "";
                decimal totalamount = 0;
                decimal provideramount = 0;
                if (txtAmount.Text == "")
                {
                    phone = Session["phone"].ToString();
                    totalamount = Convert.ToDecimal(Session["totalamount"]);
                    provideramount = Convert.ToDecimal(Session["provideramount"]);
                }
                else
                {
                    totalamount = decimal.Parse(txtAmount.Text) + Convert.ToInt32(oFee.Fee);
                    provideramount = decimal.Parse(txtAmount.Text);
                    if (provideramount.ToString().Contains("."))
                    {

                    }
                    else
                    {
                        provideramount = Convert.ToDecimal(string.Format("{0:0.00}", provideramount));
                    }

                    Session["totalamount"] = totalamount;
                    Session["providerAmount"] = provideramount;
                    Session["provider"] = ddProviders.SelectedItem.Text;
                    phone = txtPhone.Text.Replace("-", "").Replace("(", "").Replace(")", "");
                    Session["phone"] = phone;
                    Session["pin"] = txtPin.Text;


                }

                //await CheckBoost("https://aka-apiservices.boostmobile.com/api/prepaid/1.0/accounts/" + phone + "/validate?idField=mdn", phone, txtPin.Text);
                await CheckBoost("https://aka-apiservices.boostmobile.com/api/prepaid/authentication/1.0/login", phone, txtPin.Text);
                //await CheckBoost("https://aka-apiservices.boostmobile.com/api/prepaid/1.0/accounts/" + phone + "/validate?idField=mdn", phone);//, Convert.ToDouble(txtAmount.Text), Session["soc"].ToString());

                if (UserCookie.Value != "FastPay Online")
                {
                    string thecc = "";
                    string thecvv = "";
                    string expDate = "";
                    string ZIP = "";

                    if (oCC.Used != null)
                    {
                        string cc = oCC.CCNumber;
                        Session["cc"] = cc;
                        thecc = DAO.Decrypt(oCC.CCNumber, ConfigurationManager.AppSettings["encryptionKey"]).Trim();
                        thecvv = oCC.CVV.Trim();
                        expDate = oCC.ExpDate;
                        ZIP = oCC.ZIP;
                    }
                    else if (oCC2.Used != null)
                    {
                        string cc = oCC2.CCNumber;
                        Session["cc"] = cc;
                        thecc = DAO.Decrypt(oCC2.CCNumber, ConfigurationManager.AppSettings["encryptionKey"]).Trim();
                        thecvv = oCC2.CVV.Trim();
                        expDate = oCC2.ExpDate;
                        ZIP = oCC2.ZIP;

                    }
                    else if (oCC3.Used != null)
                    {
                        string cc = oCC3.CCNumber;
                        Session["cc"] = cc;
                        thecc = DAO.Decrypt(oCC3.CCNumber, ConfigurationManager.AppSettings["encryptionKey"]).Trim();
                        thecvv = oCC3.CVV.Trim();
                        expDate = oCC3.ExpDate;
                        ZIP = oCC3.ZIP;

                    }
                    if (oCC3.Used == null && oCC2.Used == null && oCC.Used == null)
                    {
                        //text
                        TextAndEmail("Telbug Error", "no cards in the system for boost, switched to manual payments", true);
                        //Turn manual payments on
                        //oUserDAO.UpdateServiceActivity(3, false);
                        //makes manual payment
                        Session["cc"] = "jNgIidwGeXIvGWnBgyr+VPaSRZ328OYRTL7VUmuNRPTve8ieKoTjk7upoZ3oicBb";
                        if (Session["error"].ToString() != "error1")
                        {
                            ManualPayment();
                            return;  
                        }
                    }

                    //splash page if no error
                    if (Session["error"].ToString() == "")
                    {
                      await payBoost("https://aka-apiservices.boostmobile.com/api/prepaid/payments/1.0/accounts/" + phone + "/funds/creditcard", Convert.ToDouble(txtAmount.Text), ZIP, phone, thecc, GenerateName(6), expDate, thecvv);               
                    }
                   
                    //phone back up payments 
                    //await payBoostByPhone(phone, txtPin.Text, txtAmount.Text, thecc, expDate, thecvv );
                    //await payBoostByPhoneBackUp(phone, txtPin.Text, txtAmount.Text, thecc, expDate, thecvv);
                    //ManualBoost(thecc);
                    //return;
                }
                else
                {

                    //FastPay Online 
                    //await CheckTokenIDBoost("https://aka-apiservices.boostmobile.com/api/prepaid/authentication/1.0/login", phone, txtPin.Text);
                    if (Session["error"].ToString() == "")
                    {

                        await GetCityandState("http://www.zipcodeapi.com/rest/jMhIO8BPVggglYdeUPMraJHIL0gFiC4QH59rCBTlhr5UrjMMDxOaAlXpeaDihOtQ/info.json/" + txtZip.Text + "/radians");
                        await payBoost("https://aka-apiservices.boostmobile.com/api/prepaid/payments/1.0/accounts/" + phone + "/funds/creditcard", Convert.ToDouble(txtAmount.Text), txtZip.Text, phone, txtCC.Text, GenerateName(6), txtExpDate.Text, txtCVV.Text);

                        // Session["cc"] = "GAMFQB336+lBhwhfoORRfL4cmy+/N1nZSUmre8T4D/A+2KRc9KvmVwsSNLXxc4aY";

                        //    if (txtPin.Text == "")
                        //    {
                        //        await payBoostGift("https://aka-apiservices.boostmobile.com/api/prepaid/payments/1.0/accounts/" + phone + "/guest/funds/creditcard", Convert.ToDouble(txtAmount.Text), txtZip.Text, phone, txtCC.Text, GenerateName(6), txtExpDate.Text, txtCVV.Text);
                        //await payBoostByPhone(phone, txtPin.Text, txtAmount.Text, txtCC.Text, txtExpDate.Text, txtCVV.Text);
                        //await payBoostByPhoneBackUp(phone, txtPin.Text, txtAmount.Text, txtCC.Text, txtExpDate.Text, txtCVV.Text);
                        //ManualBoost(txtCC.Text);
                        //return;
                        //    }
                        //    else
                        //    {
                        //        await CheckTokenIDBoost("https://aka-apiservices.boostmobile.com/api/prepaid/authentication/1.0/login", phone, txtPin.Text);
                        //        if (Session["error"].ToString() == "")
                        //        {
                        //            await payBoost("https://aka-apiservices.boostmobile.com/api/prepaid/payments/1.0/accounts/" + phone + "/funds/creditcard", Convert.ToDouble(txtAmount.Text), txtZip.Text, phone, txtCC.Text, GenerateName(6), txtExpDate.Text, txtCVV.Text, Session["access_token"].ToString());
                        //        }
                        //    }

                        // AuthorizePayment(txtFirstName.Text, txtLastName.Text, "0987" + GenerateName(6) + "Rd", Session["City"].ToString(), Session["State"].ToString(), txtZip.Text, "USA", 3, txtCC.Text, txtExpDate.Text, txtCVV.Text, Session["provider"].ToString() + " payments made with FastPay Online", "FastPay Online ", Session["provider"].ToString() + " payment made for # " + phone + " in the amount of " + txtAmount.Text);

                    }
                }
                if (Session["error"].ToString() == "error1" || Session["error"].ToString() == "error2" || Session["error"].ToString().Contains("errorPin") || Session["error"].ToString().Contains("errorLockBoost") || Session["error"].ToString().Contains("errorLockBoost2"))
                {
                    ddProviders.SelectedValue = "0";
                    txtPhone.Text = "";
                    txtAmount.Text = "";
                    lbInfo.Text = "";

                    Response.Redirect("Splash.aspx?Phone=" + phone + "&datepaid=" + DateTime.Now + "&provider=" + Session["provider"].ToString() + "&providerText=" + Session["providerText"].ToString() + "&cc=" + Session["cc"].ToString() + "&providerAmount=" + Session["providerAmount"].ToString() + "&error=" + Session["error"].ToString() + "&conf=" + Session["conf"].ToString() + "&amount=" + Session["totalamount"].ToString(), false);

                }

                if ((Session["error"].ToString().Contains("errors") || Session["error"].ToString().Contains("FAILURE") || Session["error"].ToString().Contains("error2") || Session["error"].ToString().Contains("error3") || Session["error"].ToString().Contains("error4")
                    || Session["error"].ToString().Contains("error5") || Session["error"].ToString().Contains("errorLockedAccount")) && Session["error"].ToString() != "error1" || Session["error"].ToString().Contains("error18"))
                {
                    if (UserCookie.Value != "FastPay Online")
                    {
                        //if (oCC.Used == null)
                        //{
                        //    TextAndEmail("Telbug Error", "no cards in the system for boost, switched to manual payments", true);
                        //    //oUserDAO.UpdateServiceActivity(3, false);
                        //    // Response.Redirect("Splash.aspx?Phone=" + phone.Replace("-", "") + "&datepaid=" + DateTime.Now + "&provider=" + Session["provider"].ToString() + "&providerText=" + Session["providerText"].ToString() + "&cc=" + Session["cc"].ToString() + "&providerAmount=" + Session["providerAmount"].ToString() + "&error=" + Session["error"].ToString() + "&conf=" + Session["conf"].ToString() + "&amount=" + Session["totalamount"].ToString(), false);
                        //}
                        if (oCC.Used != null && Session["error"].ToString() != "error5")
                        {
                            oUserDAO.DisableCard(oCC.CCNumber, false);
                        }
                        else if (oCC2.Used != null && Session["error"].ToString() != "error5")
                        {
                            oUserDAO.DisableCard(oCC2.CCNumber, false);
                        }
                        else if (oCC3.Used != null && Session["error"].ToString() != "error5")
                        {
                            oUserDAO.DisableCard(oCC3.CCNumber, false);
                        }
                    }
                    Response.Redirect("Splash.aspx?Phone=" + phone.Replace("-", "") + "&datepaid=" + DateTime.Now + "&provider=" + Session["provider"].ToString() + "&providerText=" + Session["providerText"].ToString() + "&cc=" + Session["cc"].ToString() + "&providerAmount=" + Session["providerAmount"].ToString() + "&error=" + Session["error"].ToString() + "&conf=" + Session["conf"].ToString() + "&amount=" + Session["totalamount"].ToString(), false);



                }

                if (Session["conf"].ToString().Length > 5)
                {
                    ddProviders.SelectedValue = "0";
                    txtPhone.Text = "";
                    txtAmount.Text = "";
                    lbInfo.Text = "";

                    Response.Redirect("Splash.aspx?Phone=" + phone.Replace("-", "") + "&datepaid=" + DateTime.Now + "&provider=" + Session["provider"].ToString() + "&providerText=" + Session["providerText"].ToString() + "&cc=" + Session["cc"].ToString() + "&providerAmount=" + Session["providerAmount"].ToString() + "&error=" + Session["error"].ToString() + "&conf=" + Session["conf"].ToString() + "&amount=" + Session["totalamount"].ToString(), false);
                }

            }
            catch (Exception ex)
            {
                TextAndEmail("Error: " + Session["provider"].ToString() + " might be down", ex + " try to make payment " + UserCookie.Value, true);
                oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), Session["cc"].ToString(), Session["provider"].ToString() + "($" + Session["provideramount"].ToString() + ") - " + ex.ToString());
                lbInfo.Text = "Boost is experiencing technical difficulties, please call 561-860-5276";
                lbInfo.ForeColor = Color.Red;


            }
        }

        public async void SinPinPayment()
        {
            try
            {
                Payment oPay = new Payment();
                oPay = oUserDAO.RetrieveLastPayment(UserCookie.Value);
                User oDisUser = new User();
                User oFee = new User();
                oFee = oUserDAO.RetrieveFeebyUserID(UserCookie.Value);
                if (oPay.AmountPaid == 204 && oPay.CreatedDate.ToString("dd/MM/yyyy") == DateTime.Now.ToString("dd/MM/yyyy"))
                {
                    oDisUser = oUserDAO.DisableAccount(UserCookie.Value, false);
                }


                string phone = "";
                decimal totalamount = 0;
                decimal provideramount = 0;
                if (txtAmount.Text == "")
                {
                    phone = Session["phone"].ToString();
                    totalamount = Convert.ToDecimal(Session["totalamount"]);
                    provideramount = Convert.ToDecimal(Session["provideramount"]);
                }
                else
                {
                    totalamount = decimal.Parse(txtAmount.Text) + Convert.ToInt32(oFee.Fee);
                    provideramount = decimal.Parse(txtAmount.Text);
                    if (provideramount.ToString().Contains("."))
                    {

                    }
                    else
                    {
                        provideramount = Convert.ToDecimal(string.Format("{0:0.00}", provideramount));
                    }

                    Session["totalamount"] = totalamount;
                    Session["providerAmount"] = provideramount;
                    Session["provider"] = ddProviders.SelectedItem.Text;
                    phone = txtPhone.Text.Replace("-", "").Replace("(", "").Replace(")", "");
                    Session["phone"] = phone;
                }

                if (UserCookie.Value != "FastPay Online")
                {
                    //recharge SinPin
                    await checkSinPinAmount("https://webservice.sinpin.com/Agent/recharge/?Username=fandf.webapi&Password=Marcos2168!PB_561*!&apiKey=9e8roNDqY4Ssx6A607TxwYoJI0y246Ph&amount=" + provideramount + "&phone=" + phone);
                }
                else
                {
                    AuthorizePayment(txtFirstName.Text, txtLastName.Text, "0987" + GenerateName(6) + "Rd", Session["City"].ToString(), Session["State"].ToString(), txtZip.Text, "USA", Convert.ToInt32(provideramount), txtCC.Text, txtExpDate.Text, txtCVV.Text, Session["provider"].ToString() + " payments made with FastPay Online", "FastPay Online ", Session["provider"].ToString() + " payment made for # " + phone + " in the amount of " + txtAmount.Text);
                    if (MoneyWentThru == true)
                    {
                        await checkSinPinAmount("https://webservice.sinpin.com/Agent/recharge/?Username=fandf.webapi&Password=Marcos2168!PB_561*!&apiKey=9e8roNDqY4Ssx6A607TxwYoJI0y246Ph&amount=" + provideramount + "&phone=" + phone);
                    }
                    else
                    {
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Your credit card did not go through, please try again. Thank you for using Telbug')", true);
                    }

                }





                ddProviders.SelectedValue = "0";
                txtPhone.Text = "";
                txtAmount.Text = "";
                lbInfo.Text = "";

                if (Session["conf"].ToString().Length >= 8)
                {
                    string conf = Session["conf"].ToString();
                    string EN = Session["EnglishNumber"].ToString();
                    string SP = Session["SpanishNumber"].ToString();
                    string Balance = Session["Balance"].ToString();
                    string PrevBalance = "";
                    Response.Redirect("Splash.aspx?Phone=" + phone.Replace("-", "") + "&datepaid=" + DateTime.Now + "&provider=" + Session["provider"].ToString() + "&providerText=" + Session["providerText"].ToString() + "&cc=" + Session["cc"].ToString() + "&providerAmount=" + Session["providerAmount"].ToString() + "&error=" + Session["error"].ToString() + "&conf=" + conf + "&amount=" + Session["totalamount"].ToString() + "&EnglishNumber=" + EN + "&SpanishNumber=" + SP + "&Balance=" + Balance + "&PrevBalance=" + PrevBalance, false);
                }

                if (Session["error"].ToString() == "error3")
                {
                    Response.Redirect("Splash.aspx?Phone=" + phone.Replace("-", "") + "&datepaid=" + DateTime.Now + "&provider=" + Session["provider"].ToString() + "&providerText=" + Session["providerText"].ToString() + "&cc=" + Session["cc"].ToString() + "&providerAmount=" + Session["providerAmount"].ToString() + "&error=" + Session["error"].ToString() + "&conf=" + Session["conf"].ToString() + "&amount=" + Session["totalamount"].ToString(), false);
                }

            }
            catch (Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, typeof(string), "Alert", "alert('SinPin is expiriencing technical difficulties, please call 561-860-5276');", true);
                lbInfo.Text = "SinPin is expiriencing technical difficulties, please call 561-860-5276" + ex;
                lbInfo.ForeColor = Color.Red;
            }
        }


        public async void DollarPhonePayment()
        {
            try
            {
                Payment oPay = new Payment();
                oPay = oUserDAO.RetrieveLastPayment(UserCookie.Value);
                User oDisUser = new User();
                User oFee = new User();
                oFee = oUserDAO.RetrieveFeebyUserID(UserCookie.Value);
                if (oPay.AmountPaid == 204 && oPay.CreatedDate.ToString("dd/MM/yyyy") == DateTime.Now.ToString("dd/MM/yyyy"))
                {
                    oDisUser = oUserDAO.DisableAccount(UserCookie.Value, false);
                }

                User getComm = oUserDAO.RetrieveServiceActivity(5);
                string phone = "";
                decimal totalamount = 0;
                decimal provideramount = 0;
                int offeringid = 0;
                if (txtAmount.Text == "")
                {
                    phone = Session["phone"].ToString();
                    totalamount = Convert.ToDecimal(Session["totalamount"]);
                    provideramount = Convert.ToDecimal(Session["provideramount"]);
                }
                else
                {
                    totalamount = decimal.Parse(txtAmount.Text) + Convert.ToInt32(oFee.Fee);
                    provideramount = decimal.Parse(txtAmount.Text);
                    if (provideramount.ToString().Contains("."))
                    {

                    }
                    else
                    {
                        // provideramount = Convert.ToDecimal(string.Format("{0:0.00}", provideramount));
                    }

                    Session["totalamount"] = totalamount;
                    Session["providerAmount"] = provideramount;
                    Session["provider"] = ddProviders.SelectedItem.Text;
                    phone = txtPhone.Text.Replace("-", "").Replace("(", "").Replace(")", "");
                    Session["phone"] = phone;
                    offeringid = Convert.ToInt32(Session["offeringid"]);
                }


                if (UserCookie.Value == "FastPay Online")
                {
                    AuthorizePayment(txtFirstName.Text, txtLastName.Text, "0987" + GenerateName(6) + "Rd", Session["City"].ToString(), Session["State"].ToString(), txtZip.Text, "USA", Convert.ToInt32(provideramount), txtCC.Text, txtExpDate.Text, txtCVV.Text, Session["provider"].ToString() + " payments made with FastPay Online", "FastPay Online ", Session["provider"].ToString() + " payment made for # " + phone + " in the amount of " + txtAmount.Text);
                    if (MoneyWentThru == true)
                    {
                        //continue
                    }
                    else
                    {
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Your credit card did not go through, please try again. Thank you for using Telbug')", true);
                        Session["cc"] = "GAMFQB336+lBhwhfoORRfL4cmy+/N1nZSUmre8T4D/A+2KRc9KvmVwsSNLXxc4aY";
                        Session["conf"] = "";
                        Response.Redirect("Splash.aspx?Phone=" + phone.Replace("-", "") + "&datepaid=" + DateTime.Now + "&provider=" + Session["provider"].ToString() + "&providerText=" + Session["providerText"].ToString() + "&cc=" + Session["cc"].ToString() + "&providerAmount=" + Session["providerAmount"].ToString() + "&error=" + Session["error"].ToString() + "&conf=" + Session["conf"].ToString() + "&amount=" + Session["providerAmount"].ToString(), false);

                    }

                }

                //recharge DP
                TopUpReqType tu = new TopUpReqType();
                TransResponseType ts = new TransResponseType();
                ActivateOrRechargeAccountType af = new ActivateOrRechargeAccountType();
                AccountInfo ai = new AccountInfo();
                
                using (PinManager pm = new PinManager())
                {
                    ServicePointManager.Expect100Continue = true;
                    ServicePointManager.DefaultConnectionLimit = 9999;
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12 | SecurityProtocolType.Ssl3;
                    pm.Credentials = new System.Net.NetworkCredential(ConfigurationManager.AppSettings["dpUser"], ConfigurationManager.AppSettings["dpPass"]);

                    af.Account = ai;
                    af.Account.Ani = phone;
                    af.Account.OfferingId = offeringid;
                    User getReferral = oUserDAO.RetrieveGuatePinReferral(phone);
                    User getReferrer = oUserDAO.RetrieveGuatePinReferrer(phone);
                    User getPrevRecharge = oUserDAO.RetrieveGuatePinRecharge(getReferrer.ReferralNumber);

                    if (getReferral.ReferralNumber != null)
                    {
                        //referal used / make it true
                        oUserDAO.UpdatetGuatePinReferrals(phone, true);

                        //add a dollar because of referral
                        af.Account.Balance = provideramount;
                    }
                    else if (getReferrer.Active == true && getPrevRecharge.PhoneNumber != null)
                    {
                        //add a dollar because of referral
                        provideramount = provideramount + 1;
                        Session["providerAmount"] = provideramount;
                        af.Account.Balance = provideramount;
                    }
                    else
                    {
                        af.Account.Balance = provideramount;
                    }

                    ai = pm.ActivateOrRechargeAccount(af);


                    if ((ai.TransId > 0))
                    {

                        DateTime start = DateTime.Now;
                        for (
                        ; ((ts.Status == TransactionStatus.Pending) && ((DateTime.Now - start).TotalSeconds <= 180));
                        )
                        {
                            System.Threading.Thread.Sleep(3000);
                            ts = pm.TopupConfirm(Convert.ToInt32(ai.TransId));
                        }
                        switch (ts.Status)
                        {

                            case TransactionStatus.Success:


                                af.OrderId = ai.TransId.ToString();
                                Session["conf"] = ai.TransId;
                                Session["error"] = "";
                                Session["cc"] = "6MJ26xFJGDeR5WNKLVU2MElxAq3lrfqJwpW9Ly8fLlEGl3/zUMrsfbyGVRonHF5G";

                                Session["Balance"] = provideramount;
                                Session["PrevBalance"] = pm.GetAccountInfoByAniOffering(phone, offeringid).Balance.ToString();


                                //update credit line
                                MetroFastPayLibrary.Account oAccount = new MetroFastPayLibrary.Account();
                                oAccount = oUserDAO.RetrieveAccount(UserCookie.Value);

                                if (oAccount.Active == true)
                                {
                                    decimal DPamount = Convert.ToDecimal(txtAmount.Text) * Convert.ToDecimal(Session["UserComm"]);
                                    oUserDAO.UpdateAccountbyPost(oAccount.Credit - (Convert.ToDecimal(txtAmount.Text) - DPamount), oUser.Post);
                                    //insert payments
                                    oUserDAO.InsertPayments(UserCookie.Value, oUser.Post, Session["Phone"].ToString(), Convert.ToDecimal(Session["provideramount"].ToString()), 0, Session["provider"].ToString().Trim() + " - Conf#:" + Session["conf"].ToString(), "6MJ26xFJGDeR5WNKLVU2MElxAq3lrfqJwpW9Ly8fLlEGl3/zUMrsfbyGVRonHF5G", DateTime.Now);

                                }
                                else
                                {
                                    //insert payments
                                    oUserDAO.InsertPayments(UserCookie.Value, oUser.Post, Session["Phone"].ToString(), Convert.ToDecimal(Session["provideramount"].ToString()), 0, Session["provider"].ToString().Trim() + " - Conf#:" + Session["conf"].ToString(), "6MJ26xFJGDeR5WNKLVU2MElxAq3lrfqJwpW9Ly8fLlEGl3/zUMrsfbyGVRonHF5G", DateTime.Now);

                                }

                                if (Session["provider"].ToString() == "GuatePin")
                                {
                                    //send recharge sc
                                    await sendShortCodes(phone, Session["provider"].ToString() + " $" + string.Format("{0:0.00}", Convert.ToDecimal(provideramount)) + "\nTu recarga Guatemalteca \nNumero de acceso: 5612291367\nConf: " + ai.TransId + "\n");
                                    //send referral 
                                    await sendShortCodes(phone, "GuatePin- Para recivir un dolar gratis haga clic aqui https://telbug.com/guatepin?ReferrerNumber=" + phone + " para referir a un amigo");
                                    //send sc for the referral 
                                    if (getReferrer.Active == true && getPrevRecharge.PhoneNumber != null)
                                    {
                                        oUserDAO.UpdatetGuatePinReferrals(getReferrer.ReferralNumber, false);
                                        //send short code
                                        await sendShortCodes(phone, "GuatePin- Gracias por referir a un amigo, le dimos un dolar extra en su recarga.");
                                    }
                                }
                                //capture IP
                                Payment oPayment = new Payment();
                                oPayment = oUserDAO.RetrievePaymentbyConfID(Session["conf"].ToString());
                                oUserDAO.InsertIP(UserCookie.Value, GetIPAddress(), oPayment.ID);

                                break;
                            case TransactionStatus.Failed:
                                Session["cc"] = "";
                                Session["conf"] = "";
                                Session["error"] = "error3";
                                oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), "6MJ26xFJGDeR5WNKLVU2MElxAq3lrfqJwpW9Ly8fLlEGl3/zUMrsfbyGVRonHF5G", Session["provider"].ToString() + "($" + Session["provideramount"].ToString() + ") - " + ts.ErrorCode);
                                break;
                            case TransactionStatus.Pending:
                                Session["cc"] = "";
                                Session["conf"] = "";
                                Session["error"] = "error3";
                                oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), "6MJ26xFJGDeR5WNKLVU2MElxAq3lrfqJwpW9Ly8fLlEGl3/zUMrsfbyGVRonHF5G", Session["provider"].ToString() + "($" + Session["provideramount"].ToString() + ") - " + ts.ErrorCode);
                                break;
                        }
                    }
                    else
                    {
                        Session["cc"] = "";
                        Session["conf"] = "";
                        Session["error"] = "error3";
                        oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), "6MJ26xFJGDeR5WNKLVU2MElxAq3lrfqJwpW9Ly8fLlEGl3/zUMrsfbyGVRonHF5G", Session["provider"].ToString() + "($" + Session["provideramount"].ToString() + ") - " + ts.ErrorCode);

                    }


                }


                ddProviders.SelectedValue = "0";
                txtPhone.Text = "";
                txtAmount.Text = "";
                lbInfo.Text = "";

                if (Session["conf"].ToString().Length <= 8)
                {
                    string conf = Session["conf"].ToString();
                    string EN = "1-800-608-1305";
                    string SP = "1-888-279-6141";
                    if (Session["provider"].ToString() == "GuatePin")
                    {
                        EN = "561-229-1367";
                        SP = "561-229-1367";
                    }
                    string Balance = Session["Balance"].ToString();
                    string PrevBalance = Session["PrevBalance"].ToString();
                    //using (PinManager pm = new PinManager())
                    //{
                    //    pm.Credentials = new System.Net.NetworkCredential(ConfigurationManager.AppSettings["dpUser"], ConfigurationManager.AppSettings["dpPass"]);
                    //    string dpBalance = pm.GetAccountInfoByAni(Request.QueryString["DP"]).Balance.ToString();
                    //    Balance = string.Format("{0:0.00}", dpBalance).Trim();
                    //}

                    Response.Redirect("Splash.aspx?Phone=" + phone.Replace("-", "") + "&datepaid=" + DateTime.Now + "&provider=" + Session["provider"].ToString() + "&providerText=" + Session["providerText"].ToString() + "&cc=" + Session["cc"].ToString() + "&providerAmount=" + Session["providerAmount"].ToString() + "&error=" + Session["error"].ToString() + "&conf=" + conf + "&amount=" + Session["totalamount"].ToString() + "&EnglishNumber=" + EN + "&SpanishNumber=" + SP + "&Balance=" + Balance + "&PrevBalance=" + PrevBalance, false);
                }

                if (Session["error"].ToString() == "error3")
                {
                    Response.Redirect("Splash.aspx?Phone=" + phone.Replace("-", "") + "&datepaid=" + DateTime.Now + "&provider=" + Session["provider"].ToString() + "&providerText=" + Session["providerText"].ToString() + "&cc=" + Session["cc"].ToString() + "&providerAmount=" + Session["providerAmount"].ToString() + "&error=" + Session["error"].ToString() + "&conf=" + Session["conf"].ToString() + "&amount=" + Session["providerAmount"].ToString(), false);
                }

            }
            catch (Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, typeof(string), "Alert", "alert('Dollar Phone is expiriencing technical difficulties, please call 561-860-5276');", true);
                lbInfo.Text = Session["provider"].ToString() + " is expiriencing technical difficulties, please call 561-860-5276" + ex;
                lbInfo.ForeColor = Color.Red;
            }
        }

        public async void DPMobilePayment()
        {
            try
            {
                Payment oPay = new Payment();
                oPay = oUserDAO.RetrieveLastPayment(UserCookie.Value);
                User oDisUser = new User();
                User oFee = new User();
                oFee = oUserDAO.RetrieveFeebyUserID(UserCookie.Value);
                if (oPay.AmountPaid == 204 && oPay.CreatedDate.ToString("dd/MM/yyyy") == DateTime.Now.ToString("dd/MM/yyyy"))
                {
                    oDisUser = oUserDAO.DisableAccount(UserCookie.Value, false);
                }


                string phone = "";
                decimal totalamount = 0;
                decimal provideramount = 0;
                int offeringid = 0;
                if (txtAmount.Text == "")
                {
                    phone = Session["phone"].ToString();
                    totalamount = Convert.ToDecimal(Session["totalamount"]);
                    provideramount = Convert.ToDecimal(Session["provideramount"]);
                }
                else
                {
                    totalamount = decimal.Parse(txtAmount.Text) + Convert.ToInt32(oFee.Fee);
                    provideramount = decimal.Parse(txtAmount.Text);

                    Session["totalamount"] = totalamount;
                    Session["providerAmount"] = provideramount;
                    if (ddProviders.SelectedItem.Text.Contains("Tigo") || ddProviders.SelectedItem.Text.Contains("Claro") || ddProviders.SelectedItem.Text.Contains("Digicel"))
                    {
                        Session["provider"] = ddProviders.SelectedItem.Text + " " + Session["OtherService"];
                    }
                    else
                    {
                        Session["provider"] = ddProviders.SelectedItem.Text;
                    }

                    phone = txtPhone.Text.Replace("-", "").Replace("(", "").Replace(")", "");
                    Session["phone"] = phone;
                    offeringid = Convert.ToInt32(Session["offeringid"]);
                }

                //mobile DP
                MobileTopUpType tu = new MobileTopUpType();
                TopUpResp tr;
                TransResponseType ts = new TransResponseType();

                //pin
                TopUpReqType tq = new TopUpReqType();

                using (PinManager pm = new PinManager())
                {
                    ServicePointManager.Expect100Continue = true;
                    ServicePointManager.DefaultConnectionLimit = 9999;
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12 | SecurityProtocolType.Ssl3;

                    pm.Credentials = new System.Net.NetworkCredential(ConfigurationManager.AppSettings["dpUser"], ConfigurationManager.AppSettings["dpPass"]);



                    if (Session["provider"].ToString().Contains("Liberty"))
                    {
                        tq.Action = TopUpAction.PurchasePin;
                        tq.OfferingId = offeringid;
                        tq.PhoneNumber = phone;
                        tq.Amount = Convert.ToDouble(provideramount);
                        tr = pm.TopUpRequest(tq);
                    }
                    else
                    {
                        tu.Ani = phone;
                        tu.OfferingId = offeringid;
                        tu.PhoneNumber = phone;
                        tu.Amount = Convert.ToDouble(provideramount);
                        tr = pm.MobileTopup(tu);
                    }

                    ts = pm.TopupConfirm(Convert.ToInt32(tr.TransId));
                    if (ts.ErrorCode == -401)
                    {
                        Session["cc"] = "";
                        Session["conf"] = "";
                        Session["error"] = "error3";
                    }
                    else
                    {

                        if ((tr.TransId > 0))
                        {

                            DateTime start = DateTime.Now;
                            for (
                            ; ((ts.Status == TransactionStatus.Pending) && ((DateTime.Now - start).TotalSeconds <= 180));
                            )
                            {
                                System.Threading.Thread.Sleep(3000);
                                ts = pm.TopupConfirm(Convert.ToInt32(tr.TransId));
                            }
                            switch (ts.Status)
                            {

                                case TransactionStatus.Success:
                                    Session["conf"] = tr.TransId;                                      
                                    Session["error"] = "";
                                    Session["cc"] = "6MJ26xFJGDeR5WNKLVU2MElxAq3lrfqJwpW9Ly8fLlEGl3/zUMrsfbyGVRonHF5G";

                                    //Pin requests only
                                    if (Session["provider"].ToString().Contains("Liberty"))
                                    {
                                        Session["PIN"] = ts.PIN;
                                    }
                                    else
                                    {
                                        Session["PIN"] = "";
                                    }

                                    //update credit line
                                    MetroFastPayLibrary.Account oAccount = new MetroFastPayLibrary.Account();
                                    oAccount = oUserDAO.RetrieveAccount(UserCookie.Value);
                                    int doublepay = getPreviousPayment(txtPhone.Text);

                                    if (oAccount.Active == true)
                                    {
                                        User GetProduct = new User();

                                        GetProduct = oUserDAO.RetrieveServiceActivityByProduct(Session["provider"].ToString(), UserCookie.Value);

                                        decimal SMamount = Convert.ToDecimal(txtAmount.Text) * Convert.ToDecimal(GetProduct.UserCommission);



                                        if (doublepay >= 1)
                                        {

                                            if (Session["provider"].ToString().Contains("MetroPCS"))
                                            {
                                                oUserDAO.UpdateAccountbyPost(oAccount.Credit - (Convert.ToDecimal(txtAmount.Text) + Convert.ToDecimal(2)), oUser.Post);
                                                //insert payments
                                                oUserDAO.InsertPayments(UserCookie.Value, oUser.Post, Session["Phone"].ToString(), Convert.ToDecimal(Session["provideramount"].ToString()), 0, Session["provider"].ToString() + " - Conf#:" + Session["conf"].ToString(), "p1U+X7SOkDLpOsgOfuoiwohqtF9Imk4oeifZ+yZ/OroTWqilU8IBxumOYi4Yu1DO", DateTime.Now);
                                            }
                                            else
                                            {
                                                if (GetProduct.UserCommission.ToString().Contains("."))
                                                {
                                                    oUserDAO.UpdateAccountbyPost(oAccount.Credit - (Convert.ToDecimal(txtAmount.Text) - 0), oUser.Post);
                                                }
                                                else
                                                {
                                                    oUserDAO.UpdateAccountbyPost(oAccount.Credit - (Convert.ToDecimal(txtAmount.Text) - 0), oUser.Post);
                                                }
                                                //insert payments
                                                oUserDAO.InsertPayments(UserCookie.Value, oUser.Post, Session["Phone"].ToString(), Convert.ToDecimal(Session["provideramount"].ToString()), 0, Session["provider"].ToString() + " - Conf#:" + Session["conf"].ToString(), Session["cc"].ToString(), DateTime.Now);
                                            }
                                        }
                                        else
                                        {

                                            if (Session["provider"].ToString().Contains("MetroPCS"))
                                            {
                                                oUserDAO.UpdateAccountbyPost(oAccount.Credit - (Convert.ToDecimal(txtAmount.Text) + Convert.ToDecimal(2)), oUser.Post);
                                                //insert payments
                                                oUserDAO.InsertPayments(UserCookie.Value, oUser.Post, Session["Phone"].ToString(), Convert.ToDecimal(Session["provideramount"].ToString()), Convert.ToDecimal(oFee.Fee), Session["provider"].ToString() + " - Conf#:" + Session["conf"].ToString(), "p1U+X7SOkDLpOsgOfuoiwohqtF9Imk4oeifZ+yZ/OroTWqilU8IBxumOYi4Yu1DO", DateTime.Now);
                                            }
                                            else
                                            {
                                                //if (Session["provider"].ToString() == "Simple") { oUserDAO.UpdateAccountbyPost(oAccount.Credit - (Convert.ToDecimal(txtAmount.Text) - 1), oUser.Post); }
                                                //else if (Session["provider"].ToString() == "H2O") { oUserDAO.UpdateAccountbyPost(oAccount.Credit - (Convert.ToDecimal(txtAmount.Text) - 1), oUser.Post); }
                                                //else if (Session["provider"].ToString() == "Ultra") { oUserDAO.UpdateAccountbyPost(oAccount.Credit - (Convert.ToDecimal(txtAmount.Text) - 1), oUser.Post); }
                                                //else if (Session["provider"].ToString() == "Lyca") { oUserDAO.UpdateAccountbyPost(oAccount.Credit - (Convert.ToDecimal(txtAmount.Text) - 1), oUser.Post); }
                                                //else if (Session["provider"].ToString() == "AT&T") { oUserDAO.UpdateAccountbyPost(oAccount.Credit - (Convert.ToDecimal(txtAmount.Text) - 2), oUser.Post); }
                                                //else if (Session["provider"].ToString() == "T-Mobile") { oUserDAO.UpdateAccountbyPost(oAccount.Credit - (Convert.ToDecimal(txtAmount.Text) - 1), oUser.Post); }
                                                //else if (Session["provider"].ToString() == "Verizon") { oUserDAO.UpdateAccountbyPost(oAccount.Credit - (Convert.ToDecimal(txtAmount.Text) - 1), oUser.Post); }
                                                //else if (Session["provider"].ToString() == "Net10") { oUserDAO.UpdateAccountbyPost(oAccount.Credit - (Convert.ToDecimal(txtAmount.Text) - 1), oUser.Post); }
                                                //else if (Session["provider"].ToString() == "EasyGo") { oUserDAO.UpdateAccountbyPost(oAccount.Credit - (Convert.ToDecimal(txtAmount.Text) - 1), oUser.Post); }
                                                //else
                                                //{
                                                //    oUserDAO.UpdateAccountbyPost(oAccount.Credit - (Convert.ToDecimal(txtAmount.Text) - SMamount), oUser.Post);
                                                //}
                                                if (GetProduct.UserCommission.ToString().Contains("."))
                                                {
                                                    oUserDAO.UpdateAccountbyPost(oAccount.Credit - (Convert.ToDecimal(txtAmount.Text) - SMamount), oUser.Post);
                                                }
                                                else
                                                {
                                                    oUserDAO.UpdateAccountbyPost(oAccount.Credit - (Convert.ToDecimal(txtAmount.Text) - GetProduct.UserCommission), oUser.Post);
                                                }
                                                //insert payments
                                                oUserDAO.InsertPayments(UserCookie.Value, oUser.Post, Session["Phone"].ToString(), Convert.ToDecimal(Session["provideramount"].ToString()), 0, Session["provider"].ToString() + " - Conf#:" + Session["conf"].ToString(), Session["cc"].ToString(), DateTime.Now);
                                            }
                                        }

                                    }
                                    else
                                    {
                                        //insert payments
                                        if (Session["provider"].ToString().Contains("MetroPCS"))
                                        {
                                            //insert payments
                                            oUserDAO.InsertPayments(UserCookie.Value, oUser.Post, Session["Phone"].ToString(), Convert.ToDecimal(Session["provideramount"].ToString()), Convert.ToDecimal(oFee.Fee), Session["provider"].ToString() + " - Conf#:" + Session["conf"].ToString(), "p1U+X7SOkDLpOsgOfuoiwohqtF9Imk4oeifZ+yZ/OroTWqilU8IBxumOYi4Yu1DO", DateTime.Now);
                                        }
                                        else
                                        {
                                            //insert payments
                                            oUserDAO.InsertPayments(UserCookie.Value, oUser.Post, Session["Phone"].ToString(), Convert.ToDecimal(Session["provideramount"].ToString()), 0, Session["provider"].ToString() + " - Conf#:" + Session["conf"].ToString(), Session["cc"].ToString(), DateTime.Now);
                                        }

                                    }

                                    //capture IP
                                    Payment oPayment = new Payment();
                                    oPayment = oUserDAO.RetrievePaymentbyConfID(Session["conf"].ToString());
                                    oUserDAO.InsertIP(UserCookie.Value, GetIPAddress(), oPayment.ID);

                                    if (usesShortCode == true)
                                    {
                                        if (txtUSNumber.Text == "")
                                        {
                                            lbInfo.Text = "US Number needed";
                                            return;
                                        }
                                        else
                                        {

                                            txtUSNumber.Text = txtUSNumber.Text.Replace("(", "").Replace(")", "").Replace("-", "") ;
                                            
                                            await sendShortCodes(txtUSNumber.Text, Session["provider"].ToString() + " $" + Convert.ToDouble(provideramount) + "\nNumero: " + phone + "\nConf: " + tr.TransId + "\nGracias por usar TelBug\n");

                                        }
                                    }

                                    break;
                                case TransactionStatus.Failed:
                                    if (ts.ErrorCode == -400)
                                    {
                                        Session["cc"] = "";
                                        Session["conf"] = "";
                                        Session["error"] = "error1";
                                        oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), "6MJ26xFJGDeR5WNKLVU2MElxAq3lrfqJwpW9Ly8fLlEGl3/zUMrsfbyGVRonHF5G", Session["provider"].ToString() + "($" + Session["provideramount"].ToString() + ") - " + ts.ErrorCode);
                                    }
                                    else if (ts.ErrorCode == -401)
                                    {
                                        if (Session["provider"].ToString() == "Ultra")
                                        {
                                            Session["error"] = "UltraError";
                                        }
                                        else
                                        {
                                            Session["error"] = "error18";
                                        }
                                        Session["cc"] = "";
                                        Session["conf"] = "";
                                        oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), "6MJ26xFJGDeR5WNKLVU2MElxAq3lrfqJwpW9Ly8fLlEGl3/zUMrsfbyGVRonHF5G", Session["provider"].ToString() + "($" + Session["provideramount"].ToString() + ") - " + ts.ErrorCode);
                                    }
                                    else if (ts.ErrorCode == -404 || ts.ErrorCode == -403)
                                    {
                                        Session["cc"] = "";
                                        Session["conf"] = "";
                                        Session["error"] = "errorFunds";
                                        oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), "6MJ26xFJGDeR5WNKLVU2MElxAq3lrfqJwpW9Ly8fLlEGl3/zUMrsfbyGVRonHF5G", Session["provider"].ToString() + "($" + Session["provideramount"].ToString() + ") - " + ts.ErrorCode);
                                    }
                                    else
                                    {
                                        Session["cc"] = "";
                                        Session["conf"] = "";
                                        Session["error"] = "error3";
                                        oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), "6MJ26xFJGDeR5WNKLVU2MElxAq3lrfqJwpW9Ly8fLlEGl3/zUMrsfbyGVRonHF5G", Session["provider"].ToString() + "($" + Session["provideramount"].ToString() + ") - " + ts.ErrorCode);
                                    }

                                    break;
                                case TransactionStatus.Pending:
                                    Session["cc"] = "";
                                    Session["conf"] = "";
                                    Session["error"] = "error3";
                                    oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), "6MJ26xFJGDeR5WNKLVU2MElxAq3lrfqJwpW9Ly8fLlEGl3/zUMrsfbyGVRonHF5G", Session["provider"].ToString() + "($" + Session["provideramount"].ToString() + ") - " + ts.ErrorCode);
                                    break;
                            }
                        }
                        else
                        {
                            if (tr.TransId == -404 || tr.TransId == -406)
                            {
                                Session["cc"] = "";
                                Session["conf"] = "";
                                Session["error"] = "error3";
                                oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), "6MJ26xFJGDeR5WNKLVU2MElxAq3lrfqJwpW9Ly8fLlEGl3/zUMrsfbyGVRonHF5G", Session["provider"].ToString() + "($" + Session["provideramount"].ToString() + ") - " + tr.TransId);
                            }
                            else
                            {
                                Session["cc"] = "";
                                Session["conf"] = "";
                                Session["error"] = "error3";
                                oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), "6MJ26xFJGDeR5WNKLVU2MElxAq3lrfqJwpW9Ly8fLlEGl3/zUMrsfbyGVRonHF5G", Session["provider"].ToString() + "($" + Session["provideramount"].ToString() + ") - " + tr.TransId);
                            }
                        }
                    }



                }


                ddProviders.SelectedValue = "0";
                txtPhone.Text = "";
                txtAmount.Text = "";
                lbInfo.Text = "";

                //if (Session["conf"].ToString().Length == 8 && Session["provider"].ToString() == "DollarPhone")
                //{
                //    string conf = Session["conf"].ToString();
                //    string EN = "954-414-1955";
                //    string SP = "954-414-1955";
                //    string Balance = "";
                //    Response.Redirect("Splash.aspx?Phone=" + phone.Replace("-", "") + "&datepaid=" + DateTime.Now + "&provider=" + Session["provider"].ToString() + "&providerText=" + Session["providerText"].ToString() + "&cc=" + Session["cc"].ToString() + "&providerAmount=" + Session["providerAmount"].ToString() + "&error=" + Session["error"].ToString() + "&conf=" + conf + "&amount=" + Session["totalamount"].ToString() + "&EnglishNumber=" + EN + "&SpanishNumber=" + SP + "&Balance=" + Balance, false);
                //}
                if (Session["conf"].ToString().Length >= 7)
                {
                    string conf = Session["conf"].ToString();
                    Session["error"] = "";
                    Response.Redirect("Splash.aspx?Phone=" + phone.Replace("-", "") + "&datepaid=" + DateTime.Now + "&provider=" + Session["provider"].ToString() + "&providerText=" + Session["providerText"].ToString() + "&cc=" + Session["cc"].ToString() + "&providerAmount=" + Session["providerAmount"].ToString() + "&error=" + Session["error"].ToString() + "&conf=" + conf + "&amount=" + Session["totalamount"].ToString() + "&PIN=" + Session["PIN"].ToString(), false);
                }
                if (Session["error"].ToString().Contains("error") || Session["error"].ToString().Contains("UltraError"))
                {
                    Response.Redirect("Splash.aspx?Phone=" + phone.Replace("-", "") + "&datepaid=" + DateTime.Now + "&provider=" + Session["provider"].ToString() + "&providerText=" + Session["providerText"].ToString() + "&cc=" + Session["cc"].ToString() + "&providerAmount=" + Session["providerAmount"].ToString() + "&error=" + Session["error"].ToString() + "&conf=" + Session["conf"].ToString() + "&amount=" + Session["providerAmount"].ToString(), false);
                }

            }
            catch (Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, typeof(string), "Alert", "alert('" + ddProviders.SelectedItem.Text + " is expiriencing technical difficulties, please call 561-860-5276');", true);
                lbInfo.Text = ddProviders.SelectedItem.Text + " is expiriencing technical difficulties, please call 561-860-5276" + ex;
                lbInfo.ForeColor = Color.Red;
            }
        }
        public async void ReupPayments()
        {
            try
            {
                Payment oPay = new Payment();
                oPay = oUserDAO.RetrieveLastPayment(UserCookie.Value);
                User oDisUser = new User();
                User oFee = new User();
                oFee = oUserDAO.RetrieveFeebyUserID(UserCookie.Value);
                if (oPay.AmountPaid == 204 && oPay.CreatedDate.ToString("dd/MM/yyyy") == DateTime.Now.ToString("dd/MM/yyyy"))
                {
                    oDisUser = oUserDAO.DisableAccount(UserCookie.Value, false);
                }

                string phone = "";
                decimal totalamount = 0;
                int provideramount = 0;
                int offeringid = 0;
                int planid = Convert.ToInt32(Session["PlanID"]);
                if (txtAmount.Text == "")
                {
                    phone = Session["phone"].ToString();
                    totalamount = Convert.ToInt32(Session["totalamount"]);
                    provideramount = Convert.ToInt32(Session["provideramount"]);
                }
                else
                {
                    totalamount = decimal.Parse(txtAmount.Text) + Convert.ToInt32(oFee.Fee);
                    provideramount = Convert.ToInt32(txtAmount.Text);
                    Session["totalamount"] = totalamount;
                    Session["providerAmount"] = provideramount;
                    Session["provider"] = ddProviders.SelectedItem.Text;
                    phone = txtPhone.Text.Replace("-", "").Replace("(", "").Replace(")", "");
                    Session["phone"] = phone;
                    offeringid = Convert.ToInt32(Session["offeringid"]);
                    Session["cc"] = "6MJ26xFJGDeR5WNKLVU2MElxAq3lrfqJwpW9Ly8fLlEGl3/zUMrsfbyGVRonHF5G";

                    await ReupAPI("https://api.reupmobile.com/api/action/topup", offeringid, planid, provideramount, phone);
                }

                ddProviders.SelectedValue = "0";
                txtPhone.Text = "";
                txtAmount.Text = "";
                lbInfo.Text = "";


                if (Session["conf"].ToString().Length >= 9 && Session["error"].ToString() == "")
                {
                    string conf = Session["conf"].ToString();
                    Session["error"] = "";
                    Response.Redirect("Splash.aspx?Phone=" + phone.Replace("-", "") + "&datepaid=" + DateTime.Now + "&provider=ATT&providerText=" + Session["providerText"].ToString() + "&cc=" + Session["cc"].ToString() + "&providerAmount=" + Session["providerAmount"].ToString() + "&error=" + Session["error"].ToString() + "&conf=" + conf + "&amount=" + Session["totalamount"].ToString(), false);
                }
                if (Session["error"].ToString().Contains("error"))
                {
                    Response.Redirect("Splash.aspx?Phone=" + phone.Replace("-", "") + "&datepaid=" + DateTime.Now + "&provider=ATT&providerText=" + Session["providerText"].ToString() + "&cc=" + Session["cc"].ToString() + "&providerAmount=" + Session["providerAmount"].ToString() + "&error=" + Session["error"].ToString() + "&conf=" + Session["conf"].ToString() + "&amount=" + Session["providerAmount"].ToString(), false);
                }
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, typeof(string), "Alert", "alert('" + ddProviders.SelectedItem.Text + " is expiriencing technical difficulties, please call 561-860-5276');", true);
                lbInfo.Text = ddProviders.SelectedItem.Text + " is expiriencing technical difficulties, please call 561-860-5276" + ex;
                lbInfo.ForeColor = Color.Red;
            }
        }
        public static string getBetween(string strSource, string strStart, string strEnd)
        {
            int Start, End;
            if (strSource.Contains(strStart) && strSource.Contains(strEnd))
            {
                Start = strSource.IndexOf(strStart, 0) + strStart.Length;
                End = strSource.IndexOf(strEnd, Start);
                return strSource.Substring(Start, End - Start);
            }
            else
            {
                return "";
            }
        }
        async Task PostRequest(string url)
        {
            try
            {


                IEnumerable<KeyValuePair<string, string>> queries = new List<KeyValuePair<string, string>>()
            {
                new KeyValuePair<string, string>("origin", "https://www.metropcs.com"),
                new KeyValuePair<string, string>("content-type", "application/x-www-form-urlencoded"),
                new KeyValuePair<string, string>("referer", "https://www.metropcs.com/bill-pay.html")


            };



                HttpContent q = new FormUrlEncodedContent(queries);
                using (HttpClient client = new HttpClient())
                {
                    using (HttpResponseMessage response = await client.PostAsync(url, q))
                    {
                        HttpContent content = response.Content;
                        string mycontent = await content.ReadAsStringAsync();

                        if (mycontent.Contains("billingConfirmationId"))
                        {

                            Session["conf"] = getBetween(mycontent, "billingConfirmationId\":\"", "\",\"convenienceFee");


                            //update credit line
                            MetroFastPayLibrary.Account oAccount = new MetroFastPayLibrary.Account();
                            oAccount = oUserDAO.RetrieveAccount(UserCookie.Value);

                            User oFee = new User();
                            oFee = oUserDAO.RetrieveFeebyUserID(UserCookie.Value);
                            int doublepay = getPreviousPayment(Session["Phone"].ToString());
                            if (oAccount.Active == true)
                            {

                                if (doublepay >= 1)
                                {
                                    oUserDAO.UpdateAccountbyPost(oAccount.Credit - Convert.ToInt32(txtAmount.Text), oUser.Post);
                                    oUserDAO.InsertPayments(UserCookie.Value, oUser.Post, Session["Phone"].ToString(), Convert.ToDecimal(Session["provideramount"].ToString()), 0, Session["provider"].ToString() + " - Conf#:" + Session["conf"].ToString(), Session["cc"].ToString(), DateTime.Now);
                                    //5 card warning
                                    CCLeft();
                                }
                                else
                                {
                                    oUserDAO.UpdateAccountbyPost(oAccount.Credit - (Convert.ToInt32(txtAmount.Text) + (Convert.ToInt32(oFee.Fee) - 2)), oUser.Post);
                                    oUserDAO.InsertPayments(UserCookie.Value, oUser.Post, Session["Phone"].ToString(), Convert.ToDecimal(Session["provideramount"].ToString()), Convert.ToDecimal(oFee.Fee), Session["provider"].ToString() + " - Conf#:" + Session["conf"].ToString(), Session["cc"].ToString(), DateTime.Now);
                                    //5 card warning
                                    CCLeft();
                                }
                            }
                            else
                            {
                                if (doublepay >= 1)
                                {
                                    //insert payments
                                    oUserDAO.InsertPayments(UserCookie.Value, oUser.Post, Session["Phone"].ToString(), Convert.ToDecimal(Session["provideramount"].ToString()), 0, Session["provider"].ToString() + " - Conf#:" + Session["conf"].ToString(), Session["cc"].ToString(), DateTime.Now);
                                    //5 card warning
                                    CCLeft();
                                }
                                else
                                {
                                    //insert payments
                                    oUserDAO.InsertPayments(UserCookie.Value, oUser.Post, Session["Phone"].ToString(), Convert.ToDecimal(Session["provideramount"].ToString()), Convert.ToDecimal(oFee.Fee), Session["provider"].ToString() + " - Conf#:" + Session["conf"].ToString(), Session["cc"].ToString(), DateTime.Now);
                                    //5 card warning
                                    CCLeft();
                                }
                            }

                            CC oCC = new CC();
                            oCC = oUserDAO.RetrieveCC();
                            CC oCC2 = new CC();
                            oCC2 = oUserDAO.RetrieveCC2();
                            CC oCC3 = new CC();
                            oCC3 = oUserDAO.RetrieveCC3();

                            if (oCC.Used != null)
                            {
                                //update card used
                                int used = Convert.ToInt16(oCC.Used) + 1;
                                oUserDAO.UpdateCCUsage(Convert.ToString(used), oCC.CCNumber);

                                //update ccusage
                                Usage oUsage = new Usage();
                                oUsage = oUserDAO.RetrieveCCAmountUsed(oCC.FirstName.Substring(0, 1).ToUpper() + oCC.LastName.Substring(0, 1).ToUpper());
                                oUserDAO.UpdateCCAmountUsed(oCC.FirstName.Substring(0, 1).ToUpper() + oCC.LastName.Substring(0, 1).ToUpper(), oUsage.CurrentAmount + Convert.ToInt32(txtAmount.Text));

                                //if (oUsage.MaxAmount <= oUsage.CurrentAmount)
                                //{
                                //    //makes cards in cc table false 
                                //    oUserDAO.UpdateCCUsageByName(oCC.FirstName.Substring(0, 1).ToUpper(), oCC.LastName.Substring(0, 1).ToUpper());

                                //    //makes ccusage false
                                //    oUserDAO.UpdateCCUsageToFalse(oCC.FirstName.Substring(0, 1).ToUpper() + oCC.LastName.Substring(0, 1).ToUpper());

                                //        //send text
                                //    TextAndEmail("Card: " + oCC.FirstName.Substring(0, 1).ToUpper() + oCC.LastName.Substring(0, 1).ToUpper() + " has been maxed out", "Marcos, go put new cards in the system");
                                //}

                                //CC oDisCC = new CC();
                                //oDisCC = oUserDAO.DisableCard(oCC.CCNumber, false);
                            }
                            else if (oCC2.Used != null)
                            {
                                //update card used
                                int used = Convert.ToInt16(oCC2.Used) + 1;
                                oUserDAO.UpdateCCUsage(Convert.ToString(used), oCC2.CCNumber);

                                //update ccusage
                                Usage oUsage = new Usage();
                                oUsage = oUserDAO.RetrieveCCAmountUsed(oCC2.FirstName.Substring(0, 1).ToUpper() + oCC2.LastName.Substring(0, 1).ToUpper());
                                oUserDAO.UpdateCCAmountUsed(oCC2.FirstName.Substring(0, 1).ToUpper() + oCC2.LastName.Substring(0, 1).ToUpper(), oUsage.CurrentAmount + Convert.ToInt32(txtAmount.Text));


                                //if (oUsage.MaxAmount <= oUsage.CurrentAmount)
                                //{
                                //    //makes cards in cc table false 
                                //    oUserDAO.UpdateCCUsageByName(oCC2.FirstName.Substring(0, 1).ToUpper(), oCC2.LastName.Substring(0, 1).ToUpper());

                                //    //makes ccusage false
                                //    oUserDAO.UpdateCCUsageToFalse(oCC2.FirstName.Substring(0, 1).ToUpper() + oCC2.LastName.Substring(0, 1).ToUpper());

                                //    //send text
                                //    TextAndEmail("Card: " + oCC2.FirstName.Substring(0, 1).ToUpper() + oCC2.LastName.Substring(0, 1).ToUpper() + " has been maxed out", "Marcos, go put new cards in the system");
                                //}

                                CC oDisCC = new CC();
                                oDisCC = oUserDAO.DisableCard(oCC2.CCNumber, false);
                            }
                            else if (oCC3.Used != null)
                            {
                                //update card used
                                int used = Convert.ToInt16(oCC3.Used) + 1;
                                oUserDAO.UpdateCCUsage(Convert.ToString(used), oCC3.CCNumber);

                                //update ccusage
                                //Usage oUsage = new Usage();
                                //oUsage = oUserDAO.RetrieveCCAmountUsed(oCC3.FirstName.Substring(0, 1).ToUpper() + oCC3.LastName.Substring(0, 1).ToUpper());
                                //oUserDAO.UpdateCCAmountUsed(oCC3.FirstName.Substring(0, 1).ToUpper() + oCC3.LastName.Substring(0, 1).ToUpper(), oUsage.CurrentAmount + Convert.ToInt32(txtAmount.Text));

                                //if (oUsage.MaxAmount <= oUsage.CurrentAmount)
                                //{
                                //    //makes cards in cc table false 
                                //    oUserDAO.UpdateCCUsageByName(oCC3.FirstName.Substring(0, 1).ToUpper(), oCC3.LastName.Substring(0, 1).ToUpper());

                                //    //makes ccusage false
                                //    oUserDAO.UpdateCCUsageToFalse(oCC3.FirstName.Substring(0, 1).ToUpper() + oCC3.LastName.Substring(0, 1).ToUpper());

                                //    //send text
                                //    TextAndEmail("Card: " + oCC3.FirstName.Substring(0, 1).ToUpper() + oCC3.LastName.Substring(0, 1).ToUpper() + " has been maxed out", "Marcos, go put new cards in the system");
                                //}

                                CC oDisCC = new CC();
                                oDisCC = oUserDAO.DisableCard(oCC3.CCNumber, false);
                            }

                            //text
                            //TextAndEmail("Telbug Payment - MetroPCS", UserCookie.Value + " made a payment of $" + string.Format("{0:0.00}", txtAmount.Text) + " to " + Session["Phone"].ToString(), false);
                            TextAndEmail("MetroPCS ", "MetroPCS, " + UserCookie.Value + ", " + txtAmount.Text + ", " + Session["Phone"].ToString(), false);

                            //capture IP
                            Payment oPayment = new Payment();
                            oPayment = oUserDAO.RetrievePaymentbyConfID(Session["conf"].ToString());
                            oUserDAO.InsertIP(UserCookie.Value, GetIPAddress(), oPayment.ID);

                        }

                        if (mycontent.Contains("errorCode"))
                        {


                            if (mycontent.Contains("10000017"))
                            {
                                Session["error"] = "error4";
                                Session["conf"] = "";
                            }
                            else
                            {
                                Session["error"] = mycontent;
                                Session["conf"] = "";
                            }
                            if (mycontent.Contains("10000013"))
                            {
                                Session["error"] = "error13";

                            }
                            if (mycontent.Contains("10001099"))
                            {
                                Session["error"] = "error99";
                            }

                            oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), Session["cc"].ToString(), Session["provider"].ToString() + "($" + Session["provideramount"].ToString() + ") - " + mycontent.ToString());
                            TextAndEmail(Session["provider"].ToString() + " Payment Error", UserCookie.Value + " tried to make payment. No payments was made - " + mycontent.ToString(), true);

                        }
                        else
                        {
                            Session["error"] = "";
                        }



                    }

                }

            }
            catch (Exception ex)
            {
                oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), Session["cc"].ToString(), "MetroPCS -" + ex);
                TextAndEmail("Payment Error", "MetroPCS threw an error when " + UserCookie.Value + " tried to make payment. No payments was made", true);
                Response.Redirect("Error.aspx", false);
            }
        }
        async Task checkNumberinDB(string url)
        {
            IEnumerable<KeyValuePair<string, string>> queries = new List<KeyValuePair<string, string>>()
            {
                new KeyValuePair<string, string>("origin", "https://www.metropcs.com"),
                new KeyValuePair<string, string>("content-type", "application/x-www-form-urlencoded"),
                new KeyValuePair<string, string>("referer", "https://www.metropcs.com/bill-pay.html")

            };


            HttpContent q = new FormUrlEncodedContent(queries);
            using (HttpClient client = new HttpClient())
            {
                using (HttpResponseMessage response = await client.PostAsync(url, q))
                {
                    HttpContent content = response.Content;
                    string mycontent = await content.ReadAsStringAsync();

                    Session["conf"] = "no conf";
                    Session["error"] = "";
                    if (mycontent.Contains("false") && url.Contains("genericservlet"))
                    {
                        Session["error"] = "error1";
                    }
                }

            }
        }

        async Task MetroPostRequest(string url, decimal amount, string cc, string firstname, string lastname, string expdate, string cvv, string zip, string number, string metrocc)
        {
            try
            {
                ServicePointManager.Expect100Continue = true;
                ServicePointManager.DefaultConnectionLimit = 9999;
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12 | SecurityProtocolType.Ssl3;

                //old way of doing metropcs payments
                //var client = new RestClient(url);
                //var request = new RestRequest(Method.POST);
                //request.AddHeader("postman-token", "a744fec0-2c03-8c52-33ac-875b59827bec");
                //request.AddHeader("cache-control", "no-cache");
                //request.AddHeader("origin", "https://www.metropcs.com");
                //request.AddHeader("referer", "https://www.metropcs.com/bill-pay.html");
                //request.AddHeader("content-type", "multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW");
                //request.AddParameter("multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW", "------WebKitFormBoundary7MA4YWxkTrZu0gW\r\nContent-Disposition: form-data; name=\"inputReqParam\"\r\n\r\n{\"serviceName\":\"profileManagementService\",\"serviceProviderName\":\"applicationSpecific\",\"requestParams\":{\"phoneNumber\":\"5612012168\"},\"componentId\":\"getLimitedCustomerInfo\",\"applicationId\":\"metropcs\",\"siteId\":\"metropcs\"}\r\n------WebKitFormBoundary7MA4YWxkTrZu0gW--", ParameterType.RequestBody);
                //IRestResponse response = client.Execute(request);

                string cardType = "MC";
                if (cc.StartsWith("5"))
                {
                    cardType = "MC";
                }
                else
                {
                    cardType = "VS";
                }

                var client = new RestClient(url);
                var request = new RestRequest(Method.POST);
                request.AddHeader("postman-token", "d3b6a44d-37da-edc5-61e6-57865347cff9");
                request.AddHeader("cache-control", "no-cache");
                request.AddHeader("referer", "https://www.metropcs.com/payment");
                request.AddHeader("mdn", number);
                request.AddHeader("content-type", "application/json");
                request.AddHeader("x-7xh4mcgiye-z", oMetroPCSSecurity.z);
                request.AddHeader("x-7xh4mcgiye-f", oMetroPCSSecurity.f);
                request.AddHeader("x-7xh4mcgiye-d", oMetroPCSSecurity.d);
                request.AddHeader("x-7xh4mcgiye-c", oMetroPCSSecurity.c);
                request.AddHeader("x-7xh4mcgiye-b", oMetroPCSSecurity.b);
                request.AddHeader("x-7xh4mcgiye-a", oMetroPCSSecurity.a);
                // request.AddHeader("x-49exvsbl-uniquestatekey", oMetroPCSSecurity.uniquestatekey);// "A-sRC5NpAQAAYgsCEbwAVt2P9KWLq_HOg-86gWSL0D-qeOYfhvCU2h66jXRtAawUMfGuctHLwH8AABszAAAAAA==");
                request.AddParameter("application/json", "{\"emailAddress\":\"9874559@gmail.com\",\"marketingPreference\":false,\"paymentDetails\":{\"amount\":\"" + amount + "\",\"confirmationEmailAddress\":\"9874559@gmail.com\",\"isDebitPreferred\":false,\"paymentType\":10,\"sensitiveAuthorizedCardInfo\":{\"cardNumber\":\"" + metrocc + "\",\"firstName\":\"" + GenerateName(5) + "\",\"lastName\":\"" + GenerateName(6) + "\",\"expDate\":\"" + expdate + "\",\"verificationCode\":\"" + cvv + "\",\"zipCode\":\"" + zip + "\",\"cardBrand\":\"MC\"},\"paymentMethodCode\":\"\"}}", ParameterType.RequestBody);
                IRestResponse response = client.Execute(request);



                string mycontent = response.Content;

                if (mycontent.Contains("billingConfirmationId"))
                {
                    Session["conf"] = getBetween(mycontent, "billingConfirmationId\":\"", "\",\"convenienceFee");


                    //update credit line
                    MetroFastPayLibrary.Account oAccount = new MetroFastPayLibrary.Account();
                    oAccount = oUserDAO.RetrieveAccount(UserCookie.Value);

                    User oFee = new User();
                    oFee = oUserDAO.RetrieveFeebyUserID(UserCookie.Value);
                    int doublepay = getPreviousPayment(Session["Phone"].ToString());
                    if (oAccount.Active == true)
                    {

                        if (doublepay >= 1)
                        {
                            oUserDAO.UpdateAccountbyPost(oAccount.Credit - Convert.ToInt32(txtAmount.Text), oUser.Post);
                            oUserDAO.InsertPayments(UserCookie.Value, oUser.Post, Session["Phone"].ToString(), Convert.ToDecimal(Session["provideramount"].ToString()), 0, Session["provider"].ToString() + " - Conf#:" + Session["conf"].ToString(), Session["cc"].ToString(), DateTime.Now);
                            //5 card warning
                            CCLeft();
                        }
                        else
                        {
                            oUserDAO.UpdateAccountbyPost(oAccount.Credit - (Convert.ToInt32(txtAmount.Text) + (Convert.ToInt32(oFee.Fee) - (Convert.ToInt32(oFee.Fee) - 2))), oUser.Post);
                            oUserDAO.InsertPayments(UserCookie.Value, oUser.Post, Session["Phone"].ToString(), Convert.ToDecimal(Session["provideramount"].ToString()), Convert.ToDecimal(oFee.Fee), Session["provider"].ToString() + " - Conf#:" + Session["conf"].ToString(), Session["cc"].ToString(), DateTime.Now);
                            //5 card warning
                            CCLeft();

                        }
                    }
                    else
                    {
                        if (doublepay >= 1)
                        {
                            //insert payments
                            oUserDAO.InsertPayments(UserCookie.Value, oUser.Post, Session["Phone"].ToString(), Convert.ToDecimal(Session["provideramount"].ToString()), 0, Session["provider"].ToString() + " - Conf#:" + Session["conf"].ToString(), Session["cc"].ToString(), DateTime.Now);
                            //5 card warning
                            CCLeft();
                        }
                        else
                        {
                            //insert payments
                            oUserDAO.InsertPayments(UserCookie.Value, oUser.Post, Session["Phone"].ToString(), Convert.ToDecimal(Session["provideramount"].ToString()), Convert.ToDecimal(oFee.Fee), Session["provider"].ToString() + " - Conf#:" + Session["conf"].ToString(), Session["cc"].ToString(), DateTime.Now);
                            //5 card warning
                            CCLeft();
                        }
                    }
                    //if online user then skip
                    if (UserCookie.Value != "FastPay Online")
                    {
                        CC oCC = new CC();
                        oCC = oUserDAO.RetrieveCC();
                        CC oCC2 = new CC();
                        oCC2 = oUserDAO.RetrieveCC2();
                        CC oCC3 = new CC();
                        oCC3 = oUserDAO.RetrieveCC3();

                        if (oCC.Used != null)
                        {
                            //update card used
                            int used = Convert.ToInt16(oCC.Used) + 1;
                            oUserDAO.UpdateCCUsage(Convert.ToString(used), oCC.CCNumber);

                        }
                        else if (oCC2.Used != null)
                        {
                            //update card used
                            int used = Convert.ToInt16(oCC2.Used) + 1;
                            oUserDAO.UpdateCCUsage(Convert.ToString(used), oCC2.CCNumber);


                            //CC oDisCC = new CC();
                            //oDisCC = oUserDAO.DisableCard(oCC2.CCNumber, false);
                        }
                        else if (oCC3.Used != null)
                        {
                            //update card used
                            int used = Convert.ToInt16(oCC3.Used) + 1;
                            oUserDAO.UpdateCCUsage(Convert.ToString(used), oCC3.CCNumber);

                            CC oDisCC = new CC();
                            oDisCC = oUserDAO.DisableCard(oCC3.CCNumber, false);


                        }
                    }
                    //text
                    //TextAndEmail("Telbug Payment - MetroPCS", UserCookie.Value + " made a payment of $" + string.Format("{0:0.00}", txtAmount.Text) + " to " + Session["Phone"].ToString(), false);
                    TextAndEmail("MetroPCS ", "MetroPCS, " + UserCookie.Value + ", " + txtAmount.Text + ", " + Session["Phone"].ToString(), false);

                    //capture IP
                    Payment oPayment = new Payment();
                    oPayment = oUserDAO.RetrievePaymentbyConfID(Session["conf"].ToString());
                    oUserDAO.InsertIP(UserCookie.Value, GetIPAddress(), oPayment.ID);

                }

                if (mycontent.Contains("Backend system error"))
                {
                    

                    if (mycontent.Contains("10000017"))
                    {
                        Session["error"] = "error4";
                        Session["conf"] = "";
                    }
                    else
                    {
                        Session["error"] = mycontent;
                        Session["conf"] = "";
                        oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), Session["cc"].ToString(), Session["provider"].ToString() + "($" + Session["provideramount"].ToString() + ") - " + mycontent.ToString());
                    }
                    if (mycontent.Contains("10000013"))
                    {
                        //Session["error"] = "error13";
                        oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), Session["cc"].ToString(), Session["provider"].ToString() + "($" + Session["provideramount"].ToString() + ") - " + mycontent.ToString());
                        //oUserDAO.DisableCard(cc, false);
                        TextAndEmail(Session["provider"].ToString() + " Payment Error", UserCookie.Value + " tried to make payment. No payments was made - " + mycontent.ToString() + " sent over as manual", true);
                        //ManualPayment();

                    }
                    if (mycontent.Contains("10001099"))
                    {
                        Session["error"] = "error99";
                        oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), Session["cc"].ToString(), Session["provider"].ToString() + "($" + Session["provideramount"].ToString() + ") - " + mycontent.ToString());
                    }
                    if (mycontent.Contains("10000117"))
                    {
                        Session["error"] = "errorDup";
                        oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), Session["cc"].ToString(), Session["provider"].ToString() + "($" + Session["provideramount"].ToString() + ") - " + mycontent.ToString());
                    }
                    if (mycontent.Contains("10000115"))
                    {
                        oUserDAO.DisableCard(Session["cc"].ToString(), false);

                        //CC oCC = new CC();
                        //oCC = oUserDAO.RetrieveCC();
                        //CC oCC2 = new CC();
                        //oCC2 = oUserDAO.RetrieveCC2();

                        //string thecc = "";
                        //string thecvv = "";
                        //string expDate = "";
                        //string ZIP = "";

                        //if (oCC.Used != null)
                        //{
                        //    cc = oCC.CCNumber;
                        //    Session["cc"] = cc;
                        //    thecc = DAO.Decrypt(oCC.CCNumber, ConfigurationManager.AppSettings["encryptionKey"]).Trim();
                        //    thecvv = oCC.CVV.Trim();
                        //    expDate = oCC.ExpDate;
                        //    ZIP = oCC.ZIP;
                        //}
                        //else if (oCC2.Used != null)
                        //{
                        //    cc = oCC2.CCNumber;
                        //    Session["cc"] = cc;
                        //    thecc = DAO.Decrypt(oCC2.CCNumber, ConfigurationManager.AppSettings["encryptionKey"]).Trim();
                        //    thecvv = oCC2.CVV.Trim();
                        //    expDate = oCC2.ExpDate;
                        //    ZIP = oCC2.ZIP;

                        //}
                        //await MetroPostRequest("https://www.metrobyt-mobile.com/api/v1/billing/payment/authorize-anonymous", Convert.ToDecimal(Session["provideramount"]), thecc, GenerateName(5), GenerateName(6), expDate, thecvv, ZIP, Session["Phone"].ToString(), metrocc);
                        oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), Session["cc"].ToString(), Session["provider"].ToString() + "($" + Session["provideramount"].ToString() + ") - " + mycontent.ToString());
                        TextAndEmail(Session["provider"].ToString() + " Payment Error", UserCookie.Value + " tried to make payment. No payments was made - " + mycontent.ToString() + " sent over as manual", true);
                        Session["error"] = "error3";

                    }
                    if (mycontent.Contains("10000018"))
                    {

                        //CC oCC = new CC();
                        //oCC = oUserDAO.RetrieveBackUpCC();
                        //CC oCC2 = new CC();
                        //oCC2 = oUserDAO.RetrieveBackUpCC2();
                        //CC oCC3 = new CC();
                        //oCC3 = oUserDAO.RetrieveBackUpCC3();


                        //string thecc = "";
                        //string thecvv = "";
                        //string expDate = "";
                        //string ZIP = "";

                        //if (oCC3.Used == null)
                        //{
                        //    //back up 2 to DP
                        //    Session["offeringid"] = "30175480";
                        //    DPMobilePayment();
                        //}

                        //if (oCC.Used != null)
                        //{
                        //    cc = oCC.CCNumber;
                        //    Session["cc"] = cc;
                        //    thecc = DAO.Decrypt(oCC.CCNumber, ConfigurationManager.AppSettings["encryptionKey"]).Trim();
                        //    thecvv = oCC.CVV.Trim();
                        //    expDate = oCC.ExpDate;
                        //    ZIP = oCC.ZIP;
                        //    metrocc = oCC.Address;
                        //}
                        //else if (oCC2.Used != null)
                        //{
                        //    cc = oCC2.CCNumber;
                        //    Session["cc"] = cc;
                        //    thecc = DAO.Decrypt(oCC2.CCNumber, ConfigurationManager.AppSettings["encryptionKey"]).Trim();
                        //    thecvv = oCC2.CVV.Trim();
                        //    expDate = oCC2.ExpDate;
                        //    ZIP = oCC2.ZIP;
                        //    metrocc = oCC2.Address;
                        //}
                        //else if (oCC3.Used != null)
                        //{
                        //    cc = oCC3.CCNumber;
                        //    Session["cc"] = cc;
                        //    thecc = DAO.Decrypt(oCC3.CCNumber, ConfigurationManager.AppSettings["encryptionKey"]).Trim();
                        //    thecvv = oCC3.CVV.Trim();
                        //    expDate = oCC3.ExpDate;
                        //    ZIP = oCC3.ZIP;
                        //    metrocc = oCC3.Address;
                        //}

                        //await MetroPostRequestBackUp("https://www.metrobyt-mobile.com/api/v1/billing/payment/authorize-anonymous", Convert.ToDecimal(Session["provideramount"]), thecc, GenerateName(5), GenerateName(6), expDate, thecvv, ZIP, Session["Phone"].ToString(), metrocc);

                        //back up 2 to DP
                        Session["offeringid"] = "30175480";
                        DPMobilePayment();

                        //Session["error"] = "error18";
                        //Session["conf"] = "";
                        oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), Session["cc"].ToString(), Session["provider"].ToString() + "($" + Session["provideramount"].ToString() + ") - " + mycontent.ToString());
                        TextAndEmail(Session["provider"].ToString() + " Payment Error", UserCookie.Value + " tried to make payment. No payments was made - " + mycontent.ToString(), true);
                    }
                    else
                    {
                        oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), Session["cc"].ToString(), Session["provider"].ToString() + "($" + Session["provideramount"].ToString() + ") - " + mycontent.ToString());
                        TextAndEmail(Session["provider"].ToString() + " Payment Error", UserCookie.Value + " tried to make payment. No payments was made - " + mycontent.ToString(), true);
                    }


                }
                else
                {
                    Session["error"] = "";
                }



            }
            catch (Exception ex)
            {
                oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), Session["cc"].ToString(), "MetroPCS -" + ex);
                TextAndEmail("Payment Error", "MetroPCS threw an error when " + UserCookie.Value + " tried to make payment. No payments was made", true);
                Response.Redirect("Error.aspx", false);
            }
        }

        async Task MetroPostRequestBackUp(string url, decimal amount, string cc, string firstname, string lastname, string expdate, string cvv, string zip, string number, string metrocc)
        {
            try
            {
                ServicePointManager.Expect100Continue = true;
                ServicePointManager.DefaultConnectionLimit = 9999;
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12 | SecurityProtocolType.Ssl3;

                //old way of doing metropcs payments
                //var client = new RestClient(url);
                //var request = new RestRequest(Method.POST);
                //request.AddHeader("postman-token", "a744fec0-2c03-8c52-33ac-875b59827bec");
                //request.AddHeader("cache-control", "no-cache");
                //request.AddHeader("origin", "https://www.metropcs.com");
                //request.AddHeader("referer", "https://www.metropcs.com/bill-pay.html");
                //request.AddHeader("content-type", "multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW");
                //request.AddParameter("multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW", "------WebKitFormBoundary7MA4YWxkTrZu0gW\r\nContent-Disposition: form-data; name=\"inputReqParam\"\r\n\r\n{\"serviceName\":\"profileManagementService\",\"serviceProviderName\":\"applicationSpecific\",\"requestParams\":{\"phoneNumber\":\"5612012168\"},\"componentId\":\"getLimitedCustomerInfo\",\"applicationId\":\"metropcs\",\"siteId\":\"metropcs\"}\r\n------WebKitFormBoundary7MA4YWxkTrZu0gW--", ParameterType.RequestBody);
                //IRestResponse response = client.Execute(request);

                string cardType = "MC";
                if (cc.StartsWith("5"))
                {
                    cardType = "MC";
                }
                else
                {
                    cardType = "VS";
                }

                var client = new RestClient(url);
                var request = new RestRequest(Method.POST);
                request.AddHeader("postman-token", "d3b6a44d-37da-edc5-61e6-57865347cff9");
                request.AddHeader("cache-control", "no-cache");
                request.AddHeader("referer", "https://www.metropcs.com/payment");
                request.AddHeader("mdn", number);
                request.AddHeader("content-type", "application/json");
                request.AddHeader("x-7xh4mcgiye-z", oMetroPCSSecurity.z);
                request.AddHeader("x-7xh4mcgiye-f", oMetroPCSSecurity.f);
                request.AddHeader("x-7xh4mcgiye-d", oMetroPCSSecurity.d);
                request.AddHeader("x-7xh4mcgiye-c", oMetroPCSSecurity.c);
                request.AddHeader("x-7xh4mcgiye-b", oMetroPCSSecurity.b);
                request.AddHeader("x-7xh4mcgiye-a", oMetroPCSSecurity.a);
                request.AddParameter("application/json", "{\"emailAddress\":\"9874559@gmail.com\",\"marketingPreference\":false,\"paymentDetails\":{\"amount\":\"" + amount + "\",\"confirmationEmailAddress\":\"9874559@gmail.com\",\"isDebitPreferred\":false,\"paymentType\":10,\"sensitiveAuthorizedCardInfo\":{\"cardNumber\":\"" + metrocc + "\",\"firstName\":\"" + GenerateName(5) + "\",\"lastName\":\"" + GenerateName(6) + "\",\"expDate\":\"" + expdate + "\",\"verificationCode\":\"" + cvv + "\",\"zipCode\":\"" + zip + "\",\"cardBrand\":\"MC\"},\"paymentMethodCode\":\"\"}}", ParameterType.RequestBody);
                IRestResponse response = client.Execute(request);



                string mycontent = response.Content;

                if (mycontent.Contains("billingConfirmationId"))
                {

                    Session["conf"] = getBetween(mycontent, "billingConfirmationId\":\"", "\",\"convenienceFee");


                    //update credit line
                    MetroFastPayLibrary.Account oAccount = new MetroFastPayLibrary.Account();
                    oAccount = oUserDAO.RetrieveAccount(UserCookie.Value);

                    User oFee = new User();
                    oFee = oUserDAO.RetrieveFeebyUserID(UserCookie.Value);
                    int doublepay = getPreviousPayment(Session["Phone"].ToString());
                    if (oAccount.Active == true)
                    {

                        if (doublepay >= 1)
                        {
                            oUserDAO.UpdateAccountbyPost(oAccount.Credit - Convert.ToInt32(txtAmount.Text), oUser.Post);
                            oUserDAO.InsertPayments(UserCookie.Value, oUser.Post, Session["Phone"].ToString(), Convert.ToDecimal(Session["provideramount"].ToString()), 0, Session["provider"].ToString() + " - Conf#:" + Session["conf"].ToString(), Session["cc"].ToString(), DateTime.Now);
                            //5 card warning
                            CCLeft();
                        }
                        else
                        {
                            oUserDAO.UpdateAccountbyPost(oAccount.Credit - (Convert.ToInt32(txtAmount.Text) + (Convert.ToInt32(oFee.Fee) - (Convert.ToInt32(oFee.Fee) - 2))), oUser.Post);
                            oUserDAO.InsertPayments(UserCookie.Value, oUser.Post, Session["Phone"].ToString(), Convert.ToDecimal(Session["provideramount"].ToString()), Convert.ToDecimal(oFee.Fee), Session["provider"].ToString() + " - Conf#:" + Session["conf"].ToString(), Session["cc"].ToString(), DateTime.Now);
                            //5 card warning
                            CCLeft();

                        }
                    }
                    else
                    {
                        if (doublepay >= 1)
                        {
                            //insert payments
                            oUserDAO.InsertPayments(UserCookie.Value, oUser.Post, Session["Phone"].ToString(), Convert.ToDecimal(Session["provideramount"].ToString()), 0, Session["provider"].ToString() + " - Conf#:" + Session["conf"].ToString(), Session["cc"].ToString(), DateTime.Now);
                            //5 card warning
                            CCLeft();
                        }
                        else
                        {
                            //insert payments
                            oUserDAO.InsertPayments(UserCookie.Value, oUser.Post, Session["Phone"].ToString(), Convert.ToDecimal(Session["provideramount"].ToString()), Convert.ToDecimal(oFee.Fee), Session["provider"].ToString() + " - Conf#:" + Session["conf"].ToString(), Session["cc"].ToString(), DateTime.Now);
                            //5 card warning
                            CCLeft();
                        }
                    }
                    //if online user then skip
                    if (UserCookie.Value != "FastPay Online")
                    {
                        CC oCC = new CC();
                        oCC = oUserDAO.RetrieveBackUpCC();
                        CC oCC2 = new CC();
                        oCC2 = oUserDAO.RetrieveBackUpCC2();
                        CC oCC3 = new CC();
                        oCC3 = oUserDAO.RetrieveBackUpCC3();

                        if (oCC.Used != null)
                        {
                            //update card used
                            int used = Convert.ToInt16(oCC.Used) + 1;
                            oUserDAO.UpdateCCUsageBackUp(Convert.ToString(used), oCC.CCNumber);

                        }
                        else if (oCC2.Used != null)
                        {
                            //update card used
                            int used = Convert.ToInt16(oCC2.Used) + 1;
                            oUserDAO.UpdateCCUsageBackUp(Convert.ToString(used), oCC2.CCNumber);

                            //CC oDisCC = new CC();
                            //oDisCC = oUserDAO.DisableCard(oCC2.CCNumber, false);
                        }
                        else if (oCC3.Used != null)
                        {
                            //update card used
                            int used = Convert.ToInt16(oCC3.Used) + 1;
                            oUserDAO.UpdateCCUsageBackUp(Convert.ToString(used), oCC3.CCNumber);


                            CC oDisCC = new CC();
                            oDisCC = oUserDAO.DisableCardBackUp(oCC3.CCNumber, false);
                        }
                    }
                    //text
                    //TextAndEmail("Telbug Payment - MetroPCS", UserCookie.Value + " made a payment of $" + string.Format("{0:0.00}", txtAmount.Text) + " to " + Session["Phone"].ToString(), false);
                    TextAndEmail("MetroPCS ", "MetroPCS, " + UserCookie.Value + ", " + txtAmount.Text + ", " + Session["Phone"].ToString(), false);

                    //capture IP
                    Payment oPayment = new Payment();
                    oPayment = oUserDAO.RetrievePaymentbyConfID(Session["conf"].ToString());
                    oUserDAO.InsertIP(UserCookie.Value, GetIPAddress(), oPayment.ID);

                }

                if (mycontent.Contains("Backend system error"))
                {


                    if (mycontent.Contains("10000017"))
                    {
                        Session["error"] = "error4";
                        Session["conf"] = "";
                    }
                    else
                    {
                        Session["error"] = mycontent;
                        Session["conf"] = "";
                    }
                    if (mycontent.Contains("10000013"))
                    {
                        Session["error"] = "error13";

                    }
                    if (mycontent.Contains("10001099"))
                    {
                        Session["error"] = "error99";
                    }
                    if (mycontent.Contains("10000117"))
                    {
                        Session["error"] = "errorDup";
                    }
                    if (mycontent.Contains("10000018"))
                    {
                        //back up 2 to DP
                        Session["offeringid"] = "30175480";
                        DPMobilePayment();
                    }
                    if (mycontent.Contains("10000115"))
                    {
                        oUserDAO.DisableCardBackUp(Session["cc"].ToString(), false);

                        //back up 2 to DP
                        Session["offeringid"] = "30175480";
                        DPMobilePayment();
                    }

                }
                else
                {
                    Session["error"] = "";
                }



            }
            catch (Exception ex)
            {
                oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), Session["cc"].ToString(), "MetroPCS -" + ex);
                TextAndEmail("Payment Error", "MetroPCS threw an error when " + UserCookie.Value + " tried to make payment. No payments was made", true);
                Response.Redirect("Error.aspx", false);
            }
        }
        async Task payMetroByPhone(string phone, string amount, string cc, string expdate, string cvv)
        {
            try
            {
                ServicePointManager.Expect100Continue = true;
                ServicePointManager.DefaultConnectionLimit = 9999;
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12 | SecurityProtocolType.Ssl3;

                expdate = expdate.Replace("/", "");
                var client = new RestClient("http://orqclasea.com/api/products/MakeMetroPaymentByCall/" + phone + "/" + amount + "/" + cc + "/" + expdate + "/" + cvv + "/JXdXJnLPToP7nHEaVp8yYQ==/W36LMly02eDkS9QY9J149RomrFVdR4SC2fSE35oZX-M=");
                var request = new RestRequest(Method.POST);
                request.AddHeader("postman-token", "f83362a9-f459-cfea-da6c-9f51266621ce");
                request.AddHeader("cache-control", "no-cache");
                IRestResponse response = client.Execute(request);
                string s = response.Content;


                if (s.Contains("Payment Processing..."))
                {
                    CC oCC = new CC();
                    oCC = oUserDAO.RetrieveCC();
                    CC oCC2 = new CC();
                    oCC2 = oUserDAO.RetrieveCC2();
                    CC oCC3 = new CC();
                    oCC3 = oUserDAO.RetrieveCC3();

                    if (oCC.Used != null)
                    {
                        //update card used
                        int used = Convert.ToInt16(oCC.Used) + 1;
                        oUserDAO.UpdateCCUsage(Convert.ToString(used), oCC.CCNumber);

                    }
                    else if (oCC2.Used != null)
                    {
                        //update card used
                        int used = Convert.ToInt16(oCC2.Used) + 1;
                        oUserDAO.UpdateCCUsage(Convert.ToString(used), oCC2.CCNumber);


                        //CC oDisCC = new CC();
                        //oDisCC = oUserDAO.DisableCard(oCC2.CCNumber, false);
                    }
                    else if (oCC3.Used != null)
                    {
                        //update card used
                        int used = Convert.ToInt16(oCC3.Used) + 1;
                        oUserDAO.UpdateCCUsage(Convert.ToString(used), oCC3.CCNumber);

                        CC oDisCC = new CC();
                        oDisCC = oUserDAO.DisableCard(oCC3.CCNumber, false);


                    }



                    Session["error"] = "";
                }
                else
                {


                    Session["error"] = "error3";
                }

            }
            catch (Exception ex)
            {
                oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), Session["cc"].ToString(), Session["provider"].ToString() + "($" + Session["provideramount"].ToString() + ") - " + ex.ToString());
                TextAndEmailNew("Payment Error", "Metro threw an error when " + UserCookie.Value + " tried to make payment. No payments was made", true);
                Response.Redirect("Error.aspx", false);
            }
        }
        async Task CheckMetro(string number)
        {
            try
            {

                ServicePointManager.Expect100Continue = true;
                ServicePointManager.DefaultConnectionLimit = 9999;
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12 | SecurityProtocolType.Ssl3;

                //old way of doing things for metropcs
                //var client = new RestClient(url);
                //var request = new RestRequest(Method.POST);
                //request.AddHeader("postman-token", "a744fec0-2c03-8c52-33ac-875b59827bec");
                //request.AddHeader("cache-control", "no-cache");
                //request.AddHeader("origin", "https://www.metropcs.com");
                //request.AddHeader("referer", "https://www.metropcs.com/bill-pay.html");
                //request.AddHeader("content-type", "multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW");
                //request.AddParameter("multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW", "------WebKitFormBoundary7MA4YWxkTrZu0gW\r\nContent-Disposition: form-data; name=\"inputReqParam\"\r\n\r\n{\"serviceName\":\"profileManagementService\",\"serviceProviderName\":\"applicationSpecific\",\"requestParams\":{\"phoneNumber\":\"5612012168\"},\"componentId\":\"getLimitedCustomerInfo\",\"applicationId\":\"metropcs\",\"siteId\":\"metropcs\"}\r\n------WebKitFormBoundary7MA4YWxkTrZu0gW--", ParameterType.RequestBody);
                //IRestResponse response = client.Execute(request);
                oMetroPCSSecurity = oUserDAO.GetAllX49exvsbl();
                var client = new RestClient("https://www.metrobyt-mobile.com/api/v1/billing/payment/validate-mdn");
                var request = new RestRequest(Method.POST);
                request.AddHeader("postman-token", "37ac1819-7324-0c2f-aee2-23e414fded1a");
                request.AddHeader("cache-control", "no-cache");
                request.AddHeader("mdn", number);
                request.AddHeader("x-7xh4mcgiye-z", oMetroPCSSecurity.z);
                request.AddHeader("x-7xh4mcgiye-f", oMetroPCSSecurity.f);
                request.AddHeader("x-7xh4mcgiye-d", oMetroPCSSecurity.d);
                request.AddHeader("x-7xh4mcgiye-c", oMetroPCSSecurity.c);
                request.AddHeader("x-7xh4mcgiye-b", oMetroPCSSecurity.b);
                request.AddHeader("x-7xh4mcgiye-a", oMetroPCSSecurity.a);
                //request.AddHeader("x-49exvsbl-uniquestatekey", oMetroPCSSecurity.uniquestatekey);// "A-sRC5NpAQAAYgsCEbwAVt2P9KWLq_HOg-86gWSL0D-qeOYfhvCU2h66jXRtAawUMfGuctHLwH8AABszAAAAAA==");
                IRestResponse response = client.Execute(request);


                //var response = await _Client.GetAsync(url);
                //HttpContent content = response.Content;
                //string mycontent3 = await content.ReadAsStringAsync();
                if (response.Content.Length > 0)
                {
                    string s = response.Content;

                    Session["conf"] = "";
                    Session["error"] = "";
                    if (s.Contains("Transaction failed"))
                    {
                        Session["error"] = "error1";
                    }
                }
                else
                {
                    UserDAO oUserDAO = new UserDAO();
                    MetroFastPayLibrary.MetroPCSSecurity oMetroPCSSecurity = new MetroFastPayLibrary.MetroPCSSecurity();
                    oMetroPCSSecurity = oUserDAO.RetrieveMSbyA();
                   
                    if(oMetroPCSSecurity.b != null)
                    {
                        oUserDAO.DeleteMS(oMetroPCSSecurity.b);
                        TextAndEmail("Telbug Error", "MetroPCS security had been changed", true);
                        await CheckMetro(number);
                    }
                    else
                    {
                        TextAndEmail("Telbug Error", "Change MetroPCS Security", true);
                        ManualPayment();
                        return;
                        //Session["error"] = "error3";
                    }

   

                    Session["conf"] = "";
                    
                }

            }
            catch (Exception ex)
            {
                TextAndEmail("Payment Error", "Metro threw an error when " + UserCookie.Value + " tried to make payment. No payments was made", true);
                Response.Redirect("Error.aspx");
            }
        }
        async Task payCricketAPI(string amount, string number, string cc, string cvv, string expdate)
        {
            try
            {
                ServicePointManager.Expect100Continue = true;
                ServicePointManager.DefaultConnectionLimit = 9999;
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12 | SecurityProtocolType.Ssl3;

                expdate = expdate.Replace("/", "");
                var client = new RestClient("http://73.245.250.27:85/api/products/paycricket/" + amount + "/" + number + "/" + cc + "/" + cvv + "/" + expdate);
                var request = new RestRequest(Method.POST);
                request.AddHeader("postman-token", "f83362a9-f459-cfea-da6c-9f51266621ce");
                request.AddHeader("cache-control", "no-cache");
                IRestResponse response = client.Execute(request);
                string s = response.Content;


                if (s.Contains("Error") || s.Contains("Success"))
                {
                    if (s.Contains("failure"))
                    {

                        Session["error"] = "error3";
                        Session["conf"] = "";

                        if (s.Contains("1006"))
                        {
                            Session["error"] = "error1";
                            Session["conf"] = "";
                        }
                        else
                        {
                            oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), Session["cc"].ToString(), Session["provider"].ToString() + "($" + Session["provideramount"].ToString() + ") - " + s.ToString());
                            TextAndEmail(Session["provider"].ToString() + " Payment Error", UserCookie.Value + " tried to make payment. No payments was made - " + s.ToString(), true);
                        }
                    }
                    if (s.Contains("5000"))
                    {
                        CC oDisCC = new CC();
                        oDisCC = oUserDAO.DisableCard(oCC.CCNumber, false);
                        Session["error"] = "error5000";
                    }

                    if (s.Contains("1009"))
                    {
                        Session["error"] = "error6";
                        Session["conf"] = "";

                    }

                    if (s.Contains("Confirmationid"))
                    {

                        Session["conf"] = getBetween(s, "Success:{Confirmationid : ", "}");

                        //update credit line
                        MetroFastPayLibrary.Account oAccount = new MetroFastPayLibrary.Account();
                        oAccount = oUserDAO.RetrieveAccount(UserCookie.Value);
                        int doublepay = getPreviousPayment(Session["Phone"].ToString());
                        User oFee = new User();
                        oFee = oUserDAO.RetrieveFeebyUserID(UserCookie.Value);
                        if (oAccount.Active == true)
                        {

                            if (doublepay >= 1)
                            {
                                oUserDAO.UpdateAccountbyPost(oAccount.Credit - Convert.ToInt32(txtAmount.Text), oUser.Post);
                                //insert payments
                                oUserDAO.InsertPayments(UserCookie.Value, oUser.Post, Session["Phone"].ToString(), Convert.ToDecimal(Session["provideramount"].ToString()), 0, Session["provider"].ToString() + " - Conf#:" + Session["conf"].ToString(), Session["cc"].ToString(), DateTime.Now);
                                //5 card warning
                                CricketCCLeft();
                            }
                            else
                            {

                                oUserDAO.UpdateAccountbyPost(oAccount.Credit - (Convert.ToInt32(txtAmount.Text) + (Convert.ToInt32(oFee.Fee) - (Convert.ToInt32(oFee.Fee) - 2))), oUser.Post);
                                oUserDAO.InsertPayments(UserCookie.Value, oUser.Post, Session["Phone"].ToString(), Convert.ToDecimal(Session["provideramount"].ToString()), Convert.ToDecimal(oFee.Fee), Session["provider"].ToString() + " - Conf#:" + Session["conf"].ToString(), Session["cc"].ToString(), DateTime.Now);
                                //5 card warning
                                CricketCCLeft();

                            }
                        }
                        else
                        {
                            if (doublepay >= 1)
                            {
                                //insert payments
                                oUserDAO.InsertPayments(UserCookie.Value, oUser.Post, Session["Phone"].ToString(), Convert.ToDecimal(Session["provideramount"].ToString()), 0, Session["provider"].ToString() + " - Conf#:" + Session["conf"].ToString(), Session["cc"].ToString(), DateTime.Now);
                                //5 card warning
                                CricketCCLeft();
                            }
                            else
                            {
                                //insert payments
                                oUserDAO.InsertPayments(UserCookie.Value, oUser.Post, Session["Phone"].ToString(), Convert.ToDecimal(Session["provideramount"].ToString()), Convert.ToDecimal(oFee.Fee), Session["provider"].ToString() + " - Conf#:" + Session["conf"].ToString(), Session["cc"].ToString(), DateTime.Now);
                                //5 card warning
                                CricketCCLeft();
                            }
                        }

                        if (UserCookie.Value != "FastPay Online")
                        {
                            CC oCC = new CC();
                            oCC = oUserDAO.RetrieveCricketCC();
                            CC oCC2 = new CC();
                            oCC2 = oUserDAO.RetrieveCricketCC2();
                            CC oCC3 = new CC();
                            oCC3 = oUserDAO.RetrieveCricketCC3();


                            if (oCC.Used != null)
                            {
                                //update card used
                                int used = Convert.ToInt16(oCC.Used) + 1;
                                oUserDAO.UpdateCCUsage(Convert.ToString(used), oCC.CCNumber);

                                //update ccusage
                                //Usage oUsage = new Usage();
                                //oUsage = oUserDAO.RetrieveCCAmountUsed(oCC.FirstName.Substring(0, 1).ToUpper() + oCC.LastName.Substring(0, 1).ToUpper());
                                //oUserDAO.UpdateCCAmountUsed(oCC.FirstName.Substring(0, 1).ToUpper() + oCC.LastName.Substring(0, 1).ToUpper(), oUsage.CurrentAmount + Convert.ToInt32(txtAmount.Text));

                                //if (oUsage.MaxAmount <= oUsage.CurrentAmount)
                                //{
                                //    //makes cards in cc table false 
                                //    oUserDAO.UpdateCCUsageByName(oCC.FirstName.Substring(0, 1).ToUpper(), oCC.LastName.Substring(0, 1).ToUpper());

                                //    //makes ccusage false
                                //    oUserDAO.UpdateCCUsageToFalse(oCC.FirstName.Substring(0, 1).ToUpper() + oCC.LastName.Substring(0, 1).ToUpper());

                                //    //send text
                                //    TextAndEmail("Card: " + oCC.FirstName.Substring(0, 1).ToUpper() + oCC.LastName.Substring(0, 1).ToUpper() + " has been maxed out", "Marcos, go put new cards in the system");
                                //}


                                CC oDisCC = new CC();
                                oDisCC = oUserDAO.DisableCard(oCC.CCNumber, false);
                            }
                            else if (oCC2.Used != null)
                            {
                                //update card used
                                int used = Convert.ToInt16(oCC2.Used) + 1;
                                oUserDAO.UpdateCCUsage(Convert.ToString(used), oCC2.CCNumber);

                                //update ccusage
                                //Usage oUsage = new Usage();
                                //oUsage = oUserDAO.RetrieveCCAmountUsed(oCC2.FirstName.Substring(0, 1).ToUpper() + oCC2.LastName.Substring(0, 1).ToUpper());
                                //oUserDAO.UpdateCCAmountUsed(oCC2.FirstName.Substring(0, 1).ToUpper() + oCC2.LastName.Substring(0, 1).ToUpper(), oUsage.CurrentAmount + Convert.ToInt32(txtAmount.Text));

                                //if (oUsage.MaxAmount <= oUsage.CurrentAmount)
                                //{
                                //    //makes cards in cc table false 
                                //    oUserDAO.UpdateCCUsageByName(oCC2.FirstName.Substring(0, 1).ToUpper(), oCC2.LastName.Substring(0, 1).ToUpper());

                                //    //makes ccusage false
                                //    oUserDAO.UpdateCCUsageToFalse(oCC2.FirstName.Substring(0, 1).ToUpper() + oCC2.LastName.Substring(0, 1).ToUpper());

                                //    //send text
                                //    TextAndEmail("Card: " + oCC2.FirstName.Substring(0, 1).ToUpper() + oCC2.LastName.Substring(0, 1).ToUpper() + " has been maxed out", "Marcos, go put new cards in the system");
                                //}

                                CC oDisCC = new CC();
                                oDisCC = oUserDAO.DisableCard(oCC.CCNumber, false);
                            }
                            else if (oCC3.Used != null)
                            {
                                //update card used
                                int used = Convert.ToInt16(oCC3.Used) + 1;
                                oUserDAO.UpdateCCUsage(Convert.ToString(used), oCC3.CCNumber);

                                //update ccusage
                                //Usage oUsage = new Usage();
                                //oUsage = oUserDAO.RetrieveCCAmountUsed(oCC3.FirstName.Substring(0, 1).ToUpper() + oCC3.LastName.Substring(0, 1).ToUpper());
                                //oUserDAO.UpdateCCAmountUsed(oCC3.FirstName.Substring(0, 1).ToUpper() + oCC3.LastName.Substring(0, 1).ToUpper(), oUsage.CurrentAmount + Convert.ToInt32(txtAmount.Text));

                                //if (oUsage.MaxAmount <= oUsage.CurrentAmount)
                                //{
                                //    //makes cards in cc table false 
                                //    oUserDAO.UpdateCCUsageByName(oCC3.FirstName.Substring(0, 1).ToUpper(), oCC3.LastName.Substring(0, 1).ToUpper());

                                //    //makes ccusage false
                                //    oUserDAO.UpdateCCUsageToFalse(oCC3.FirstName.Substring(0, 1).ToUpper() + oCC3.LastName.Substring(0, 1).ToUpper());

                                //    //send text
                                //    TextAndEmail("Card: " + oCC3.FirstName.Substring(0, 1).ToUpper() + oCC3.LastName.Substring(0, 1).ToUpper() + " has been maxed out", "Marcos, go put new cards in the system");
                                //}

                                CC oDisCC = new CC();
                                oDisCC = oUserDAO.DisableCard(oCC3.CCNumber, false);
                            }
                        }

                        //text
                        //TextAndEmail("Telbug Payment - Cricket", UserCookie.Value + " made a payment of $" + string.Format("{0:0.00}", txtAmount.Text) + " to " + Session["Phone"].ToString());
                        TextAndEmail("Cricket", "Cricket, " + UserCookie.Value + ", " + txtAmount.Text + ", " + Session["Phone"].ToString(), false);

                        //capture IP
                        Payment oPayment = new Payment();
                        oPayment = oUserDAO.RetrievePaymentbyConfID(Session["conf"].ToString());
                        oUserDAO.InsertIP(UserCookie.Value, GetIPAddress(), oPayment.ID);



                        Session["error"] = "";
                    }

                }
                else
                {

                    Session["error"] = "error3";
                    Session["conf"] = "";
                    oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), Session["cc"].ToString(), Session["provider"].ToString() + "($" + Session["provideramount"].ToString() + ") - " + s.ToString());
                }
            }
            catch (Exception ex)
            {
                oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), Session["cc"].ToString(), Session["provider"].ToString() + "($" + Session["provideramount"].ToString() + ") - " + ex.ToString());
                TextAndEmail("Payment Error", "Cricket threw an error when " + UserCookie.Value + " tried to make payment. No payments was made", true);
                Response.Redirect("Error.aspx", false);
            }
        }

        async Task paycriket(string Cricketamount, string Cricketpostalcode, string Cricketctn, string Cricketcc, string Cricketcardname, string CricketcardExpirationDate, string CricketsecurityCode)
        {
            try
            {
                ServicePointManager.Expect100Continue = true;
                ServicePointManager.DefaultConnectionLimit = 9999;
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12 | SecurityProtocolType.Ssl3;
               // _Client = GetProxyClient();
                _Client = new HttpClient();
                _Client.BaseAddress = new Uri("https://www.cricketwireless.com");
                _Client.DefaultRequestHeaders.Accept.Clear();
                _Client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                _Client.DefaultRequestHeaders.AcceptCharset.Add(new StringWithQualityHeaderValue("UTF-8"));

                

                Cricketpostalcode = "33415";
                Data data = new Data(Cricketamount, Cricketpostalcode, Cricketctn, Cricketcc, Cricketcardname, CricketcardExpirationDate, CricketsecurityCode);

                var myContent = JsonConvert.SerializeObject(data);
                var buffer = System.Text.Encoding.UTF8.GetBytes(myContent);
                var byteContent = new ByteArrayContent(buffer);
                byteContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                byteContent.Headers.ContentLength = myContent.Length;
                byteContent.Headers.Add("ContentType", "application/json");



                var response = await _Client.PostAsync("selfservice/rest/quickpay/creditcard/", byteContent);
                HttpContent content = response.Content;
                string mycontent2 = await content.ReadAsStringAsync();
                string s = response.Content.ReadAsStringAsync().Result;
                if (response.IsSuccessStatusCode)
                {
                    

                    if (s.Contains("failure"))
                    {

                        Session["error"] = "error3";
                        Session["conf"] = "";

                        if (s.Contains("1006"))
                        {
                            Session["error"] = "error1";
                            Session["conf"] = "";
                        }
                        else
                        {
                            oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), Session["cc"].ToString(), Session["provider"].ToString() + "($" + Session["provideramount"].ToString() + ") - " + s.ToString());
                             TextAndEmail(Session["provider"].ToString() + " Payment Error", UserCookie.Value + " tried to make payment. No payments was made - " + s.ToString(), true);
                        }
                    }
                    if (s.Contains("5000"))
                    {
                        CC oDisCC = new CC();
                        oDisCC = oUserDAO.DisableCard(DAO.Encrypt(Cricketcc, ConfigurationManager.AppSettings["encryptionKey"]), false);
                        Session["error"] = "error5000";
                    }

                    if (s.Contains("1009"))
                    {
                        Session["error"] = "error6";
                        Session["conf"] = "";

                    }

                    if (s.Contains("confirmationId"))
                    {

                        Session["conf"] = getBetween(s, "confirmationId\":\"", "\",\"amountReceived\"");

                        //update credit line
                        MetroFastPayLibrary.Account oAccount = new MetroFastPayLibrary.Account();
                        oAccount = oUserDAO.RetrieveAccount(UserCookie.Value);
                        int doublepay = getPreviousPayment(Session["Phone"].ToString());
                        User oFee = new User();
                        oFee = oUserDAO.RetrieveFeebyUserID(UserCookie.Value);
                        if (oAccount.Active == true)
                        {

                            if (doublepay >= 1)
                            {
                                oUserDAO.UpdateAccountbyPost(oAccount.Credit - Convert.ToInt32(txtAmount.Text), oUser.Post);
                                //insert payments
                                oUserDAO.InsertPayments(UserCookie.Value, oUser.Post, Session["Phone"].ToString(), Convert.ToDecimal(Session["provideramount"].ToString()), 0, Session["provider"].ToString() + " - Conf#:" + Session["conf"].ToString(), Session["cc"].ToString(), DateTime.Now);
                                //5 card warning
                                CricketCCLeft();
                            }
                            else
                            {

                                oUserDAO.UpdateAccountbyPost(oAccount.Credit - (Convert.ToInt32(txtAmount.Text) + (Convert.ToInt32(oFee.Fee) - (Convert.ToInt32(oFee.Fee) - 2))), oUser.Post);
                                oUserDAO.InsertPayments(UserCookie.Value, oUser.Post, Session["Phone"].ToString(), Convert.ToDecimal(Session["provideramount"].ToString()), Convert.ToDecimal(oFee.Fee), Session["provider"].ToString() + " - Conf#:" + Session["conf"].ToString(), Session["cc"].ToString(), DateTime.Now);
                                //5 card warning
                                CricketCCLeft();

                            }
                        }
                        else
                        {
                            if (doublepay >= 1)
                            {
                                //insert payments
                                oUserDAO.InsertPayments(UserCookie.Value, oUser.Post, Session["Phone"].ToString(), Convert.ToDecimal(Session["provideramount"].ToString()), 0, Session["provider"].ToString() + " - Conf#:" + Session["conf"].ToString(), Session["cc"].ToString(), DateTime.Now);
                                //5 card warning
                                CricketCCLeft();
                            }
                            else
                            {
                                //insert payments
                                oUserDAO.InsertPayments(UserCookie.Value, oUser.Post, Session["Phone"].ToString(), Convert.ToDecimal(Session["provideramount"].ToString()), Convert.ToDecimal(oFee.Fee), Session["provider"].ToString() + " - Conf#:" + Session["conf"].ToString(), Session["cc"].ToString(), DateTime.Now);
                                //5 card warning
                                CricketCCLeft();
                            }
                        }

                        if (UserCookie.Value != "FastPay Online")
                        {
                            CC oCC = new CC();
                            oCC = oUserDAO.RetrieveCricketCC();
                            CC oCC2 = new CC();
                            oCC2 = oUserDAO.RetrieveCricketCC2();
                            CC oCC3 = new CC();
                            oCC3 = oUserDAO.RetrieveCricketCC3();


                            if (oCC.Used != null)
                            {
                                //update card used
                                int used = Convert.ToInt16(oCC.Used) + 1;
                                oUserDAO.UpdateCCUsage(Convert.ToString(used), oCC.CCNumber);

                                //update ccusage
                                //Usage oUsage = new Usage();
                                //oUsage = oUserDAO.RetrieveCCAmountUsed(oCC.FirstName.Substring(0, 1).ToUpper() + oCC.LastName.Substring(0, 1).ToUpper());
                                //oUserDAO.UpdateCCAmountUsed(oCC.FirstName.Substring(0, 1).ToUpper() + oCC.LastName.Substring(0, 1).ToUpper(), oUsage.CurrentAmount + Convert.ToInt32(txtAmount.Text));

                                //if (oUsage.MaxAmount <= oUsage.CurrentAmount)
                                //{
                                //    //makes cards in cc table false 
                                //    oUserDAO.UpdateCCUsageByName(oCC.FirstName.Substring(0, 1).ToUpper(), oCC.LastName.Substring(0, 1).ToUpper());

                                //    //makes ccusage false
                                //    oUserDAO.UpdateCCUsageToFalse(oCC.FirstName.Substring(0, 1).ToUpper() + oCC.LastName.Substring(0, 1).ToUpper());

                                //    //send text
                                //    TextAndEmail("Card: " + oCC.FirstName.Substring(0, 1).ToUpper() + oCC.LastName.Substring(0, 1).ToUpper() + " has been maxed out", "Marcos, go put new cards in the system");
                                //}


                                CC oDisCC = new CC();
                                oDisCC = oUserDAO.DisableCard(oCC.CCNumber, false);
                            }
                            else if (oCC2.Used != null)
                            {
                                //update card used
                                int used = Convert.ToInt16(oCC2.Used) + 1;
                                oUserDAO.UpdateCCUsage(Convert.ToString(used), oCC2.CCNumber);

                                //update ccusage
                                //Usage oUsage = new Usage();
                                //oUsage = oUserDAO.RetrieveCCAmountUsed(oCC2.FirstName.Substring(0, 1).ToUpper() + oCC2.LastName.Substring(0, 1).ToUpper());
                                //oUserDAO.UpdateCCAmountUsed(oCC2.FirstName.Substring(0, 1).ToUpper() + oCC2.LastName.Substring(0, 1).ToUpper(), oUsage.CurrentAmount + Convert.ToInt32(txtAmount.Text));

                                //if (oUsage.MaxAmount <= oUsage.CurrentAmount)
                                //{
                                //    //makes cards in cc table false 
                                //    oUserDAO.UpdateCCUsageByName(oCC2.FirstName.Substring(0, 1).ToUpper(), oCC2.LastName.Substring(0, 1).ToUpper());

                                //    //makes ccusage false
                                //    oUserDAO.UpdateCCUsageToFalse(oCC2.FirstName.Substring(0, 1).ToUpper() + oCC2.LastName.Substring(0, 1).ToUpper());

                                //    //send text
                                //    TextAndEmail("Card: " + oCC2.FirstName.Substring(0, 1).ToUpper() + oCC2.LastName.Substring(0, 1).ToUpper() + " has been maxed out", "Marcos, go put new cards in the system");
                                //}

                                CC oDisCC = new CC();
                                oDisCC = oUserDAO.DisableCard(oCC.CCNumber, false);
                            }
                            else if (oCC3.Used != null)
                            {
                                //update card used
                                int used = Convert.ToInt16(oCC3.Used) + 1;
                                oUserDAO.UpdateCCUsage(Convert.ToString(used), oCC3.CCNumber);

                                //update ccusage
                                //Usage oUsage = new Usage();
                                //oUsage = oUserDAO.RetrieveCCAmountUsed(oCC3.FirstName.Substring(0, 1).ToUpper() + oCC3.LastName.Substring(0, 1).ToUpper());
                                //oUserDAO.UpdateCCAmountUsed(oCC3.FirstName.Substring(0, 1).ToUpper() + oCC3.LastName.Substring(0, 1).ToUpper(), oUsage.CurrentAmount + Convert.ToInt32(txtAmount.Text));

                                //if (oUsage.MaxAmount <= oUsage.CurrentAmount)
                                //{
                                //    //makes cards in cc table false 
                                //    oUserDAO.UpdateCCUsageByName(oCC3.FirstName.Substring(0, 1).ToUpper(), oCC3.LastName.Substring(0, 1).ToUpper());

                                //    //makes ccusage false
                                //    oUserDAO.UpdateCCUsageToFalse(oCC3.FirstName.Substring(0, 1).ToUpper() + oCC3.LastName.Substring(0, 1).ToUpper());

                                //    //send text
                                //    TextAndEmail("Card: " + oCC3.FirstName.Substring(0, 1).ToUpper() + oCC3.LastName.Substring(0, 1).ToUpper() + " has been maxed out", "Marcos, go put new cards in the system");
                                //}

                                CC oDisCC = new CC();
                                oDisCC = oUserDAO.DisableCard(oCC3.CCNumber, false);
                            }
                        }

                        //text
                        //TextAndEmail("Telbug Payment - Cricket", UserCookie.Value + " made a payment of $" + string.Format("{0:0.00}", txtAmount.Text) + " to " + Session["Phone"].ToString());
                        TextAndEmail("Cricket", "Cricket, " + UserCookie.Value + ", " + txtAmount.Text + ", " + Session["Phone"].ToString(), false);

                        //capture IP
                        Payment oPayment = new Payment();
                        oPayment = oUserDAO.RetrievePaymentbyConfID(Session["conf"].ToString());
                        oUserDAO.InsertIP(UserCookie.Value, GetIPAddress(), oPayment.ID);



                        Session["error"] = "";
                    }

                }
                else
                {

                    Session["error"] = "error3";
                    Session["conf"] = "";
                    oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), Session["cc"].ToString(), Session["provider"].ToString() + "($" + Session["provideramount"].ToString() + ") - " + s.ToString());
                }

            }
            catch (Exception ex)
            {
                oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), Session["cc"].ToString(), Session["provider"].ToString() + "($" + Session["provideramount"].ToString() + ") - " + ex.ToString());
                TextAndEmail("Payment Error", "Cricket threw an error when " + UserCookie.Value + " tried to make payment. No payments was made", true);
                Response.Redirect("Error.aspx", false);
            }
        }
        async Task CheckBoost(string url, string number, string pin)
        {
            try
            {
                var client = new RestClient(url);
                var request = new RestRequest(Method.POST);
                request.AddHeader("postman-token", "ac609826-d0e7-ffe4-c6c6-0705268153f8");
                request.AddHeader("cache-control", "no-cache");
                request.AddHeader("applicationid", "OWO");
                request.AddHeader("brandcode", "BST");
                //request.AddHeader("consumerId", "PROD");
                request.AddHeader("messagedatetimestamp", string.Format("{0:yyyy-MM-ddTHH:mm:ssZ}", DateTime.Now));
                request.AddHeader("enterprisemessageid", "OWONdOB3OawZFslLIddiRFYSS");
                request.AddHeader("messageid", "ioN4v1TTbEckJVWTIrBEeW");
                //request.AddHeader("referer", "https://myaccount.boostmobile.com/primary/guest-replenish");
               request.AddHeader("content-type", "application/json");
                request.AddParameter("application/json", "{\r\n  \"mdn\": \"" + number + "\",\r\n  \"pin\": \"" + pin + "\",\r\n  \"scope\": \"login_auth\"\r\n}", ParameterType.RequestBody);
                IRestResponse response = client.Execute(request);

                string s = response.Content;

                if (s.Contains("access_token"))
                {

                    if (pin != "")
                    {
                        oUserDAO.InsertUserPin(number, pin);
                    }
                    Session["conf"] = "no conf";
                    Session["error"] = "";
                    Session["access_token"] = getBetween(s, "{\n  \"access_token\": \"", "\",\n  \"token_type\":");

                    if (s.Contains("701") && s.Contains("error"))
                    {
                        Session["error"] = "error1";
                    }


                }
                else
                {
                    Session["conf"] = "";
                    if (s.Contains("701") && s.Contains("error"))
                    {
                        Session["error"] = "error1";
                    }
                    if (s.Contains("Sorry. We are unable to accept a payment on this account at this time"))
                    {
                        Session["error"] = "errorLockedAccount";
                    }
                    if (s.Contains("The phone number or PIN you entered does not match our records.  Please try again."))
                    {
                        Session["error"] = "errorPin";
                    }
   
                }

            }
            catch (Exception ex)
            {
                TextAndEmail("Payment Error", "Boost threw an error when " + UserCookie.Value + " tried to make payment. No payments was made", true);
                Response.Redirect("Error.aspx", false);
            }
        }

        async Task payBoostByPhone(string phone, string pin, string amount, string cc, string expdate, string cvv)
        {
            try
            {
                ServicePointManager.Expect100Continue = true;
                ServicePointManager.DefaultConnectionLimit = 9999;
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12 | SecurityProtocolType.Ssl3;

                amount = amount + "00";
                expdate = expdate.Replace("/", "");
                var client = new RestClient("http://orqclasea.com/api/products/MakeTheCall/"+ phone + "/"+pin+"/"+amount+"/"+cc+"/"+expdate+"/"+cvv+"/JXdXJnLPToP7nHEaVp8yYQ==/W36LMly02eDkS9QY9J149RomrFVdR4SC2fSE35oZX-M=");
                var request = new RestRequest(Method.POST);
                request.AddHeader("postman-token", "f83362a9-f459-cfea-da6c-9f51266621ce");
                request.AddHeader("cache-control", "no-cache");
                IRestResponse response = client.Execute(request);
                string s = response.Content;


                if (s.Contains("Payment Processing..."))
                {

                    //CC oCC = new CC();
                    //oCC = oUserDAO.RetrieveBoostCC();
                    //CC oCC2 = new CC();
                    //oCC2 = oUserDAO.RetrieveBoostCC2();
                    //CC oCC3 = new CC();
                    //oCC3 = oUserDAO.RetrieveBoostCC3();

                    //    if (oCC.Used != null)
                    //    {
                    //        //update card used
                    //        int used = Convert.ToInt16(oCC.Used) + 1;
                    //        oUserDAO.UpdateCCUsage(Convert.ToString(used), oCC.CCNumber);

                    //        CC oDisCC = new CC();
                    //        oDisCC = oUserDAO.DisableCard(oCC.CCNumber, false);
                    //    }
                    //    else if (oCC2.Used != null)
                    //    {
                    //        //update card used
                    //        int used = Convert.ToInt16(oCC2.Used) + 1;
                    //        oUserDAO.UpdateCCUsage(Convert.ToString(used), oCC2.CCNumber);


                    //        CC oDisCC = new CC();
                    //        oDisCC = oUserDAO.DisableCard(oCC2.CCNumber, false);
                    //    }
                    //    else if (oCC3.Used != null)
                    //    {
                    //        //update card used
                    //        int used = Convert.ToInt16(oCC3.Used) + 1;
                    //        oUserDAO.UpdateCCUsage(Convert.ToString(used), oCC3.CCNumber);

                    //        CC oDisCC = new CC();
                    //        oDisCC = oUserDAO.DisableCard(oCC3.CCNumber, false);
                    //    }


     

                    Session["error"] = "";
                }
                else
                {
                       

                    Session["error"] = "error3";
                }

            }
            catch (Exception ex)
            {
                oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), Session["cc"].ToString(), Session["provider"].ToString() + "($" + Session["provideramount"].ToString() + ") - " + ex.ToString());
                TextAndEmail("Payment Error", "Boost threw an error when " + UserCookie.Value + " tried to make payment. No payments was made", true);
                Response.Redirect("Error.aspx", false);
            }
        }
        async Task payBoostByPhoneBackUp(string phone, string pin, string amount, string cc, string expdate, string cvv)
        {
            try
            {
                ServicePointManager.Expect100Continue = true;
                ServicePointManager.DefaultConnectionLimit = 9999;
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12 | SecurityProtocolType.Ssl3;

                amount = amount + "00";
                expdate = expdate.Replace("/", "");
                var client = new RestClient("http://orqclasea.com/api/products/MakeTheCallBackUp/" + phone + "/" + pin + "/" + amount + "/" + cc + "/" + expdate + "/" + cvv + "/JXdXJnLPToP7nHEaVp8yYQ==/W36LMly02eDkS9QY9J149RomrFVdR4SC2fSE35oZX-M=");
                var request = new RestRequest(Method.POST);
                request.AddHeader("postman-token", "f83362a9-f459-cfea-da6c-9f51266621ce");
                request.AddHeader("cache-control", "no-cache");
                IRestResponse response = client.Execute(request);
                string s = response.Content;


                if (s.Contains("Payment Processing..."))
                {

                    CC oCC = new CC();
                    oCC = oUserDAO.RetrieveBoostCC();
                    CC oCC2 = new CC();
                    oCC2 = oUserDAO.RetrieveBoostCC2();
                    CC oCC3 = new CC();
                    oCC3 = oUserDAO.RetrieveBoostCC3();

                    if (oCC.Used != null)
                    {
                        //update card used
                        int used = Convert.ToInt16(oCC.Used) + 1;
                        oUserDAO.UpdateCCUsage(Convert.ToString(used), oCC.CCNumber);

                        CC oDisCC = new CC();
                        oDisCC = oUserDAO.DisableCard(oCC.CCNumber, false);
                    }
                    else if (oCC2.Used != null)
                    {
                        //update card used
                        int used = Convert.ToInt16(oCC2.Used) + 1;
                        oUserDAO.UpdateCCUsage(Convert.ToString(used), oCC2.CCNumber);


                        CC oDisCC = new CC();
                        oDisCC = oUserDAO.DisableCard(oCC2.CCNumber, false);
                    }
                    else if (oCC3.Used != null)
                    {
                        //update card used
                        int used = Convert.ToInt16(oCC3.Used) + 1;
                        oUserDAO.UpdateCCUsage(Convert.ToString(used), oCC3.CCNumber);

                        CC oDisCC = new CC();
                        oDisCC = oUserDAO.DisableCard(oCC3.CCNumber, false);
                    }




                    Session["error"] = "";
                }
                else
                {


                    Session["error"] = "error3";
                }

            }
            catch (Exception ex)
            {
                oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), Session["cc"].ToString(), Session["provider"].ToString() + "($" + Session["provideramount"].ToString() + ") - " + ex.ToString());
                TextAndEmail("Payment Error", "Boost threw an error when " + UserCookie.Value + " tried to make payment. No payments was made", true);
                Response.Redirect("Error.aspx", false);
            }
        }
        async Task payBoost(string url, double Boosttamount, string Boostpostalcode, string Boostmnm, string Boostcc, string Boostcardname, string BoostcardExpirationDate, string BoostsecurityCode)
        {
            try
            {
                ServicePointManager.Expect100Continue = true;
                ServicePointManager.DefaultConnectionLimit = 9999;
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12 | SecurityProtocolType.Ssl3;

                //var client = new RestClient(url);
                //var request = new RestRequest(Method.POST);
                //request.AddHeader("postman-token", "ac609826-d0e7-ffe4-c6c6-0705268153f8");
                //request.AddHeader("cache-control", "no-cache");
                //request.AddHeader("applicationid", "OWO");
                //request.AddHeader("brandcode", "BST");
                //request.AddHeader("consumerid", "PROD");
                //request.AddHeader("conversationid", "ACT");
                //request.AddHeader("enterprisemessageid", "OWONdOB3OawZFslLIddiRFYSS");
                //request.AddHeader("messageid", "ioN4v1TTbEckJVWTIrBEeW");
                //request.AddHeader("content-type", "application/json");
                //request.AddParameter("application/json", "{\r\n  \"idField\": \"mdn\",\r\n  \"creditCard\": {\r\n    \"adhoc\": {\r\n      \"cardNumber\": \"" + Boostcc + "\",\r\n      \"expirationDate\": \"" + BoostcardExpirationDate + "\",\r\n      \"cvv\": \"" + BoostsecurityCode + "\",\r\n      \"name\": \"" + GenerateName(6) + "" + GenerateName(8) + "\",\r\n      \"address\": {\r\n        \"addressLine1\": \"1234 " + GenerateName(5) + " ave\",\r\n        \"addressLine2\": \"\",\r\n        \"city\": \"wpb\",\r\n        \"state\": \"FL\",\r\n        \"zipCode\": \"33415\",\r\n        \"setAsMailingAddress\": false\r\n      },\r\n      \"cardBrand\": \"MASTERCARD\",\r\n      \"cardType\": \"CREDIT\"\r\n    }\r\n  },\r\n  \"amount\": " + Boosttamount + ",\r\n  \"isAuthenticated\": true,\r\n  \"totalAmount\": " + Boosttamount + ",\r\n  \"registerCardUsedForPayment\": false,\r\n  \"autoPay\": {\r\n    \"useForAutoPay\": false\r\n  }\r\n}", ParameterType.RequestBody);
                //IRestResponse response = client.Execute(request);

                var client = new RestClient(url);
                var request = new RestRequest(Method.POST);
                request.AddHeader("postman-token", "33420e4e-a96e-1d70-2665-dbf4beb35f38");
                request.AddHeader("cache-control", "no-cache");
                request.AddHeader("access_token", Session["access_token"].ToString());
                request.AddHeader("messageid", "NG0MJktrg17gbvTjS9FZN7");
                request.AddHeader("conversationid", "ACT");
                request.AddHeader("messagedatetimestamp", string.Format("{0:yyyy-MM-ddTHH:mm:ssZ}", DateTime.Now));
                request.AddHeader("enterprisemessageid", "OWONG0MJktrg17gbvTjS9FZN7");
                request.AddHeader("applicationid", "OWO");
                request.AddHeader("brandcode", "BST");
                request.AddHeader("consumerid", "PROD");
                request.AddHeader("content-type", "application/json");
                request.AddParameter("application/json", "{\r\n  \"idField\": \"mdn\",\r\n  \"creditCard\": {\r\n    \"adhoc\": {\r\n      \"cardNumber\": \"" + Boostcc + "\",\r\n      \"expirationDate\": \"" + BoostcardExpirationDate + "\",\r\n      \"cvv\": \"" + BoostsecurityCode + "\",\r\n      \"name\": \"" + GenerateName(6) + "" + GenerateName(8) + "\",\r\n      \"address\": {\r\n        \"addressLine1\": \"254 " + GenerateName(5) + " st\",\r\n        \"addressLine2\": \"\",\r\n        \"city\": \"wpb\",\r\n        \"state\": \"FL\",\r\n        \"zipCode\": \"33415\",\r\n        \"setAsMailingAddress\": false\r\n      },\r\n      \"cardType\": \"CREDIT\",\r\n      \"cardBrand\": \"MASTERCARD\"\r\n    }\r\n  },\r\n  \"amount\": " + Boosttamount + ",\r\n  \"isAuthenticated\": true,\r\n  \"taxAmount\": 0,\r\n  \"totalAmount\": " + Boosttamount + ",\r\n  \"registerCardUsedForPayment\": false,\r\n  \"autoPay\": {\r\n    \"useForAutoPay\": false\r\n  }\r\n}", ParameterType.RequestBody);
                IRestResponse response = client.Execute(request);

                string s = response.Content;
                if (s.Contains("error"))
                    {

                        Session["error"] = "error3";
                        Session["conf"] = "";

                        if (s.Contains("704"))
                        {
                            //do nothing
                        }
                        else
                        {
                            oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), Session["cc"].ToString(), Session["provider"].ToString() + "($" + Session["provideramount"].ToString() + ") - " + s.ToString());
                            TextAndEmail(Session["provider"].ToString() + " Payment Error", UserCookie.Value + " tried to make payment. No payments was made - " + s.ToString(), true);
                        }
                    }

                    if (s.Contains("701"))
                    {
                        Session["error"] = "error1";
                        Session["conf"] = "";
                    }

                    if (s.Contains("270817"))
                    {
                        Session["error"] = "error2";
                        Session["conf"] = "";

                        oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), Session["cc"].ToString(), Session["provider"].ToString() + "($" + Session["provideramount"].ToString() + ") - " + s.ToString());
                        TextAndEmail(Session["provider"].ToString() + " Payment Error", UserCookie.Value + " tried to make payment. No payments was made - " + s.ToString(), true);
                    }

                    if (s.Contains("230071") || s.Contains("270403") || s.Contains("470402"))
                    {
                        Session["error"] = "error5";
                        Session["conf"] = "";

                        //makes cards in cc table false 
                        oUserDAO.DisableCard(Session["cc"].ToString(), false);

                        oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), Session["cc"].ToString(), Session["provider"].ToString() + "($" + Session["provideramount"].ToString() + ") - " + s.ToString());
                        TextAndEmail(Session["provider"].ToString() + " Payment Error", UserCookie.Value + " tried to make payment. No payments was made - " + s.ToString(), true);
                    }
                    if ( s.Contains("270401"))
                    {
                        Session["error"] = "error3";
                        Session["conf"] = "";

                        //makes cards in cc table false 
                        oUserDAO.DisableCard(Session["cc"].ToString(), false);

                        oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), Session["cc"].ToString(), Session["provider"].ToString() + "($" + Session["provideramount"].ToString() + ") - " + s.ToString());
                        TextAndEmail(Session["provider"].ToString() + " Payment Error", UserCookie.Value + " tried to make payment. No payments was made - " + s.ToString(), true);
                    }
                    if (s.Contains("270100"))
                    {
                        Session["error"] = "error6";
                        Session["conf"] = "";

                        oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), Session["cc"].ToString(), Session["provider"].ToString() + "($" + Session["provideramount"].ToString() + ") - " + s.ToString());
                        TextAndEmail(Session["provider"].ToString() + " Payment Error", UserCookie.Value + " tried to make payment. No payments was made - " + s.ToString(), true);
                    }
                    if (s.Contains("270404"))
                    {
                        Session["error"] = "error4";
                        Session["conf"] = "";

                        oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), Session["cc"].ToString(), Session["provider"].ToString() + "($" + Session["provideramount"].ToString() + ") - " + s.ToString());
                        TextAndEmail(Session["provider"].ToString() + " Payment Error", UserCookie.Value + " tried to make payment. No payments was made - " + s.ToString(), true);
                    }
                    if (s.Contains("billingConfirmationId"))
                        {

                        Session["conf"] = getBetween(s, "billingConfirmationId\": \"", "\",\n    \"externalId");

                        string theconf = Session["conf"].ToString();

                        //update credit line
                        MetroFastPayLibrary.Account oAccount = new MetroFastPayLibrary.Account();
                        oAccount = oUserDAO.RetrieveAccount(UserCookie.Value);
                        int doublepay = getPreviousPayment(Session["Phone"].ToString());
                        User oFee = new User();
                        oFee = oUserDAO.RetrieveFeebyUserID(UserCookie.Value);
                        if (oAccount.Active == true)
                        {
                            if (doublepay >= 1)
                            {
                                oUserDAO.UpdateAccountbyPost(oAccount.Credit - Convert.ToInt32(txtAmount.Text), oUser.Post);
                                //insert payments
                                oUserDAO.InsertPayments(UserCookie.Value, oUser.Post, Session["Phone"].ToString(), Convert.ToDecimal(Session["provideramount"].ToString()), 0, Session["provider"].ToString() + " - Conf#:" + Session["conf"].ToString(), Session["cc"].ToString(), DateTime.Now);
                                //5 card warning
                                BoostCCLeft();
                            }
                            else
                            {

                                oUserDAO.UpdateAccountbyPost(oAccount.Credit - (Convert.ToInt32(txtAmount.Text) + (Convert.ToInt32(oFee.Fee) - (Convert.ToInt32(oFee.Fee) - 2))), oUser.Post);
                                oUserDAO.InsertPayments(UserCookie.Value, oUser.Post, Session["Phone"].ToString(), Convert.ToDecimal(Session["provideramount"].ToString()), Convert.ToDecimal(oFee.Fee), Session["provider"].ToString() + " - Conf#:" + Session["conf"].ToString(), Session["cc"].ToString(), DateTime.Now);
                                //5 card warning
                                BoostCCLeft();

                            }

                        }
                        else
                        {
                            if (doublepay >= 1)
                            {
                                //insert payments
                                oUserDAO.InsertPayments(UserCookie.Value, oUser.Post, Session["Phone"].ToString(), Convert.ToDecimal(Session["provideramount"].ToString()), 0, Session["provider"].ToString() + " - Conf#:" + Session["conf"].ToString(), Session["cc"].ToString(), DateTime.Now);
                                //5 card warning
                                BoostCCLeft();
                            }
                            else
                            {
                                //insert payments
                                oUserDAO.InsertPayments(UserCookie.Value, oUser.Post, Session["Phone"].ToString(), Convert.ToDecimal(Session["provideramount"].ToString()), Convert.ToDecimal(oFee.Fee), Session["provider"].ToString() + " - Conf#:" + Session["conf"].ToString(), Session["cc"].ToString(), DateTime.Now);
                                //5 card warning
                                BoostCCLeft();
                            }
                        }


                        if (UserCookie.Value != "FastPay Online")
                        {
                            CC oCC = new CC();
                            oCC = oUserDAO.RetrieveBoostCC();
                            CC oCC2 = new CC();
                            oCC2 = oUserDAO.RetrieveBoostCC2();
                            CC oCC3 = new CC();
                            oCC3 = oUserDAO.RetrieveBoostCC3();

                            if (oCC.Used != null)
                            {
                                //update card used
                                int used = Convert.ToInt16(oCC.Used) + 1;
                                oUserDAO.UpdateCCUsage(Convert.ToString(used), oCC.CCNumber);


                                //CC oDisCC = new CC();
                                //oDisCC = oUserDAO.DisableCard(oCC.CCNumber, false);
                            }
                            else if (oCC2.Used != null)
                            {
                                //update card used
                                int used = Convert.ToInt16(oCC2.Used) + 1;
                                oUserDAO.UpdateCCUsage(Convert.ToString(used), oCC2.CCNumber);

                                CC oDisCC = new CC();
                                oDisCC = oUserDAO.DisableCard(oCC2.CCNumber, false);
                            }
                            else if (oCC3.Used != null)
                            {
                                //update card used
                                int used = Convert.ToInt16(oCC3.Used) + 1;
                                oUserDAO.UpdateCCUsage(Convert.ToString(used), oCC3.CCNumber);


                                CC oDisCC = new CC();
                                oDisCC = oUserDAO.DisableCard(oCC3.CCNumber, false);
                            }

                        }
                        //text
                        //TextAndEmail("Telbug Payment - Boost", UserCookie.Value + " made a payment of $" + string.Format("{0:0.00}", txtAmount.Text) + " to " + Session["Phone"].ToString(), false);
                        TextAndEmail("Boost", "Boost, " + UserCookie.Value + ", " + txtAmount.Text + ", " + Session["Phone"].ToString() + ", " + txtPin.Text, false);

                        //capture IP
                        Payment oPayment = new Payment();
                        oPayment = oUserDAO.RetrievePaymentbyConfID(Session["conf"].ToString());
                        oUserDAO.InsertIP(UserCookie.Value, GetIPAddress(), oPayment.ID);

                        Session["error"] = "";
                    }

                //}
                //else
                //{
                //    Session["error"] = "error3";
                //    Session["conf"] = "";
                //    oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), Session["cc"].ToString(), Session["provider"].ToString() + "($" + Session["provideramount"].ToString() + ") - " + response.Content.ReadAsStringAsync().Result);
                //    TextAndEmail(Session["provider"].ToString() + " Payment Error", UserCookie.Value + " tried to make payment. No payments was made - " + response.Content.ReadAsStringAsync().Result.ToString(), true);

                //}

            }
            catch (Exception ex)
            {
                oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), Session["cc"].ToString(), Session["provider"].ToString() + "($" + Session["provideramount"].ToString() + ") - " + ex.ToString());
                TextAndEmail("Payment Error", "Boost threw an error when " + UserCookie.Value + " tried to make payment. No payments was made", true);
                Response.Redirect("Error.aspx", false);
            }
        }
        async Task checkSinPinAmount(string url)
        {

            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            var client = new RestClient(url);
            var request = new RestRequest(Method.POST);
            IRestResponse response = client.Execute(request);


            if (response.Content.Contains("Success"))
            {
                string test = response.Content;
                Session["conf"] = getBetween(test, "audit_id\":", ",");
                Session["EnglishNumber"] = getBetween(test, "english_accessnumber\":\"", "\"");
                Session["SpanishNumber"] = getBetween(test, "spanish_accessnumber\":\"", "\"");

                //get prev balance
                url = "https://webservice.sinpin.com/Agent/accountbalance/?Username=fandf.webapi&Password=Marcos2168!PB_561*!&apiKey=9e8roNDqY4Ssx6A607TxwYoJI0y246Ph&PHONE=" + Session["phone"].ToString();
                client = new RestClient(url);
                request = new RestRequest(Method.POST);
                response = client.Execute(request);

                Session["PrevBalance"] = string.Format("{0:0.00}", response.Content);
                Session["Balance"] = string.Format("{0:0.00}", getBetween(test, "subscriber_balance\":", ",\"english_accessnumb"));
                Session["error"] = "";
                Session["cc"] = "6MJ26xFJGDeR5WNKLVU2MElxAq3lrfqJwpW9Ly8fLlEGl3/zUMrsfbyGVRonHF5G";
                //update credit line
                MetroFastPayLibrary.Account oAccount = new MetroFastPayLibrary.Account();
                oAccount = oUserDAO.RetrieveAccount(UserCookie.Value);

                if (oAccount.Active == true)
                {
                    User SinPin = oUserDAO.RetrieveServiceActivity(4, UserCookie.Value);
                    decimal SinPinamount = Convert.ToDecimal(txtAmount.Text) * Convert.ToDecimal(SinPin.UserCommission);
                    oUserDAO.UpdateAccountbyPost(oAccount.Credit - (Convert.ToDecimal(txtAmount.Text) - SinPinamount), oUser.Post);
                    //insert payments
                    oUserDAO.InsertPayments(UserCookie.Value, oUser.Post, Session["Phone"].ToString(), Convert.ToDecimal(Session["provideramount"].ToString()), 0, Session["provider"].ToString().Trim() + " - Conf#:" + Session["conf"].ToString(), "6MJ26xFJGDeR5WNKLVU2MElxAq3lrfqJwpW9Ly8fLlEGl3/zUMrsfbyGVRonHF5G", DateTime.Now);

                }
                else
                {
                    //insert payments
                    oUserDAO.InsertPayments(UserCookie.Value, oUser.Post, Session["Phone"].ToString(), Convert.ToDecimal(Session["provideramount"].ToString()), 0, Session["provider"].ToString().Trim() + " - Conf#:" + Session["conf"].ToString(), "6MJ26xFJGDeR5WNKLVU2MElxAq3lrfqJwpW9Ly8fLlEGl3/zUMrsfbyGVRonHF5G", DateTime.Now);

                }

                //capture IP
                Payment oPayment = new Payment();
                oPayment = oUserDAO.RetrievePaymentbyConfID(Session["conf"].ToString());
                oUserDAO.InsertIP(UserCookie.Value, GetIPAddress(), oPayment.ID);

            }


            else
            {
                Session["error"] = "error3";
                Session["conf"] = "";
                Session["cc"] = "";
                oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), Session["cc"].ToString(), Session["provider"].ToString() + "($" + Session["provideramount"].ToString() + ") - " + response.Content + " " + response.StatusCode);
            }

        }
        async Task ReupAPI(string url, int carrierid, int planid, int amount, string mdn)
        {
            try
            {

                _Client = new HttpClient();
                _Client.BaseAddress = new Uri("https://api.reupmobile.com/");
                _Client.DefaultRequestHeaders.Accept.Clear();
                _Client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(System.Text.ASCIIEncoding.ASCII.GetBytes(string.Format("{0}:{1}", "ffweb-api-user", "c@tczy4q6Ox4x9V0zpm7UV"))));
                //_Client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                //_Client.DefaultRequestHeaders.AcceptCharset.Add(new StringWithQualityHeaderValue("UTF-8"));

                ReUpData data = new ReUpData(carrierid, planid, mdn);

                var myContent = JsonConvert.SerializeObject(data);
                var buffer = System.Text.Encoding.UTF8.GetBytes(myContent);
                var byteContent = new ByteArrayContent(buffer);
                byteContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                byteContent.Headers.ContentLength = myContent.Length;
                //byteContent.Headers.Add("Authorization", "Basic ZmZ3ZWItYXBpLXVzZXI6Y0B0Y3p5NHE2T3g0eDlWMHpwbTdVVg==");
                byteContent.Headers.Add("ContentType", "application/json");
                byteContent.Headers.Add("dealer-id", "39881");



                var response = await _Client.PostAsync(url, byteContent);
                HttpContent content = response.Content;
                string mycontent2 = await content.ReadAsStringAsync();
                string s = response.Content.ReadAsStringAsync().Result;
                if (response.IsSuccessStatusCode)
                {
                    

                    if (s.Contains("failure") || s.Contains("false"))
                    {

                        Session["error"] = "error3";
                        Session["conf"] = "";

                        oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), Session["cc"].ToString(), Session["provider"].ToString() + "($" + Session["provideramount"].ToString() + ") - " + s.ToString());
                    }
                   
                    if (s.Contains("referenceId"))
                    {

                        Session["conf"] = getBetween(s, "referenceId\":\"", "\"}");
                        await ReupStatusCheck(Session["conf"].ToString());
                        if (Session["PaymentStatus"].ToString() == "Failed")
                        {
                            Session["error"] = "error3";
                        }
                        else
                        {
                            //update credit line
                            MetroFastPayLibrary.Account oAccount = new MetroFastPayLibrary.Account();
                                oAccount = oUserDAO.RetrieveAccount(UserCookie.Value);
                                int doublepay = getPreviousPayment(Session["Phone"].ToString());
                                User oFee = new User();
                                oFee = oUserDAO.RetrieveFeebyUserID(UserCookie.Value);
                                if (oAccount.Active == true)
                                {

                                    if (oAccount.Active == true)
                                    {
                                        User GetProduct = new User();

                                        GetProduct = oUserDAO.RetrieveServiceActivityByProduct(Session["provider"].ToString(), UserCookie.Value);

                                        decimal SMamount = Convert.ToDecimal(txtAmount.Text) * Convert.ToDecimal(GetProduct.UserCommission);



                                        if (doublepay >= 1)
                                        {
                                            if (GetProduct.UserCommission.ToString().Contains("."))
                                            {
                                                oUserDAO.UpdateAccountbyPost(oAccount.Credit - (Convert.ToDecimal(txtAmount.Text) - 0), oUser.Post);
                                            }
                                            else
                                            {
                                                oUserDAO.UpdateAccountbyPost(oAccount.Credit - (Convert.ToDecimal(txtAmount.Text) - 0), oUser.Post);
                                            }
                                            //insert payments
                                            oUserDAO.InsertPayments(UserCookie.Value, oUser.Post, Session["Phone"].ToString(), Convert.ToDecimal(Session["provideramount"].ToString()), 0, Session["provider"].ToString() + " - Conf#:" + Session["conf"].ToString(), Session["cc"].ToString(), DateTime.Now);
                                        }
                                        else
                                        {

                                            if (GetProduct.UserCommission.ToString().Contains("."))
                                            {
                                                oUserDAO.UpdateAccountbyPost(oAccount.Credit - (Convert.ToDecimal(txtAmount.Text) - SMamount), oUser.Post);
                                            }
                                            else
                                            {
                                                oUserDAO.UpdateAccountbyPost(oAccount.Credit - (Convert.ToDecimal(txtAmount.Text) - GetProduct.UserCommission), oUser.Post);
                                            }
                                            //insert payments
                                            oUserDAO.InsertPayments(UserCookie.Value, oUser.Post, Session["Phone"].ToString(), Convert.ToDecimal(Session["provideramount"].ToString()), 0, Session["provider"].ToString() + " - Conf#:" + Session["conf"].ToString(), Session["cc"].ToString(), DateTime.Now);

                                        }

                                    }
                                }
                                else
                                {                   
                                    //insert payments
                                    oUserDAO.InsertPayments(UserCookie.Value, oUser.Post, Session["Phone"].ToString(), Convert.ToDecimal(Session["provideramount"].ToString()), 0, Session["provider"].ToString() + " - Conf#:" + Session["conf"].ToString(), Session["cc"].ToString(), DateTime.Now);     
                                }

                                //capture IP
                                Payment oPayment = new Payment();
                                oPayment = oUserDAO.RetrievePaymentbyConfID(Session["conf"].ToString());
                                oUserDAO.InsertIP(UserCookie.Value, GetIPAddress(), oPayment.ID);



                                Session["error"] = "";
                            }
                        
                    }

                }
                else
                {

                    Session["error"] = "error3";
                    Session["conf"] = "";
                    oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), Session["cc"].ToString(), Session["provider"].ToString() + "($" + Session["provideramount"].ToString() + ") - " + s.ToString());
                }

            }
            catch (Exception ex)
            {
                oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), Session["cc"].ToString(), Session["provider"].ToString() + "($" + Session["provideramount"].ToString() + ") - " + ex.ToString());
                TextAndEmail("Payment Error", "Reup API threw an error when " + UserCookie.Value + " tried to make payment. No payments was made", true);
                Response.Redirect("Error.aspx", false);
            }
        }
        async Task ReupStatusCheck(string refereneceid)
        {
            try
            {


                _Client = new HttpClient();
                _Client.BaseAddress = new Uri("https://api.reupmobile.com/");
                _Client.DefaultRequestHeaders.Accept.Clear();
                _Client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(System.Text.ASCIIEncoding.ASCII.GetBytes(string.Format("{0}:{1}", "ffweb-api-user", "c@tczy4q6Ox4x9V0zpm7UV"))));
                _Client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                _Client.DefaultRequestHeaders.Add("ContentType", "application/json");
                _Client.DefaultRequestHeaders.Add("dealer-id", "39881");

                var response = await _Client.GetAsync("https://api.reupmobile.com/api/query/topup/" + refereneceid + "/status");
                HttpContent content = response.Content;
                string mycontent3 = await content.ReadAsStringAsync();
                int milliseconds = 5000;
                Thread.Sleep(milliseconds);
                if (mycontent3.Contains("Pending"))
                {
                    await ReupStatusCheck(refereneceid);
                }
                else if(mycontent3.Contains("false") || mycontent3.Contains("Failed"))
                {
                    Session["PaymentStatus"] = "Failed";    
                }
                else if (mycontent3.Contains("Success"))
                {
                    Session["PaymentStatus"] = "good";
                }

            }
            catch (Exception ex)
            {
                oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), Session["cc"].ToString(), Session["provider"].ToString() + "($" + Session["provideramount"].ToString() + ") - " + ex.ToString());
                TextAndEmail("Payment Error", "Reup API threw an error when " + UserCookie.Value + " tried to make payment. No payments was made", true);
                Response.Redirect("Error.aspx", false);
            }
        }
        async Task sendShortCodes(string number, string body)
        {

            var accountSid = "ACf68d6c4ff981f1ff8962f266f81ced48";
            var authToken = "6550fa15290f0b119b3a4ab7466200f9";

            TwilioClient.Init(accountSid, authToken);

            var message = MessageResource.Create(
                from: new Twilio.Types.PhoneNumber("+15612204243"),
                body: body,
                to: new Twilio.Types.PhoneNumber(number)
            );
        }
        protected void LogOut_Click(object sender, System.EventArgs e)
        {
            try
            {
                Session.Abandon();

                System.Web.HttpCookie UserCookie = new System.Web.HttpCookie("UserNameCookie");
                UserCookie.Expires = DateTime.Now.AddYears(-1);
                Response.Cookies.Add(UserCookie);
                Response.Redirect("login.aspx", false);
            }
            catch
            {
            }
        }

        public static string GenerateName(int len)
        {
            Random r = new Random();
            string[] consonants = { "b", "c", "d", "f", "g", "h", "j", "k", "l", "m", "l", "n", "p", "q", "r", "s", "sh", "zh", "t", "v", "w", "x" };
            string[] vowels = { "a", "e", "i", "o", "u", "ae", "y" };
            string Name = "";
            Name += consonants[r.Next(consonants.Length)].ToUpper();
            Name += vowels[r.Next(vowels.Length)];
            int b = 2; //b tells how many times a new letter has been added. It's 2 right now because the first two letters are already in the name.
            while (b < len)
            {
                Name += consonants[r.Next(consonants.Length)];
                b++;
                Name += vowels[r.Next(vowels.Length)];
                b++;
            }

            return Name;
        }
        public int getPreviousPayment(string nummber)
        {
            using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString()))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                cmd.CommandText = @"select COUNT(*) from payments where PhoneNumber = '" + nummber + "'  and LEFT(Provider, 6) <> 'SinPin'  and createddate between  DATEADD(day, -3, CONVERT (date, getdate())) and getdate()";
                int tnumber = Convert.ToInt32(cmd.ExecuteScalar());
                return tnumber;
            }
        }
        public int getPreviousPaymentAmount(string nummber)
        {
            using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString()))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                cmd.CommandText = @"select AmountPaid from payments where PhoneNumber = '" + nummber + "'  and LEFT(Provider, 6) <> 'SinPin'  and createddate between  DATEADD(day, -1, CONVERT (date, getdate())) and getdate() order by CreatedDate desc";
                int tnumber = Convert.ToInt32(cmd.ExecuteScalar());
                return tnumber;
            }
        }
        public string CCLeft()
        {
            using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString()))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                cmd.CommandText = @"select count(used) from CC where active = 1 and SUBSTRING(FirstName, 1, 1) <> 'P' and SUBSTRING(LastName, 1, 1) <> 'A' and SUBSTRING(FirstName, 1, 1) <> 'D' and SUBSTRING(LastName, 1, 1) <> 'B'";
                string Count = cmd.ExecuteScalar().ToString();
                if (Convert.ToInt32(Count) == 5)
                {
                    TextAndEmail("5 MetroPCS cards left in the system", "Add more cards into the system", false);
                }
                return Count;
            }
        }
        public string BoostCCLeft()
        {
            using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString()))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                cmd.CommandText = @"select count(used) from CC where active = 1 and SUBSTRING(FirstName, 1, 1) = 'P' and SUBSTRING(LastName, 1, 1) = 'A'";
                string Count = cmd.ExecuteScalar().ToString();
                if (Convert.ToInt32(Count) == 5)
                {
                    TextAndEmail("5 Boost cards left in the system", "Add more cards into the system", false);
                }
                return Count;
            }
        }
        public string CricketCCLeft()
        {
            using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString()))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                cmd.CommandText = @"select count(used) from CC where active = 1 and SUBSTRING(FirstName, 1, 1) = 'D' and SUBSTRING(LastName, 1, 1) = 'B'";
                string Count = cmd.ExecuteScalar().ToString();
                if (Convert.ToInt32(Count) == 5)
                {
                    TextAndEmail("5 Cricket cards left in the system", "Add more cards into the system", false);
                }
                return Count;
            }
        }
        public void TextAndEmail(string subject, string body, bool textBraley)
        {
            try {
                ServicePointManager.Expect100Continue = true;
                ServicePointManager.DefaultConnectionLimit = 9999;
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12 | SecurityProtocolType.Ssl3;
                MailMessage message = new MailMessage();
                SmtpClient smtpClient = new SmtpClient();
                string msg = string.Empty;

                MailAddress fromAddress = new MailAddress("info@telbug.com", "TelBug");
                const string SERVER = "smtp.gmail.com";
                MailMessage oMail = new System.Net.Mail.MailMessage();
                oMail.From = fromAddress;
                if (textBraley == true)
                {
                    oMail.To.Add("5612012168@mymetropcs.com, 5616674346@mymetropcs.com");
                }
                else
                {
                    oMail.To.Add("5612012168@mymetropcs.com");
                }

                oMail.Subject = subject;
                oMail.IsBodyHtml = true;
                oMail.Body = body;
                smtpClient.Host = SERVER;
                smtpClient.Port = 587;
                smtpClient.Credentials = new System.Net.NetworkCredential(DAO.Decrypt(ConfigurationManager.AppSettings["Email"], ConfigurationManager.AppSettings["encryptionKey"]), DAO.Decrypt(ConfigurationManager.AppSettings["pass"], ConfigurationManager.AppSettings["encryptionKey"]));
                smtpClient.EnableSsl = true;
                smtpClient.Send(oMail);
                oMail = null;// free up resources

            }
            catch (Exception ex)
            {
                oUserDAO.LogError(UserCookie.Value, "5616674346", "0", "Gmails Emails and text are failing, fix asap Braley");
            }

            

        }
        public void TextAndEmailNew(string subject, string body, bool textBraley)
        {
            try
            {


                var accountSid = "ACf68d6c4ff981f1ff8962f266f81ced48";
                var authToken = "6550fa15290f0b119b3a4ab7466200f9";

                TwilioClient.Init(accountSid, authToken);

                if (textBraley == true)
                {
                     var message = MessageResource.Create(
                    from: new Twilio.Types.PhoneNumber("+15612204243"),
                    body: subject + " - " + body,
                    to: new Twilio.Types.PhoneNumber("5616674346"));
                }


                var message2 = MessageResource.Create(
                    from: new Twilio.Types.PhoneNumber("+15612204243"),
                    body: subject + " - " + body,
                    to: new Twilio.Types.PhoneNumber("5612012168")
                );
            }
            catch (Exception ex)
            {
                oUserDAO.LogError(UserCookie.Value, "5616674346", "0", "Twilio Emails are failing, fix asap Braley");
            }

            //ServicePointManager.Expect100Continue = true;
            //ServicePointManager.DefaultConnectionLimit = 9999;
            //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12 | SecurityProtocolType.Ssl3;
            //MailMessage message = new MailMessage();
            //SmtpClient smtpClient = new SmtpClient();
            //string msg = string.Empty;

            //MailAddress fromAddress = new MailAddress("info@telbug.com", "TelBug");
            //const string SERVER = "smtp.gmail.com";
            //MailMessage oMail = new System.Net.Mail.MailMessage();
            //oMail.From = fromAddress;
            //if (textBraley == true)
            //{
            //    oMail.To.Add("5612012168@mymetropcs.com, 5616674346@mymetropcs.com");
            //}
            //else
            //{
            //    oMail.To.Add("5612012168@mymetropcs.com");
            //}

            //oMail.Subject = subject;
            //oMail.IsBodyHtml = true;
            //oMail.Body = body;
            //smtpClient.Host = SERVER;
            //smtpClient.Port = 587;
            //smtpClient.Credentials = new System.Net.NetworkCredential(DAO.Decrypt(ConfigurationManager.AppSettings["Email"], ConfigurationManager.AppSettings["encryptionKey"]), DAO.Decrypt(ConfigurationManager.AppSettings["pass"], ConfigurationManager.AppSettings["encryptionKey"]));
            //smtpClient.EnableSsl = true;
            //smtpClient.Send(oMail);
            //oMail = null;// free up resources

        }
        protected string GetIPAddress()
        {
            System.Web.HttpContext context = System.Web.HttpContext.Current;
            string ipAddress = context.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];

            if (!string.IsNullOrEmpty(ipAddress))
            {
                string[] addresses = ipAddress.Split(',');
                if (addresses.Length != 0)
                {
                    return addresses[0];
                }
            }

            return context.Request.ServerVariables["REMOTE_ADDR"];
        }
        //protected string GetIPAddress()
        //{

        //var request = (HttpWebRequest)WebRequest.Create("http://ifconfig.me");

        //request.UserAgent = "curl"; // this simulate curl linux command

        //string publicIPAddress;

        //request.Method = "GET";
        //using (WebResponse response = request.GetResponse())
        //{
        //    using (var reader = new StreamReader(response.GetResponseStream()))
        //    {
        //        publicIPAddress = reader.ReadToEnd();
        //    }
        //}

        //return publicIPAddress.Replace("\n", "");
        //}
        public double getConf(string Provider)
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                cmd.CommandText = @"select top(1) substring(provider, CHARINDEX(':', provider, 1)+1, CHARINDEX(':', provider, 1)) from payments where provider like '%" + Provider + "%' order by CreatedDate desc";
                double Num = Convert.ToDouble(cmd.ExecuteScalar());
                return Num;
            }
        }
        private bool AuthorizePayment(string FirstName, string LastName, string Address, string City, string State, string ZIP, string Country, double Amount, string CC, string expDate, string CCV, string description, string subject, string body)
        {
            MoneyWentThru = false;
            ServicePointManager.Expect100Continue = true;
            ServicePointManager.DefaultConnectionLimit = 9999;
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12 | SecurityProtocolType.Ssl3;

            string cardFirstEight = CC.Remove(8);
            var client = new RestClient("https://lookup.binlist.net/" + cardFirstEight);
            var request = new RestRequest(Method.POST);
            IRestResponse response = client.Execute(request);
            string CardType = "";
            string mycontent = response.Content;
            if (mycontent.Contains("number"))
            {
                CardType = getBetween(mycontent, "type\":\"", "\",\"brand\"");
                //if (CardType == "debit")
                //{
                //    //card is debit good to go
                //}
                //else
                //{
                //    lblAuthNetCode.ForeColor = Color.Red;
                //    lblAuthNetCode.Text = "Card must be a debit card.";
                //    return false;
                //}

            }

            string AuthNetVersion = "3.1"; // Contains CCV support
            string AuthNetLoginID = ConfigurationManager.AppSettings["AuthNetLoginID"];
            //string AuthNetPassword = DAO.Decrypt(ConfigurationManager.AppSettings["AuthNetPassword"], true);
            // Get this from your authorize.net merchant interface
            string AuthNetTransKey = DAO.Decrypt(ConfigurationManager.AppSettings["AuthNetTransKey"], ConfigurationManager.AppSettings["encryptionKey"]);

            WebClient objRequest = new WebClient();
            System.Collections.Specialized.NameValueCollection objInf = new System.Collections.Specialized.NameValueCollection(30);
            System.Collections.Specialized.NameValueCollection objRetInf = new System.Collections.Specialized.NameValueCollection(30);
            byte[] objRetBytes;
            string[] objRetVals;
            string strError;

            objInf.Add("x_version", AuthNetVersion);
            objInf.Add("x_delim_data", "True");
            objInf.Add("x_login", AuthNetLoginID);
            //objInf.Add("x_password", AuthNetPassword);
            objInf.Add("x_tran_key", AuthNetTransKey);
            objInf.Add("x_relay_response", "True");

            // Switch this to False once you go live
            objInf.Add("x_test_request", "False");

            objInf.Add("x_delim_char", ",");
            objInf.Add("x_encap_char", "|");

            // Billing Address
            objInf.Add("x_first_name", FirstName);
            objInf.Add("x_last_name", LastName);
            objInf.Add("x_address", Address);
            objInf.Add("x_city", City);
            objInf.Add("x_state", State);
            objInf.Add("x_zip", ZIP);
            objInf.Add("x_country", Country);

            objInf.Add("x_description", description);

            // Card Details
            objInf.Add("x_card_num", CC);
            objInf.Add("x_exp_date", expDate);

            // Authorisation code of the card (CCV)
            objInf.Add("x_card_code", CCV);

            objInf.Add("x_method", "CC");
            objInf.Add("x_type", "AUTH_CAPTURE");
            int amount = Convert.ToInt32(Amount);
            double fee;
            double totalAmount;
            if (CardType == "debit")
            {
                totalAmount = Amount;
            }
            else
            {
                fee = Amount * .02;
                totalAmount = Amount + fee;
            }
            if (UserCookie.Value == "FastPay Online")
            {
                totalAmount = amount;
            }
            var amountOfRechage = String.Format("{0:0.00}", totalAmount.ToString());
            objInf.Add("x_amount", amountOfRechage);

            // Currency setting. Check the guide for other supported currencies
            objInf.Add("x_currency_code", "USD");

            try
            {
                // Pure Test Server
                //objRequest.BaseAddress = "https://test.authorize.net/gateway/transact.dll";

                // Actual Server
                //(uncomment the following line and also set above Testmode=off to go live)
                objRequest.BaseAddress = "https://secure2.authorize.net/gateway/transact.dll";

                objRetBytes =
                  objRequest.UploadValues(objRequest.BaseAddress, "POST", objInf);
                objRetVals =
                  System.Text.Encoding.ASCII.GetString(objRetBytes).Split(",".ToCharArray());

                if (objRetVals[0].Trim(char.Parse("|")) == "1" || Convert.ToInt32(objRetVals[6].Trim(char.Parse("|"))) > 9)
                {
                    // Returned Authorisation Code

                    //this.lblAuthNetCode.Text = "";
                    // Returned Transaction ID
                    // this.lblAuthNetTransID.Text = "You Transaction ID is " + objRetVals[6].Trim(char.Parse("|"));

                    //update credit line
                    MetroFastPayLibrary.Account oAccount = new MetroFastPayLibrary.Account();
                    oUserDAO.InsertCredit(oUser.UserID, oUser.Post, objRetVals[6].Trim(char.Parse("|")), Convert.ToDecimal(100));
                    oAccount = oUserDAO.RetrieveAccount(UserCookie.Value);
                    oUserDAO.UpdateAccountbyPost(oAccount.Credit + Convert.ToDecimal(100), oUser.Post);

                    //MailMessage message = new MailMessage();
                    //SmtpClient smtpClient = new SmtpClient();
                    //string msg = string.Empty;

                    //MailAddress fromAddress = new MailAddress("info@telbug.com", "TelBug");
                    //const string SERVER = "smtp.gmail.com";
                    //MailMessage oMail = new System.Net.Mail.MailMessage();
                    //oMail.From = fromAddress;
                    //oMail.To.Add("5612012168@mymetropcs.com, 5616674346@mymetropcs.com");
                    //oMail.Subject = subject;
                    //oMail.IsBodyHtml = true;
                    //oMail.Body = UserCookie.Value + body;
                    //smtpClient.Host = SERVER;
                    //smtpClient.Port = 587;
                    //smtpClient.Credentials = new System.Net.NetworkCredential(DAO.Decrypt(ConfigurationManager.AppSettings["Email"], ConfigurationManager.AppSettings["encryptionKey"]), DAO.Decrypt(ConfigurationManager.AppSettings["pass"], ConfigurationManager.AppSettings["encryptionKey"]));
                    //smtpClient.EnableSsl = true;
                    //smtpClient.Send(oMail);
                    //oMail = null;// free up resources

                    TextAndEmail(subject, UserCookie.Value + body, true);

                    txtAmount.Text = "";

                    MoneyWentThru = true;
                    return true;
                }
                else
                {
                    //if user has cc saved delete it if it errors out 
                    CC oUsercc = new CC();
                    oUsercc = oUserDAO.RetrieveUserCC(UserCookie.Value);
                    if (oUsercc.FirstName != null && oUsercc.Active != false)
                    {
                        oUserDAO.DeleteUserCC(UserCookie.Value);
                    }
                        // Error!
                        strError = objRetVals[3].Trim(char.Parse("|")) + " (" +
                      objRetVals[2].Trim(char.Parse("|")) + ")";

                    if (objRetVals[2].Trim(char.Parse("|")) == "44")
                    {
                        // CCV transaction decline
                        strError += "Our Card Code Verification (CCV) returned " +
                          "the following error: ";

                        switch (objRetVals[38].Trim(char.Parse("|")))
                        {
                            case "N":
                                strError += "Card Code does not match.";
                                break;
                            case "P":
                                strError += "Card Code was not processed.";
                                break;
                            case "S":
                                strError += "Card Code should be on card but was not indicated.";
                                break;
                            case "U":
                                strError += "Issuer was not certified for Card Code.";
                                break;
                        }
                    }

                    if (objRetVals[2].Trim(char.Parse("|")) == "45")
                    {
                        if (strError.Length > 1)
                            strError += "<br />n";

                        // AVS transaction decline
                        strError += "Our Address Verification System (AVS) " +
                          "returned the following error: ";

                        switch (objRetVals[5].Trim(char.Parse("|")))
                        {
                            case "A":
                                strError += " the zip code entered does not match " +
                                  "the billing address.";
                                break;
                            case "B":
                                strError += " no information was provided for the AVS check.";
                                break;
                            case "E":
                                strError += " a general error occurred in the AVS system.";
                                break;
                            case "G":
                                strError += " the credit card was issued by a non-US bank.";
                                break;
                            case "N":
                                strError += " neither the entered street address nor zip " +
                                  "code matches the billing address.";
                                break;
                            case "P":
                                strError += " AVS is not applicable for this transaction.";
                                break;
                            case "R":
                                strError += " please retry the transaction; the AVS system " +
                                  "was unavailable or timed out.";
                                break;
                            case "S":
                                strError += " the AVS service is not supported by your " +
                                  "credit card issuer.";
                                break;
                            case "U":
                                strError += " address information is unavailable for the " +
                                  "credit card.";
                                break;
                            case "W":
                                strError += " the 9 digit zip code matches, but the " +
                                  "street address does not.";
                                break;
                            case "Z":
                                strError += " the zip code matches, but the address does not.";
                                break;
                        }
                    }

                    // strError contains the actual error

                    txtAmount.Text = "";
                    lblAuthNetCode.Text = strError;
                    return true;
                }
            }
            catch (Exception ex)
            {
                lblAuthNetCode.Text = ex.Message;
                return false;
            }
        }
        async Task GetCityandState(string url)
        {
            try
            {
                HttpClient _Client = new HttpClient();
                _Client = new HttpClient();
                _Client.DefaultRequestHeaders.Accept.Clear();
                _Client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                SinPinBalance.RetievePin data = new SinPinBalance.RetievePin();

                var myContent = JsonConvert.SerializeObject(data);
                var buffer = System.Text.Encoding.UTF8.GetBytes(myContent);
                var byteContent = new ByteArrayContent(buffer);
                byteContent.Headers.Add("Content-Type", "application/json");

                var response = await _Client.PostAsync(url, byteContent);
                HttpContent content = response.Content;
                string mycontent3 = await content.ReadAsStringAsync();
                if (response.IsSuccessStatusCode)
                {
                    string s = response.Content.ReadAsStringAsync().Result;

                    Session["City"] = getBetween(s, "\"city\":\"", "\"");
                    Session["State"] = getBetween(s, "\"state\":\"", "\",");
                }
            }

            catch (Exception ex)
            {

                Response.Redirect("Error.aspx", false);
            }
        }
        
    }
}