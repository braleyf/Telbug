﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net.Mail;
using System.Configuration;
using System.Web.UI.HtmlControls;
using System.Drawing;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using System.Net;
using MetroFastPayLibrary;
using System.Text;
using System.Security.Cryptography;
using MetroFastPay.com.dollarphone.www;

namespace MetroFastPay
{
    public partial class ControlPanel : System.Web.UI.Page
    {
        User oUser = new User();
        UserDAO oUserDAO = new UserDAO();
        string dbCon = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
        HttpCookie UserCookie = HttpContext.Current.Request.Cookies["UserNameCookie"];
        protected void Page_Load(object sender, EventArgs e)
        {
            
            if (Request.Cookies["UserNameCookie"] == null)
            {
                Response.Redirect("out.aspx");
            }
            else
            {
                try
                {
                    oUser = oUserDAO.RetrieveUserByUserID(UserCookie.Value);
                    lbUser.Text = oUser.FullName;
                    if (oUser.UserType == "Admin")
                    {
                        txtPassword.Attributes.Add("onkeyup", "Password();");
                        txtConfPass.Attributes.Add("onkeyup", "ConfPasword();");
                        txtPaymentAmount.Attributes.Add("onkeyup", "PaymentAmount();");
                        txtPaymentNumber.Attributes.Add("onkeyup", "PaymentNumber();");
                        txtCC.Attributes.Add("onkeyup", "CC();");
                        lbLastPost.Text = "Last post was: " + LastPost();
                        lbLastPost.Font.Size = 8;
                        lbLastPost.Font.Italic = true;

                        DataTable dt = new DataTable();
                        BindPaymentGrid(dt);

                        DataTable dt2 = new DataTable();
                        BindErrorGrid(dt2);

                        DataTable dt3 = new DataTable();
                        BindTransGrid(dt3);


                        DataTable dt4 = new DataTable();
                        BindCCGrid(dt4);

                        DataTable dt5 = new DataTable();
                        BindAnnouncementGrid(dt5);

                        DataTable dt6 = new DataTable();
                        BindMSGrid(dt6);

                        CC_ON_OFF();


                        if (Request.Url.ToString().Contains("ID="))
                        {
                            int theid = Convert.ToInt32(Request.QueryString["ID"]);
                            CC oCC = new CC();
                            oCC = oUserDAO.RetrieveCCbyID(theid);


                            if (!Page.IsPostBack)
                            {
                                txtCCFirstName.Text = oCC.FirstName;
                                txtCCLastName.Text = oCC.LastName;
                                txtUsed.Text = oCC.Used;
                                ddCCActive.SelectedValue = oCC.Active.ToString();

                                divErrorLog.Attributes.Add("style", "display:none");
                                divAddCredit.Attributes.Add("style", "display:none");
                                divuser.Attributes.Add("style", "display:none");
                                divTurnOffService.Attributes.Add("style", "display:none");
                                divUserInfo.Attributes.Add("style", "display:none");
                                divPayment.Attributes.Add("style", "display:none");
                                divCCUsage.Attributes.Add("style", "display:none");
                                CCModal.Attributes.Add("style", "display:block");
                            }



                        }


                    }

                }
                catch (Exception ex)
                {

                    Response.Redirect("out.aspx");
                }
            }

        }

        protected void CC_ON_OFF()
        {

            User metro = oUserDAO.RetrieveServiceActivity(1);
            User cricket = oUserDAO.RetrieveServiceActivity(2);
            User Boost = oUserDAO.RetrieveServiceActivity(3);
            User SinPin = oUserDAO.RetrieveServiceActivity(4);

            if (metro.Active == true)
            {
                btnMetroPCS.CssClass = "form-control btn btn-success";
                btnMetroPCS.Text = "MetroPCS On";
            }
            else
            {
                btnMetroPCS.CssClass = "form-control btn btn-danger";
                btnMetroPCS.Text = "MetroPCS Off";
            }

            if (cricket.Active == true)
            {
                btnCricket.CssClass = "form-control btn btn-success";
                btnCricket.Text = "Cricket On";
            }
            else
            {
                btnCricket.CssClass = "form-control btn btn-danger";
                btnCricket.Text = "Cricket Off";
            }

            if (Boost.Active == true)
            {
                btnBoost.CssClass = "form-control btn btn-success";
                btnBoost.Text = "Boost On";
            }
            else
            {
                btnBoost.CssClass = "form-control btn btn-danger";
                btnBoost.Text = "Boost Off";
            }
            if (SinPin.Active == true)
            {
                btnSinPin.CssClass = "form-control btn btn-success";
                btnSinPin.Text = "SinPin On";
            }
            else
            {
                btnSinPin.CssClass = "form-control btn btn-danger";
                btnSinPin.Text = "SinPin Off";
            }

            bool BC = cardsActive("BC");
            bool PA = cardsActive("PA");
            bool MC = cardsActive("MC");
            bool MB = cardsActive("MB");
            bool BT = cardsActive("BT");
            bool MT = cardsActive("MT");
            bool NU = cardsActive("DB");

            if (BC == true)
            {
                btnBC.CssClass = "form-control btn btn-success";
                btnBC.Text = "BC On - CC's left " + cardsLeft("B", "C");

                btnBCdelete.CssClass = "form-control btn btn-success";
                btnBCdelete.Text = "BC On - CC's left " + cardsLeftAll("B", "C");
            }
            else
            {
                btnBC.CssClass = "form-control btn btn-danger";
                btnBC.Text = "BC Off - CC's left " + cardsLeft("B", "C");

                btnBCdelete.CssClass = "form-control btn btn-danger";
                btnBCdelete.Text = "BC Off - CC's left " + cardsLeftAll("B", "C");
            }

            if (PA == true)
            {
                btnPA.CssClass = "form-control btn btn-success";
                btnPA.Text = "PA On - CC 's left " + cardsLeft("P", "A");

                btnPAdelete.CssClass = "form-control btn btn-success";
                btnPAdelete.Text = "PA On - CC 's left " + cardsLeftAll("P", "A");
            }
            else
            {
                btnPA.CssClass = "form-control btn btn-danger";
                btnPA.Text = "PA Off - CC's left " + cardsLeft("P", "A");

                btnPAdelete.CssClass = "form-control btn btn-danger";
                btnPAdelete.Text = "PA Off - CC 's left " + cardsLeftAll("P", "A");
            }

            if (MC == true)
            {
                btnMC.CssClass = "form-control btn btn-success";
                btnMC.Text = "MC On - CC's left " + cardsLeft("M", "C");

                btnMCdelete.CssClass = "form-control btn btn-success";
                btnMCdelete.Text = "MC On - CC's left " + cardsLeftAll("M", "C");
            }
            else
            {
                btnMC.CssClass = "form-control btn btn-danger";
                btnMC.Text = "MC Off - CC's left " + cardsLeft("M", "C");

                btnMCdelete.CssClass = "form-control btn btn-danger";
                btnMCdelete.Text = "MC Off - CC's left " + cardsLeftAll("M", "C");
            }
            if (MB == true)
            {
                btnMB.CssClass = "form-control btn btn-success";
                btnMB.Text = "MB On - CC's left " + cardsLeft("M", "B");

                btnMBdelete.CssClass = "form-control btn btn-success";
                btnMBdelete.Text = "MB On - CC's left " + cardsLeftAll("M", "B");
            }
            else
            {
                btnMB.CssClass = "form-control btn btn-danger";
                btnMB.Text = "MB Off - CC's left " + cardsLeft("M", "B");

                btnMBdelete.CssClass = "form-control btn btn-danger";
                btnMBdelete.Text = "MB Off - CC's left " + cardsLeftAll("M", "B");
            }
            if (BT == true)
            {
                btnBT.CssClass = "form-control btn btn-success";
                btnBT.Text = "BT On - CC's left " + cardsLeft("B", "T");

                btnBTdelete.CssClass = "form-control btn btn-success";
                btnBTdelete.Text = "BT On - CC's left " + cardsLeftAll("B", "T");
            }
            else
            {
                btnBT.CssClass = "form-control btn btn-danger";
                btnBT.Text = "BT Off - CC's left " + cardsLeft("B", "T");

                btnBTdelete.CssClass = "form-control btn btn-danger";
                btnBTdelete.Text = "BT Off - CC's left " + cardsLeftAll("B", "T");
            }
            if (MT == true)
            {
                btnMT.CssClass = "form-control btn btn-success";
                btnMT.Text = "MT On - CC's left " + cardsLeft("M", "T");

                btnMTdelete.CssClass = "form-control btn btn-success";
                btnMTdelete.Text = "MT On - CC's left " + cardsLeftAll("M", "T");
            }
            else
            {
                btnMT.CssClass = "form-control btn btn-danger";
                btnMT.Text = "MT Off - CC's left " + cardsLeft("M", "T");

                btnMTdelete.CssClass = "form-control btn btn-danger";
                btnMTdelete.Text = "MT Off - CC's left " + cardsLeftAll("M", "T");
            }
            if (NU == true)
            {
                btnNU.CssClass = "form-control btn btn-success";
                btnNU.Text = "DB On - CC's left " + cardsLeft("D", "B");

                btnNUdelete.CssClass = "form-control btn btn-success";
                btnNUdelete.Text = "DB On - CC's left " + cardsLeftAll("D", "B");
            }
            else
            {
                btnNU.CssClass = "form-control btn btn-danger";
                btnNU.Text = "DB Off - CC's left " + cardsLeft("D", "B");

                btnNUdelete.CssClass = "form-control btn btn-danger";
                btnNUdelete.Text = "DB Off - CC's left " + cardsLeftAll("D", "B");
            }
            btndeleteFalse.CssClass = "form-control btn btn-warning";
            btndeleteFalse.Text = "CC's that are false " + cardsLeftFalse();
            if (!Page.IsPostBack)
            {
                lbCount.Text = "Metro cards left in the database: " + CCLeft() + "<br /> Boost cards left in the database: " + CCBoostLeft() + "<br /> Cricket cards left in the database: " + CCCricketLeft() + "<br /> Back up cards left in the database: " + NUCCLeft();
            }
        }
        //CLICKS----------------------------------------------------------------------------------------------------------------------------------
        protected void Submit_Click(object sender, System.EventArgs e)
        {
            try
            {
                if (Page.IsPostBack)
                {
                    int i = 0;
                    if (txtFirstNameUser.Text == "") { i = 1; }
                    else if (txtLastNameUser.Text == "") { i = 2; }
                    else if (txtPhoneNumber.Text == "") { i = 3; }
                    else if (txtUserName.Text == "") { i = 4; }
                    else if (txtPassword.Text == "") { i = 5; }
                    else if (txtFee.Text == "") { i = 6; }
                    else if (txtEmail.Text == "") { i = 7; }
                    else if (txtBusinessName.Text == "") { i = 8; }
                    else if (txtBusinessAddress.Text == "") { i = 9; }

                    switch (i)
                    {
                        case 1: lbDesc.Text = "First name missing!"; break;
                        case 2: lbDesc.Text = "Last name missing!"; break;
                        case 3: lbDesc.Text = "Phone missing!"; break;
                        case 4: lbDesc.Text = "User Name missing!"; break;
                        case 5: lbDesc.Text = "Password missing!"; break;
                        case 6: lbDesc.Text = "Fee missing!"; break;
                        case 7: lbDesc.Text = "Email missing!"; break;
                        case 8: lbDesc.Text = "Business Name missing!"; break;
                        case 9: lbDesc.Text = "Business Address missing!"; break;

                    }

                    if (i == 0)
                    {
                        oUser = oUserDAO.RetrieveUserByUserID(txtUserName.Text);
                        if (oUser.UserID != null)
                        {
                            string LowerUsername = oUser.UserID.ToLower();
                            string LowerUsername2 = txtUserName.Text;

                            if (LowerUsername == LowerUsername2)
                            {
                                lbDesc.ForeColor = Color.Red;
                                lbDesc.Text = "Username already exists, account was not created.";
                                return;
                            }
                        }
                        //insert user
                        oUser = oUserDAO.InsertUser(txtUserName.Text, DAO.Encrypt(txtPassword.Text, ConfigurationManager.AppSettings["encryptionKey"]), txtFirstNameUser.Text + " " + txtLastNameUser.Text, txtPhoneNumber.Text, txtEmail.Text, txtBusinessName.Text, txtBusinessAddress.Text, txtPost.Text, ddUserType.SelectedItem.Text, true, DateTime.Now, txtBusinessCity.Text, ddBusinessState.SelectedItem.Value, txtBusinessZip.Text, txtResale.Text, txtEIN.Text);
                        oUser = oUserDAO.InsertFee(txtUserName.Text, Convert.ToInt32(txtFee.Text));
                        if (ddHasAccount.SelectedValue == "Yes")
                        {
                            oUser = oUserDAO.InsertAccount(txtUserName.Text, txtPost.Text);
                        }
                        lbDesc.Text = "User Entered";
                        lbDesc.ForeColor = Color.Green;
                        txtFirstNameUser.Text = "";
                        txtLastNameUser.Text = "";
                        txtPhoneNumber.Text = "";
                        txtUserName.Text = "";
                        txtPost.Text = "";
                        txtEmail.Text = "";
                        txtBusinessName.Text = "";
                        txtBusinessAddress.Text = "";
                        txtBusinessCity.Text = "";
                        txtBusinessZip.Text = "";
                        txtEIN.Text = "";
                        txtResale.Text = "";

                    }
                    Session["cc"] = "false";
                    if (Session["cc"].ToString() == "false")
                    {
                        divcc.Attributes.Add("style", "display:none");
                        divuser.Attributes.Add("style", "display:block");
                    }
                }

            }
            catch (Exception ex)
            {
                lbDesc.Text = ex.Message;
            }


        }
        protected void CC_Click(object sender, System.EventArgs e)
        {
            try
            {
                if (Page.IsPostBack)
                {
                    int i = 0;
                    if (txtCC.Text == "") { i = 1; }
                    else if (txtExpDate.Text == "") { i = 2; }
                    else if (txtCVV.Text == "") { i = 3; }
                    else if (txtFirstName.Text == "") { i = 4; }
                    else if (txtLastName.Text == "") { i = 5; }
                    switch (i)
                    {
                        case 1: lbcc.Text = "CC missing!"; break;
                        case 2: lbcc.Text = "ExpDate missing!"; break;
                        case 3: lbcc.Text = "CVV missing!"; break;
                        case 4: lbcc.Text = "First name missing!"; break;
                        case 5: lbcc.Text = "Last name missing!"; break;
                    }

                    if (i == 0)
                    {
                        string thecc = txtCC.Text.Trim();
                        if (thecc.Replace(" ", "").Length == 16)
                        {
                            string cc = txtCC.Text.Replace(" ", "");
                            CC oCC = new CC();
                            oCC = oUserDAO.RetrieveCCByCC(DAO.Encrypt(cc, ConfigurationManager.AppSettings["encryptionKey"]));
                            CC oCCMetroCC = new CC();
                            oCCMetroCC = oUserDAO.RetrieveCCByAddress(txtMetroCC.Text);
                            string DBCC = oCC.CCNumber;
                            string DBEncryption = oCCMetroCC.Address;
                            string CurrentCC = DAO.Encrypt(cc, ConfigurationManager.AppSettings["encryptionKey"]);

                            if (DBCC == null)
                            {
                                DBCC = "";
                            }
                            if (DBCC.Trim() == CurrentCC.Trim())
                            {
                                lbcc.ForeColor = Color.Red;
                                lbcc.Text = "CC Failed, there is a duplicate in the system";
                            }
                            else
                            {
                                //insert cc
                                if (txtCCFirstName.Text == "Don")
                                {
                                    oUser = oUserDAO.InsertCC(txtFirstName.Text, txtLastName.Text, "5047 Summit Blvd", "33415", DAO.Encrypt(cc, ConfigurationManager.AppSettings["encryptionKey"]), txtExpDate.Text, txtCVV.Text);
                                }
                                else if (txThetAddress.Text != "")
                                {
                                    oUser = oUserDAO.InsertCC(txtFirstName.Text, txtLastName.Text, txThetAddress.Text, txtZip.Text, DAO.Encrypt(cc, ConfigurationManager.AppSettings["encryptionKey"]), txtExpDate.Text, txtCVV.Text);
                                }
                                else if (txtMetroCC.Text != "")
                                {
                                    if (DBEncryption != null)
                                    {
                                        if (DBEncryption.Trim() == txtMetroCC.Text.Trim())
                                        {
                                            lbcc.ForeColor = Color.Red;
                                            lbcc.Text = "MetroCC encryption has a duplicate in the system";
                                            return;
                                        }
                                        else
                                        {
                                            oUser = oUserDAO.InsertCC(txtFirstName.Text, txtLastName.Text, txtMetroCC.Text, "33415", DAO.Encrypt(cc, ConfigurationManager.AppSettings["encryptionKey"]), txtExpDate.Text, txtCVV.Text);

                                        }
                                    }
                                    else
                                    {
                                        oUser = oUserDAO.InsertCC(txtFirstName.Text, txtLastName.Text, txtMetroCC.Text, "33415", DAO.Encrypt(cc, ConfigurationManager.AppSettings["encryptionKey"]), txtExpDate.Text, txtCVV.Text);

                                    }

                                }
                                else
                                {
                                    oUser = oUserDAO.InsertCC(txtFirstName.Text, txtLastName.Text, "5047 Summit Blvd", "33415", DAO.Encrypt(cc, ConfigurationManager.AppSettings["encryptionKey"]), this.txtExpDate.Text, this.txtCVV.Text);
                                }


                                lbCount.Text = "Metro cards left in the database: " + CCLeft() + "<br /> Boost cards left in the database: " + CCBoostLeft() + "<br /> Cricket cards left in the database: " + CCCricketLeft() + "<br /> Back up cards left in the database: " + NUCCLeft();
                                lbDesc.ForeColor = Color.Green;
                                lbcc.ForeColor = Color.Green;
                                lbcc.Text = "CC Entered successfully";
                                txtCC.Text = "";
                                txtExpDate.Text = "";
                                txtMetroCC.Text = "";
                                txtCVV.Text = "";

                                DataTable dt = new DataTable();
                                BindCCGrid(dt);
                             }
                        }
                        else
                        {
                            lbcc.ForeColor = Color.Red;
                            lbcc.Text = "CC field has to be 16 digits";
                        }
                    }
                    Session["cc"] = "true";
                    if (Session["cc"].ToString() == "true")
                    {
                        divcc.Attributes.Add("style", "display:block");
                        divuser.Attributes.Add("style", "display:none");
                    }
                }
            }
            catch (Exception ex)
            {
                lbcc.Text = ex.Message;
            }
        }
        
        protected void Credit_Click(object sender, System.EventArgs e)
        {
            try
            {
                if (ddUser.SelectedItem.Text != "--Select User--")
                {
                    if (ddPayMethod.SelectedItem.Value != "--Select Payment Method--")
                    {
                        MetroFastPayLibrary.Account oAccount = new MetroFastPayLibrary.Account();
                        oUser = oUserDAO.RetrieveUserByUserID(ddUser.SelectedItem.Value);

                        //update credit line
                        oUserDAO.InsertCredit(oUser.UserID, oUser.Post, ddPayMethod.SelectedItem.Value, Convert.ToInt32(txtCreditAmount.Text));
                        oAccount = oUserDAO.RetrieveAccount(oUser.UserID);
                        oUserDAO.UpdateAccountbyPost(oAccount.Credit + Convert.ToInt32(txtCreditAmount.Text), oUser.Post);
                        lbCreditDesc.ForeColor = Color.Green;
                        lbCreditDesc.Text = "Credit added! ($" + txtCreditAmount.Text + ")";
                        txtCreditAmount.Text = "";

                        DataTable dt = new DataTable();
                        BindTransGrid(dt);
                    }
                    else
                    {
                        lbCreditDesc.ForeColor = Color.Red;
                        lbCreditDesc.Text = "Select a pay method";
                    }
                }
                else
                {
                    lbCreditDesc.ForeColor = Color.Red;
                    lbCreditDesc.Text = "Select a user";
                }

            }
            catch (Exception ex)
            {
                lbCreditDesc.Text = ex.Message;
            }
        }
        protected void ResetError_Click(object sender, System.EventArgs e)
        {
            DataTable dt2 = new DataTable();
            BindErrorGrid(dt2);
        }

        protected void ResetCredit_Click(object sender, System.EventArgs e)
        {
            DataTable dt2 = new DataTable();
            BindTransGrid(dt2);
        }
        protected void ResetPaymentsClick(object sender, System.EventArgs e)
        {
            DataTable dt2 = new DataTable();
            BindPaymentGrid(dt2);
        }


        protected void Payment_Click(object sender, System.EventArgs e)
        {
            try
            {
                if (ddUserPayment.SelectedItem.Text != "--Select User--")
                {
                    if (ddProvider.SelectedItem.Value != "--Select Provider--")
                    {
                        MetroFastPayLibrary.Account oAccount = new MetroFastPayLibrary.Account();
                        oUser = oUserDAO.RetrieveUserByUserID(ddUserPayment.SelectedItem.Text);
                        decimal fee = 0;
                        //update credit line
                        //oUserDAO.InsertCredit(oUser.UserID, oUser.Post, ddPayMethod.SelectedItem.Value, Convert.ToInt32(txtCreditAmount.Text));
                        User oFee = new User();
                        oFee = oUserDAO.RetrieveFeebyUserID(oUser.UserID);
                        fee = Convert.ToDecimal(oFee.Fee) - (Convert.ToDecimal(oFee.Fee) - 2);
                        oAccount = oUserDAO.RetrieveAccount(oUser.UserID);
                        int conf = getConf(ddProvider.SelectedItem.Text) + 1;
                        string cc = "";
                        decimal totalPay = 0;
                        decimal sub = Convert.ToDecimal(txtPaymentAmount.Text) + fee;
                        if (oAccount.Active == true)
                        {
                            totalPay = Convert.ToDecimal(oAccount.Credit - sub);
                            if (totalPay > 1)
                            {
                                oUserDAO.UpdateAccountbyPost(totalPay, oUser.Post);
                                if (ddProvider.SelectedItem.Value == "MetroPCS" || ddProvider.SelectedItem.Value == "Boost")
                                {
                                    cc = "jNgIidwGeXIvGWnBgyr+VPaSRZ328OYRTL7VUmuNRPTve8ieKoTjk7upoZ3oicBb";
                                }
                                else
                                {
                                    cc = "7nqjU73xlX7XUPPicl4to8urStzwUH2jwrI6R+XvB1I42EKi55cDaMwoyEJ/gB95";
                                }
                                if (txtFrom.Text == "")
                                {
                                    oUserDAO.InsertPayments(oUser.UserID, oUser.Post, txtPaymentNumber.Text, Convert.ToDecimal(txtPaymentAmount.Text), Convert.ToDecimal(fee + 2), ddProvider.SelectedItem.Text + " - Conf#:" + conf, cc, DateTime.Now);

                                }
                                else
                                {
                                    oUserDAO.InsertPayments(oUser.UserID, oUser.Post, txtPaymentNumber.Text, Convert.ToDecimal(txtPaymentAmount.Text), Convert.ToDecimal(fee + 2), ddProvider.SelectedItem.Text + " - Conf#:" + conf, cc, Convert.ToDateTime(txtFrom.Text + " " + DateTime.Now.TimeOfDay.ToString()));
                                }
                                lbPaymentInfo.ForeColor = Color.Green;
                                lbPaymentInfo.Text = "Payment made! ($" + txtPaymentAmount.Text + ")";
                                txtPaymentAmount.Text = "";

                            }
                            else
                            {
                                lbPaymentInfo.ForeColor = Color.Red;
                                lbPaymentInfo.Text = "Payment could not be made because account is less than the payment";
                            }

                        }
                        else
                        {
                            if (ddProvider.SelectedItem.Value == "MetroPCS")
                            {
                                cc = "jNgIidwGeXIvGWnBgyr+VPaSRZ328OYRTL7VUmuNRPTve8ieKoTjk7upoZ3oicBb";
                            }
                            else
                            {
                                cc = "7nqjU73xlX7XUPPicl4to8urStzwUH2jwrI6R+XvB1I42EKi55cDaMwoyEJ/gB95";
                            }
                            if (txtFrom.Text == "")
                            {
                                oUserDAO.InsertPayments(oUser.UserID, oUser.Post, txtPaymentNumber.Text, Convert.ToDecimal(txtPaymentAmount.Text), Convert.ToDecimal(fee + 2), ddProvider.SelectedItem.Text + " - Conf#:" + conf, cc, DateTime.Now);

                            }
                            else
                            {
                                oUserDAO.InsertPayments(oUser.UserID, oUser.Post, txtPaymentNumber.Text, Convert.ToDecimal(txtPaymentAmount.Text), Convert.ToDecimal(fee + 2), ddProvider.SelectedItem.Text + " - Conf#:" + conf, cc, Convert.ToDateTime(txtFrom.Text + " " + DateTime.Now.TimeOfDay.ToString()));
                            }
                            lbPaymentInfo.ForeColor = Color.Green;
                            lbPaymentInfo.Text = "Payment made! ($" + txtPaymentAmount.Text + ")";
                            txtPaymentAmount.Text = "";


                        }

                        DataTable dt1 = new DataTable();
                        BindPaymentGrid(dt1);

                    }
                    else
                    {
                        lbPaymentInfo.ForeColor = Color.Red;
                        lbPaymentInfo.Text = "Select a provider";
                    }

                }
                else
                {
                    lbPaymentInfo.ForeColor = Color.Red;
                    lbPaymentInfo.Text = "Select a user";
                }

            }
            catch (Exception ex)
            {
                lbPaymentInfo.Text = ex.Message;
            }
        }
        protected void x_Click(object sender, System.EventArgs e)
        {
            CCModal.Attributes.Add("style", "display:none");
        }

        protected void Announce_Click(object sender, EventArgs e)
        {
            Announcement announcement = new Announcement();
            announcement = oUserDAO.RetrieveAnnouncement();
            if (txtAnnounceDate.Text == "" && txtAnnounceDateEnd.Text == "")
            {
                this.lbPostAnnounce.ForeColor = Color.Red;
                this.lbPostAnnounce.Text = "Enter dates to create announcement.";
            }
            else
            {
                this.lbPostAnnounce.ForeColor = Color.Green;
                DateTime it = announcement.AnnouncementDate;
                if (txtAnnounceDate.Text == it.ToString("MM/dd/yyyy"))
                {
                    this.oUserDAO.UpdateAnnouncement(this.txtAnnounce.Text, txtAnnounceDate.Text, txtAnnounceDateEnd.Text);
                    this.lbPostAnnounce.Text = "Annoucement (" + txtAnnounce.Text + ") posted for " + txtAnnounceDate.Text;
                }
                else
                {
                    this.oUserDAO.InsertAnnouncement(this.txtAnnounce.Text, txtAnnounceDate.Text, txtAnnounceDateEnd.Text);
                    this.lbPostAnnounce.Text = "Annoucement (" + txtAnnounce.Text + ") posted for " + txtAnnounceDate.Text;
                }
                DataTable dt5 = new DataTable();
                BindAnnouncementGrid(dt5);
            }

        }
        protected void MetroPCSFix_Click (object sender, System.EventArgs e)
        {
            try
            {
                if (txta.Text == "" && txtb.Text == "" && txtc.Text == "" && txtd.Text == "" && txtf.Text == "" && txtz.Text == "")
                {
                    lbMetroPCSSecutiry.ForeColor = Color.Red;
                    lbMetroPCSSecutiry.Text = "All security fields must be filled";                 
                }
                else
                {
                    MetroFastPayLibrary.MetroPCSSecurity oMetroPCSSecurity = new MetroFastPayLibrary.MetroPCSSecurity();
                    oMetroPCSSecurity = oUserDAO.InsertMetroPCSSecurity(txta.Text.Trim(), txtb.Text.Trim(), txtc.Text.Trim(), txtd.Text.Trim(), txtf.Text.Trim(), txtz.Text.Trim());

                    lbMetroPCSSecutiry.ForeColor = Color.Green;
                    lbMetroPCSSecutiry.Text = "Security Updated";
                }
                DataTable dt = new DataTable();
                BindMSGrid(dt);
            }
            catch (Exception ex)
            {
                lbCreditDesc.Text = ex.Message;
            }
        }
        //GRIDS---------------------------------------------------------------------------------------------------------------------------------

        private void BindErrorGrid(DataTable dt2)

        {
            DataTable dtCount = new DataTable();
            List<MetroFastPayLibrary.Payment> aList = new List<MetroFastPayLibrary.Payment>();
            aList = new List<MetroFastPayLibrary.Payment>();

            aList = oUserDAO.PopulateErrorLog();

            dtCount = new DataTable();
            dt2.Columns.AddRange(new DataColumn[5] { new DataColumn("UserID"), new DataColumn("PhoneNumber"), new DataColumn("CC"), new DataColumn("Error"), new DataColumn("CreatedDate") });
            foreach (MetroFastPayLibrary.Payment oPayment in aList)
            {

                dt2.Rows.Add(oPayment.UserID, oPayment.PhoneNumber, oPayment.CCNumberUsed, oPayment.Provider, oPayment.CreatedDate);

            }

            gvErrorLog.DataSource = dt2;
            gvErrorLog.DataBind();
        }

        private void BindTransGrid(DataTable dt)

        {
            DataTable dtCount = new DataTable();
            List<MetroFastPayLibrary.Account> aList = new List<MetroFastPayLibrary.Account>();
            aList = new List<MetroFastPayLibrary.Account>();

            if (txtFrom1.Text == "")
            {
                aList = oUserDAO.PopulateAccountTransactionAll();
            }
            else
            {
                var date1 = Convert.ToDateTime(txtFrom1.Text).Date.ToString("yyyy/MM/dd");
                var date2 = Convert.ToDateTime(txtTo1.Text).Date.ToString("yyyy/MM/dd");
                aList = oUserDAO.PopulateAccountTransByDate(date1, date2);
            }


            dtCount = new DataTable();
            dt.Columns.AddRange(new DataColumn[5] { new DataColumn("ID"), new DataColumn("UserID"), new DataColumn("Amount"), new DataColumn("TransactionID"), new DataColumn("Date Added") });
            foreach (MetroFastPayLibrary.Account oAccount in aList)
            {

                dt.Rows.Add(oAccount.ID, oAccount.UserID, string.Format("{0:0.00}", Convert.ToDecimal(oAccount.Amount)), oAccount.TransactionID, oAccount.CreatedDate);

            }
            Label3.Text = "";
            if (aList.Count == 0)
            {
                //  divTrans.Attributes.Add("style", "display:none")
                Label3.Text = "There is no data";
            }
            gvTrans.DataSource = dt;
            gvTrans.DataBind();

            foreach (GridViewRow gvr in gvTrans.Rows)
            {
                if (Convert.ToDateTime(gvr.Cells[5].Text) < DateTime.Today.AddDays(-7))
                {
                    gvr.Cells[0].Enabled = false;
                }
            }
        }
        private void BindPaymentGrid(DataTable dt)

        {
            DataTable dtCount = new DataTable();
            List<Payment> aList = new List<Payment>();
            aList = new List<Payment>();


            aList = oUserDAO.PopulateReportbydateAll(DateTime.Now.ToShortDateString(), DateTime.Now.ToShortDateString());


            dtCount = new DataTable();
            dt.Columns.AddRange(new DataColumn[11] { new DataColumn("ID"), new DataColumn("Post"), new DataColumn("UserID"), new DataColumn("Provider"), new DataColumn("Client#"), new DataColumn("Conf#"), new DataColumn("Code"), new DataColumn("Payment"), new DataColumn("Fees"), new DataColumn("Total"), new DataColumn("Date Paid") });
            foreach (Payment oPayment in aList)
            {
                User oFee = new User();
                oFee = oUserDAO.RetrieveFeebyUserID(oPayment.UserID);
                decimal cardcom;
                string cardnum = DAO.Decrypt(oPayment.CCNumberUsed.Trim(), ConfigurationManager.AppSettings["encryptionKey"]).Remove(1, 15);
                if (cardnum == "5" && oPayment.Provider.Substring(0, oPayment.Provider.LastIndexOf(" -") + 1).Trim() != "SinPin")
                {
                    cardcom = Convert.ToDecimal(oPayment.AmountPaid) * Convert.ToDecimal(.02);
                    dt.Rows.Add(oPayment.ID, oPayment.Post, oPayment.UserID, oPayment.Provider.Substring(0, oPayment.Provider.LastIndexOf(" -") + 1).Trim(), oPayment.PhoneNumber, oPayment.Provider.Substring(oPayment.Provider.LastIndexOf(':') + 1), DAO.Decrypt(oPayment.CCNumberUsed.Trim(), ConfigurationManager.AppSettings["encryptionKey"]).Remove(0, 12), string.Format("{0:0.00}", Convert.ToDecimal(oPayment.AmountPaid)), string.Format("{0:0.00}", Convert.ToDecimal(oPayment.Fee)), string.Format("{0:0.00}", Convert.ToDecimal(oPayment.AmountPaid) + Convert.ToDecimal(oPayment.Fee)), oPayment.CreatedDate);
                }
                else if (cardnum == "4" && oPayment.Provider.Substring(0, oPayment.Provider.LastIndexOf(" -") + 1).Trim() != "SinPin")
                {
                    cardcom = Convert.ToDecimal(oPayment.AmountPaid) * Convert.ToDecimal(.01);
                    dt.Rows.Add(oPayment.ID, oPayment.Post, oPayment.UserID, oPayment.Provider.Substring(0, oPayment.Provider.LastIndexOf(" -") + 1).Trim(), oPayment.PhoneNumber, oPayment.Provider.Substring(oPayment.Provider.LastIndexOf(':') + 1), DAO.Decrypt(oPayment.CCNumberUsed.Trim(), ConfigurationManager.AppSettings["encryptionKey"]).Remove(0, 12), string.Format("{0:0.00}", Convert.ToDecimal(oPayment.AmountPaid)), string.Format("{0:0.00}", Convert.ToDecimal(oPayment.Fee)), string.Format("{0:0.00}", Convert.ToDecimal(oPayment.AmountPaid) + Convert.ToDecimal(oPayment.Fee)), oPayment.CreatedDate);
                }
                //else if (oPayment.Provider.Substring(0, oPayment.Provider.LastIndexOf(" -") + 1).Trim() == "SinPin")
                //{
                //    dt.Rows.Add(oPayment.ID, oPayment.Post, oPayment.UserID, oPayment.Provider.Substring(0, oPayment.Provider.LastIndexOf(" -") + 1).Trim(), oPayment.PhoneNumber, oPayment.Provider.Substring(oPayment.Provider.LastIndexOf(':') + 1), DAO.Decrypt(oPayment.CCNumberUsed.Trim(), ConfigurationManager.AppSettings["encryptionKey"]).Remove(0, 12), string.Format("{0:0.00}", Convert.ToDecimal(oPayment.AmountPaid)), string.Format("{0:0.00}", Convert.ToDecimal(oPayment.Fee)), string.Format("{0:0.00}", Convert.ToDecimal(oPayment.AmountPaid) + Convert.ToDecimal(oPayment.Fee)), oPayment.CreatedDate);

                //}
            }

            gvPayment.DataSource = dt;
            gvPayment.DataBind();

        }

        private void BindCCGrid(DataTable dt)

        {
            DataTable dtCount = new DataTable();
            List<MetroFastPayLibrary.CC> aList = new List<MetroFastPayLibrary.CC>();
            aList = new List<MetroFastPayLibrary.CC>();

            aList = oUserDAO.PopulateCCs();

            dtCount = new DataTable();
            dt.Columns.AddRange(new DataColumn[9] { new DataColumn("ID"), new DataColumn("FirstName"), new DataColumn("LastName"), new DataColumn("CCNumber"), new DataColumn("ExpDate"), new DataColumn("CVV"), new DataColumn("Used"), new DataColumn("Active"), new DataColumn("DateModified") });
            foreach (MetroFastPayLibrary.CC oCC in aList)
            {

                dt.Rows.Add(oCC.ID, oCC.FirstName, oCC.LastName, DAO.Decrypt(oCC.CCNumber, ConfigurationManager.AppSettings["encryptionKey"]).Trim().Substring(12, 4), oCC.ExpDate, oCC.CVV, oCC.Used, oCC.Active, oCC.DateModified);

            }

            gvCC.DataSource = dt;
            gvCC.DataBind();

            lbCount.Text = "Metro cards left in the database: " + CCLeft() + "<br /> Boost cards left in the database: " + CCBoostLeft() + "<br /> Cricket cards left in the database: " + CCCricketLeft() + "<br /> Back up cards left in the database: " + NUCCLeft();

        }
        private void BindAnnouncementGrid(DataTable dt)

        {
            DataTable dtCount = new DataTable();
            List<Announcement> aList = new List<Announcement>();
            aList = new List<Announcement>();


            aList = oUserDAO.PopukateAnnouncement();


            dtCount = new DataTable();
            dt.Columns.AddRange(new DataColumn[5] { new DataColumn("ID"), new DataColumn("Text"), new DataColumn("AnnouncementDate"), new DataColumn("AnnouuncementDateEnd"), new DataColumn("Created Date") });
            foreach (Announcement oAnnouncement in aList)
            {

                    dt.Rows.Add(oAnnouncement.AnnounceID, oAnnouncement.AnnounceText, oAnnouncement.AnnouncementDate, oAnnouncement.AnnouncementDateEnd, oAnnouncement.CreatedDate);
                
            }

            gvAnnouncement.DataSource = dt;
            gvAnnouncement.DataBind();

        }

        private void BindMSGrid(DataTable dt)

        {
            DataTable dtCount = new DataTable();
            List<MetroPCSSecurity> aList = new List<MetroPCSSecurity>();
            aList = new List<MetroPCSSecurity>();


            aList = oUserDAO.PopulateMS();


            dtCount = new DataTable();
            dt.Columns.AddRange(new DataColumn[7] {new DataColumn("a"), new DataColumn("b"), new DataColumn("c"), new DataColumn("d"), new DataColumn("f"), new DataColumn("z"), new DataColumn("Created Date") });
            foreach (MetroPCSSecurity oMetroPCSSecurity in aList)
            {

                dt.Rows.Add(oMetroPCSSecurity.a, oMetroPCSSecurity.b, oMetroPCSSecurity.c, oMetroPCSSecurity.d, oMetroPCSSecurity.f, oMetroPCSSecurity.z, oMetroPCSSecurity.CreatedDate);

            }

            gvMS.DataSource = dt;
            gvMS.DataBind();

        }
        //DELETES-----------------------------------------------------------------------------------------------------------------------------------
        protected void DeletePayment(object sender, EventArgs e)
        {


            UserDAO oUserDAO = new UserDAO();
            Button btnDelete = (Button)sender;
            MetroFastPayLibrary.Account oAccount = new MetroFastPayLibrary.Account();
            MetroFastPayLibrary.Account oAccount2 = new MetroFastPayLibrary.Account();
            string id = btnDelete.CommandArgument;


            oAccount = oUserDAO.RetrieveAccount(btnDelete.ToolTip);
            oAccount2 = oUserDAO.RetrieveCreditbyID(Convert.ToInt32(id));
            if (oAccount.Credit == 0)
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('cant delete this transaction, user has 0 in their account');", true);
            }
            else
            {
                decimal total = Convert.ToDecimal(oAccount.Credit) - Convert.ToDecimal(oAccount2.Amount);
                oUserDAO.UpdateAccount(total, btnDelete.ToolTip);
                oUserDAO.DeleteCreditTrans(Convert.ToInt32(id));

                DataTable dt = new DataTable();
                BindTransGrid(dt);
            }


        }
        protected void DeleteCC(object sender, EventArgs e)
        {


            UserDAO oUserDAO = new UserDAO();
            Button btnDeleteCC = (Button)sender;

            string id = btnDeleteCC.CommandArgument;
            oUserDAO.DeleteCC(Convert.ToInt32(id));

            lbCount.Text = "Metro cards left in the database: " + CCLeft() + "<br /> Boost cards left in the database: " + CCBoostLeft() + "<br /> Cricket cards left in the database: " + CCCricketLeft() + "<br /> Back up cards left in the database: " + NUCCLeft();


            DataTable dt = new DataTable();
            BindCCGrid(dt);



        }
        protected void EditCC(object sender, EventArgs e)
        {

            int theid = Convert.ToInt32(Request.QueryString["ID"]);
            CC oCC = new CC();
            oCC = oUserDAO.RetrieveCCbyID(theid);

            oUserDAO.UpdateCCbyID(theid, txtCCFirstName.Text, txtCCLastName.Text, txtUsed.Text, Convert.ToBoolean(ddCCActive.SelectedItem.Value));

            CCModal.Attributes.Add("style", "display:none");

            lbCount.Text = "Metro cards left in the database: " + CCLeft() + "<br /> Boost cards left in the database: " + CCBoostLeft() + "<br /> Cricket cards left in the database: " + CCCricketLeft() + "<br /> Back up cards left in the database: " + NUCCLeft();


            DataTable dt = new DataTable();
            BindCCGrid(dt);



        }
        protected void DeleteAddedPayment(object sender, EventArgs e)
        {
            try
            {
                UserDAO oUserDAO = new UserDAO();
                Button btnDeletePayments = (Button)sender;
                User oFee = new User();

                MetroFastPayLibrary.Account oAccount = new MetroFastPayLibrary.Account();
                oAccount = oUserDAO.RetrieveAccount(btnDeletePayments.ToolTip);
                oUser = oUserDAO.RetrieveUserByUserID(btnDeletePayments.ToolTip);

                string id = btnDeletePayments.CommandArgument;

                Payment oPay = new Payment();
                oPay = oUserDAO.RetrievePaymentbyID(Convert.ToInt32(id));

                if (oAccount.Active == true)
                {

                    oFee = oUserDAO.RetrieveFeebyUserID(oUser.UserID);
                    decimal fee = Convert.ToInt32(oFee.Fee) - (Convert.ToInt32(oFee.Fee) - 2);
                    decimal totalPay = 0;
                    decimal sub = Convert.ToDecimal(oPay.AmountPaid) + fee;

                    totalPay = Convert.ToDecimal(oAccount.Credit + sub);
                    oUserDAO.UpdateAccountbyPost(totalPay, oUser.Post);
                }

                //oUserDAO.DeletePayment(Convert.ToInt32(id));
                oUserDAO.InsertPayments(oPay.UserID, oPay.Post, oPay.PhoneNumber, -oPay.AmountPaid, -oPay.Fee, oPay.Provider, oPay.CCNumberUsed, DateTime.Now);
                DataTable dt = new DataTable();
                BindPaymentGrid(dt);

            }
            catch
            {
                lbPaymentInfo.Text = "";
            }


        }

        protected void DeleteAnnouncement(object sender, EventArgs e)
        {


            UserDAO oUserDAO = new UserDAO();
            Button btnDeleteAnnounce = (Button)sender;
            MetroFastPayLibrary.Announcement oAnnouncement = new MetroFastPayLibrary.Announcement();

            string id = btnDeleteAnnounce.CommandArgument;


            oAnnouncement = oUserDAO.RetrieveAnnouncementbyID(Convert.ToInt32(id));
            oUserDAO.DeleteAnnoucement(Convert.ToInt32(id));

                DataTable dt = new DataTable();
                BindAnnouncementGrid(dt);


        }
        protected void DeleteMS(object sender, EventArgs e)
        {


            UserDAO oUserDAO = new UserDAO();
            Button btnDeleteMS = (Button)sender;
            MetroFastPayLibrary.MetroPCSSecurity oMetroPCSSecurity = new MetroFastPayLibrary.MetroPCSSecurity();

            string b = btnDeleteMS.CommandArgument;


            //oMetroPCSSecurity = oUserDAO.RetrieveMSbyA(a);
            oUserDAO.DeleteMS(b);

            DataTable dt = new DataTable();
            BindMSGrid(dt);


        }
        //PROVIDER_CLICKS-----------------------------------------------------------------------------------------------------------------------------
        protected void MetroPCS_Click(object sender, System.EventArgs e)
        {
            User metro = oUserDAO.RetrieveServiceActivity(1);
            if (metro.Active == true)
            {
                oUserDAO.UpdateServiceActivity(1, false);
            }
            else
            {
                oUserDAO.UpdateServiceActivity(1, true);
            }


            Response.Redirect(Request.Url.AbsolutePath + "?TurnOffServices");
        }
        protected void Cricket_Click(object sender, System.EventArgs e)
        {
            User Cricket = oUserDAO.RetrieveServiceActivity(2);
            if (Cricket.Active == true)
            {
                oUserDAO.UpdateServiceActivity(2, false);
            }
            else
            {
                oUserDAO.UpdateServiceActivity(2, true);
            }


            Response.Redirect(Request.Url.AbsolutePath + "?TurnOffServices");
        }
        protected void Boost_Click(object sender, System.EventArgs e)
        {
            User Boost = oUserDAO.RetrieveServiceActivity(3);
            if (Boost.Active == true)
            {
                oUserDAO.UpdateServiceActivity(3, false);
            }
            else
            {
                oUserDAO.UpdateServiceActivity(3, true);
            }


            Response.Redirect(Request.Url.AbsolutePath + "?TurnOffServices");
        }
        protected void SinPin_Click(object sender, System.EventArgs e)
        {
            User SinPin = oUserDAO.RetrieveServiceActivity(4);
            if (SinPin.Active == true)
            {
                oUserDAO.UpdateServiceActivity(4, false);
            }
            else
            {
                oUserDAO.UpdateServiceActivity(4, true);
            }


            Response.Redirect(Request.Url.AbsolutePath + "?TurnOffServices");
        }
        protected void DPPayment_Click(object sender, System.EventArgs e)
        {
            Session["offeringid"] = "30175480";
            DPMobilePayment();

            //Response.Redirect(Request.Url.AbsolutePath + "?TurnOffServices");
        }
        //CARD_ON_OFF--------------------------------------------------------------------------------------------------------------------------------

        protected void BC_Click(object sender, System.EventArgs e)
        {
            bool BC = cardsActive("BC");
            if (BC == true)
            {
                oUserDAO.UpdateCCUsageToFalse("BC", false);
                oUserDAO.UpdateCConANDoff("B", "C", false);
            }
            else
            {
                oUserDAO.UpdateCCUsageToFalse("BC", true);
                oUserDAO.UpdateCConANDoff("B", "C", true);
            }


            Response.Redirect(Request.Url.AbsolutePath + "?reset");
        }
        protected void PA_Click(object sender, System.EventArgs e)
        {
            bool PA = cardsActive("PA");
            if (PA == true)
            {
                oUserDAO.UpdateCCUsageToFalse("PA", false);
                oUserDAO.UpdateCConANDoff("P", "A", false);
            }
            else
            {
                oUserDAO.UpdateCCUsageToFalse("PA", true);
                oUserDAO.UpdateCConANDoff("P", "A", true);
            }


            Response.Redirect(Request.Url.AbsolutePath + "?reset");
        }
        protected void MC_Click(object sender, System.EventArgs e)
        {
            bool MC = cardsActive("MC");
            if (MC == true)
            {
                oUserDAO.UpdateCCUsageToFalse("MC", false);
                oUserDAO.UpdateCConANDoff("M", "C", false);
            }
            else
            {
                oUserDAO.UpdateCCUsageToFalse("MC", true);
                oUserDAO.UpdateCConANDoff("M", "C", true);
            }


            Response.Redirect(Request.Url.AbsolutePath + "?reset");
        }
        protected void MB_Click(object sender, System.EventArgs e)
        {
            bool MB = cardsActive("MB");
            if (MB == true)
            {
                oUserDAO.UpdateCCUsageToFalse("MB", false);
                oUserDAO.UpdateCConANDoff("M", "B", false);
            }
            else
            {
                oUserDAO.UpdateCCUsageToFalse("MB", true);
                oUserDAO.UpdateCConANDoff("M", "B", true);
            }


            Response.Redirect(Request.Url.AbsolutePath + "?reset");
        }
        protected void BT_Click(object sender, System.EventArgs e)
        {
            bool BT = cardsActive("BT");
            if (BT == true)
            {
                oUserDAO.UpdateCCUsageToFalse("BT", false);
                oUserDAO.UpdateCConANDoff("B", "T", false);
            }
            else
            {
                oUserDAO.UpdateCCUsageToFalse("BT", true);
                oUserDAO.UpdateCConANDoff("B", "T", true);
            }


            Response.Redirect(Request.Url.AbsolutePath + "?reset");
        }
        protected void MT_Click(object sender, System.EventArgs e)
        {
            bool MT = cardsActive("MT");
            if (MT == true)
            {
                oUserDAO.UpdateCCUsageToFalse("MT", false);
                oUserDAO.UpdateCConANDoff("M", "T", false);
            }
            else
            {
                oUserDAO.UpdateCCUsageToFalse("MT", true);
                oUserDAO.UpdateCConANDoff("M", "T", true);
            }


            Response.Redirect(Request.Url.AbsolutePath + "?reset");
        }
        protected void NU_Click(object sender, System.EventArgs e)
        {
            bool NU = cardsActive("DB");
            if (NU == true)
            {
                oUserDAO.UpdateCCUsageToFalse("DB", false);
                oUserDAO.UpdateCConANDoff("D", "B", false);
            }
            else
            {
                oUserDAO.UpdateCCUsageToFalse("DB", true);
                oUserDAO.UpdateCConANDoff("D", "B", true);
            }


            Response.Redirect(Request.Url.AbsolutePath + "?reset");
        }
        //-------------------------------------------------------------------------------------------------------------------------------------------
        //CARD_Delete--------------------------------------------------------------------------------------------------------------------------------

        protected void deleteBC_Click(object sender, System.EventArgs e)
        {
            try
            {
                oUserDAO.DeleteCCsByName("B", "C");
                Response.Redirect(Request.Url.AbsolutePath + "?reset");
            }
            catch (Exception ex)
            {
                lbcc.Text = ex.Message;
            }
        }
        protected void deletePA_Click(object sender, System.EventArgs e)
        {
            try
            {

                oUserDAO.DeleteCCsByName("P", "A");
                Response.Redirect(Request.Url.AbsolutePath + "?reset");
            }
            catch (Exception ex)
            {
                lbcc.Text = ex.Message;
            }
        }
        protected void deleteMC_Click(object sender, System.EventArgs e)
        {
            try
            {
                oUserDAO.DeleteCCsByName("M", "C");
                Response.Redirect(Request.Url.AbsolutePath + "?reset");
            }
            catch (Exception ex)
            {
                lbcc.Text = ex.Message;
            }
        }
        protected void deleteMB_Click(object sender, System.EventArgs e)
        {
            try
            {
                oUserDAO.DeleteCCsByName("M", "B");
                Response.Redirect(Request.Url.AbsolutePath + "?reset");
            }
            catch (Exception ex)
            {
                lbcc.Text = ex.Message;
            }
        }
        protected void deleteBT_Click(object sender, System.EventArgs e)
        {
            try
            {
                oUserDAO.DeleteCCsByName("B", "T");
                Response.Redirect(Request.Url.AbsolutePath + "?reset");
            }
            catch (Exception ex)
            {
                lbcc.Text = ex.Message;
            }
        }
        protected void deleteMT_Click(object sender, System.EventArgs e)
        {
            try
            {
                oUserDAO.DeleteCCsByName("M", "T");
                Response.Redirect(Request.Url.AbsolutePath + "?reset");
            }
            catch (Exception ex)
            {
                lbcc.Text = ex.Message;
            }
        }
        protected void deleteNU_Click(object sender, System.EventArgs e)
        {
            try
            {
                oUserDAO.DeleteCCsByName("D", "B");
                Response.Redirect(Request.Url.AbsolutePath + "?reset");
            }
            catch (Exception ex)
            {
                lbcc.Text = ex.Message;
            }
        }
        protected void deleteFalse_Click(object sender, System.EventArgs e)
        {
            try
            {
                oUserDAO.DeleteCCsEqualToFalse();
                Response.Redirect(Request.Url.AbsolutePath + "?reset");
            }
            catch (Exception ex)
            {
                lbcc.Text = ex.Message;
            }
        }
        //-------------------------------------------------------------------------------------------------------------------------------------------
        protected void LogOut_Click(object sender, System.EventArgs e)
        {
            try
            {
                Session.Abandon();

                HttpCookie UserCookie = new HttpCookie("UserNameCookie");
                UserCookie.Expires = DateTime.Now.AddYears(-1);
                Response.Cookies.Add(UserCookie);
                Response.Redirect("login.aspx");
            }
            catch
            {
            }
        }

        //SQL SHORTCUTS------------------------------------------------------------------------------------------------------------------------------
        public string CCLeft()
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                cmd.CommandText = @"select count(used) from CC where active = 1 and SUBSTRING(FirstName, 1, 1) <> 'P' and SUBSTRING(LastName, 1, 1) <> 'A' and SUBSTRING(FirstName, 1, 1) <> 'D' and SUBSTRING(LastName, 1, 1) <> 'B'";
                string Count = cmd.ExecuteScalar().ToString();
                return Count;
            }
        }
        public string CCBoostLeft()
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                cmd.CommandText = @"select count(used) from CC where active = 1 and SUBSTRING(FirstName, 1, 1) = 'P' and SUBSTRING(LastName, 1, 1) = 'A'";
                string Count = cmd.ExecuteScalar().ToString();
                return Count;
            }
        }
        public string NUCCLeft()
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                cmd.CommandText = @"select (count(*) * 3) - sum(cast(used as int)) as hits from CCBackup where active = 1";
                string Count = cmd.ExecuteScalar().ToString();
                return Count;
            }
        }
        public string CCCricketLeft()
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                cmd.CommandText = @"select count(used) from CC where active = 1 and SUBSTRING(FirstName, 1, 1) = 'D' and SUBSTRING(LastName, 1, 1) = 'B'";
                string Count = cmd.ExecuteScalar().ToString();
                return Count;
            }
        }
        public string LastPost()
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                cmd.CommandText = @"select top(1) post from users order by CreatedDate desc";
                string Post = cmd.ExecuteScalar().ToString();
                return Post;
            }
        }
        public bool cardsActive(string ccname)
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                cmd.CommandText = @"select active from ccusage where ccname = '" + ccname + "'";
                bool Num = Convert.ToBoolean(cmd.ExecuteScalar());
                return Num;
            }
        }
        public string cardsLeft(string ccFirstname, string ccLastname)
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                cmd.CommandText = @"select count(*) from CC where active = 1 and SUBSTRING(FirstName, 1,1) = '" + ccFirstname + "' and SUBSTRING(LastName, 1,1) = '" + ccLastname + "'";
                string Num = cmd.ExecuteScalar().ToString();
                return Num;
            }
        }
        public string cardsLeftAll(string ccFirstname, string ccLastname)
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                cmd.CommandText = @"select count(*) from CC where SUBSTRING(FirstName, 1,1) = '" + ccFirstname + "' and SUBSTRING(LastName, 1,1) = '" + ccLastname + "'";
                string Num = cmd.ExecuteScalar().ToString();
                return Num;
            }
        }
        public string cardsLeftFalse()
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                cmd.CommandText = @"select count(*) from CC where active = 'False'";
                string Num = cmd.ExecuteScalar().ToString();
                return Num;
            }
        }
        public int getConf(string Provider)
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                cmd.CommandText = @"select top(1) substring(provider, CHARINDEX(':', provider, 1)+1, CHARINDEX(':', provider, 1)) from payments where provider like '%" + Provider + "%' order by CreatedDate desc";
                int Num = Convert.ToInt32(cmd.ExecuteScalar());
                return Num;
            }
        }
        protected void Go_Click(object sender, System.EventArgs e)
        {
            try
            {
                if (Request.Cookies["UserNameCookie"] == null)
                {
                    Response.Redirect("login.aspx");
                }
                DataTable dt = new DataTable();
                BindTransGrid(dt);
            }
            catch (Exception ex)
            {
                Response.Redirect("login.aspx");
            }
        }
        protected void ExportToExcel(object sender, EventArgs e)
        {
            try
            {
                Response.Clear();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment;filename=Telbug Credit Transactions Report-" + DateTime.Now + ".xls");
                Response.Charset = "";
                Response.ContentType = "application/vnd.ms-excel";
                using (StringWriter sw = new StringWriter())
                {
                    HtmlTextWriter hw = new HtmlTextWriter(sw);

                    //To Export all pages
                    gvTrans.AllowPaging = false;
                    DataTable dt = new DataTable();
                    this.BindTransGrid(dt);


                    gvTrans.HeaderRow.BackColor = Color.White;
                    foreach (TableCell cell in gvTrans.HeaderRow.Cells)
                    {

                        cell.BackColor = gvTrans.HeaderStyle.BackColor;
                    }
                    foreach (GridViewRow row in gvTrans.Rows)
                    {
                        gvTrans.HeaderRow.Cells[0].Visible = false;
                        row.Cells[0].Visible = false;

                        row.BackColor = Color.White;
                        foreach (TableCell cell in row.Cells)
                        {
                            if (row.RowIndex % 2 == 0)
                            {
                                cell.BackColor = gvTrans.AlternatingRowStyle.BackColor;
                            }
                            else
                            {
                                cell.BackColor = gvTrans.RowStyle.BackColor;
                            }
                            cell.CssClass = "textmode";
                        }
                    }

                    gvTrans.RenderControl(hw);

                    //style to format numbers to string
                    string style = @"<style> .textmode { } </style>";
                    Response.Write(style);
                    Response.Output.Write(sw.ToString());
                    Response.Flush();
                    Response.End();
                }
            }
            catch (Exception ex)
            {
                Label3.Text = ex.Message;
            }
        }

        public async void DPMobilePayment()
        {
            try
            {
                Payment oPay = new Payment();
                oPay = oUserDAO.RetrieveLastPayment(UserCookie.Value);
                User oDisUser = new User();
                User oFee = new User();
                oFee = oUserDAO.RetrieveFeebyUserID(UserCookie.Value);
                if (oPay.AmountPaid == 204 && oPay.CreatedDate.ToString("dd/MM/yyyy") == DateTime.Now.ToString("dd/MM/yyyy"))
                {
                    oDisUser = oUserDAO.DisableAccount(UserCookie.Value, false);
                }


                string phone = "";
                decimal totalamount = 0;
                decimal provideramount = 0;
                int offeringid = 0;
                if (txtDPAmount.Text == "")
                {
                    lbDPPayment.Text = "Need amount to continue";
                    return;
                }
                else if(txtDPNumber.Text == "")
                {
                    lbDPPayment.Text = "Need number to continue";
                    return;
                }
                else
                {
                    totalamount = decimal.Parse(txtDPAmount.Text) + Convert.ToInt32(oFee.Fee);
                    provideramount = decimal.Parse(txtDPAmount.Text);

                    Session["totalamount"] = totalamount;
                    Session["providerAmount"] = provideramount;
              
                    Session["provider"] = "MetroPCS";


                    phone = txtDPNumber.Text;
                    Session["phone"] = phone;
                    offeringid = Convert.ToInt32(Session["offeringid"]);
                }

                //mobile DP
                MobileTopUpType tu = new MobileTopUpType();
                TopUpResp tr;
                TransResponseType ts = new TransResponseType();


                using (PinManager pm = new PinManager())
                {
                    ServicePointManager.Expect100Continue = true;
                    ServicePointManager.DefaultConnectionLimit = 9999;
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12 | SecurityProtocolType.Ssl3;

                    pm.Credentials = new System.Net.NetworkCredential(ConfigurationManager.AppSettings["dpUser"], ConfigurationManager.AppSettings["dpPass"]);


                    tu.Ani = phone;
                    tu.OfferingId = offeringid;
                    tu.PhoneNumber = phone;
                    tu.Amount = Convert.ToDouble(provideramount);
                    



                    tr = pm.MobileTopup(tu);
                    ts = pm.TopupConfirm(Convert.ToInt32(tr.TransId));
                    if (ts.ErrorCode == -401)
                    {
                        Session["cc"] = "";
                        Session["conf"] = "";
                        Session["error"] = "error3";
                    }
                    else
                    {

                        if ((tr.TransId > 0))
                        {

                            DateTime start = DateTime.Now;
                            for (
                            ; ((ts.Status == TransactionStatus.Pending) && ((DateTime.Now - start).TotalSeconds <= 180));
                            )
                            {
                                System.Threading.Thread.Sleep(3000);
                                ts = pm.TopupConfirm(Convert.ToInt32(tr.TransId));
                            }
                            switch (ts.Status)
                            {

                                case TransactionStatus.Success:
                                    Session["conf"] = tr.TransId;
                                    Session["error"] = "";
                                    Session["cc"] = "6MJ26xFJGDeR5WNKLVU2MElxAq3lrfqJwpW9Ly8fLlEGl3/zUMrsfbyGVRonHF5G";
                                    break;
             
                                case TransactionStatus.Failed:
                                    if (ts.ErrorCode == -400)
                                    {
                                        Session["cc"] = "";
                                        Session["conf"] = "";
                                        Session["error"] = "error1";
                                        oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), "6MJ26xFJGDeR5WNKLVU2MElxAq3lrfqJwpW9Ly8fLlEGl3/zUMrsfbyGVRonHF5G", Session["provider"].ToString() + "($" + Session["provideramount"].ToString() + ") - " + ts.ErrorCode);
                                    }
                                    else if (ts.ErrorCode == -401)
                                    {
                                        if (Session["provider"].ToString() == "Ultra")
                                        {
                                            Session["error"] = "UltraError";
                                        }
                                        else
                                        {
                                            Session["error"] = "error18";
                                        }
                                        Session["cc"] = "";
                                        Session["conf"] = "";
                                        oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), "6MJ26xFJGDeR5WNKLVU2MElxAq3lrfqJwpW9Ly8fLlEGl3/zUMrsfbyGVRonHF5G", Session["provider"].ToString() + "($" + Session["provideramount"].ToString() + ") - " + ts.ErrorCode);
                                    }
                                    else if (ts.ErrorCode == -404 || ts.ErrorCode == -403)
                                    {
                                        Session["cc"] = "";
                                        Session["conf"] = "";
                                        Session["error"] = "errorFunds";
                                        oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), "6MJ26xFJGDeR5WNKLVU2MElxAq3lrfqJwpW9Ly8fLlEGl3/zUMrsfbyGVRonHF5G", Session["provider"].ToString() + "($" + Session["provideramount"].ToString() + ") - " + ts.ErrorCode);
                                    }
                                    else
                                    {
                                        Session["cc"] = "";
                                        Session["conf"] = "";
                                        Session["error"] = "error3";
                                        oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), "6MJ26xFJGDeR5WNKLVU2MElxAq3lrfqJwpW9Ly8fLlEGl3/zUMrsfbyGVRonHF5G", Session["provider"].ToString() + "($" + Session["provideramount"].ToString() + ") - " + ts.ErrorCode);
                                    }

                                    break;
                                case TransactionStatus.Pending:
                                    Session["cc"] = "";
                                    Session["conf"] = "";
                                    Session["error"] = "error3";
                                    oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), "6MJ26xFJGDeR5WNKLVU2MElxAq3lrfqJwpW9Ly8fLlEGl3/zUMrsfbyGVRonHF5G", Session["provider"].ToString() + "($" + Session["provideramount"].ToString() + ") - " + ts.ErrorCode);
                                    break;
                            }
                        }
                        else
                        {
                            if (tr.TransId == -404 || tr.TransId == -406)
                            {
                                Session["cc"] = "";
                                Session["conf"] = "";
                                Session["error"] = "error3";
                                oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), "6MJ26xFJGDeR5WNKLVU2MElxAq3lrfqJwpW9Ly8fLlEGl3/zUMrsfbyGVRonHF5G", Session["provider"].ToString() + "($" + Session["provideramount"].ToString() + ") - " + tr.TransId);
                            }
                            else
                            {
                                Session["cc"] = "";
                                Session["conf"] = "";
                                Session["error"] = "error3";
                                oUserDAO.LogError(UserCookie.Value, Session["Phone"].ToString(), "6MJ26xFJGDeR5WNKLVU2MElxAq3lrfqJwpW9Ly8fLlEGl3/zUMrsfbyGVRonHF5G", Session["provider"].ToString() + "($" + Session["provideramount"].ToString() + ") - " + tr.TransId);
                            }
                        }
                    }



                }


              
                if (Session["conf"].ToString().Length >= 7)
                {
                    string conf = Session["conf"].ToString();
                    Session["error"] = "";
                    lbDPPayment.ForeColor = Color.Green;
                    lbDPPayment.Text = "Payment made, conf: " + conf;
                }
                if (Session["error"].ToString().Contains("error") || Session["error"].ToString().Contains("UltraError"))
                {
                    lbDPPayment.Text = "No payment made";
                }

            }
            catch (Exception ex)
            {
               // ScriptManager.RegisterStartupScript(this, typeof(string), "Alert", "alert('" + ddProviders.SelectedItem.Text + " is expiriencing technical difficulties, please call 561-860-5276');", true);
                lbDPPayment.Text = "Send to DP is fucked up, call braley";
                lbDPPayment.ForeColor = Color.Red;
            }
        }
        public override void VerifyRenderingInServerForm(Control control)
        {
            /* Verifies that the control is rendered */
        }
    }
}