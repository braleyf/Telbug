﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net.Mail;
using System.Configuration;
using System.Web.UI.HtmlControls;
using System.Drawing;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using System.Net;
using MetroFastPayLibrary;
using System.Text;
using System.Security.Cryptography;
using System.Web.Script.Serialization;
using System.Web.Script.Services;
using RestSharp;
using MetroFastPay.com.dollarphone.www;
using System.Net.Http;
using System.Net.Http.Headers;
using Newtonsoft.Json;

namespace MetroFastPay
{
    public partial class Splash : System.Web.UI.Page
    {
        User oUser = new User();
        UserDAO oUserDAO = new UserDAO();
        System.Web.HttpCookie UserCookie = HttpContext.Current.Request.Cookies["UserNameCookie"];
        protected void Page_Load(object sender, EventArgs e)
        {
            if (UserCookie.Value == "FastPay Online")
            {
                btnLeave.PostBackUrl = "~/FastPayOnline.aspx";
            }
            else
            {
                btnLeave.PostBackUrl = "~/fastpay.aspx";
            }
                if (Request.Cookies["UserNameCookie"] == null)
            {
                //Session.Abandon();
                //UserCookie.Expires = DateTime.Now.AddYears(-1);
                //Response.Cookies.Add(UserCookie);
                Response.Redirect("out.aspx");

            }
            else
            {

                try
                {
                    if (UserCookie.Value == "")
                    {
                        Response.Redirect("login.aspx");
                    }
                    else
                    {
                        oUser = oUserDAO.RetrieveUserByUserID(UserCookie.Value);
                    }

                    if (Request.QueryString["error"].ToString() == "error1")
                    {
                        lbPayConf.Text = "Not a " + Request.QueryString["provider"].ToString() + " number  <br/> Numero no es de " + Request.QueryString["provider"].ToString();
                        pConfpay.Style["display"] = "none";
                        pPaymntFailed.Style["display"] = "block";
                        btnText.Visible = false;
                    }
                    else if (Request.QueryString["error"].ToString() == "error2")
                    {
                        lbPayConf.Text = "Number has been paid too many times <br/> Este numero se a pagado varias veces";
                        pConfpay.Style["display"] = "none";
                        pPaymntFailed.Style["display"] = "block";
                        btnText.Visible = false;
                    }
                    else if (Request.QueryString["error"].ToString() == "error3")
                    {
                        lbPayConf.Text = "Payent was not proccessed, please try again <br />  Error al anadir un metodo de pago, traté de nuevo ";
                        pConfpay.Style["display"] = "none";
                        pPaymntFailed.Style["display"] = "block";
                        btnText.Visible = false;
                    }
                    else if (Request.QueryString["error"].ToString() == "error4")
                    {
                        lbPayConf.Text = "This number cannot be paid using our system. Sorry for the inconvenience <br />  Este numero no se puede pagar por este systema ";
                        pConfpay.Style["display"] = "none";
                        pPaymntFailed.Style["display"] = "block";
                        btnText.Visible = false;
                    }
                    else if (Request.QueryString["error"].ToString() == "error5")
                    {
                        lbPayConf.Text = "Payment cannot be proccessed at this time, please try back in 15 minutes<br />  Error al anadir un metodo de pago, trate en 15 minutos<br /> Call 561-860-5276";
                        pConfpay.Style["display"] = "none";
                        pPaymntFailed.Style["display"] = "block";
                        btnText.Visible = false;
                    }
                    else if (Request.QueryString["error"].ToString() == "error6")
                    {
                        lbPayConf.Text = "This number is cancelled and connot be paid<br /> Numero esta desconnectado Y no se puede pagar";
                        pConfpay.Style["display"] = "none";
                        pPaymntFailed.Style["display"] = "block";
                        btnText.Visible = false;
                    }
                    else if (Request.QueryString["error"].ToString() == "error99")
                    {
                        lbPayConf.Text = "MetroPCS down, call 561-860-7276 for assitants and do not reattempt payment. <br /> Error al anadir un metodo de pago, llame al 561-860-5276 y no reintente el pago nuevamente.";
                        pConfpay.Style["display"] = "none";
                        pPaymntFailed.Style["display"] = "block";
                        btnText.Visible = false;
                    }
                    else if (Request.QueryString["error"].ToString() == "errordown")
                    {
                        lbPayConf.Text = "Please call 561-860-5276 for payments processed manually </br> Por favor llame al 561-860-5276 para que el pago sea procesado ";
                        pConfpay.Style["display"] = "none";
                        pPaymntFailed.Style["display"] = "block";
                        btnText.Visible = false;
                    }
                    else if (Request.QueryString["error"].ToString() == "errorFunds")
                    {
                        lbPayConf.Text = "Incorrect amount/ Cantidad incorrecta";
                        pConfpay.Style["display"] = "none";
                        pPaymntFailed.Style["display"] = "block";
                        btnText.Visible = false;
                    }
                    else if (Request.QueryString["error"].ToString() == "errorLockedAccount")
                    {
                        lbPayConf.Text = "This account is locked <br /> Esta cuenta esta bloqueada";
                        pConfpay.Style["display"] = "none";
                        pPaymntFailed.Style["display"] = "block";
                        btnText.Visible = false;
                    }
                    else if (Request.QueryString["error"].ToString() == "errorDup")
                    {
                        lbPayConf.Text = "This is a duplicate payment <br/> Este es un pago duplicado";
                        pConfpay.Style["display"] = "none";
                        pPaymntFailed.Style["display"] = "block";
                        btnText.Visible = false;
                    }
                    else if (Request.QueryString["error"].ToString() == "errorPin")
                    {
                        btnSendPin.Visible = false;
                        lbPayConf.Text = "Incorrect PIN or Number <br/> PIN o Numero Esta Incorrecto <br />";
                        pConfpay.Style["display"] = "none";
                        pPaymntFailed.Style["display"] = "block";
                        btnText.Visible = false;
                    }
                    else if (Request.QueryString["error"].ToString() == "errorLockBoost")
                    {
                        lbPayConf.Text = "Your account has been locked. Please try again in 1 hour<br/> Su cuenta ha sido bloqueada. Por favor intente de nuevo en 1 hora";
                        pConfpay.Style["display"] = "none";
                        pPaymntFailed.Style["display"] = "block";
                        btnText.Visible = false;
                        btnSendPin.Visible = false;
                    }
                    else if (Request.QueryString["error"].ToString() == "errorLockBoost2")
                    {
                        lbPayConf.Text = "Your account has been locked. Please try again in 24 hour<br/> Su cuenta ha sido bloqueada. Por favor intente de nuevo en 24 hora";
                        pConfpay.Style["display"] = "none";
                        pPaymntFailed.Style["display"] = "block";
                        btnText.Visible = false;
                    }
                    else if (Request.QueryString["error"].ToString() == "error18")
                    {
                        lbPayConf.Text = "Payment cannot be proccessed at this time <br /> El pago no puede ser procesado en este momento";
                        pConfpay.Style["display"] = "none";
                        pPaymntFailed.Style["display"] = "block";
                        btnText.Visible = false;
                    }
                    else if (Request.QueryString["error"].ToString() == "UltraError")
                    {
                        lbPayConf.Text = "Amount entered is incorrect, please add a dollar and try again <br /> La cantidad ingresada es incorrecta, agregue un dólar y intente nuevamente";
                        pConfpay.Style["display"] = "none";
                        pPaymntFailed.Style["display"] = "block";
                        btnText.Visible = false;
                    }
                    else if (Request.QueryString["error"].ToString() != "")
                    {
                        lbPayConf.Text = "Payment was not proccessed <br />" + Request.QueryString["error"].ToString() + "<br /> Error al anadir un metodo de pago";
                        pConfpay.Style["display"] = "none";
                        pPaymntFailed.Style["display"] = "block";
                        btnText.Visible = false;
                    }
                    else
                    {
                        oUser = this.oUserDAO.RetrieveFeebyUserID(this.UserCookie.Value);
                        if(Request.QueryString["provider"].ToString() == "Liberty")
                        {
                            lbconf.Text = Request.QueryString["conf"].ToString() + "<br /> PIN: " + Request.QueryString["PIN"].ToString();
                        }
                        else
                        {
                            lbconf.Text = Request.QueryString["conf"].ToString();
                        }
                        
                        lbDatePaid.Text = Request.QueryString["datepaid"].ToString();
                        lbAmountPaid.Text = Request.QueryString["providerAmount"].ToString();
                        if (base.Request.QueryString["provider"].ToString() == "MetroPCS" || base.Request.QueryString["provider"].ToString() == "Boost" || base.Request.QueryString["provider"].ToString() == "Cricket")
                        {
                            lbFee.Text = string.Concat(oUser.Fee, ".00");
                        }
                        else
                        {
                            lbFee.Text = "0.00";
                        }
                        lbProvider.Text = Request.QueryString["provider"].ToString();
                        lbPhone.Text = Request.QueryString["phone"].ToString();
                        lbPayConf.Text = "completed!";

                        if (Request.QueryString["provider"].ToString() == "SinPin" || Request.QueryString["provider"].ToString() == "DollarPhone" || Request.QueryString["provider"].ToString() == "GuatePin")
                        {
                            decimal totalbalance = 0;
                            if (Request.QueryString["PrevBalance"] != "")
                            {
                                totalbalance = Convert.ToDecimal(Request.QueryString["Balance"]) + Convert.ToDecimal(Request.QueryString["PrevBalance"]);
                            }
                            else
                            {
                                totalbalance = Convert.ToDecimal(Request.QueryString["Balance"]);
                            }
                            btnVoid.Visible = true;
                            lbconf.Text = Request.QueryString["conf"].ToString() + "<br /> English Access Number: " + Request.QueryString["EnglishNumber"].ToString() + "<br /> Spanish Access Number: " + Request.QueryString["SpanishNumber"].ToString() + "<br /> Balance: " + totalbalance.ToString();
                            lbDatePaid.Text = Request.QueryString["datepaid"].ToString();
                            lbAmountPaid.Text = Request.QueryString["providerAmount"].ToString();
                            lbProvider.Text = Request.QueryString["provider"].ToString();
                            lbPhone.Text = Request.QueryString["phone"].ToString();
                            lbPayConf.Text = "completed!";
                            if (Request.Url.ToString().Contains("Refund"))
                            {
                                lbRefund.Text = "Balance: $" + Convert.ToDecimal(Request.QueryString["Refund"].ToString());
                                btnVoid.Enabled = false;
                            }

                        }
                    }

                    if (Request.QueryString["error"].ToString().Contains("CreditError"))
                    {
                        lbPayConf.Text = "Insufficient credit, please add more money to your account <br /> Su cuenta no tiene suficiente dinero";
                        pConfpay.Style["display"] = "none";
                        btnText.Visible = false;
                    }

                    Session["error"] = "";
                    Session["conf"] = "";

                    Response.Cache.SetExpires(DateTime.Now);
                }
                catch (Exception ex)
                {

                    lbconf.Text = Request.QueryString["conf"].ToString();
                    lbDatePaid.Text = Request.QueryString["datepaid"].ToString();
                    lbAmountPaid.Text = Request.QueryString["providerAmount"].ToString();
                    lbProvider.Text = Request.QueryString["provider"].ToString();
                    lbPhone.Text = Request.QueryString["phone"].ToString();
                    lbPayConf.Text = "completed!";
                }
            }
        }


        protected void Void_Click(object sender, System.EventArgs e)
        {
            Payment oPay = new Payment();
            oPay = oUserDAO.RetrieveLastPayment(UserCookie.Value);
            User getComm = oUserDAO.RetrieveServiceActivity(5);
            //update credit line
            MetroFastPayLibrary.Account oAccount = new MetroFastPayLibrary.Account();
            oAccount = oUserDAO.RetrieveAccount(UserCookie.Value);

            if (Request.QueryString["provider"].ToString().Contains("DollarPhone") || Request.QueryString["provider"].ToString().Contains("GuatePin"))
            {
                TransResponseType ts = new TransResponseType();
                ActivateOrRechargeAccountType af = new ActivateOrRechargeAccountType();
                AccountInfo ai = new AccountInfo();

                using (PinManager pm = new PinManager())
                {
                    pm.Credentials = new System.Net.NetworkCredential(ConfigurationManager.AppSettings["dpUser"], ConfigurationManager.AppSettings["dpPass"]);

                    af.Account = ai;
                    af.Account.Ani = oPay.PhoneNumber;
                    if (Request.QueryString["provider"].ToString().Contains("GuatePin"))
                    {
                        getComm = oUserDAO.RetrieveServiceActivity(33);
                        af.Account.OfferingId = 30178480;
                    }
                    else
                    {
                        getComm = oUserDAO.RetrieveServiceActivity(5);
                        af.Account.OfferingId = 30030280;
                    }

                    af.Account.Balance = -oPay.AmountPaid;



                    ai = pm.ActivateOrRechargeAccount(af);


                    if ((ai.TransId > 0))
                    {

                        DateTime start = DateTime.Now;
                        for (
                        ; ((ts.Status == TransactionStatus.Pending) && ((DateTime.Now - start).TotalSeconds <= 180));
                        )
                        {
                            System.Threading.Thread.Sleep(3000);
                            ts = pm.TopupConfirm(Convert.ToInt32(ai.TransId));
                        }
                        switch (ts.Status)
                        {

                            case TransactionStatus.Success:

                                //update credit line
                                oAccount = oUserDAO.RetrieveAccount(UserCookie.Value);

                                string dpBalance = pm.GetAccountInfoByAniOffering(oPay.PhoneNumber, getComm.OfferingID).Balance.ToString();
                                decimal refundBalance = Convert.ToDecimal(dpBalance) - Convert.ToDecimal(Request.QueryString["providerAmount"]);
                                Response.Redirect(Request.Url.ToString() + "&Refund=" + refundBalance, false);

                                if (oAccount.Active == true)
                                {
                                    decimal DPamount = Convert.ToDecimal(-oPay.AmountPaid) * Convert.ToDecimal(getComm.UserCommission);
                                    oUserDAO.UpdateAccountbyPost(oAccount.Credit - (Convert.ToDecimal(-oPay.AmountPaid) - DPamount), oPay.Post);
                                }

                                break;
                            case TransactionStatus.Failed:
                                lbRefund.Text = "Error: Refund has failed/ reembolso ha fallado";
                                break;
                            case TransactionStatus.Pending:
                                break;
                        }
                    }
                }
            }
            else
            {
                System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                string url = "https://webservice.sinpin.com/Agent/VoidRecharge/?Username=fandf.webapi&Password=Marcos2168!PB_561*!&apiKey=9e8roNDqY4Ssx6A607TxwYoJI0y246Ph&audit_id=" + Request.QueryString["conf"].ToString();
                var client = new RestClient(url);
                var request = new RestRequest(Method.POST);
                IRestResponse response = client.Execute(request);


                if (response.Content.Contains("Success"))
                {
                    string resultsMessage = getBetween(response.Content, "subscriber_balance\":", "}");
                    Response.Redirect(Request.Url.ToString() + "&Refund=" + string.Format("{0:0.00}", resultsMessage), false);

                    if (oAccount.Active == true)
                    {
                        decimal SinPinamount = Convert.ToDecimal(Request.QueryString["providerAmount"].ToString()) * Convert.ToDecimal(.22);
                        oUserDAO.UpdateAccountbyPost(oAccount.Credit + Convert.ToDecimal(Request.QueryString["providerAmount"].ToString()) - SinPinamount, oPay.Post);
                    }
                }
                else
                {
                    lbRefund.Text = "Error: Refund has failed/ reembolso ha fallado";
                }
            }
            DataTable dt = new DataTable();
            //oUserDAO.DeletePayment(Convert.ToInt32(oPay.ID));
            oUserDAO.InsertPayments(oPay.UserID, oPay.Post, oPay.PhoneNumber, -oPay.AmountPaid, -oPay.Fee, oPay.Provider, oPay.CCNumberUsed, DateTime.Now);
        }

        public static string getBetween(string strSource, string strStart, string strEnd)
        {
            int Start, End;
            if (strSource.Contains(strStart) && strSource.Contains(strEnd))
            {
                Start = strSource.IndexOf(strStart, 0) + strStart.Length;
                End = strSource.IndexOf(strEnd, Start);
                return strSource.Substring(Start, End - Start);
            }
            else
            {
                return "";
            }
        }

        protected async void SendPin_Click(object sender, System.EventArgs e)
        {
            try
            {
                HttpClient _Client = new HttpClient();
                _Client = new HttpClient();
                _Client.DefaultRequestHeaders.Accept.Clear();
                _Client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                SinPinBalance.RetievePin data = new SinPinBalance.RetievePin();

                var myContent = JsonConvert.SerializeObject(data);
                var buffer = System.Text.Encoding.UTF8.GetBytes(myContent);
                var byteContent = new ByteArrayContent(buffer);
                byteContent.Headers.Add("Content-Type", "application/json");
                byteContent.Headers.Add("applicationId", "OWO");
                byteContent.Headers.Add("consumerId", " ");
                byteContent.Headers.Add("messageId", "sjmyY7Qe");
                byteContent.Headers.Add("enterpriseMessageId", " ");
                byteContent.Headers.Add("conversationId", "PROD");
                byteContent.Headers.Add("brandCode", "BST");
                byteContent.Headers.Add("messageDateTimeStamp", string.Format("{0:yyyy-MM-ddTHH:mm:ssZ}", DateTime.Now));

                var response = await _Client.PostAsync("https://aka-apiservices.boostmobile.com/api/prepaid/1.0/accounts/" + Request.QueryString["Phone"].ToString() + "/retrievepin?idField=mdn", byteContent);
                HttpContent content = response.Content;
                string mycontent3 = await content.ReadAsStringAsync();
                if (response.IsSuccessStatusCode)
                {
                    string s = response.Content.ReadAsStringAsync().Result;


                    if (s.Contains("SUCCESS"))
                    {
                        lbPIN.ForeColor = System.Drawing.Color.Green;
                        lbPIN.Text = "Text sent to customer | Texto enviado al cliente";

                    }
                    else
                    {
                        lbPIN.ForeColor = System.Drawing.Color.Red;
                        lbPIN.Text = "Number is not correct | El número no es correcto";
                    }

                }
                else
                {
                    lbPIN.ForeColor = System.Drawing.Color.Red;
                    lbPIN.Text = "Number is not correct | El número no es correcto";
                }
                }

                catch (Exception ex)
                {

                    Response.Redirect("Error.aspx");
                }
            }
        }
       
}
