﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net.Mail;
using System.Configuration;
using System.Web.UI.HtmlControls;
using System.Drawing;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using System.Net;
using MetroFastPayLibrary;
using System.Text;
using System.Security.Cryptography;
using System.Data.OleDb;
using RestSharp;
using MetroFastPay.com.dollarphone.www;

namespace MetroFastPay
{
    public partial class Report : System.Web.UI.Page
    {
        User oUser = new User();
        UserDAO oUserDAO = new UserDAO();
        string dbCon = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();

        System.Web.HttpCookie UserCookie = HttpContext.Current.Request.Cookies["UserNameCookie"];
        protected void Page_Load(object sender, EventArgs e)
        {

            if (Request.Cookies["UserNameCookie"] == null)
            {
                //Session.Abandon();
                //UserCookie.Expires = DateTime.Now.AddYears(-1);
                //Response.Cookies.Add(UserCookie);
                Response.Redirect("out.aspx");

            }
            else
            {
                try
                {
                    MetroFastPayLibrary.Account oAccount = new MetroFastPayLibrary.Account();
                    oAccount = oUserDAO.RetrieveAccount(UserCookie.Value);
                    DataTable dt = new DataTable();
                    if (oAccount.Active == true)
                    {
                        lbPayment.Visible = false;
                        lbAccount.Visible = true;
                        oAccount = oUserDAO.RetrieveAccount(UserCookie.Value);
                        lbCredit.Text = "| Balance: $" + string.Format("{0:0.00}", oAccount.Credit);
                    }
                    //admin rights
                    oUser = oUserDAO.RetrieveUserByUserID(UserCookie.Value);
                    lbUser.Text = oUser.FullName;
                    btnExcel.Enabled = true;
                    if (oUser.UserType == "Admin")
                    {
                        ddUser.Visible = true;
                        ddPost.Visible = true;
                        ddProvider.Visible = true;
                        lbControlPanel.Visible = true;
                    }
                    else
                    {
                        ddUser.Visible = true;
                        ddPost.Visible = true;
                        ddProvider.Visible = true;
                        // filterby.Attributes.Add("style", "display:none");

                        BindGrid(dt, oUser.UserID);
                    }

                    if (oUser.UserType == "Viewer")
                    {
                        filterby.Attributes.Add("style", "display:block");
                        // ddUser.Visible = true;
                        dsUser.SelectCommand = "select p.UserID from Users p inner join Dealer a ON p.Post = a.UserPost where a.UserID = '" + UserCookie.Value + "' and p.Active = 'True' order by userid asc";
                    }

                    if (oUser.UserType == "User")
                    {
                        // filterby.Attributes.Add("style", "display:block");
                        // ddUser.Visible = true;
                        dsUser.SelectCommand = "select UserID from Users where Post = '" + oUser.Post + "' and Active = 'True' order by userid asc";
                        dsPost.SelectCommand = "select post from users where post = '" + oUser.Post + "' and Active = 'True'";
                    }


                }
                catch (Exception ex)
                {
                    Response.Redirect("login.aspx");
                }
            }

        }
        protected void Go_Click(object sender, System.EventArgs e)
        {
            try
            {
                if (Request.Cookies["UserNameCookie"] == null)
                {
                    Response.Redirect("login.aspx");
                }
                DataTable dt = new DataTable();
                BindGrid(dt, oUser.UserID);
            }
            catch (Exception ex)
            {
                //Response.Redirect("login.aspx");

                lbInfo.Text = ex.Message;

            }
        }
        protected void Reset_Click(object sender, System.EventArgs e)
        {
            ddUser.SelectedIndex = 0;
            ddUser.Enabled = true;
            ddPost.SelectedIndex = 0;
            ddPost.Enabled = true;
            ddProvider.SelectedIndex = 0;
            ddProvider.Enabled = true;
            txtFrom.Text = "";
            txtTo.Text = "";
            DataTable dt = new DataTable();
            BindGrid(dt, "");
        }
        protected void cboUserFilter_OnSelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (Request.Cookies["UserNameCookie"] == null)
                {
                    Response.Redirect("login.aspx");
                }

                DataTable dt = new DataTable();
                BindGrid(dt, ddUser.SelectedItem.Value);
            }
            catch (Exception ex)
            {
                Response.Redirect("login.aspx");
            }
        }
        protected void cboPostFilter_OnSelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (Request.Cookies["UserNameCookie"] == null)
                {
                    Response.Redirect("login.aspx");
                }
                ddUser.Enabled = false;
                DataTable dt = new DataTable();
                BindGrid(dt, ddPost.SelectedItem.Value);
            }
            catch (Exception ex)
            {
                Response.Redirect("login.aspx");
            }
        }
        protected void cboProviderFilter_OnSelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (Request.Cookies["UserNameCookie"] == null)
                {
                    Response.Redirect("login.aspx");
                }

                DataTable dt = new DataTable();

                BindGrid(dt, ddProvider.SelectedItem.Value);
            }
            catch (Exception ex)
            {
                Response.Redirect("login.aspx");
            }
        }
        private void BindGrid(DataTable dt, string user)
        {
            DateTime dateTime;
            decimal cardcom;
            if (base.IsPostBack)
            {
                DataTable dataTable = new DataTable();
                List<Payment> aList = new List<Payment>();
                aList = new List<Payment>();
                DataTable table = this.oUserDAO.Services();
                if (this.txtFrom.Text.Length > 0 && this.txtTo.Text.Length > 0 && this.ddUser.SelectedItem.Value != "" && (this.oUser.UserType == "Admin" || this.oUser.UserType == "Viewer" || this.oUser.UserType == "User"))
                {
                    dateTime = Convert.ToDateTime(this.txtFrom.Text);
                    dateTime = dateTime.Date;
                    string date1 = dateTime.ToString("yyyy/MM/dd");
                    dateTime = Convert.ToDateTime(this.txtTo.Text);
                    dateTime = dateTime.Date;
                    string date2 = dateTime.ToString("yyyy/MM/dd");
                    aList = this.oUserDAO.PopulateReportbydate(this.ddUser.SelectedItem.Value, date1, date2);
                }
                if (this.txtFrom.Text.Length > 0 && this.txtTo.Text.Length > 0 && this.ddPost.SelectedItem.Value != "" && this.oUser.UserType == "Admin")
                {
                    dateTime = Convert.ToDateTime(this.txtFrom.Text);
                    dateTime = dateTime.Date;
                    string date1 = dateTime.ToString("yyyy/MM/dd");
                    dateTime = Convert.ToDateTime(this.txtTo.Text);
                    dateTime = dateTime.Date;
                    string date2 = dateTime.ToString("yyyy/MM/dd");
                    aList = this.oUserDAO.PopulateReportbyPostandDate(this.ddPost.SelectedItem.Value, date1, date2);
                }
                if (this.txtFrom.Text.Length > 0 && this.txtTo.Text.Length > 0 && this.ddProvider.SelectedItem.Value != "" && this.oUser.UserType == "Admin")
                {
                    dateTime = Convert.ToDateTime(this.txtFrom.Text);
                    dateTime = dateTime.Date;
                    string date1 = dateTime.ToString("yyyy/MM/dd");
                    dateTime = Convert.ToDateTime(this.txtTo.Text);
                    dateTime = dateTime.Date;
                    string date2 = dateTime.ToString("yyyy/MM/dd");
                    aList = this.oUserDAO.PopulateReportbyProviderandDate(this.ddProvider.SelectedItem.Text, date1, date2);
                }
                if (this.txtFrom.Text.Length > 0 && this.txtTo.Text.Length > 0 && this.ddUser.SelectedItem.Value != "" && this.ddProvider.SelectedItem.Value != "" && this.oUser.UserType == "User")
                {
                    dateTime = Convert.ToDateTime(this.txtFrom.Text);
                    dateTime = dateTime.Date;
                    string date1 = dateTime.ToString("yyyy/MM/dd");
                    dateTime = Convert.ToDateTime(this.txtTo.Text);
                    dateTime = dateTime.Date;
                    string date2 = dateTime.ToString("yyyy/MM/dd");
                    aList = this.oUserDAO.PopulateReportbyUserandProvider(date1, date2, this.ddUser.SelectedItem.Text, this.ddProvider.SelectedItem.Text);
                }
                if (this.txtFrom.Text.Length > 0 && this.txtTo.Text.Length > 0 && this.ddUser.SelectedItem.Value == "" && this.oUser.UserType == "User")
                {
                    dateTime = Convert.ToDateTime(this.txtFrom.Text);
                    dateTime = dateTime.Date;
                    string date1 = dateTime.ToString("yyyy/MM/dd");
                    dateTime = Convert.ToDateTime(this.txtTo.Text);
                    dateTime = dateTime.Date;
                    string date2 = dateTime.ToString("yyyy/MM/dd");
                    aList = this.oUserDAO.PopulateReportbyPostandDate(this.oUser.Post, date1, date2);
                }
                if (this.ddProvider.SelectedItem.Value != "" && this.ddUser.SelectedItem.Value == "" && this.oUser.UserType == "User")
                {
                    dateTime = Convert.ToDateTime(this.txtFrom.Text);
                    dateTime = dateTime.Date;
                    string date1 = dateTime.ToString("yyyy/MM/dd");
                    dateTime = Convert.ToDateTime(this.txtTo.Text);
                    dateTime = dateTime.Date;
                    string date2 = dateTime.ToString("yyyy/MM/dd");
                    aList = this.oUserDAO.PopulateReportbyUserbyProviderandDate(this.ddProvider.SelectedItem.Text, date1, date2, this.oUser.Post);
                }
                if (this.txtFrom.Text.Length > 0 && this.txtTo.Text.Length > 0 && this.ddUser.SelectedItem.Value == "" && this.ddPost.SelectedItem.Value == "" && this.ddProvider.SelectedItem.Value == "" && this.oUser.UserType == "Admin")
                {
                    dateTime = Convert.ToDateTime(this.txtFrom.Text);
                    dateTime = dateTime.Date;
                    string date1 = dateTime.ToString("yyyy/MM/dd");
                    dateTime = Convert.ToDateTime(this.txtTo.Text);
                    dateTime = dateTime.Date;
                    string date2 = dateTime.ToString("yyyy/MM/dd");
                    aList = this.oUserDAO.PopulateReportbydateAll(date1, date2);
                }
                else if (this.txtFrom.Text.Length > 0 && this.txtTo.Text.Length > 0 && this.ddUser.SelectedItem.Value != "" && this.ddProvider.SelectedItem.Value != "" && this.oUser.UserType == "Admin")
                {
                    dateTime = Convert.ToDateTime(this.txtFrom.Text);
                    dateTime = dateTime.Date;
                    string date1 = dateTime.ToString("yyyy/MM/dd");
                    dateTime = Convert.ToDateTime(this.txtTo.Text);
                    dateTime = dateTime.Date;
                    string date2 = dateTime.ToString("yyyy/MM/dd");
                    aList = this.oUserDAO.PopulateReportbyUserandProvider(date1, date2, this.ddUser.SelectedItem.Text, this.ddProvider.SelectedItem.Text);
                }
                else if (this.txtFrom.Text.Length > 0 && this.txtTo.Text.Length > 0 && this.ddPost.SelectedItem.Value != "" && this.ddProvider.SelectedItem.Value != "" && this.oUser.UserType == "Admin")
                {
                    dateTime = Convert.ToDateTime(this.txtFrom.Text);
                    dateTime = dateTime.Date;
                    string date1 = dateTime.ToString("yyyy/MM/dd");
                    dateTime = Convert.ToDateTime(this.txtTo.Text);
                    dateTime = dateTime.Date;
                    string date2 = dateTime.ToString("yyyy/MM/dd");
                    aList = this.oUserDAO.PopulateReportbyPostandProvider(date1, date2, this.ddPost.SelectedItem.Text, this.ddProvider.SelectedItem.Text);
                }
                else if (this.txtFrom.Text.Length == 0 && this.txtTo.Text.Length == 0 && (this.ddUser.SelectedItem.Value == "" || this.ddPost.SelectedItem.Value == "" || this.ddProvider.SelectedItem.Value == ""))
                {
                    this.lbInfo.Text = "Select dates to see data";
                }
                else if (this.txtFrom.Text.Length == 0 && this.txtTo.Text.Length == 0 && (this.ddUser.SelectedItem.Value != "" && this.ddPost.SelectedItem.Value != "" || this.ddProvider.SelectedItem.Value == ""))
                {
                    dateTime = Convert.ToDateTime(this.txtFrom.Text);
                    dateTime = dateTime.Date;
                    string date1 = dateTime.ToString("yyyy/MM/dd");
                    dateTime = Convert.ToDateTime(this.txtTo.Text);
                    dateTime = dateTime.Date;
                    string date2 = dateTime.ToString("yyyy/MM/dd");
                    aList = this.oUserDAO.PopulateReportbyPostandDate(this.ddPost.SelectedItem.Value, date1, date2);
                }
                if (this.txtFrom.Text.Length > 0 && this.txtTo.Text.Length > 0 && this.oUser.UserType == "Viewer" && this.ddUser.SelectedItem.Value == "")
                {
                    dateTime = Convert.ToDateTime(this.txtFrom.Text);
                    dateTime = dateTime.Date;
                    string date1 = dateTime.ToString("yyyy/MM/dd");
                    dateTime = Convert.ToDateTime(this.txtTo.Text);
                    dateTime = dateTime.Date;
                    string date2 = dateTime.ToString("yyyy/MM/dd");
                    aList = this.oUserDAO.PopulateDealerView(user, date1, date2);
                }
                DataTable dataTable1 = new DataTable();
                dt.Columns.AddRange(new DataColumn[] { new DataColumn("ID"), new DataColumn("Post"), new DataColumn("UserID"), new DataColumn("Provider"), new DataColumn("Client#"), new DataColumn("Conf#"), new DataColumn("Code"), new DataColumn("Payment"), new DataColumn("Fees"), new DataColumn("Total"), new DataColumn("Comm."), new DataColumn("Rewards"), new DataColumn("Date Paid") });
                foreach (Payment oPayment in aList)
                {
                    User user1 = new User();
                    this.oUserDAO.RetrieveFeebyUserID(oPayment.UserID);
                    string cardnum = DAO.Decrypt(oPayment.CCNumberUsed.Trim(), ConfigurationManager.AppSettings["encryptionKey"]).Remove(1, 15);
                    User metro = this.oUserDAO.RetrieveServiceActivity(1, oPayment.UserID, "");
                    if (this.oUser.UserType != "Admin")
                    {
                        dt.Rows.Add(new object[] { oPayment.ID, oPayment.Post, oPayment.UserID, oPayment.Provider.Substring(0, oPayment.Provider.LastIndexOf(" -") + 1).Trim(), oPayment.PhoneNumber, oPayment.Provider.Substring(oPayment.Provider.LastIndexOf(':') + 1), DAO.Decrypt(oPayment.CCNumberUsed.Trim(), ConfigurationManager.AppSettings["encryptionKey"]).Remove(0, 12), string.Format("{0:0.00}", Convert.ToDecimal(oPayment.AmountPaid)), string.Format("{0:0.00}", Convert.ToDecimal(oPayment.Fee)), string.Format("{0:0.00}", Convert.ToDecimal(oPayment.AmountPaid) + Convert.ToDecimal(oPayment.Fee)), string.Format("{0:0.00}", Convert.ToDecimal(oPayment.Fee) - Convert.ToDecimal(2)), string.Format("{0:0.00}", 0), oPayment.CreatedDate });
                    }
                    else
                    {
                        if (oPayment.Fee == decimal.Zero)
                        {
                            metro.UserCommission = new decimal();
                        }
                        if (cardnum == "5" && (oPayment.Provider.Substring(0, oPayment.Provider.LastIndexOf(" -") + 1).Trim() == "MetroPCS" || oPayment.Provider.Substring(0, oPayment.Provider.LastIndexOf(" -") + 1).Trim() == "Boost" || oPayment.Provider.Substring(0, oPayment.Provider.LastIndexOf(" -") + 1).Trim() == "Cricket"))
                        {
                            cardcom = Convert.ToDecimal(oPayment.AmountPaid) * Convert.ToDecimal(0.02);
                            dt.Rows.Add(new object[] { oPayment.ID, oPayment.Post, oPayment.UserID, oPayment.Provider.Substring(0, oPayment.Provider.LastIndexOf(" -") + 1).Trim(), oPayment.PhoneNumber, oPayment.Provider.Substring(oPayment.Provider.LastIndexOf(':') + 1), DAO.Decrypt(oPayment.CCNumberUsed.Trim(), ConfigurationManager.AppSettings["encryptionKey"]).Remove(0, 12), string.Format("{0:0.00}", Convert.ToDecimal(oPayment.AmountPaid)), string.Format("{0:0.00}", Convert.ToDecimal(oPayment.Fee)), string.Format("{0:0.00}", Convert.ToDecimal(oPayment.AmountPaid) + Convert.ToDecimal(oPayment.Fee)), string.Format("{0:0.00}", Convert.ToDecimal(oPayment.Fee) - Convert.ToDecimal(metro.UserCommission)), string.Format("{0:0.00}", cardcom), oPayment.CreatedDate });
                        }
                        else if (cardnum == "4" && (oPayment.Provider.Substring(0, oPayment.Provider.LastIndexOf(" -") + 1).Trim() == "MetroPCS" || oPayment.Provider.Substring(0, oPayment.Provider.LastIndexOf(" -") + 1).Trim() == "Boost" || oPayment.Provider.Substring(0, oPayment.Provider.LastIndexOf(" -") + 1).Trim() == "Cricket"))
                        {
                            cardcom = Convert.ToDecimal(oPayment.AmountPaid) * Convert.ToDecimal(0.01);
                            dt.Rows.Add(new object[] { oPayment.ID, oPayment.Post, oPayment.UserID, oPayment.Provider.Substring(0, oPayment.Provider.LastIndexOf(" -") + 1).Trim(), oPayment.PhoneNumber, oPayment.Provider.Substring(oPayment.Provider.LastIndexOf(':') + 1), DAO.Decrypt(oPayment.CCNumberUsed.Trim(), ConfigurationManager.AppSettings["encryptionKey"]).Remove(0, 12), string.Format("{0:0.00}", Convert.ToDecimal(oPayment.AmountPaid)), string.Format("{0:0.00}", Convert.ToDecimal(oPayment.Fee)), string.Format("{0:0.00}", Convert.ToDecimal(oPayment.AmountPaid) + Convert.ToDecimal(oPayment.Fee)), string.Format("{0:0.00}", Convert.ToDecimal(oPayment.Fee) - Convert.ToDecimal(metro.UserCommission)), string.Format("{0:0.00}", cardcom), oPayment.CreatedDate });
                        }
                        foreach (DataRow row in table.Rows)
                        {
                            string product = row["Product"].ToString();
                            decimal usercom = Convert.ToDecimal(row["UserCommission"]);
                            Convert.ToDecimal(row["Commission"]);
                            if (!(oPayment.Provider.Substring(0, oPayment.Provider.LastIndexOf(" -") + 1).Trim() == product) || !(usercom != new decimal(2)))
                            {
                                continue;
                            }
                            dt.Rows.Add(new object[] { oPayment.ID, oPayment.Post, oPayment.UserID, oPayment.Provider.Substring(0, oPayment.Provider.LastIndexOf(" -") + 1).Trim(), oPayment.PhoneNumber, oPayment.Provider.Substring(oPayment.Provider.LastIndexOf(':') + 1), DAO.Decrypt(oPayment.CCNumberUsed.Trim(), ConfigurationManager.AppSettings["encryptionKey"]).Remove(0, 12), string.Format("{0:0.00}", Convert.ToDecimal(oPayment.AmountPaid)), string.Format("{0:0.00}", Convert.ToDecimal(oPayment.Fee)), string.Format("{0:0.00}", Convert.ToDecimal(oPayment.AmountPaid) + Convert.ToDecimal(oPayment.Fee)), string.Format("{0:0.00}", Convert.ToDecimal(oPayment.Fee)), string.Format("{0:0.00}", 0), oPayment.CreatedDate });
                        }
                    }
                }
                this.gvUsers.DataSource = dt;
                this.gvUsers.DataBind();
                if (aList.Count != 0)
                {
                    this.lbInfo.Text = "";
                    this.btnExcel.Enabled = true;
                    decimal total = new decimal();
                    decimal rewards = new decimal();
                    decimal totalrewards = new decimal();
                    decimal totalcomm = new decimal();
                    User SinPin = this.oUserDAO.RetrieveServiceActivity(4, "", "");
                    User dp = this.oUserDAO.RetrieveServiceActivity(5, "", "");
                    User GuatePin = this.oUserDAO.RetrieveServiceActivity(33, "", "");
                    foreach (GridViewRow gvr in this.gvUsers.Rows)
                    {
                        int doublepay = this.getPreviousPayment(gvr.Cells[5].Text);
                        if (gvr.Cells[4].Text == SinPin.FullName && this.oUser.UserType == "User")
                        {
                            SinPin = this.oUserDAO.RetrieveServiceActivity(SinPin.ID, gvr.Cells[3].Text.Trim(), "");
                            decimal SinPinCom = Convert.ToDecimal(gvr.Cells[10].Text) * Convert.ToDecimal(SinPin.UserCommission);
                            gvr.Cells[11].Text = string.Format("{0:0.00}", SinPinCom);
                        }
                        else if (gvr.Cells[4].Text == dp.FullName && this.oUser.UserType == "User")
                        {
                            dp = this.oUserDAO.RetrieveServiceActivity(dp.ID, gvr.Cells[3].Text.Trim(), "");
                            decimal DPCom = Convert.ToDecimal(gvr.Cells[10].Text) * Convert.ToDecimal(dp.UserCommission);
                            gvr.Cells[11].Text = string.Format("{0:0.00}", DPCom);
                        }
                        else if (gvr.Cells[4].Text == GuatePin.FullName && this.oUser.UserType == "User")
                        {
                            GuatePin = this.oUserDAO.RetrieveServiceActivity(GuatePin.ID, gvr.Cells[3].Text.Trim(), "");
                            decimal GuatePinCom = Convert.ToDecimal(gvr.Cells[10].Text) * Convert.ToDecimal(GuatePin.UserCommission);
                            gvr.Cells[11].Text = string.Format("{0:0.00}", GuatePinCom);
                        }
                        else if (gvr.Cells[4].Text == SinPin.FullName && this.oUser.UserType == "Admin")
                        {
                            SinPin = this.oUserDAO.RetrieveServiceActivity(SinPin.ID, gvr.Cells[3].Text.Trim(), "");
                            decimal SinPinCom = Convert.ToDecimal(gvr.Cells[10].Text) * Convert.ToDecimal(SinPin.Commission - SinPin.UserCommission);
                            gvr.Cells[11].Text = string.Format("{0:0.00}", SinPinCom);
                        }
                        else if (gvr.Cells[4].Text == dp.FullName && this.oUser.UserType == "Admin")
                        {
                            dp = this.oUserDAO.RetrieveServiceActivity(dp.ID, gvr.Cells[3].Text.Trim(), "");
                            decimal DPCom = Convert.ToDecimal(gvr.Cells[10].Text) * Convert.ToDecimal(dp.Commission - dp.UserCommission);
                            gvr.Cells[11].Text = string.Format("{0:0.00}", DPCom);
                        }
                        else if (gvr.Cells[4].Text == GuatePin.FullName && this.oUser.UserType == "Admin")
                        {
                            GuatePin = this.oUserDAO.RetrieveServiceActivity(GuatePin.ID, gvr.Cells[3].Text.Trim(), "");
                            decimal GuatePinCom = Convert.ToDecimal(gvr.Cells[10].Text) * Convert.ToDecimal(GuatePin.Commission - GuatePin.UserCommission);
                            gvr.Cells[11].Text = string.Format("{0:0.00}", GuatePinCom);
                        }
                        else if (gvr.Cells[4].Text == SinPin.FullName && this.oUser.UserType == "Viewer")
                        {
                            decimal SinPinCom = new decimal();
                            gvr.Cells[11].Text = string.Format("{0:0.00}", SinPinCom);
                        }
                        else if (gvr.Cells[4].Text == dp.FullName && this.oUser.UserType == "Viewer")
                        {
                            decimal DPCom = new decimal();
                            gvr.Cells[11].Text = string.Format("{0:0.00}", DPCom);
                        }
                        else if (gvr.Cells[4].Text == GuatePin.FullName && this.oUser.UserType == "Viewer")
                        {
                            decimal GuatePinCom = new decimal();
                            gvr.Cells[11].Text = string.Format("{0:0.00}", GuatePinCom);
                        }
                        else if (gvr.Cells[4].Text != SinPin.FullName || gvr.Cells[4].Text != dp.FullName || gvr.Cells[4].Text != GuatePin.FullName)
                        {
                            Button button = (Button)gvr.FindControl("btnDelete");
                            Button button1 = (Button)gvr.FindControl("btnPrint");
                            gvr.Cells[0].Enabled = true;
                            button1.Visible = true;
                            this.lbDatePaid.Visible = true;
                            this.lbAmountPaid.Visible = true;
                            this.lbProvider.Visible = true;
                            this.lbPhone.Visible = true;
                            this.lbconf.Visible = true;
                            button.Visible = false;
                        }
                        foreach (DataRow dataRow in table.Rows)
                        {
                            int prodID = Convert.ToInt32(dataRow["ID"]);
                            string product = dataRow["Product"].ToString();
                            decimal usercom = Convert.ToDecimal(dataRow["UserCommission"]);
                            decimal com = Convert.ToDecimal(dataRow["Commission"]);
                            decimal DiscountCom = new decimal();
                            decimal DPCom = new decimal();
                            decimal TelbugtComAfterDiscoun = new decimal();
                            if (usercom == new decimal(2) || usercom == decimal.One)
                            {
                                if (usercom != decimal.One)
                                {
                                    continue;
                                }
                                usercom = this.oUserDAO.RetrieveServiceActivity(prodID, gvr.Cells[3].Text.Trim(), gvr.Cells[13].Text).UserCommission;
                                if (product == "AT&T")
                                {
                                    product = "AT&amp;T";
                                }
                                if (!(gvr.Cells[4].Text == product) || !(this.oUser.UserType == "User"))
                                {
                                    if (!(gvr.Cells[4].Text == product) || !(this.oUser.UserType == "Admin"))
                                    {
                                        continue;
                                    }
                                    DPCom = Convert.ToDecimal(gvr.Cells[10].Text) * com;
                                    if (doublepay > 1)
                                    {
                                        gvr.Cells[11].Text = string.Format("{0:0.00}", DPCom);
                                    }
                                    else if (!usercom.ToString().Contains("."))
                                    {
                                        gvr.Cells[11].Text = string.Format("{0:0.00}", DPCom - usercom);
                                    }
                                    else
                                    {
                                        TelbugtComAfterDiscoun = Convert.ToDecimal(gvr.Cells[10].Text) * Convert.ToDecimal(com - usercom);
                                        gvr.Cells[11].Text = string.Format("{0:0.00}", TelbugtComAfterDiscoun);
                                    }
                                }
                                else if (doublepay > 1)
                                {
                                    gvr.Cells[11].Text = string.Format("{0:0.00}", 0);
                                }
                                else if (!usercom.ToString().Contains("."))
                                {
                                    gvr.Cells[11].Text = string.Format("{0:0.00}", usercom);
                                }
                                else
                                {
                                    DiscountCom = Convert.ToDecimal(gvr.Cells[10].Text) * usercom;
                                    gvr.Cells[11].Text = string.Format("{0:0.00}", DiscountCom);
                                }
                            }
                            else if (gvr.Cells[4].Text == "SinPin" || gvr.Cells[4].Text == "DollarPhone" || gvr.Cells[4].Text == "GuatePin")
                            {
                                if (Convert.ToDateTime(gvr.Cells[13].Text) >= DateTime.Today.AddDays(-7))
                                {
                                    continue;
                                }
                                gvr.Cells[0].Enabled = false;
                            }
                            else if (!(gvr.Cells[4].Text == product) || !(this.oUser.UserType == "User"))
                            {
                                if (!(gvr.Cells[4].Text == product) || !(this.oUser.UserType == "Admin"))
                                {
                                    continue;
                                }
                                DPCom = Convert.ToDecimal(gvr.Cells[10].Text) * com;
                                gvr.Cells[11].Text = string.Format("{0:0.00}", DPCom - (Convert.ToDecimal(gvr.Cells[10].Text) * usercom));
                            }
                            else
                            {
                                gvr.Cells[11].Text = string.Format("{0:0.00}", Convert.ToDecimal(gvr.Cells[10].Text) * usercom);
                            }
                            if (doublepay > 1 && gvr.Cells[9].Text == "0.00" && this.oUser.UserType == "User")
                            {
                                if (!usercom.ToString().Contains("."))
                                {
                                    gvr.Cells[11].Text = string.Format("{0:0.00}", 0);
                                }

                            }
                        }
                         if (doublepay > 1 && gvr.Cells[9].Text == "0.00" && this.oUser.UserType == "User")
                        {
                            if(gvr.Cells[4].Text == "MetroPCS" || gvr.Cells[4].Text == "Boost" || gvr.Cells[4].Text == "Cricket")
                            {
                                gvr.Cells[11].Text = string.Format("{0:0.00}", 0);
                            }
                            
                        }
                        if (this.oUser.UserType == "Admin" && gvr.Cells[9].Text == "3.00")
                        {
                            gvr.Cells[11].Text = string.Format("{0:0.00}", 2);
                        }
                        if (this.oUser.UserType == "Admin" && gvr.Cells[7].Text == "1111")
                        {
                            gvr.Cells[9].Text = string.Format("{0:0.00}", 3);
                            gvr.Cells[11].Text = string.Format("{0:0.00}", 3);
                            gvr.Cells[12].Text = string.Format("{0:0.00}", 0);
                        }
                        if (this.oUser.UserType == "Admin" && gvr.Cells[9].Text == "5.00")
                        {
                            gvr.Cells[11].Text = string.Format("{0:0.00}", 2);
                        }
                        if (gvr.Cells[8].Text.Contains("-") && gvr.Cells[9].Text.Contains("-"))
                        {
                            gvr.Cells[11].Text = string.Format("{0:0.00}", -2);
                        }
                        if (this.oUser.UserType == "Admin" && gvr.Cells[7].Text == "1449")
                        {
                            gvr.Cells[11].Text = string.Format("{0:0.00}", 1);
                            gvr.Cells[12].Text = string.Format("{0:0.00}", 0);
                        }
                        if (this.oUser.UserType == "Admin" && gvr.Cells[7].Text == "8467")
                        {
                            gvr.Cells[12].Text = string.Format("{0:0.00}", 0);
                        }
                        if (this.oUser.UserType == "Admin" && gvr.Cells[7].Text == "9680")
                        {
                            gvr.Cells[12].Text = string.Format("{0:0.00}", 0);
                        }
                        if (this.oUser.UserType != "Admin")
                        {
                            rewards += Convert.ToDecimal(gvr.Cells[12].Text);
                            total += Convert.ToDecimal(gvr.Cells[11].Text);
                            this.lbTotalEarning.Text = string.Concat("<b>Total Earnings:</b> ", string.Format("{0:0.00}", total + rewards));
                        }
                        else
                        {
                            totalrewards += Convert.ToDecimal(gvr.Cells[12].Text);
                            totalcomm += Convert.ToDecimal(gvr.Cells[11].Text);
                            rewards += Convert.ToDecimal(gvr.Cells[12].Text);
                            total += Convert.ToDecimal(gvr.Cells[11].Text);
                            this.lbTotalEarning.Text = string.Concat(new object[] { "<b>Total Commission</b>: ", totalcomm, " + <b>Total Rewards:</b> ", totalrewards, " = <b>Total Earnings:</b> ", string.Format("{0:0.00}", total + rewards) });
                        }
                    }
                    decimal gettotal = new decimal();
                    foreach (GridViewRow gvr in this.gvUsers.Rows)
                    {
                        gettotal += Convert.ToDecimal(gvr.Cells[8].Text);
                        this.lbTotalToPay.Text = string.Concat("<b>Total Provider Payment:</b> ", string.Format("{0:0.00}", gettotal));
                    }
                    decimal gettotalDeposit = gettotal + total;
                    decimal DPPercent = new decimal();
                    decimal DollarPayout = new decimal();
                    int countZero = 0;
                    foreach (GridViewRow gvr in this.gvUsers.Rows)
                    {
                        foreach (DataRow row1 in table.Rows)
                        {
                            string product = row1["Product"].ToString();
                            decimal com = Convert.ToDecimal(row1["Commission"]);
                            if (product == "AT&T")
                            {
                                product = "AT&amp;T";
                            }
                            if (!(gvr.Cells[4].Text == product) || !(com != new decimal(2)))
                            {
                                continue;
                            }
                            DPPercent = Convert.ToDecimal(gvr.Cells[8].Text) * Convert.ToDecimal(com);
                            gettotalDeposit -= DPPercent;
                            if (product == "SinPin")
                            {
                                continue;
                            }
                            DollarPayout = (DollarPayout + Convert.ToDecimal(gvr.Cells[8].Text)) - DPPercent;
                        }
                        if (gvr.Cells[7].Text == "1449")
                        {
                            DollarPayout = (DollarPayout + Convert.ToDecimal(gvr.Cells[8].Text)) + decimal.One;
                        }
                        this.lbPayment.Text = string.Concat(new string[] { "<b>Total Deposit:</b> ", string.Format("{0:0.00}", gettotalDeposit), "<br /><b>Dollar Phone Deposit:</b> ", string.Format("{0:0.00}", DollarPayout), "<br/>" });
                        if (this.oUser.UserType == "User")
                        {
                            this.lbPayment.Text = "";
                        }
                        if (this.oUser.UserType == "Viewer")
                        {
                            User spiff = new User();
                            spiff = this.oUserDAO.RetrieveSpiffUserID(this.UserCookie.Value);
                            decimal it = Convert.ToDecimal(spiff.Fee) * new decimal(2);
                            if (gvr.Cells[3].Text.ToUpper() != this.UserCookie.Value.ToUpper() && gvr.Cells[9].Text == "0.00")
                            {
                                gvr.Cells[11].Text = "0.00";
                            }
                            else
                            {
                                gvr.Cells[11].Text = string.Format("{0:0.00}", it);
                            }
          
                            if (gvr.Cells[9].Text == "0.00")
                            {
                                countZero = 1 + countZero;
                            }
          
                            if (gvr.Cells[9].Text != "0.00" && gvr.Cells[3].Text.ToUpper() != this.UserCookie.Value.ToUpper())
                            {
 
                                decimal grandtotal = (aList.Count - countZero) * it;
                                
                                this.lbTotalToPay.Text = string.Concat("<b>Commission:</b> ", string.Format("{0:0.00}", grandtotal));
                            }
                            if (Convert.ToDecimal(spiff.Fee) == decimal.Zero)
                            {
                                this.lbTotalToPay.Text = "";
                            }
                            this.lbPayment.Text = "";
                        }
                        if (!gvr.Cells[8].Text.Contains("-"))
                        {
                            continue;
                        }
                        Button button2 = (Button)gvr.FindControl("btnDelete");
                        Button button3 = (Button)gvr.FindControl("btnPrint");
                        gvr.Cells[0].Text = "Voided";
                        button3.Visible = false;
                        button2.Visible = false;
                        gvr.BackColor = Color.IndianRed;
                    }
                    Label label = this.lbCount;
                    int count = aList.Count;
                    label.Text = string.Concat("<b>Total Payment:</b> ", count.ToString());
                    if (this.txtTo.Text.Length == 0 && this.txtFrom.Text.Length == 0)
                    {
                        this.lbInfo.Text = "Select dates to see data";
                        this.lbTotalEarning.Text = "";
                        this.lbCount.Text = "";
                        this.lbPayment.Text = "";
                    }
                }
                else
                {
                    this.lbInfo.Text = "There is no data";
                    this.lbTotalEarning.Text = "";
                    this.lbCount.Text = "";
                    this.lbTotalToPay.Text = "";
                    this.lbPayment.Text = "";
                    this.btnExcel.Enabled = false;
                }
                if (this.oUser.UserType == "User" || this.oUser.UserType == "Viewer")
                {
                    if (aList.Count > 0)
                    {
                        this.gvUsers.HeaderRow.Cells[12].Visible = false;
                        this.gvUsers.HeaderRow.Cells[7].Visible = false;
                        this.gvUsers.HeaderRow.Cells[2].Visible = false;
                        this.gvUsers.HeaderRow.Cells[1].Visible = false;
                    }
                    foreach (GridViewRow gridViewRow in this.gvUsers.Rows)
                    {
                        gridViewRow.Cells[12].Visible = false;
                        gridViewRow.Cells[7].Visible = false;
                        gridViewRow.Cells[2].Visible = false;
                        gridViewRow.Cells[1].Visible = false;
                    }
                }
                else
                {
                    foreach (GridViewRow gridViewRow1 in this.gvUsers.Rows)
                    {
                        this.gvUsers.HeaderRow.Cells[1].Visible = false;
                        gridViewRow1.Cells[1].Visible = false;
                        this.gvUsers.HeaderRow.Cells[2].Visible = false;
                        gridViewRow1.Cells[2].Visible = false;
                    }
                }
            }
        }
        protected void DeletePayment(object sender, EventArgs e)
        {
            ServicePointManager.Expect100Continue = true;
            ServicePointManager.DefaultConnectionLimit = 9999;
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12 | SecurityProtocolType.Ssl3;

            UserDAO oUserDAO = new UserDAO();
            Button btnDelete = (Button)sender;
            Payment oPay = new Payment();
            MetroFastPayLibrary.Account oAccount = new MetroFastPayLibrary.Account();
            User getComm = oUserDAO.RetrieveServiceActivity(5);
            string id = btnDelete.CommandArgument;
            oPay = oUserDAO.RetrievePaymentbyID(Convert.ToInt32(id));
            if (oPay.Provider.Contains("DollarPhone") || oPay.Provider.Contains("GuatePin"))
            {
                TransResponseType ts = new TransResponseType();
                ActivateOrRechargeAccountType af = new ActivateOrRechargeAccountType();
                AccountInfo ai = new AccountInfo();

                using (PinManager pm = new PinManager())
                {
                    pm.Credentials = new System.Net.NetworkCredential(ConfigurationManager.AppSettings["dpUser"], ConfigurationManager.AppSettings["dpPass"]);

                    af.Account = ai;
                    af.Account.Ani = oPay.PhoneNumber;
                    if (oPay.Provider.Contains("GuatePin"))
                    {
                        getComm = oUserDAO.RetrieveServiceActivity(33);
                        af.Account.OfferingId = 30178480;
                    }
                    else
                    {
                        getComm = oUserDAO.RetrieveServiceActivity(5);
                        af.Account.OfferingId = 30030280;
                    }
                    af.Account.Balance = -oPay.AmountPaid;



                    ai = pm.ActivateOrRechargeAccount(af);


                    if ((ai.TransId > 0))
                    {

                        DateTime start = DateTime.Now;
                        for (
                        ; ((ts.Status == TransactionStatus.Pending) && ((DateTime.Now - start).TotalSeconds <= 180));
                        )
                        {
                            System.Threading.Thread.Sleep(3000);
                            ts = pm.TopupConfirm(Convert.ToInt32(ai.TransId));
                        }
                        switch (ts.Status)
                        {

                            case TransactionStatus.Success:

                                //update credit line
                                oAccount = oUserDAO.RetrieveAccount(UserCookie.Value);

                                if (oAccount.Active == true)
                                {
                                    decimal DPamount = Convert.ToDecimal(-oPay.AmountPaid) * Convert.ToDecimal(getComm.UserCommission);
                                    oUserDAO.UpdateAccountbyPost(oAccount.Credit - (Convert.ToDecimal(-oPay.AmountPaid) - DPamount), oUser.Post);
                                }

                                if (oUser.UserType == "Admin")
                                {
                                    MetroFastPayLibrary.Account oAccount3 = new MetroFastPayLibrary.Account();
                                    oAccount3 = oUserDAO.RetrieveAccount(oPay.UserID);
                                    decimal DPamount = Convert.ToDecimal(oPay.AmountPaid) * Convert.ToDecimal(getComm.UserCommission);
                                    oUserDAO.UpdateAccountbyPost(oAccount3.Credit + (Convert.ToDecimal(oPay.AmountPaid) - DPamount), oPay.Post);
                                }


                                DataTable dt = new DataTable();
                                //oUserDAO.DeletePayment(Convert.ToInt32(id));
                                oUserDAO.InsertPayments(oPay.UserID, oPay.Post, oPay.PhoneNumber, -oPay.AmountPaid, -oPay.Fee, oPay.Provider, oPay.CCNumberUsed, DateTime.Now);
                                //oUserDAO.UpdatePayment(Convert.ToInt32(id), oPay.UserID, -oPay.AmountPaid, -oPay.Fee);
                                BindGrid(dt, oUser.UserID);


                                break;
                            case TransactionStatus.Failed:
                                break;
                            case TransactionStatus.Pending:
                                break;
                        }
                    }
                }
            }
            else
            {
                oAccount = oUserDAO.RetrieveAccount(UserCookie.Value);
                string theid = oPay.Provider.Substring(oPay.Provider.LastIndexOf(':') + 1);
                string url = "https://webservice.sinpin.com/Agent/VoidRecharge/?Username=fandf.webapi&Password=Marcos2168!PB_561*!&apiKey=9e8roNDqY4Ssx6A607TxwYoJI0y246Ph&audit_id=" + theid;
                var client = new RestClient(url);
                var request = new RestRequest(Method.POST);
                IRestResponse response = client.Execute(request);
                try
                {

                    if (response.Content.Contains("Success"))
                    {

                        if (oAccount.Active == true)
                        {
                            decimal SinPinamount = Convert.ToDecimal(oPay.AmountPaid) * Convert.ToDecimal(.22);
                            oUserDAO.UpdateAccountbyPost(oAccount.Credit + (Convert.ToDecimal(oPay.AmountPaid) - SinPinamount), oPay.Post);

                            MetroFastPayLibrary.Account oAccount2 = new MetroFastPayLibrary.Account();
                            oAccount2 = oUserDAO.RetrieveAccount(UserCookie.Value);
                            lbCredit.Text = "| Balance: $" + string.Format("{0:0.00}", oAccount2.Credit);
                        }

                        if (oUser.UserType == "Admin")
                        {
                            MetroFastPayLibrary.Account oAccount3 = new MetroFastPayLibrary.Account();
                            oAccount3 = oUserDAO.RetrieveAccount(oPay.UserID);
                            decimal SinPinamount = Convert.ToDecimal(oPay.AmountPaid) * Convert.ToDecimal(.22);
                            oUserDAO.UpdateAccountbyPost(oAccount3.Credit + (Convert.ToDecimal(oPay.AmountPaid) - SinPinamount), oPay.Post);
                        }


                        DataTable dt = new DataTable();
                        //oUserDAO.DeletePayment(Convert.ToInt32(id));
                        oUserDAO.InsertPayments(oPay.UserID, oPay.Post, oPay.PhoneNumber, -oPay.AmountPaid, -oPay.Fee, oPay.Provider, oPay.CCNumberUsed, DateTime.Now);
                        BindGrid(dt, oUser.UserID);
                    }
                    else
                    {
                        Response.Redirect("out.aspx");
                    }
                }
                catch (Exception ex)
                {

                }

            }
        }
        protected void PrintPayment(object sender, EventArgs e)
        {
            UserDAO oUserDAO = new UserDAO();
            Button btnPrint = (Button)sender;
            Payment oPay = new Payment();
            Payment oPaySID = new Payment();
            MetroFastPayLibrary.Account oAccount = new MetroFastPayLibrary.Account();

            string id = btnPrint.CommandArgument;
            oPay = oUserDAO.RetrievePaymentbyID(Convert.ToInt32(id));
            oAccount = oUserDAO.RetrieveAccount(UserCookie.Value);


            if (oUser.UserType == "Admin")
            {
                oPaySID = oUserDAO.RetrieveSIDbyPaymentID(Convert.ToInt32(id));
                string pageurl = "http://" + Request.Url.Authority + "/getconf.aspx?CAsid=" + oPaySID.SID + "&amount=" + oPay.AmountPaid + "&number=" + oPay.PhoneNumber + "&paymentid=" + oPay.ID + "&time=" + oPay.CreatedDate + "&user=" + oPay.UserID;

                ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "", "window.open('"+ pageurl +"', '_blank','height=300, width=200')", true);
            }
            else
            {
                lbDatePaid.Value = oPay.CreatedDate.ToString();
                lbFees.Value = string.Format("{0:0.00}", oPay.Fee);
                lbAmountPaid.Value = string.Format("{0:0.00}", oPay.AmountPaid);
                lbProvider.Value = Convert.ToString(oPay.Provider.Substring(0, oPay.Provider.LastIndexOf(" -") + 1).Trim());
                lbPhone.Value = oPay.PhoneNumber;
                lbconf.Value = Convert.ToString(oPay.Provider.Substring(oPay.Provider.LastIndexOf(":") + 1).Trim());

                ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "text", "PrintPanel()", true);
            }

        }


        protected void ExportToExcel(object sender, EventArgs e)
        {
            if(IsPostBack)
            {
                Response.Clear();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment;filename=TelbugReport-" + DateTime.Now + ".xls");
                Response.Charset = "";
                Response.ContentType = "application/vnd.ms-excel";
                using (StringWriter sw = new StringWriter())
                {
                HtmlTextWriter hw = new HtmlTextWriter(sw);

                //To Export all pages
                gvUsers.AllowPaging = false;
                DataTable dt = new DataTable();
                if (oUser.UserType == "Viewer")
                {
                    this.BindGrid(dt, UserCookie.Value);
                    //if (ddUser.SelectedItem.Value != "--Select User--")
                    //{
                    //    this.BindGrid(dt, ddUser.SelectedItem.Value);
                    //}


                }
                else
                {
                    this.BindGrid(dt, ddUser.SelectedItem.Value);

                }

                gvUsers.HeaderRow.BackColor = Color.White;
                foreach (TableCell cell in gvUsers.HeaderRow.Cells)
                {

                    cell.BackColor = gvUsers.HeaderStyle.BackColor;
                }
                foreach (GridViewRow row in gvUsers.Rows)
                {
                    gvUsers.HeaderRow.Cells[0].Visible = false;
                    row.Cells[0].Visible = false;

                    row.BackColor = Color.White;
                    foreach (TableCell cell in row.Cells)
                    {
                        if (row.RowIndex % 2 == 0)
                        {
                            cell.BackColor = gvUsers.AlternatingRowStyle.BackColor;
                        }
                        else
                        {
                            cell.BackColor = gvUsers.RowStyle.BackColor;
                        }
                        cell.CssClass = "textmode";
                    }
                }

                gvUsers.RenderControl(hw);

                //style to format numbers to string
                string style = @"<style> .textmode { } </style>";
                Response.Write(style);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
                }
            }
          
        }

        public override void VerifyRenderingInServerForm(Control control)
        {
            /* Verifies that the control is rendered */
        }
        protected void OnPaging(object sender, GridViewPageEventArgs e)
        {
            gvUsers.PageIndex = e.NewPageIndex;
            gvUsers.DataBind();
            DataTable dt = new DataTable();
            BindGrid(dt, UserCookie.Value);
        }
        protected void LogOut_Click(object sender, System.EventArgs e)
        {
            try
            {
                Session.Abandon();

                System.Web.HttpCookie UserCookie = new System.Web.HttpCookie("UserNameCookie");
                UserCookie.Expires = DateTime.Now.AddYears(-1);
                Response.Cookies.Add(UserCookie);
                Response.Redirect("login.aspx");
            }
            catch
            {
            }
        }
        public int getPreviousPayment(string nummber)
        {
            using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString()))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                cmd.CommandText = @"select COUNT(*) from payments where PhoneNumber = '" + nummber + "'  and LEFT(Provider, 6) <> 'SinPin'  and createddate between  DATEADD(day, -21, CONVERT (date, getdate())) and getdate()";
                int tnumber = Convert.ToInt32(cmd.ExecuteScalar());
                return tnumber;
            }
        }
    }
}