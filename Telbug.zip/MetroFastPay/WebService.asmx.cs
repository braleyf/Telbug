﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Services;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.Script.Services;
using RestSharp;

namespace MetroFastPay
{
    /// <summary>
    /// Summary description for WebService
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
     [System.Web.Script.Services.ScriptService]
    public class WebService : System.Web.Services.WebService
    {

        public WebService()
        {

            //Uncomment the following line if using designed components
            //InitializeComponent();
        }

        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]

        public string[] GetNumber(string prefix)
        {


            List<string> Number = new List<string>();
            using (SqlConnection conn = new SqlConnection())
            {
                    if (prefix.Length >= 7)
                    {
                    conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
                    using (SqlCommand cmd = new SqlCommand())
                    {

                        cmd.CommandText = "select phonenumber, amountpaid from payments where RIGHT(PhoneNumber, 10) = '' + @SearchText + ''  and (LEFT(Provider, 5) = 'Boost' OR LEFT(Provider, 7) = 'Cricket' OR LEFT(Provider, 8) = 'MetroPCS') and createddate between  DATEADD(day, -3, CONVERT (date, getdate())) and getdate()";
                        prefix = prefix.Replace("(", "");
                        prefix = prefix.Replace(")", "");
                        prefix = prefix.Replace("-", "");
                        string tt = prefix;
                        cmd.Parameters.AddWithValue("@SearchText", tt);
                       cmd.Connection = conn;
                        conn.Open();
                        using (SqlDataReader sdr = cmd.ExecuteReader())
                        {
                           
                            while (sdr.Read())
                            {
                                int amount = Convert.ToInt32(sdr["amountpaid"]);
                                    Number.Add(string.Format("{0}", "Number paid within last 3 days for: $" + amount.ToString() + " | Número se ha pagado en los últimos 3 días por: $" + amount.ToString()));


                            }
                            if (Number.Count == 0)
                            {
     
                                Number.Add(string.Format("{0}-{1}-{2}", "", "", ""));
                            }

                        }

                    }
                    conn.Close();
                }
                return Number.ToArray();
            }

        }

        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string[] GetBoostPin(string prefix)
            {


            List<string> Number = new List<string>();
            using (SqlConnection conn = new SqlConnection())
            {
                if (prefix.Length >= 7)
                {
                    conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
                    using (SqlCommand cmd = new SqlCommand())
                    {

                        cmd.CommandText = "select top (1) pin from boostpin where RIGHT(PhoneNumber, 10) = '' + @SearchText + ''";
                        prefix = prefix.Replace("(", "");
                        prefix = prefix.Replace(")", "");
                        prefix = prefix.Replace("-", "");
                        string tt = prefix;
                        cmd.Parameters.AddWithValue("@SearchText", tt);
                        cmd.Connection = conn;
                        conn.Open();
                        using (SqlDataReader sdr = cmd.ExecuteReader())
                        {

                            while (sdr.Read())
                            {
                                string pin = sdr["pin"].ToString();
                                Number.Add(string.Format("{0}", pin));


                            }
                            if (Number.Count == 0)
                            {
                                // do nothing 
                            }

                        }

                    }
                    conn.Close();
                }
                return Number.ToArray();
            }

        }
        public static string getBetween(string strSource, string strStart, string strEnd)
        {
            int Start, End;
            if (strSource.Contains(strStart) && strSource.Contains(strEnd))
            {
                Start = strSource.IndexOf(strStart, 0) + strStart.Length;
                End = strSource.IndexOf(strEnd, Start);
                return strSource.Substring(Start, End - Start);
            }
            else
            {
                return "";
            }
        }
        public string GetBalance(string prefix)
        {
            System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls12;
            string url = "https://webservice.sinpin.com/Agent/accountbalance/?Username=fandf.webapi&Password=Marcos2168!PB_561*!&apiKey=9e8roNDqY4Ssx6A607TxwYoJI0y246Ph&PHONE=" + prefix;
            var client = new RestClient(url);
            var request = new RestRequest(Method.POST);
            IRestResponse response = client.Execute(request);
            string balance = "";
            if (response.Content.Contains("Success"))
            {
                balance = getBetween(response.Content, "subscriber_balance\":", "}");
                

            }


            else
            {

            }
            return balance;
        }
     }
}
