﻿function leaveChange() {
        $("#divBanner").hide();
    $("#ConfPhone").show();
   
            if (document.getElementById('<%=ddProviders.ClientID %>').value == "1" || document.getElementById('<%=ddProviders.ClientID %>').value == "34") {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/metrobutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                document.getElementById('#<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').show();
    $("#ConfPhone").show();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
    $("#divBanner").hide();
    $("#SinPinBalance").hide();
    $("#pay").show();
    $("#divFee").show();
    $("#divSinPinTotal").hide();
    $("#xtraButtons").hide();
    $("#tigoFlags").hide();
    $("#digicelFlags").hide();
    $("#claroFlags").hide();
    $("#ddotherServices").hide();
    $("#shortCodes").hide();

}
            else if (document.getElementById('<%=ddProviders.ClientID %>').value == "2") {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                 document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/cricketbutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "2 - 29 days late additional fee = $5.00 <br /> 29-59 days late additional fee = $15.00";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').show();
    $("#ConfPhone").show();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
    $("#divBanner").hide();
    $("#SinPinBalance").hide();
    $("#pay").show();
    $("#divFee").show();
    $("#divSinPinTotal").hide();
    $("#xtraButtons").hide();
    $("#tigoFlags").hide();
    $("#digicelFlags").hide();
    $("#claroFlags").hide();
    $("#ddotherServices").hide();
    $("#shortCodes").hide();
}
            else if (document.getElementById('<%=ddProviders.ClientID %>').value == "3") {
        $("#divShowTextbox").show();
    $('#<%=txtPin.ClientID %>').show();
     document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/boostbutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
    $("#divGetPin").show();
                document.getElementById("divGetPin").innerHTML = "<a href='' role='button' id='btnforgotpin' class='form-control btn btn-warning btn-lg' data-toggle='modal' data-target='#myModal4'>Send Pin | Mandar Pin</a>";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').show();
    $("#ConfPhone").show();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
    $("#divBanner").hide();
    $("#SinPinBalance").hide();
    $("#pay").show();
    $("#divFee").show();
    $("#divSinPinTotal").hide();
    $("#xtraButtons").hide();
    $("#tigoFlags").hide();
    $("#digicelFlags").hide();
    $("#claroFlags").hide();
    $("#ddotherServices").hide();
    $("#shortCodes").hide();

                    $('#btnSendPin').click(function (e) { 
                    var numb = document.getElementById('<%=txtBoostNumber.ClientID %>').value;
                    document.getElementById('<%=lbPin.ClientID %>').innerHTML = "<iframe src='SinPinBalance.aspx?boost=" + numb + "' width='400px' height='25px' frameborder='0' scrolling='no'></iframe>";
    });
}
            else if (document.getElementById('<%=ddProviders.ClientID %>').value == "4") {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/sinpinbutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "<a href='' data-toggle='modal' data-target='#myModal6'>Numero de accesso</a> / <a href='https://sinpin.com/home/rates' target='_blank'>Rates</a>";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').show();
    $("#ConfPhone").hide();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
                document.getElementById('<%=lbinto2.ClientID %>').innerHTML = "";
    $("#divBanner").hide();
    $("#SinPinBalance").show();
    $("#pay").hide();
    $("#divFee").hide();
    $("#divSinPinTotal").show();
    $("#xtraButtons").hide();
    $("#tigoFlags").hide();
    $("#digicelFlags").hide();
    $("#claroFlags").hide();
    $("#ddotherServices").hide();
    $("#shortCodes").hide();

                                $('#popupBtn').click(function (e) {
                    var numb = document.getElementById('<%=txtPhone.ClientID %>').value;
                document.getElementById('<%=lbBalance.ClientID %>').innerHTML = "<iframe src='SinPinBalance.aspx?phone=" + numb + "' width='150px' height='25px' frameborder='0' scrolling='no'></iframe>";

                var num = parseFloat(document.getElementById('<%=txtAmount.ClientID %>').value);
                    document.getElementById('<%=lbtotal2.ClientID %>').innerHTML = num.toFixed(2);

});
}
            else if (document.getElementById('<%=ddProviders.ClientID %>').value == "5") {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/dpbutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "<a href='' data-toggle='modal' data-target='#myModal5'>Numero de accesso</a> / <a href='https://www.dollarphonepinless.com/phone-rates' target='_blank'>Rates</a>";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').show();
    $("#ConfPhone").show();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
    $("#divBanner").hide();
    $("#SinPinBalance").show();
    $("#pay").hide();
    $("#divFee").hide();
    $("#divSinPinTotal").show();
    $("#xtraButtons").hide();
    $("#tigoFlags").hide();
    $("#digicelFlags").hide();
    $("#claroFlags").hide();
    $("#ddotherServices").hide();
    $("#shortCodes").hide();

                                $('#popupBtn').click(function (e) {
                    var numb = document.getElementById('<%=txtPhone.ClientID %>').value;
                document.getElementById('<%=lbBalance.ClientID %>').innerHTML = "<iframe src='SinPinBalance.aspx?DP=" + numb + "' width='150px' height='25px' frameborder='0' scrolling='no'></iframe>";

                var num = parseFloat(document.getElementById('<%=txtAmount.ClientID %>').value);
                    document.getElementById('<%=lbtotal2.ClientID %>').innerHTML = num.toFixed(2);

});
}
            else if (document.getElementById('<%=ddProviders.ClientID %>').value == "6") {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/simplebutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').hide();
    $("#ConfPhone").show();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
    $("#divBanner").hide();
    $("#SinPinBalance").hide();
    $("#pay").show();
    $("#divFee").show();
    $("#divSinPinTotal").hide
    $("#xtraButtons").show();
    $("#tigoFlags").hide();
    $("#digicelFlags").hide();
    $("#claroFlags").hide();
    $("#ddotherServices").hide();
    $("#shortCodes").hide();

                document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
                var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
    select.add(new Option(25));
    select.add(new Option(30));
    select.add(new Option(40));
    select.add(new Option(50));
    select.add(new Option(60));
}
             else if (document.getElementById('<%=ddProviders.ClientID %>').value == "7") {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/h2obutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').hide();
    $("#ConfPhone").show();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
    $("#divBanner").hide();
    $("#SinPinBalance").hide();
    $("#pay").show();
    $("#divFee").show();
    $("#divSinPinTotal").hide();
    $("#xtraButtons").show();
    $("#tigoFlags").hide();
    $("#digicelFlags").hide();
    $("#claroFlags").hide();
    $("#ddotherServices").hide();
    $("#shortCodes").hide();

                document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
                var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
   
    select.add(new Option(25));
    select.add(new Option(30));
    select.add(new Option(35));
    select.add(new Option(40));
    select.add(new Option(50));
    select.add(new Option(60));
    select.add(new Option(65));

}
            else if (document.getElementById('<%=ddProviders.ClientID %>').value == "8") {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/ultrabutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').hide();
    $("#ConfPhone").show();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
    $("#divBanner").hide();
    $("#SinPinBalance").hide();
    $("#pay").show();
    $("#divFee").show();
    $("#divSinPinTotal").hide();
    $("#xtraButtons").show();
    $("#tigoFlags").hide();
    $("#digicelFlags").hide();
    $("#claroFlags").hide();
    $("#ddotherServices").hide();
    $("#shortCodes").hide();

                document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
                var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
    select.add(new Option(11));
    select.add(new Option(12));
    select.add(new Option(13));
    select.add(new Option(16));
    select.add(new Option(19));
    select.add(new Option(20));
    select.add(new Option(21));
    select.add(new Option(22));
    select.add(new Option(24));
    select.add(new Option(25));
    select.add(new Option(26));
    select.add(new Option(27));
    select.add(new Option(29));
    select.add(new Option(30));
    select.add(new Option(31));
    select.add(new Option(33));
    select.add(new Option(34));
    select.add(new Option(35));
    select.add(new Option(36));
    select.add(new Option(37));
    select.add(new Option(39));
    select.add(new Option(40));
    select.add(new Option(41));
    select.add(new Option(44));
    select.add(new Option(45));
    select.add(new Option(46));
    select.add(new Option(47));
    select.add(new Option(49));
    select.add(new Option(50));
    select.add(new Option(51));
    select.add(new Option(55));
    select.add(new Option(56));
    select.add(new Option(60));
    select.add(new Option(61));
    select.add(new Option(65));
    select.add(new Option(66));
    select.add(new Option(70));
    select.add(new Option(71));
    select.add(new Option(75));
    select.add(new Option(76));
    select.add(new Option(80));
    select.add(new Option(81));
    select.add(new Option(85));
    select.add(new Option(86));
    select.add(new Option(90));
    select.add(new Option(100));
}
            else if (document.getElementById('<%=ddProviders.ClientID %>').value == "9") {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/lycabutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').hide();
    $("#ConfPhone").show();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
    $("#divBanner").hide();
    $("#SinPinBalance").hide();
    $("#pay").show();
    $("#divFee").show();
    $("#divSinPinTotal").hide();
    $("#xtraButtons").show();
    $("#tigoFlags").hide();
    $("#digicelFlags").hide();
    $("#claroFlags").hide();
    $("#ddotherServices").hide();
    $("#shortCodes").hide();

                document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
                var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
    select.add(new Option(30));
    select.add(new Option(36));
    select.add(new Option(40));
    select.add(new Option(46));
    select.add(new Option(50));
    select.add(new Option(56));
    select.add(new Option(60));

}
            else if (document.getElementById('<%=ddProviders.ClientID %>').value == "10") {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/attbutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').hide();
    $("#ConfPhone").show();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
    $("#divBanner").hide();
    $("#SinPinBalance").hide();
    $("#pay").show();
    $("#divFee").show();
    $("#divSinPinTotal").hide();
    $("#xtraButtons").show();
    $("#tigoFlags").hide();
    $("#digicelFlags").hide();
    $("#claroFlags").hide();
    $("#ddotherServices").hide();
    $("#shortCodes").hide();

                document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
                var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
    //DP
    //select.add(new Option(10));
    //select.add(new Option(12));
    //select.add(new Option(15));
    //select.add(new Option(20));
    //select.add(new Option(30));
    //select.add(new Option(35));
    //select.add(new Option(40));
    //select.add(new Option(45));
    //select.add(new Option(50));
    //select.add(new Option(55));
    //select.add(new Option(60));
    //select.add(new Option(65));
    //select.add(new Option(70));
    //select.add(new Option(75));
    //select.add(new Option(80));
    //select.add(new Option(85));
    //select.add(new Option(90));
    //select.add(new Option(100));

    //reup
    select.add(new Option(10));
    select.add(new Option(15));
    select.add(new Option(20));
    select.add(new Option(25));
    select.add(new Option(30));
    select.add(new Option(35));
    select.add(new Option(40));
    select.add(new Option(45));
    select.add(new Option(50));
    select.add(new Option(60));
    select.add(new Option(65));
    select.add(new Option(70));
    select.add(new Option(75));
    select.add(new Option(80));
    select.add(new Option(85));
    select.add(new Option(100));
}
           else if (document.getElementById('<%=ddProviders.ClientID %>').value == "11") {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
               document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/tmobilebutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "Amount Allowed: $10 - $100";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').show();
    $("#ConfPhone").show();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
               document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
    $("#divBanner").hide();
     $("#SinPinBalance").hide();
     $("#pay").show();
     $("#divFee").show();
     $("#divSinPinTotal").hide();
     $("#xtraButtons").hide();
     $("#tigoFlags").hide();
     $("#digicelFlags").hide();
     $("#claroFlags").hide();
     $("#ddotherServices").hide();
     $("#shortCodes").hide();

}
           else if (document.getElementById('<%=ddProviders.ClientID %>').value == "12") {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/verisonbutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').hide();
    $("#ConfPhone").hide();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
               document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
    $("#divBanner").hide();
     $("#SinPinBalance").hide();
     $("#pay").show();
     $("#divFee").show();
     $("#divSinPinTotal").hide
     $("#xtraButtons").show();
     $("#tigoFlags").hide();
     $("#digicelFlags").hide();
     $("#claroFlags").hide();
     $("#ddotherServices").hide();
     $("#shortCodes").hide();

                document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
                var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
    select.add(new Option(15));
    select.add(new Option(20));
    select.add(new Option(25));
    select.add(new Option(30));
    select.add(new Option(35));
    select.add(new Option(40));
    select.add(new Option(45));
    select.add(new Option(50));
    select.add(new Option(55));
    select.add(new Option(60));
    select.add(new Option(65));
    select.add(new Option(70));
    select.add(new Option(80));
    select.add(new Option(100));
    select.add(new Option(150));
}
           else if (document.getElementById('<%=ddProviders.ClientID %>').value == "13") {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/tigobutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').hide();
    $("#ConfPhone").hide();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
               document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
    $("#divBanner").hide();
     $("#SinPinBalance").hide();
     $("#pay").show();
     $("#divFee").show();
     $("#divSinPinTotal").hide();
     $("#xtraButtons").show();
     $("#tigoFlags").show();
     $("#digicelFlags").hide();
     $("#claroFlags").hide();
     $("#ddotherServices").show();
     $("#shortCodes").show();

                document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
                var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
    select.add(new Option(7));
    select.add(new Option(10));
    select.add(new Option(12));
    select.add(new Option(14));
    select.add(new Option(15));
    select.add(new Option(20));
    select.add(new Option(25));
    select.add(new Option(30));

                document.getElementById('<%=ddOtherService.ClientID %>').options.length = 0;
                var select = document.getElementById('<%=ddOtherService.ClientID %>');
   select.add(new Option("Tigo TopUp", 1));
   select.add(new Option("PaqueTigo", 2));
   select.add(new Option("Internet", 3));

}
           else if (document.getElementById('<%=ddProviders.ClientID %>').value == "14") {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/tigobutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').hide();
    $("#ConfPhone").hide();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
               document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
    $("#divBanner").hide();
     $("#SinPinBalance").hide();
     $("#pay").show();
     $("#divFee").show();
     $("#divSinPinTotal").hide();
     $("#xtraButtons").show();
     $("#tigoFlags").show();
     $("#digicelFlags").hide();
     $("#claroFlags").hide();
     $("#ddotherServices").show();
     $("#shortCodes").show();

                document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
                var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
    select.add(new Option(5));
    select.add(new Option(6));
    select.add(new Option(7));
    select.add(new Option(9));
    select.add(new Option(10));
    select.add(new Option(12));
    select.add(new Option(14));
    select.add(new Option(15));
    select.add(new Option(20));
    select.add(new Option(22));
    select.add(new Option(25));
    select.add(new Option(30));
    select.add(new Option(40));


                document.getElementById('<%=ddOtherService.ClientID %>').options.length = 0;
                var select = document.getElementById('<%=ddOtherService.ClientID %>');
   select.add(new Option("Tigo TopUp", 1));
   select.add(new Option("PaqueTigo", 2));
}
           else if (document.getElementById('<%=ddProviders.ClientID %>').value == "15") {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/tigobutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').hide();
    $("#ConfPhone").hide();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
               document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
    $("#divBanner").hide();
     $("#SinPinBalance").hide();
     $("#pay").show();
     $("#divFee").show();
     $("#divSinPinTotal").hide();
     $("#xtraButtons").show();
     $("#tigoFlags").show();
     $("#digicelFlags").hide();
     $("#claroFlags").hide();
     $("#ddotherServices").show();
     $("#shortCodes").show();

                document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
                var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
    select.add(new Option(7));
    select.add(new Option(9));
    select.add(new Option(10));
    select.add(new Option(12));
    select.add(new Option(15));
    select.add(new Option(18));
    select.add(new Option(20));
    select.add(new Option(25));
    select.add(new Option(30));

                document.getElementById('<%=ddOtherService.ClientID %>').options.length = 0;
                var select = document.getElementById('<%=ddOtherService.ClientID %>');
   select.add(new Option("Tigo TopUp", 1));
    select.add(new Option("PaqueTigo", 2));
}
           else if (document.getElementById('<%=ddProviders.ClientID %>').value == "20") {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
     document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/cubacellbutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').hide();
    $("#ConfPhone").hide();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
               document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
    $("#divBanner").hide();
     $("#SinPinBalance").hide();
     $("#pay").show();
     $("#divFee").show();
     $("#divSinPinTotal").hide();
     $("#xtraButtons").show();
     $("#tigoFlags").hide();
     $("#digicelFlags").hide();
     $("#claroFlags").hide();
     $("#ddotherServices").hide();
     $("#shortCodes").show();

                document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
                var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
    select.add(new Option(10));
    select.add(new Option(11));
    select.add(new Option(13));
    select.add(new Option(14));
    select.add(new Option(15));
    select.add(new Option(16));
    select.add(new Option(17));
    select.add(new Option(18));
    select.add(new Option(19));
    select.add(new Option(20));
    select.add(new Option(21));
    select.add(new Option(22));
    select.add(new Option(23));
    select.add(new Option(25));
    select.add(new Option(30));
    select.add(new Option(40));
    select.add(new Option(45));
    select.add(new Option(50));
}
           else if (document.getElementById('<%=ddProviders.ClientID %>').value == "21") {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
     document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/digicelbutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').hide();
    $("#ConfPhone").hide();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
               document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
    $("#divBanner").hide();
     $("#SinPinBalance").hide();
     $("#pay").show();
     $("#divFee").show();
     $("#divSinPinTotal").hide();
     $("#xtraButtons").show();
     $("#tigoFlags").hide();
     $("#digicelFlags").show();
     $("#claroFlags").hide();
     $("#ddotherServices").show();
     $("#shortCodes").show();

                document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
    var i = 1;

                var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
                for (i = 1; i < 101; i++)
                {
        select.add(new Option(i));
    }

                document.getElementById('<%=ddOtherService.ClientID %>').options.length = 0;
                var select = document.getElementById('<%=ddOtherService.ClientID %>');
   select.add(new Option("Digicel TopUp", 1));
   select.add(new Option("Bundle", 2));

}
           else if (document.getElementById('<%=ddProviders.ClientID %>').value == "22") {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
     document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/digicelbutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').hide();
    $("#ConfPhone").hide();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
               document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
    $("#divBanner").hide();
     $("#SinPinBalance").hide();
     $("#pay").show();
     $("#divFee").show();
     $("#divSinPinTotal").hide();
     $("#xtraButtons").show();
     $("#tigoFlags").hide();
     $("#digicelFlags").show();
     $("#claroFlags").hide();
     $("#ddotherServices").show();
     $("#shortCodes").show();

                document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
    var i = 1;

                var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
                for (i = 1; i < 101; i++)
                {
        select.add(new Option(i));
    }

                document.getElementById('<%=ddOtherService.ClientID %>').options.length = 0;
                var select = document.getElementById('<%=ddOtherService.ClientID %>');
   select.add(new Option("Digicel TopUp", 1));
   select.add(new Option("Bundle", 2));
}
           else if (document.getElementById('<%=ddProviders.ClientID %>').value == "23") {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/digicelbutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').hide();
    $("#ConfPhone").hide();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
               document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
    $("#divBanner").hide();
     $("#SinPinBalance").hide();
     $("#pay").show();
     $("#divFee").show();
     $("#divSinPinTotal").hide();
     $("#xtraButtons").show();
     $("#tigoFlags").hide();
     $("#digicelFlags").show();
     $("#claroFlags").hide();
     $("#ddotherServices").hide();
     $("#shortCodes").show();

                document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
    var i = 1;

                var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
                for (i = 1; i < 101; i++)
                {
        select.add(new Option(i));
    }

}
           else if (document.getElementById('<%=ddProviders.ClientID %>').value == "26") {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/clarobutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').hide();
    $("#ConfPhone").hide();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
               document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
    $("#divBanner").hide();
     $("#SinPinBalance").hide();
     $("#pay").show();
     $("#divFee").show();
     $("#divSinPinTotal").hide();
     $("#xtraButtons").show();
     $("#tigoFlags").hide();
     $("#digicelFlags").hide();
     $("#claroFlags").show();
     $("#ddotherServices").show();
     $("#shortCodes").show();

                document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
                var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
    select.add(new Option(4));
    select.add(new Option(5));
    select.add(new Option(6));
    select.add(new Option(7));
    select.add(new Option(8));
    select.add(new Option(9));
    select.add(new Option(10));
    select.add(new Option(11));
    select.add(new Option(12));
    select.add(new Option(13));
    select.add(new Option(14));
    select.add(new Option(15));
    select.add(new Option(16));
    select.add(new Option(17));
    select.add(new Option(18));
    select.add(new Option(19));
    select.add(new Option(20));
    select.add(new Option(21));
    select.add(new Option(22));
    select.add(new Option(23));
    select.add(new Option(24));
    select.add(new Option(25));
    select.add(new Option(26));
    select.add(new Option(27));
    select.add(new Option(28));
    select.add(new Option(29));
    select.add(new Option(30));
    select.add(new Option(35));
    select.add(new Option(40));
    select.add(new Option(45));
    select.add(new Option(50));

                document.getElementById('<%=ddOtherService.ClientID %>').options.length = 0;
                var select = document.getElementById('<%=ddOtherService.ClientID %>');
   select.add(new Option("Claro TopUp", 1));
   select.add(new Option("SuperPack", 2));

}
           else if (document.getElementById('<%=ddProviders.ClientID %>').value == "27") {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/clarobutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').hide();
    $("#ConfPhone").hide();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
               document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
    $("#divBanner").hide();
     $("#SinPinBalance").hide();
     $("#pay").show();
     $("#divFee").show();
     $("#divSinPinTotal").hide();
     $("#xtraButtons").show();
     $("#tigoFlags").hide();
     $("#digicelFlags").hide();
     $("#claroFlags").show();
     $("#ddotherServices").show();
     $("#shortCodes").show();

                document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
                var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
    select.add(new Option(4));
    select.add(new Option(5));
    select.add(new Option(6));
    select.add(new Option(7));
    select.add(new Option(8));
    select.add(new Option(9));
    select.add(new Option(10));
    select.add(new Option(11));
    select.add(new Option(12));
    select.add(new Option(13));
    select.add(new Option(14));
    select.add(new Option(15));
    select.add(new Option(16));
    select.add(new Option(17));
    select.add(new Option(18));
    select.add(new Option(19));
    select.add(new Option(20));
    select.add(new Option(21));
    select.add(new Option(22));
    select.add(new Option(23));
    select.add(new Option(24));
    select.add(new Option(25));
    select.add(new Option(26));
    select.add(new Option(27));
    select.add(new Option(28));
    select.add(new Option(29));
    select.add(new Option(30));
    select.add(new Option(35));
    select.add(new Option(40));
    select.add(new Option(45));
    select.add(new Option(50));


                document.getElementById('<%=ddOtherService.ClientID %>').options.length = 0;
                var select = document.getElementById('<%=ddOtherService.ClientID %>');
   select.add(new Option("Claro TopUp", 1));
   select.add(new Option("SuperPack", 2));
   select.add(new Option("Internet", 3));
}
           else if (document.getElementById('<%=ddProviders.ClientID %>').value == "28") {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/tigobutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').hide();
    $("#ConfPhone").hide();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
               document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
    $("#divBanner").hide();
     $("#SinPinBalance").hide();
     $("#pay").show();
     $("#divFee").show();
     $("#divSinPinTotal").hide();
     $("#xtraButtons").show();
     $("#tigoFlags").hide();
     $("#digicelFlags").hide();
     $("#claroFlags").show();
     $("#ddotherServices").show();
     $("#shortCodes").show();

                document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
                var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option(4));
    select.add(new Option(5));
    select.add(new Option(6));
    select.add(new Option(7));
    select.add(new Option(8));
    select.add(new Option(9));
    select.add(new Option(10));
    select.add(new Option(11));
    select.add(new Option(12));
    select.add(new Option(13));
    select.add(new Option(14));
    select.add(new Option(15));
    select.add(new Option(16));
    select.add(new Option(17));
    select.add(new Option(18));
    select.add(new Option(19));
    select.add(new Option(20));
    select.add(new Option(21));
    select.add(new Option(22));
    select.add(new Option(23));
    select.add(new Option(24));
    select.add(new Option(25));
    select.add(new Option(26));
    select.add(new Option(27));
    select.add(new Option(28));
    select.add(new Option(29));
    select.add(new Option(30));
    select.add(new Option(35));
    select.add(new Option(40));
    select.add(new Option(45));
    select.add(new Option(50));


                document.getElementById('<%=ddOtherService.ClientID %>').options.length = 0;
                var select = document.getElementById('<%=ddOtherService.ClientID %>');
    select.add(new Option("Claro TopUp", 1));
    select.add(new Option("SuperPack", 2));
}
           else if (document.getElementById('<%=ddProviders.ClientID %>').value == "32") {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/flowbutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').hide();
    $("#ConfPhone").hide();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
               document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
    $("#divBanner").hide();
     $("#SinPinBalance").hide();
     $("#pay").show();
     $("#divFee").show();
     $("#divSinPinTotal").hide
     $("#xtraButtons").show();
     $("#tigoFlags").hide();
     $("#digicelFlags").hide();
     $("#claroFlags").hide();
     $("#ddotherServices").hide();
     $("#shortCodes").show();

                document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
    var i = 1;

                var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
                for (i = 1; i < 101; i++)
                {
        select.add(new Option(i));
    }
}
           else if (document.getElementById('<%=ddProviders.ClientID %>').value == "33") {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/guatepinbutton.png' width='15%' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "<a href='' data-toggle='modal' data-target='#myModal8'>Numero de accesso</a> / <a href='http://www.guatepin.com' target='_blank'>Rates</a>";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').show();
   $("#ConfPhone").hide();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
    $("#divBanner").hide();
    $("#SinPinBalance").show();
    $("#pay").hide();
    $("#divFee").hide();
    $("#divSinPinTotal").show();
    $("#xtraButtons").hide();
    $("#tigoFlags").hide();
    $("#digicelFlags").hide();
    $("#claroFlags").hide();
    $("#ddotherServices").hide();
    $("#shortCodes").hide();

                $('#popupBtn').click(function (e) {
                    var numb = document.getElementById('<%=txtPhone.ClientID %>').value;
                document.getElementById('<%=lbBalance.ClientID %>').innerHTML = "<iframe src='SinPinBalance.aspx?GuatePin=" + numb + "' width='150px' height='25px' frameborder='0' scrolling='no'></iframe>";

                var num = parseFloat(document.getElementById('<%=txtAmount.ClientID %>').value);
                    document.getElementById('<%=lbtotal2.ClientID %>').innerHTML = num.toFixed(2);

});


}
           else if (document.getElementById('<%=ddProviders.ClientID %>').value == "35") {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/net10button.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').hide();
    $("#ConfPhone").hide();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
               document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
    $("#divBanner").hide();
    $("#SinPinBalance").hide();
    $("#pay").show();
    $("#divFee").show();
    $("#divSinPinTotal").hide();
    $("#xtraButtons").show();
    $("#tigoFlags").hide();
    $("#digicelFlags").hide();
    $("#claroFlags").hide();
    $("#ddotherServices").hide();
    $("#shortCodes").hide();

                document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
               var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
     select.add(new Option(25));
     select.add(new Option(30));
     select.add(new Option(35));
     select.add(new Option(40));
     select.add(new Option(50));
     select.add(new Option(60));
     select.add(new Option(65));

}
           else if (document.getElementById('<%=ddProviders.ClientID %>').value == "36") {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/easygobutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').hide();
    $("#ConfPhone").hide();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
               document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
    $("#divBanner").hide();
    $("#SinPinBalance").hide();
    $("#pay").show();
    $("#divFee").show();
    $("#divSinPinTotal").hide();
    $("#xtraButtons").show();
    $("#tigoFlags").hide();
    $("#digicelFlags").hide();
    $("#claroFlags").hide();
    $("#ddotherServices").hide();
    $("#shortCodes").hide();

                document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
               var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
     select.add(new Option(20));
     select.add(new Option(30));
     select.add(new Option(35));

}
                else if (document.getElementById('<%=ddProviders.ClientID %>').value == "37") {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/gosmartbutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').hide();
    $("#ConfPhone").show();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
    $("#divBanner").hide();
    $("#SinPinBalance").hide();
    $("#pay").show();
    $("#divFee").show();
    $("#divSinPinTotal").hide();
    $("#xtraButtons").show();
    $("#tigoFlags").hide();
    $("#digicelFlags").hide();
    $("#claroFlags").hide();
    $("#ddotherServices").hide();
    $("#shortCodes").hide();

                document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
                var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
    select.add(new Option(25));
    select.add(new Option(35));
    select.add(new Option(45));
    select.add(new Option(55));
    select.add(new Option(65));

    }
               else if (document.getElementById('<%=ddProviders.ClientID %>').value == "38") {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/natcombutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').hide();
    $("#ConfPhone").hide();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
               document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
    $("#divBanner").hide();
     $("#SinPinBalance").hide();
     $("#pay").show();
     $("#divFee").show();
     $("#divSinPinTotal").hide
     $("#xtraButtons").show();
     $("#tigoFlags").hide();
     $("#digicelFlags").hide();
     $("#claroFlags").hide();
     $("#ddotherServices").hide();
     $("#shortCodes").show();

                document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
    var i = 2;

                var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
                for (i = 2; i < 31; i++)
                {
        select.add(new Option(i));
    }
}
 else if (document.getElementById('<%=ddProviders.ClientID %>').value == "39") {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/telcelbutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').hide();
    $("#ConfPhone").hide();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
               document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
    $("#divBanner").hide();
     $("#SinPinBalance").hide();
     $("#pay").show();
     $("#divFee").show();
     $("#divSinPinTotal").hide
     $("#xtraButtons").show();
     $("#tigoFlags").hide();
     $("#digicelFlags").hide();
     $("#claroFlags").hide();
     $("#ddotherServices").hide();
     $("#shortCodes").show();

                document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
                var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
    select.add(new Option(1));
    select.add(new Option(2));
    select.add(new Option(3));
    select.add(new Option(5));
    select.add(new Option(10));
    select.add(new Option(15));
    select.add(new Option(20));
    select.add(new Option(30));
    select.add(new Option(50));
}
            else if (document.getElementById('<%=ddProviders.ClientID %>').value == "0") {
        $("#divShowTextbox").hide();
    document.getElementById("message").innerHTML = "Select Provider";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
}
}

        $(document).ready(function () {
        $(function () {
            $('#<%=txtPin.ClientID %>').hide();
            $(window).bind("resize", function () {
                console.log($(this).width())
                if ($(this).width() < 500) {
                    $("#divBanner").hide();
                    $('#ProviderIcon').css("display", "none");
                    $('#divPay').css("width", "100%");
                }
                else {
                    $("#divBanner").show();
                    $('#ProviderIcon').css("display", "block");
                    $('#divPay').css("width", "350px");
                }
            })
        })

            var windowWidth = window.screen.width < window.outerWidth ?
    window.screen.width : window.outerWidth;
            var mobile = windowWidth < 500;
            if (mobile) {
        $("#divBanner").hide();
    $('#ProviderIcon').css("display", "none");
    $('#divPay').css("width", "100%");
}



            $('#metro').click(function (e) {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/metrobutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                document.getElementById('<%=ddProviders.ClientID %>').value = "1";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').show();
    $("#ConfPhone").show();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
                document.getElementById('<%=lbinto2.ClientID %>').innerHTML = document.getElementById('<%=hfLastPaid.ClientID %>').value;
    $("#divBanner").hide();
    $("#SinPinBalance").hide();
    $("#pay").show();
    $("#divFee").show();
    $("#divSinPinTotal").hide();
    $("#xtraButtons").hide();
                $('<%=txtAmount.ClientID %>').show();
    $("#tigoFlags").hide();
    $("#digicelFlags").hide();
    $("#claroFlags").hide();
    $("#ddotherServices").hide();
    $("#shortCodes").hide();

});
            $('#cricket').click(function (e) {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/cricketbutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "2 - 29 days late additional fee = $5.00 <br /> 29-59 days late additional fee = $15.00";
                document.getElementById('<%=ddProviders.ClientID %>').value = "2";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').show();
    $("#ConfPhone").show();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
                document.getElementById('<%=lbinto2.ClientID %>').innerHTML = document.getElementById('<%=hfLastPaid.ClientID %>').value;
    $("#divBanner").hide();
    $("#SinPinBalance").hide();
    $("#pay").show();
    $("#divFee").show();
    $("#divSinPinTotal").hide();
    $("#xtraButtons").hide();
    $("#tigoFlags").hide();
    $("#digicelFlags").hide();
    $("#claroFlags").hide();
    $("#ddotherServices").hide();
    $("#shortCodes").hide();

});
              $('#boost').click(function (e) {
        $("#divShowTextbox").show();
    $("#divGetPin").show();
                  $('#<%=txtPin.ClientID %>').show();
  document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/boostbutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                  document.getElementById("divGetPin").innerHTML = "<a href='' role='button' id='btnforgotpin' class='form-control btn btn-warning btn-lg' data-toggle='modal' data-target='#myModal4'>Send Pin | Mandar Pin</a>";
                document.getElementById('<%=ddProviders.ClientID %>').value = "3";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').show();
    $("#ConfPhone").show();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
                document.getElementById('<%=lbinto2.ClientID %>').innerHTML = document.getElementById('<%=hfLastPaid.ClientID %>').value;
    $("#divBanner").hide();
    $("#SinPinBalance").hide();
    $("#pay").show();
    $("#divFee").show();
    $("#divSinPinTotal").hide();
    $("#xtraButtons").hide();
    $("#tigoFlags").hide();
    $("#digicelFlags").hide();
    $("#claroFlags").hide();
    $("#ddotherServices").hide();
    $("#shortCodes").hide();

     
                  $('#btnSendPin').click(function (e) {
        document.getElementById('<%=txtBoostNumber.ClientID %>').innerHTML = document.getElementById('<%=txtPhoneConf.ClientID %>').value;
    var numb = document.getElementById('<%=txtBoostNumber.ClientID %>').value;
                    document.getElementById('<%=lbPin.ClientID %>').innerHTML = "<iframe src='SinPinBalance.aspx?boost=" + numb + "' width='400px' height='25px' frameborder='0' scrolling='no'></iframe>";
  });

});
              $('#sinpin').click(function (e) {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
					$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                    document.getElementById('<%=txtAmount.ClientID %>').value = "";
                    document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                    document.getElementById("message").innerHTML = "<img src='Img/sinpinbutton.png' /><br /><br />";
                    document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "<a href='' data-toggle='modal' data-target='#myModal5'>Numero de acceso</a> / <a href='https://sinpin.com/home/rates' target='_blank'>Rates</a>";
                    document.getElementById('<%=ddProviders.ClientID %>').value = "4";
                    document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                  $('#<%=txtAmount.ClientID %>').show();
      $("#ConfPhone").hide();
                    document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
                    document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
                    document.getElementById('<%=lbinto2.ClientID %>').innerHTML = "";
  $("#divBanner").hide();
    $("#SinPinBalance").show();
    $("#pay").hide();
    $("#divFee").hide();
    $("#divSinPinTotal").show();
    $("#xtraButtons").hide();
    $("#tigoFlags").hide();
    $("#digicelFlags").hide();
    $("#claroFlags").hide();
    $("#ddotherServices").hide();
    $("#shortCodes").hide();


                $('#popupBtn').click(function (e) {
                    var numb = document.getElementById('<%=txtPhone.ClientID %>').value;
                document.getElementById('<%=lbBalance.ClientID %>').innerHTML = "<iframe src='SinPinBalance.aspx?phone=" + numb + "' width='150px' height='25px' frameborder='0' scrolling='no'></iframe>";

                var num = parseFloat(document.getElementById('<%=txtAmount.ClientID %>').value);
                    document.getElementById('<%=lbtotal2.ClientID %>').innerHTML = num.toFixed(2);

});

});
             $('#dp').click(function (e) {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/dpbutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "<a href='' data-toggle='modal' data-target='#myModal6'>Numero de accesso</a> / <a href='https://www.dollarphonepinless.com/phone-rates' target='_blank'>Rates</a>";
                document.getElementById('<%=ddProviders.ClientID %>').value = "5";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').show();
    $("#ConfPhone").show();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
                document.getElementById('<%=lbinto2.ClientID %>').innerHTML = "";
     $("#divBanner").hide();
    $("#SinPinBalance").show();
    $("#pay").hide();
    $("#divFee").hide();
    $("#divSinPinTotal").show();
    $("#xtraButtons").hide();
    $("#tigoFlags").hide();
    $("#digicelFlags").hide();
    $("#claroFlags").hide();
    $("#ddotherServices").hide();
    $("#shortCodes").hide();


                $('#popupBtn').click(function (e) {
                    var numb = document.getElementById('<%=txtPhone.ClientID %>').value;
                document.getElementById('<%=lbBalance.ClientID %>').innerHTML = "<iframe src='SinPinBalance.aspx?DP=" + numb + "' width='150px' height='25px' frameborder='0' scrolling='no'></iframe>";

                var num = parseFloat(document.getElementById('<%=txtAmount.ClientID %>').value);
                    document.getElementById('<%=lbtotal2.ClientID %>').innerHTML = num.toFixed(2);

});

});

                $('#simple').click(function (e) {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
					$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                    document.getElementById('<%=txtAmount.ClientID %>').value = "";
                    document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                    document.getElementById("message").innerHTML = "<img src='Img/simplebutton.png' /><br /><br />";
                    document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                    document.getElementById('<%=ddProviders.ClientID %>').value = "6";
                    document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                    $('#<%=txtAmount.ClientID %>').hide();
    $("#ConfPhone").show();
                    document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
                    document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
                    document.getElementById('<%=lbinto2.ClientID %>').innerHTML = document.getElementById('<%=hfLastPaid.ClientID %>').value;
    $("#divBanner").hide();
    $("#SinPinBalance").hide();
    $("#pay").show();
    $("#divFee").show();
    $("#divSinPinTotal").hide();
    $("#xtraButtons").show();
    $("#tigoFlags").hide();
    $("#digicelFlags").hide();
    $("#claroFlags").hide();
    $("#ddotherServices").hide();
    $("#shortCodes").hide();

                document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
                var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
    select.add(new Option(25));
    select.add(new Option(30));
    select.add(new Option(40));
    select.add(new Option(50));
    select.add(new Option(60));

  });

                $('#h2o').click(function (e) {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/h2obutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                document.getElementById('<%=ddProviders.ClientID %>').value = "7";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').hide();
    $("#ConfPhone").show();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
                document.getElementById('<%=lbinto2.ClientID %>').innerHTML = document.getElementById('<%=hfLastPaid.ClientID %>').value;
    $("#divBanner").hide();
    $("#SinPinBalance").hide();
    $("#pay").show();
    $("#divFee").show();
    $("#divSinPinTotal").hide();
    $("#xtraButtons").show();
    $("#tigoFlags").hide();
    $("#digicelFlags").hide();
    $("#claroFlags").hide();
    $("#ddotherServices").hide();
    $("#shortCodes").hide();

                document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
                var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
   
    select.add(new Option(25));
    select.add(new Option(30));
    select.add(new Option(35));
    select.add(new Option(40));
    select.add(new Option(50));
    select.add(new Option(60));
    select.add(new Option(65));


    });

           $('#ultra').click(function (e) {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/ultrabutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                document.getElementById('<%=ddProviders.ClientID %>').value = "8";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').hide();
    $("#ConfPhone").show();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
                document.getElementById('<%=lbinto2.ClientID %>').innerHTML = document.getElementById('<%=hfLastPaid.ClientID %>').value;
    $("#divBanner").hide();
    $("#SinPinBalance").hide();
    $("#pay").show();
    $("#divFee").show();
    $("#divSinPinTotal").hide();
    $("#xtraButtons").show();
    $("#tigoFlags").hide();
    $("#digicelFlags").hide();
    $("#claroFlags").hide();
    $("#ddotherServices").hide();
    $("#shortCodes").hide();

                document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
                var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
    select.add(new Option(11));
    select.add(new Option(12));
    select.add(new Option(13));
    select.add(new Option(16));
    select.add(new Option(19));
    select.add(new Option(20));
    select.add(new Option(21));
    select.add(new Option(22));
    select.add(new Option(24));
    select.add(new Option(25));
    select.add(new Option(26));
    select.add(new Option(27));
    select.add(new Option(29));
    select.add(new Option(30));
    select.add(new Option(31));
    select.add(new Option(33));
    select.add(new Option(34));
    select.add(new Option(35));
    select.add(new Option(36));
    select.add(new Option(37));
    select.add(new Option(39));
    select.add(new Option(40));
    select.add(new Option(41));
    select.add(new Option(44));
    select.add(new Option(45));
    select.add(new Option(46));
    select.add(new Option(47));
    select.add(new Option(49));
    select.add(new Option(50));
    select.add(new Option(51));
    select.add(new Option(55));
    select.add(new Option(56));
    select.add(new Option(60));
    select.add(new Option(61));
    select.add(new Option(65));
    select.add(new Option(66));
    select.add(new Option(70));
    select.add(new Option(71));
    select.add(new Option(75));
    select.add(new Option(76));
    select.add(new Option(80));
    select.add(new Option(81));
    select.add(new Option(85));
    select.add(new Option(86));
    select.add(new Option(90));
    select.add(new Option(100));

  });
            $('#lyca').click(function (e) {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/lycabutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                document.getElementById('<%=ddProviders.ClientID %>').value = "9";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').hide();
    $("#ConfPhone").show();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
                document.getElementById('<%=lbinto2.ClientID %>').innerHTML = document.getElementById('<%=hfLastPaid.ClientID %>').value;
    $("#divBanner").hide();
    $("#SinPinBalance").hide();
    $("#pay").show();
    $("#divFee").show();
    $("#divSinPinTotal").hide();
    $("#xtraButtons").show();
    $("#tigoFlags").hide();
    $("#digicelFlags").hide();
    $("#claroFlags").hide();
    $("#ddotherServices").hide();
    $("#shortCodes").hide();

                document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
                var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
    select.add(new Option(30));
    select.add(new Option(36));
    select.add(new Option(40));
    select.add(new Option(46));
    select.add(new Option(50));
    select.add(new Option(56));
    select.add(new Option(60));

  });
            $('#att').click(function (e) {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
			   $('#<%=txtPin.ClientID %>').hide();
     document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/attbutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                document.getElementById('<%=ddProviders.ClientID %>').value = "10";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').hide();
    $("#ConfPhone").show();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
                document.getElementById('<%=lbinto2.ClientID %>').innerHTML = document.getElementById('<%=hfLastPaid.ClientID %>').value;
    $("#divBanner").hide();
    $("#SinPinBalance").hide();
    $("#pay").show();
    $("#divFee").show();
    $("#divSinPinTotal").hide();
    $("#xtraButtons").show();
    $("#tigoFlags").hide();
    $("#digicelFlags").hide();
    $("#claroFlags").hide();
    $("#ddotherServices").hide();
    $("#shortCodes").hide();

                document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
                var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
    //DP
    //select.add(new Option(10));
    //select.add(new Option(12));
    //select.add(new Option(15));
    //select.add(new Option(20));
    //select.add(new Option(30));
    //select.add(new Option(35));
    //select.add(new Option(40));
    //select.add(new Option(45));
    //select.add(new Option(50));
    //select.add(new Option(55));
    //select.add(new Option(60));
    //select.add(new Option(65));
    //select.add(new Option(70));
    //select.add(new Option(75));
    //select.add(new Option(80));
    //select.add(new Option(85));
    //select.add(new Option(90));
    //select.add(new Option(100));

    //reup
    select.add(new Option(10));
    select.add(new Option(15));
    select.add(new Option(20));
    select.add(new Option(25));
    select.add(new Option(30));
    select.add(new Option(35));
    select.add(new Option(40));
    select.add(new Option(45));
    select.add(new Option(50));
    select.add(new Option(60));
    select.add(new Option(65));
    select.add(new Option(70));
    select.add(new Option(75));
    select.add(new Option(80));
    select.add(new Option(85));
    select.add(new Option(100));
});
            $('#tmobile').click(function (e) {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/tmobilebutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "Amount Allowed: $10 - $100";
                document.getElementById('<%=ddProviders.ClientID %>').value = "11";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').show();
    $("#ConfPhone").show();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
                document.getElementById('<%=lbinto2.ClientID %>').innerHTML = document.getElementById('<%=hfLastPaid.ClientID %>').value;
    $("#divBanner").hide();
    $("#SinPinBalance").hide();
    $("#pay").show();
    $("#divFee").show();
    $("#divSinPinTotal").hide();
    $("#xtraButtons").hide();
    $("#tigoFlags").hide();
    $("#digicelFlags").hide();
    $("#claroFlags").hide();
    $("#ddotherServices").hide();
    $("#shortCodes").hide();

});
            $('#verison').click(function (e) {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/verisonbutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                document.getElementById('<%=ddProviders.ClientID %>').value = "12";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').hide();
    $("#ConfPhone").show();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
                document.getElementById('<%=lbinto2.ClientID %>').innerHTML = document.getElementById('<%=hfLastPaid.ClientID %>').value;
    $("#divBanner").hide();
    $("#SinPinBalance").hide();
    $("#pay").show();
    $("#divFee").show();
    $("#divSinPinTotal").hide();
    $("#xtraButtons").show();
    $("#tigoFlags").hide();
    $("#digicelFlags").hide();
    $("#claroFlags").hide();
    $("#ddotherServices").hide();
    $("#shortCodes").hide();

                document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
                var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
    select.add(new Option(15));
    select.add(new Option(20));
    select.add(new Option(25));
    select.add(new Option(30));
    select.add(new Option(35));
    select.add(new Option(40));
    select.add(new Option(45));
    select.add(new Option(50));
    select.add(new Option(55));
    select.add(new Option(60));
    select.add(new Option(65));
    select.add(new Option(70));
    select.add(new Option(80));
    select.add(new Option(100));
    select.add(new Option(150));
  
});

                $('#tigo').click(function (e) {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/tigobutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                document.getElementById('<%=ddProviders.ClientID %>').value = "13";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').hide();
    $("#ConfPhone").hide();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
                document.getElementById('<%=lbinto2.ClientID %>').innerHTML = document.getElementById('<%=hfLastPaid.ClientID %>').value;
    $("#divBanner").hide();
    $("#SinPinBalance").hide();
    $("#pay").show();
    $("#divFee").show();
    $("#divSinPinTotal").hide();
    $("#xtraButtons").show();
    $("#tigoFlags").show();
    $("#digicelFlags").hide();
    $("#claroFlags").hide();
    $("#ddotherServices").show();
    $("#shortCodes").show();

                document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
                var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
    select.add(new Option(7));
    select.add(new Option(10));
    select.add(new Option(12));
    select.add(new Option(14));
    select.add(new Option(15));
    select.add(new Option(20));
    select.add(new Option(25));
    select.add(new Option(30));

    });

            $('#tigoguate').click(function (e) {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/tigobutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                document.getElementById('<%=ddProviders.ClientID %>').value = "13";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').hide();
    $("#ConfPhone").hide();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
                document.getElementById('<%=lbinto2.ClientID %>').innerHTML = document.getElementById('<%=hfLastPaid.ClientID %>').value;
    $("#divBanner").hide();
    $("#SinPinBalance").hide();
    $("#pay").show();
    $("#divFee").show();
    $("#divSinPinTotal").hide();
    $("#xtraButtons").show();
    $("#tigoFlags").show();
    $("#digicelFlags").hide();
    $("#claroFlags").hide();
    $("#ddotherServices").show();
    $("#shortCodes").show();

                document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
                var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
    select.add(new Option(7));
    select.add(new Option(10));
    select.add(new Option(12));
    select.add(new Option(14));
    select.add(new Option(15));
    select.add(new Option(20));
    select.add(new Option(25));
    select.add(new Option(30));

                document.getElementById('<%=ddOtherService.ClientID %>').options.length = 0;
                var select = document.getElementById('<%=ddOtherService.ClientID %>');
    select.add(new Option("Tigo TopUp", 1));
    select.add(new Option("PaqueTigo", 2));
    select.add(new Option("Internet", 3));
   

});

              $('#tigosal').click(function (e) {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/tigobutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                document.getElementById('<%=ddProviders.ClientID %>').value = "14";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').hide();
    $("#ConfPhone").hide();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
                document.getElementById('<%=lbinto2.ClientID %>').innerHTML = document.getElementById('<%=hfLastPaid.ClientID %>').value;
    $("#divBanner").hide();
    $("#SinPinBalance").hide();
    $("#pay").show();
    $("#divFee").show();
    $("#divSinPinTotal").hide();
    $("#xtraButtons").show();
    $("#tigoFlags").show();
    $("#digicelFlags").hide();
    $("#claroFlags").hide();
    $("#ddotherServices").show();
    $("#shortCodes").show();

                document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
                var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
    select.add(new Option(5));
    select.add(new Option(6));
    select.add(new Option(7));
    select.add(new Option(9));
    select.add(new Option(10));
    select.add(new Option(12));
    select.add(new Option(14));
    select.add(new Option(15));
    select.add(new Option(20));
    select.add(new Option(22));
    select.add(new Option(25));
    select.add(new Option(30));
    select.add(new Option(40));


                document.getElementById('<%=ddOtherService.ClientID %>').options.length = 0;
                var select = document.getElementById('<%=ddOtherService.ClientID %>');
      select.add(new Option("Tigo TopUp", 1));
    select.add(new Option("PaqueTigo", 2));

  });


              $('#tigohon').click(function (e) {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/tigobutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                document.getElementById('<%=ddProviders.ClientID %>').value = "15";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').hide();
    $("#ConfPhone").hide();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
                document.getElementById('<%=lbinto2.ClientID %>').innerHTML = document.getElementById('<%=hfLastPaid.ClientID %>').value;
    $("#divBanner").hide();
    $("#SinPinBalance").hide();
    $("#pay").show();
    $("#divFee").show();
    $("#divSinPinTotal").hide();
    $("#xtraButtons").show();
    $("#tigoFlags").show();
    $("#digicelFlags").hide();
    $("#claroFlags").hide();
    $("#ddotherServices").show();
    $("#shortCodes").show();

                document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
                var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
    select.add(new Option(7));
    select.add(new Option(9));
    select.add(new Option(10));
    select.add(new Option(12));
    select.add(new Option(15));
    select.add(new Option(18));
    select.add(new Option(20));
    select.add(new Option(25));
    select.add(new Option(30));

                document.getElementById('<%=ddOtherService.ClientID %>').options.length = 0;
                var select = document.getElementById('<%=ddOtherService.ClientID %>');
      select.add(new Option("Tigo TopUp", 1));
    select.add(new Option("PaqueTigo", 2));

  });
              $('#cubacell').click(function (e) {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/cubacellbutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                document.getElementById('<%=ddProviders.ClientID %>').value = "20";
                $('#<%=txtAmount.ClientID %>').hide();
    $("#ConfPhone").hide();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
               document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
    $("#divBanner").hide();
     $("#SinPinBalance").hide();
     $("#pay").show();
     $("#divFee").show();
     $("#divSinPinTotal").hide
     $("#xtraButtons").show();
     $("#tigoFlags").hide();
     $("#digicelFlags").hide();
     $("#claroFlags").hide();
     $("#ddotherServices").hide();
     $("#shortCodes").show();

                document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
                var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
    select.add(new Option(10));
    select.add(new Option(11));
    select.add(new Option(13));
    select.add(new Option(14));
    select.add(new Option(15));
    select.add(new Option(16));
    select.add(new Option(17));
    select.add(new Option(18));
    select.add(new Option(19));
    select.add(new Option(20));
    select.add(new Option(21));
    select.add(new Option(22));
    select.add(new Option(23));
    select.add(new Option(25));
    select.add(new Option(30));
    select.add(new Option(40));
    select.add(new Option(45));
    select.add(new Option(50));
  });
             $('#digicel').click(function (e) {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/digicelbutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                document.getElementById('<%=ddProviders.ClientID %>').value = "21";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').hide();
    $("#ConfPhone").hide();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
                document.getElementById('<%=lbinto2.ClientID %>').innerHTML = document.getElementById('<%=hfLastPaid.ClientID %>').value;
    $("#divBanner").hide();
    $("#SinPinBalance").hide();
    $("#pay").show();
    $("#divFee").show();
    $("#divSinPinTotal").hide();
    $("#xtraButtons").show();
    $("#tigoFlags").hide();
    $("#digicelFlags").show();
    $("#claroFlags").hide();
    $("#ddotherServices").show();
    $("#shortCodes").show();

                document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
    var i = 1;

                var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
                for (i = 1; i < 101; i++)
                {
        select.add(new Option(i));
    }

                document.getElementById('<%=ddOtherService.ClientID %>').options.length = 0;
                var select = document.getElementById('<%=ddOtherService.ClientID %>');
   select.add(new Option("Digicel TopUp", 1));
   select.add(new Option("Bundle", 2));

  });
              $('#digicelHaiti').click(function (e) {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/digicelbutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                document.getElementById('<%=ddProviders.ClientID %>').value = "21";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').hide();
    $("#ConfPhone").hide();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
                document.getElementById('<%=lbinto2.ClientID %>').innerHTML = document.getElementById('<%=hfLastPaid.ClientID %>').value;
    $("#divBanner").hide();
    $("#SinPinBalance").hide();
    $("#pay").show();
    $("#divFee").show();
    $("#divSinPinTotal").hide();
    $("#xtraButtons").show();
    $("#tigoFlags").hide();
    $("#digicelFlags").show();
    $("#claroFlags").hide();
    $("#ddotherServices").show();
    $("#shortCodes").show();

                document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
    var i = 1;

                var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
                for (i = 1; i < 101; i++)
                {
        select.add(new Option(i));
    }

                document.getElementById('<%=ddOtherService.ClientID %>').options.length = 0;
                var select = document.getElementById('<%=ddOtherService.ClientID %>');
   select.add(new Option("Digicel TopUp", 1));
   select.add(new Option("Bundle", 2));

  });
            $('#digicelElSalvador').click(function (e) {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/digicelbutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                document.getElementById('<%=ddProviders.ClientID %>').value = "22";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').hide();
    $("#ConfPhone").hide();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
                document.getElementById('<%=lbinto2.ClientID %>').innerHTML = document.getElementById('<%=hfLastPaid.ClientID %>').value;
    $("#divBanner").hide();
    $("#SinPinBalance").hide();
    $("#pay").show();
    $("#divFee").show();
    $("#divSinPinTotal").hide();
    $("#xtraButtons").show();
    $("#tigoFlags").hide();
    $("#digicelFlags").show();
    $("#claroFlags").hide();
    $("#ddotherServices").show();
    $("#shortCodes").show();

                document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
    var i = 1;

                var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
                for (i = 1; i < 101; i++)
                {
        select.add(new Option(i));
    }

                document.getElementById('<%=ddOtherService.ClientID %>').options.length = 0;
                var select = document.getElementById('<%=ddOtherService.ClientID %>');
   select.add(new Option("Digicel TopUp", 1));
   select.add(new Option("Bundle", 2));

});
             $('#digicelJamaica').click(function (e) {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/digicelbutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                document.getElementById('<%=ddProviders.ClientID %>').value = "23";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').hide();
    $("#ConfPhone").hide();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
                document.getElementById('<%=lbinto2.ClientID %>').innerHTML = document.getElementById('<%=hfLastPaid.ClientID %>').value;
    $("#divBanner").hide();
    $("#SinPinBalance").hide();
    $("#pay").show();
    $("#divFee").show();
    $("#divSinPinTotal").hide();
    $("#xtraButtons").show();
    $("#tigoFlags").hide();
    $("#digicelFlags").show();
    $("#claroFlags").hide();
    $("#ddotherServices").hide();
    $("#shortCodes").show();

                document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
    var i = 1;

                var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
                for (i = 1; i < 101; i++)
                {
        select.add(new Option(i));

    }



 });
             $('#claro').click(function (e) {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/clarobutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                document.getElementById('<%=ddProviders.ClientID %>').value = "26";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').hide();
    $("#ConfPhone").hide();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
                document.getElementById('<%=lbinto2.ClientID %>').innerHTML = document.getElementById('<%=hfLastPaid.ClientID %>').value;
    $("#divBanner").hide();
    $("#SinPinBalance").hide();
    $("#pay").show();
    $("#divFee").show();
    $("#divSinPinTotal").hide();
    $("#xtraButtons").show();
    $("#tigoFlags").hide();
    $("#digicelFlags").hide();
    $("#claroFlags").show();
    $("#ddotherServices").show();
    $("#shortCodes").show();

                document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
                var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
    select.add(new Option(4));
    select.add(new Option(5));
    select.add(new Option(6));
    select.add(new Option(7));
    select.add(new Option(8));
    select.add(new Option(9));
    select.add(new Option(10));
    select.add(new Option(11));
    select.add(new Option(12));
    select.add(new Option(13));
    select.add(new Option(14));
    select.add(new Option(15));
    select.add(new Option(16));
    select.add(new Option(17));
    select.add(new Option(18));
    select.add(new Option(19));
    select.add(new Option(20));
    select.add(new Option(21));
    select.add(new Option(22));
    select.add(new Option(23));
    select.add(new Option(24));
    select.add(new Option(25));
    select.add(new Option(26));
    select.add(new Option(27));
    select.add(new Option(28));
    select.add(new Option(29));
    select.add(new Option(30));
    select.add(new Option(35));
    select.add(new Option(40));
    select.add(new Option(45));
    select.add(new Option(50));


                document.getElementById('<%=ddOtherService.ClientID %>').options.length = 0;
                var select = document.getElementById('<%=ddOtherService.ClientID %>');
   select.add(new Option("Claro TopUp", 1));
   select.add(new Option("SuperPack", 2));
   select.add(new Option("Internet", 3));
});
             $('#claroguate').click(function (e) {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/clarobutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                document.getElementById('<%=ddProviders.ClientID %>').value = "26";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').hide();
    $("#ConfPhone").hide();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
                document.getElementById('<%=lbinto2.ClientID %>').innerHTML = document.getElementById('<%=hfLastPaid.ClientID %>').value;
    $("#divBanner").hide();
    $("#SinPinBalance").hide();
    $("#pay").show();
    $("#divFee").show();
    $("#divSinPinTotal").hide();
    $("#xtraButtons").show();
    $("#tigoFlags").hide();
    $("#digicelFlags").hide();
    $("#claroFlags").show();
    $("#ddotherServices").show();
    $("#shortCodes").show();

                document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
                var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
    select.add(new Option(4));
    select.add(new Option(5));
    select.add(new Option(6));
    select.add(new Option(7));
    select.add(new Option(8));
    select.add(new Option(9));
    select.add(new Option(10));
    select.add(new Option(11));
    select.add(new Option(12));
    select.add(new Option(13));
    select.add(new Option(14));
    select.add(new Option(15));
    select.add(new Option(16));
    select.add(new Option(17));
    select.add(new Option(18));
    select.add(new Option(19));
    select.add(new Option(20));
    select.add(new Option(21));
    select.add(new Option(22));
    select.add(new Option(23));
    select.add(new Option(24));
    select.add(new Option(25));
    select.add(new Option(26));
    select.add(new Option(27));
    select.add(new Option(28));
    select.add(new Option(29));
    select.add(new Option(30));
    select.add(new Option(35));
    select.add(new Option(40));
    select.add(new Option(45));
    select.add(new Option(50));


                document.getElementById('<%=ddOtherService.ClientID %>').options.length = 0;
                var select = document.getElementById('<%=ddOtherService.ClientID %>');
   select.add(new Option("Claro TopUp", 1));
   select.add(new Option("SuperPack", 2));
   select.add(new Option("Internet", 3));

});

              $('#clarosal').click(function (e) {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/clarobutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                document.getElementById('<%=ddProviders.ClientID %>').value = "27";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').hide();
    $("#ConfPhone").hide();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
                document.getElementById('<%=lbinto2.ClientID %>').innerHTML = document.getElementById('<%=hfLastPaid.ClientID %>').value;
    $("#divBanner").hide();
    $("#SinPinBalance").hide();
    $("#pay").show();
    $("#divFee").show();
    $("#divSinPinTotal").hide();
    $("#xtraButtons").show();
    $("#tigoFlags").hide();
    $("#digicelFlags").hide();
    $("#claroFlags").show();
    $("#ddotherServices").show();
    $("#shortCodes").show();

                document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
                var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
    select.add(new Option(4));
    select.add(new Option(5));
    select.add(new Option(6));
    select.add(new Option(7));
    select.add(new Option(8));
    select.add(new Option(9));
    select.add(new Option(10));
    select.add(new Option(11));
    select.add(new Option(12));
    select.add(new Option(13));
    select.add(new Option(14));
    select.add(new Option(15));
    select.add(new Option(16));
    select.add(new Option(17));
    select.add(new Option(18));
    select.add(new Option(19));
    select.add(new Option(20));
    select.add(new Option(21));
    select.add(new Option(22));
    select.add(new Option(23));
    select.add(new Option(24));
    select.add(new Option(25));
    select.add(new Option(26));
    select.add(new Option(27));
    select.add(new Option(28));
    select.add(new Option(29));
    select.add(new Option(30));
    select.add(new Option(35));
    select.add(new Option(40));
    select.add(new Option(45));
    select.add(new Option(50));


                document.getElementById('<%=ddOtherService.ClientID %>').options.length = 0;
                var select = document.getElementById('<%=ddOtherService.ClientID %>');
   select.add(new Option("Claro TopUp", 1));
   select.add(new Option("SuperPack", 2));
   select.add(new Option("Internet", 3));

  });


              $('#clarohon').click(function (e) {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/clarobutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                document.getElementById('<%=ddProviders.ClientID %>').value = "28";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').hide();
    $("#ConfPhone").hide();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
                document.getElementById('<%=lbinto2.ClientID %>').innerHTML = document.getElementById('<%=hfLastPaid.ClientID %>').value;
    $("#divBanner").hide();
    $("#SinPinBalance").hide();
    $("#pay").show();
    $("#divFee").show();
    $("#divSinPinTotal").hide();
    $("#xtraButtons").show();
    $("#tigoFlags").hide();
    $("#digicelFlags").hide();
    $("#claroFlags").show();
    $("#ddotherServices").show();
    $("#shortCodes").show();

                document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
                var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
    select.add(new Option(4));
    select.add(new Option(5));
    select.add(new Option(6));
    select.add(new Option(7));
    select.add(new Option(8));
    select.add(new Option(9));
    select.add(new Option(10));
    select.add(new Option(11));
    select.add(new Option(12));
    select.add(new Option(13));
    select.add(new Option(14));
    select.add(new Option(15));
    select.add(new Option(16));
    select.add(new Option(17));
    select.add(new Option(18));
    select.add(new Option(19));
    select.add(new Option(20));
    select.add(new Option(21));
    select.add(new Option(22));
    select.add(new Option(23));
    select.add(new Option(24));
    select.add(new Option(25));
    select.add(new Option(26));
    select.add(new Option(27));
    select.add(new Option(28));
    select.add(new Option(29));
    select.add(new Option(30));
    select.add(new Option(35));
    select.add(new Option(40));
    select.add(new Option(45));
    select.add(new Option(50));


                document.getElementById('<%=ddOtherService.ClientID %>').options.length = 0;
                var select = document.getElementById('<%=ddOtherService.ClientID %>');
   select.add(new Option("Claro TopUp", 1));
   select.add(new Option("SuperPack", 2));
   select.add(new Option("Internet", 3));
  });
             $('#flow').click(function (e) {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/flowbutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                document.getElementById('<%=ddProviders.ClientID %>').value = "32";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').hide();
    $("#ConfPhone").hide();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
                document.getElementById('<%=lbinto2.ClientID %>').innerHTML = document.getElementById('<%=hfLastPaid.ClientID %>').value;
    $("#divBanner").hide();
    $("#SinPinBalance").hide();
    $("#pay").show();
    $("#divFee").show();
    $("#divSinPinTotal").hide();
    $("#xtraButtons").show();
    $("#tigoFlags").hide();
    $("#digicelFlags").hide();
    $("#claroFlags").hide();
    $("#ddotherServices").hide();
    $("#shortCodes").show();

                document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
    var i = 1;

                var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
                for (i = 1; i < 101; i++)
                {
        select.add(new Option(i));

    }
 });

           $('#guatepin').click(function (e) {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
               document.getElementById("message").innerHTML = "<img src='Img/guatepinbutton.png' width=100%' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "<a href='' data-toggle='modal' data-target='#myModal8'>Numero de accesso</a> / <a href='http://www.guatepin.com' target='_blank'>Rates</a>";
                document.getElementById('<%=ddProviders.ClientID %>').value = "33";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').show();
   $("#ConfPhone").hide();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
                document.getElementById('<%=lbinto2.ClientID %>').innerHTML = "";
     $("#divBanner").hide();
    $("#SinPinBalance").show();
    $("#pay").hide();
    $("#divFee").hide();
    $("#divSinPinTotal").show();
    $("#xtraButtons").hide();
    $("#tigoFlags").hide();
    $("#digicelFlags").hide();
    $("#claroFlags").hide();
    $("#ddotherServices").hide();
    $("#shortCodes").hide();


                $('#popupBtn').click(function (e) {
                    var numb = document.getElementById('<%=txtPhone.ClientID %>').value;
                document.getElementById('<%=lbBalance.ClientID %>').innerHTML = "<iframe src='SinPinBalance.aspx?GuatePin=" + numb + "' width='150px' height='25px' frameborder='0' scrolling='no'></iframe>";

                var num = parseFloat(document.getElementById('<%=txtAmount.ClientID %>').value);
                    document.getElementById('<%=lbtotal2.ClientID %>').innerHTML = num.toFixed(2);

});

});

              $('#net10').click(function (e) {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/net10button.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                document.getElementById('<%=ddProviders.ClientID %>').value = "35";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').hide();
    $("#ConfPhone").show();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
                document.getElementById('<%=lbinto2.ClientID %>').innerHTML = document.getElementById('<%=hfLastPaid.ClientID %>').value;
      $("#divBanner").hide();
      $("#SinPinBalance").hide();
      $("#pay").show();
      $("#divFee").show();
      $("#divSinPinTotal").hide();
      $("#xtraButtons").show();
      $("#tigoFlags").hide();
      $("#digicelFlags").hide();
      $("#claroFlags").hide();
      $("#ddotherServices").hide();
      $("#shortCodes").hide();

                document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
                var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
    select.add(new Option(25));
    select.add(new Option(30));
    select.add(new Option(35));
    select.add(new Option(40));
    select.add(new Option(50));
    select.add(new Option(60));
    select.add(new Option(65));
  });
              $('#easygo').click(function (e) {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                  document.getElementById("message").innerHTML = "<img src='Img/easygobutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                document.getElementById('<%=ddProviders.ClientID %>').value = "36";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').hide();
    $("#ConfPhone").show();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
                document.getElementById('<%=lbinto2.ClientID %>').innerHTML = document.getElementById('<%=hfLastPaid.ClientID %>').value;
      $("#divBanner").hide();
      $("#SinPinBalance").hide();
      $("#pay").show();
      $("#divFee").show();
      $("#divSinPinTotal").hide();
      $("#xtraButtons").show();
      $("#tigoFlags").hide();
      $("#digicelFlags").hide();
      $("#claroFlags").hide();
      $("#ddotherServices").hide();
      $("#shortCodes").hide();

                document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
                var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
    select.add(new Option(20));
    select.add(new Option(25));
    select.add(new Option(30));
  });
              $('#gosmart').click(function (e) {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                  document.getElementById("message").innerHTML = "<img src='Img/gosmartbutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                document.getElementById('<%=ddProviders.ClientID %>').value = "37";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').hide();
    $("#ConfPhone").show();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
                document.getElementById('<%=lbinto2.ClientID %>').innerHTML = document.getElementById('<%=hfLastPaid.ClientID %>').value;
    $("#divBanner").hide();
    $("#SinPinBalance").hide();
    $("#pay").show();
    $("#divFee").show();
    $("#divSinPinTotal").hide();
    $("#xtraButtons").show();
    $("#tigoFlags").hide();
    $("#digicelFlags").hide();
    $("#claroFlags").hide();
    $("#ddotherServices").hide();
    $("#shortCodes").hide();

                document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
                var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
    select.add(new Option(25));
    select.add(new Option(35));
    select.add(new Option(45));
    select.add(new Option(55));
    select.add(new Option(65));

  });
             $('#natcom').click(function (e) {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/natcombutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                document.getElementById('<%=ddProviders.ClientID %>').value = "38";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').hide();
    $("#ConfPhone").hide();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
                document.getElementById('<%=lbinto2.ClientID %>').innerHTML = document.getElementById('<%=hfLastPaid.ClientID %>').value;
    $("#divBanner").hide();
    $("#SinPinBalance").hide();
    $("#pay").show();
    $("#divFee").show();
    $("#divSinPinTotal").hide();
    $("#xtraButtons").show();
    $("#tigoFlags").hide();
    $("#digicelFlags").hide();
    $("#claroFlags").hide();
    $("#ddotherServices").hide();
    $("#shortCodes").show();

                document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
    var i = 2;

                var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
                for (i = 2; i < 31; i++)
                {
        select.add(new Option(i));

    }
 });
            $('#telcel').click(function (e) {
        $("#divShowTextbox").show();
    $("#divGetPin").hide();
				$('#<%=txtPin.ClientID %>').hide();
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=txtAmount.ClientID %>').value = "";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
                document.getElementById("message").innerHTML = "<img src='Img/telcelbutton.png' /><br /><br />";
                document.getElementById('<%=lbCricketFee.ClientID %>').innerHTML = "";
                document.getElementById('<%=ddProviders.ClientID %>').value = "39";
                document.getElementById('<%=txtAmount.ClientID %>').innerHTML = "";
                $('#<%=txtAmount.ClientID %>').hide();
    $("#ConfPhone").hide();
                document.getElementById('<%=txtPhoneConf.ClientID %>').innerHTML = "";
                document.getElementById('<%=txtPhone.ClientID %>').innerHTML = "";
                document.getElementById('<%=lbinto2.ClientID %>').innerHTML = document.getElementById('<%=hfLastPaid.ClientID %>').value;
    $("#divBanner").hide();
    $("#SinPinBalance").hide();
    $("#pay").show();
    $("#divFee").show();
    $("#divSinPinTotal").hide();
    $("#xtraButtons").show();
    $("#tigoFlags").hide();
    $("#digicelFlags").hide();
    $("#claroFlags").hide();
    $("#ddotherServices").hide();
    $("#shortCodes").show();

                document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
                var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
    select.add(new Option(1));
    select.add(new Option(2));
    select.add(new Option(3));
    select.add(new Option(5));
    select.add(new Option(10));
    select.add(new Option(15));
    select.add(new Option(20));
    select.add(new Option(30));
    select.add(new Option(50));
 });
});
        function ThreeDayGrace() {
        $(document).ready(function () {
            $("#<%=txtPhone.ClientID %>").autocomplete({
                source: function (request, response) {
                    $.ajax({
                        url: '<%=ResolveUrl("~/WebService.asmx/GetNumber") %>',
                        data: "{ 'prefix': '" + request.term + "'}",
                        dataType: "json",
                        type: "POST",
                        contentType: "application/json; charset=utf-8",
                        success: function (data) {
                            $('#<%=hfLastPaid.ClientID %>').val(data.d);
                        },
                        error: function (response) {
                            alert(response.responseText + " Session has timed out. (log out)");
                        },
                        failure: function (response) {
                            alert(response.responseText + " Session has timed out. (log out)");
                        }
                    });
                }

            });


        });
    }
        function GetBoostPin() {
        $(document).ready(function () {
            $("#<%=txtPhone.ClientID %>").autocomplete({
                source: function (request, response) {
                    $.ajax({
                        url: '<%=ResolveUrl("~/WebService.asmx/GetBoostPin") %>',
                        data: "{ 'prefix': '" + request.term + "'}",
                        dataType: "json",
                        type: "POST",
                        contentType: "application/json; charset=utf-8",
                        success: function (data) {
                            $('#<%=txtPin.ClientID %>').val(data.d);
                        },
                        error: function (response) {
                            alert(response.responseText + " Session has timed out. (log out)");
                        },
                        failure: function (response) {
                            alert(response.responseText + " Session has timed out. (log out)");
                        }
                    });
                }

            });


        });
    }

    var phoneNumber;
        function PhoneNumber(controlID) {

            var controlVal = $(controlID).val();
            document.getElementById('<%=lbNumberConf.ClientID %>').innerHTML = document.getElementById('<%=txtPhone.ClientID %>').value;
            if (controlVal != null && controlVal != '') {
                var text = controlVal.replace(/[^0-9]+/g, '');
    var textLength = text.length;

                switch (true) {
                    case (textLength < 3 || textLength == 3):
        $(controlID).val(text);
        break;
                    case (textLength > 3 && textLength < 7 || textLength == 7):
        $(controlID).val(text.substr(0, 3) + text.substr(3, textLength));
        break;
                        //textLength > 7 && textLength < 10 ||
case (textLength == 10):
    $(controlID).val('(' + text.substr(0, 3) + ')' + text.substr(3, 3) + '-' + text.substr(6, textLength));
    ThreeDayGrace();
    GetBoostPin();
    break;
                    case (textLength > 8 && textLength < 11 || textLength == 11):
        $(controlID).val('' + text.substr(0, 3) + '' + text.substr(3, 3) + '' + text.substr(6, textLength));
                        document.getElementById('<%=txtPhone.ClientID %>').style.borderColor = "green";
    ThreeDayGrace();
    GetBoostPin();
    break;
case (textLength > 10):
    $(controlID).val('' + text.substr(0, 3) + text.substr(3, 3) + text.substr(6, 4));
    break;
default:
    break;

   

}


                if (textLength != 10) {
        document.getElementById('<%=txtPhone.ClientID %>').style.borderColor = "red";
    document.getElementById("popupBtn").setAttribute("disabled", "disabled");
                    document.getElementById('<%=lbinto2.ClientID %>').innerHTML = "";
                    document.getElementById('<%=lbinto2.ClientID %>').innerHTML = document.getElementById('<%=hfLastPaid.ClientID %>').value;

}
                if (textLength == 10) {
        ThreeDayGrace();
    GetBoostPin();
                    document.getElementById('<%=txtPhone.ClientID %>').style.borderColor = "green";
                    if (document.getElementById('<%=ddProviders.ClientID %>').value == "4" || document.getElementById('<%=ddProviders.ClientID %>').value == "5"  || document.getElementById('<%=ddProviders.ClientID %>').value == "33")
                    {
        document.getElementById('<%=txtPhoneConf.ClientID %>').style.borderColor = "green";
    document.getElementById("popupBtn").disabled = true;
                         document.getElementById('<%=lbinto2.ClientID %>').innerHTML = document.getElementById('<%=hfLastPaid.ClientID %>').value;
                         document.getElementById('<%=txtAmount.ClientID %>').value = "";

                        if (document.getElementById('<%=hfLastPaid.ClientID %>').value == "--" || document.getElementById('<%=hfLastPaid.ClientID %>').value == "")
                        {
        //document.getElementById('<%=lbfee.ClientID %>').innerHTML = "4.00";
    }
    else
                        {
        document.getElementById('<%=lbfee.ClientID %>').innerHTML = "0.00";
    }
   
}
}
                if (textLength == 10 && document.getElementById('<%=txtAmount.ClientID %>').value != '') {
        document.getElementById('<%=txtPhone.ClientID %>').style.borderColor = "green";
    document.getElementById("popupBtn").disabled = false;
}
                if (document.getElementById('<%=txtPhoneConf.ClientID %>').value == document.getElementById('<%=txtPhone.ClientID %>').value) {
        document.getElementById('<%=txtPhoneConf.ClientID %>').style.borderColor = "green";
    document.getElementById('<%=lbinto2.ClientID %>').innerHTML = document.getElementById('<%=hfLastPaid.ClientID %>').value;
    ThreeDayGrace();
    GetBoostPin();
}
                else {
        document.getElementById('<%=lbinto2.ClientID %>').innerHTML = "";
    document.getElementById('<%=txtPhoneConf.ClientID %>').style.borderColor = "red";
    document.getElementById("popupBtn").disabled = true;
}

                if (document.getElementById('<%=txtAmount.ClientID %>').value == '') {
        document.getElementById("popupBtn").disabled = true;
    document.getElementById("popupBtn").setAttribute("disabled", "disabled");
}
//guatemala TopUp
                if ((textLength == 8 || textLength == 11) && (document.getElementById('<%=ddProviders.ClientID %>').value == "13" || document.getElementById('<%=ddProviders.ClientID %>').value == "26")) {
        document.getElementById('<%=txtPhone.ClientID %>').style.borderColor = "green";
    }
    //cuba TopUp
                if ((textLength == 8 || textLength == 10) && ( document.getElementById('<%=ddProviders.ClientID %>').value == "20")) {
        document.getElementById('<%=txtPhone.ClientID %>').style.borderColor = "green";
    }
    //jamica TopUp
                if ((textLength == 11 || textLength == 10) && ( document.getElementById('<%=ddProviders.ClientID %>').value == "23" || document.getElementById('<%=ddProviders.ClientID %>').value == "32")) {
        document.getElementById('<%=txtPhone.ClientID %>').style.borderColor = "green";

    }
    //honduras & el salvador & haiti TopUps
    if ((textLength == 7 || textLength == 8 || textLength == 10 || textLenth == 11) &&
                   (document.getElementById('<%=ddProviders.ClientID %>').value == "14" ||  document.getElementById('<%=ddProviders.ClientID %>').value == "15" ||
                    document.getElementById('<%=ddProviders.ClientID %>').value == "17" ||  document.getElementById('<%=ddProviders.ClientID %>').value == "18" ||  document.getElementById('<%=ddProviders.ClientID %>').value == "21" ||
                    document.getElementById('<%=ddProviders.ClientID %>').value == "22" ||  document.getElementById('<%=ddProviders.ClientID %>').value == "27" ||  document.getElementById('<%=ddProviders.ClientID %>').value == "28" || document.getElementById('<%=ddProviders.ClientID %>').value == "38")) {
        document.getElementById('<%=txtPhone.ClientID %>').style.borderColor = "green";
    }
                document.getElementById('<%=txtBoostNumber.ClientID %>').innerHTML = document.getElementById('<%=txtPhone.ClientID %>').value;
    ThreeDayGrace();
    GetBoostPin();
}
}
        function Amount(controlID) {

            var fee;

            if (document.getElementById('<%=ddProviders.ClientID %>').value == "6" || document.getElementById('<%=ddProviders.ClientID %>').value == "7" ||
                document.getElementById('<%=ddProviders.ClientID %>').value == "8" || document.getElementById('<%=ddProviders.ClientID %>').value == "9" ||
                document.getElementById('<%=ddProviders.ClientID %>').value == "10" || document.getElementById('<%=ddProviders.ClientID %>').value == "11" ||
                document.getElementById('<%=ddProviders.ClientID %>').value == "12" || document.getElementById('<%=ddProviders.ClientID %>').value == "13"||
                document.getElementById('<%=ddProviders.ClientID %>').value == "14" ||document.getElementById('<%=ddProviders.ClientID %>').value == "15"||
                document.getElementById('<%=ddProviders.ClientID %>').value == "20" ||document.getElementById('<%=ddProviders.ClientID %>').value == "21" ||
                document.getElementById('<%=ddProviders.ClientID %>').value == "22" ||document.getElementById('<%=ddProviders.ClientID %>').value == "23" ||
                document.getElementById('<%=ddProviders.ClientID %>').value == "24" ||document.getElementById('<%=ddProviders.ClientID %>').value == "25" ||
                document.getElementById('<%=ddProviders.ClientID %>').value == "26" ||document.getElementById('<%=ddProviders.ClientID %>').value == "27" ||
                document.getElementById('<%=ddProviders.ClientID %>').value == "28" ||document.getElementById('<%=ddProviders.ClientID %>').value == "29" ||
                document.getElementById('<%=ddProviders.ClientID %>').value == "30" ||document.getElementById('<%=ddProviders.ClientID %>').value == "31" ||
                document.getElementById('<%=ddProviders.ClientID %>').value == "32" || document.getElementById('<%=ddProviders.ClientID %>').value == "35" ||
                document.getElementById('<%=ddProviders.ClientID %>').value == "36" || document.getElementById('<%=ddProviders.ClientID %>').value == "37" || document.getElementById('<%=ddProviders.ClientID %>').value == "38")
            {
        fee = parseFloat(0.00);
    document.getElementById('<%=lbfee.ClientID %>').innerHTML = "0.00";
}
else
            {
        document.getElementById('<%=lbfee.ClientID %>').innerHTML = document.getElementById('<%=hfFee.ClientID %>').value;
    }

            if (document.getElementById('<%=hfLastPaid.ClientID %>').value == "--" || document.getElementById('<%=hfLastPaid.ClientID %>').value == "")
            {
        fee = parseFloat(document.getElementById('<%=lbfee.ClientID %>').innerHTML);
    <%--                document.getElementById('<%=lbfee.ClientID %>').innerHTML = "4.00";--%>
                }
                else
            {
        fee = parseFloat(0.00);
    document.getElementById('<%=lbfee.ClientID %>').innerHTML = "0.00";
}

            var billAmount =  parseFloat(document.getElementById('<%=txtAmount.ClientID %>').value);
    var total = fee + billAmount;
            document.getElementById('<%=lbamount.ClientID %>').innerHTML = billAmount;

            document.getElementById('<%=lbtotal.ClientID %>').innerHTML = total.toFixed(2);
   
    var controlVal = $(controlID).val();
            if (controlVal != null && controlVal != '' && document.getElementById('<%=txtPhoneConf.ClientID %>').value != '')
            {
        document.getElementById('<%=txtAmount.ClientID %>').style.borderColor = "green";
    document.getElementById("popupBtn").disabled = false;
}
            else if (document.getElementById('<%=ddProviders.ClientID %>').value == "4" || document.getElementById('<%=ddProviders.ClientID %>').value == "33")
            {
        document.getElementById('<%=txtAmount.ClientID %>').style.borderColor = "green";
    document.getElementById("popupBtn").disabled = false;
}
else
            {
        document.getElementById('<%=txtAmount.ClientID %>').style.borderColor = "red";
    document.getElementById("popupBtn").setAttribute("disabled", "disabled")
}

            if (document.getElementById('<%=txtPhoneConf.ClientID %>').value != document.getElementById('<%=txtPhone.ClientID %>').value)
            {
        document.getElementById("popupBtn").disabled = true;

    if(document.getElementById('<%=ddProviders.ClientID %>').value == "4")
                {
        document.getElementById("popupBtn").disabled = false;
    }
                if(document.getElementById('<%=ddProviders.ClientID %>').value == "33")
                {
        document.getElementById("popupBtn").disabled = false;
    }
}



            if (!(document.getElementById('<%=ddProviders.ClientID %>').value == "33" || document.getElementById('<%=ddProviders.ClientID %>').value == "4")) {
                if (document.getElementById('<%=txtAmount.ClientID %>').value < 5)
                {
        document.getElementById("popupBtn").disabled = true;
    document.getElementById('<%=lbInfo.ClientID %>').style.color = "red";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "Amount has to be more than $5";
    }

}
            if (!(document.getElementById('<%=ddProviders.ClientID %>').value == "33" || document.getElementById('<%=ddProviders.ClientID %>').value == "4")) {
                if (document.getElementById('<%=txtAmount.ClientID %>').value > 200) {
        document.getElementById("popupBtn").disabled = true;
    document.getElementById('<%=lbInfo.ClientID %>').style.color = "red";
                    document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "Amount has to be less than $200";
}
}

            else {
        document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
    }

            if (document.getElementById('<%=txtPin.ClientID %>').value.length != 4 && document.getElementById('<%=ddProviders.ClientID %>').value == "3") {
        document.getElementById("popupBtn").disabled = true;
    document.getElementById('<%=txtPin.ClientID %>').style.borderColor = "red";
                    document.getElementById('<%=lbInfo.ClientID %>').style.borderColor = "red";
              document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "Boost pin needs to be 4 digits";

  }

            if (document.getElementById('<%=ddProviders.ClientID %>').value == "4" && document.getElementById('<%=txtPhoneConf.ClientID %>').value != '') {
        document.getElementById("popupBtn").disabled = false;
    document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
}


             if (document.getElementById('<%=ddProviders.ClientID %>').value == "5" && document.getElementById('<%=txtPhoneConf.ClientID %>').value != '') {
        document.getElementById("popupBtn").disabled = false;
    document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
 }


            if (document.getElementById('<%=ddProviders.ClientID %>').value == "33" && document.getElementById('<%=txtPhoneConf.ClientID %>').value != '') {
        document.getElementById("popupBtn").disabled = false;
    document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
}
            if (document.getElementById('<%=txtAmount.ClientID %>').value < 1 && document.getElementById('<%=ddProviders.ClientID %>').value == "4") {
        document.getElementById("popupBtn").disabled = true;
    document.getElementById('<%=lbInfo.ClientID %>').style.color = "red";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "Amount has to be more than $1";
}
            if (document.getElementById('<%=txtAmount.ClientID %>').value < 1 && document.getElementById('<%=ddProviders.ClientID %>').value == "5") {
        document.getElementById("popupBtn").disabled = true;
    document.getElementById('<%=lbInfo.ClientID %>').style.color = "red";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "Amount has to be more than $1";
}
            if (document.getElementById('<%=txtAmount.ClientID %>').value < 1 && document.getElementById('<%=ddProviders.ClientID %>').value == "33") {
        document.getElementById("popupBtn").disabled = true;
    document.getElementById('<%=lbInfo.ClientID %>').style.color = "red";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "Amount has to be more than $1";
}
            if (document.getElementById('<%=txtAmount.ClientID %>').value > 100 && document.getElementById('<%=ddProviders.ClientID %>').value == "4") {
        document.getElementById("popupBtn").disabled = true;
    document.getElementById('<%=lbInfo.ClientID %>').style.color = "red";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "Amount has to be less than $100";
}
            if (document.getElementById('<%=txtAmount.ClientID %>').value > 100 && document.getElementById('<%=ddProviders.ClientID %>').value == "5") {
        document.getElementById("popupBtn").disabled = true;
    document.getElementById('<%=lbInfo.ClientID %>').style.color = "red";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "Amount has to be less than $100";
}
            if (document.getElementById('<%=txtAmount.ClientID %>').value > 100 && document.getElementById('<%=ddProviders.ClientID %>').value == "33") {
        document.getElementById("popupBtn").disabled = true;
    document.getElementById('<%=lbInfo.ClientID %>').style.color = "red";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "Amount has to be less than $100";
}
             if (document.getElementById('<%=txtAmount.ClientID %>').value < 10 && document.getElementById('<%=ddProviders.ClientID %>').value == "11") {
        document.getElementById("popupBtn").disabled = true;
    document.getElementById('<%=lbInfo.ClientID %>').style.color = "red";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "Amount has to be more than $10";
}
            if (document.getElementById('<%=txtAmount.ClientID %>').value > 100 && document.getElementById('<%=ddProviders.ClientID %>').value == "11") {
        document.getElementById("popupBtn").disabled = true;
    document.getElementById('<%=lbInfo.ClientID %>').style.color = "red";
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "Amount has to be less than $100";
}
            if ((textLength < 10) && ( document.getElementById('<%=ddProviders.ClientID %>').value == "23" || document.getElementById('<%=ddProviders.ClientID %>').value == "32")) {
        document.getElementById('<%=txtPhone.ClientID %>').style.borderColor = "red";
    document.getElementById("popupBtn").disabled = true;
                document.getElementById('<%=lbInfo.ClientID %>').innerHTML ="Number needs to be 10 or 11 digits";
}

}

        function BoostPin(evt) {

          var input = document.getElementById('<%=txtPin.ClientID %>');


                input.onkeypress = function (e) {

                if (document.getElementById('<%=txtPin.ClientID %>').value.length > 3 && document.getElementById('<%=ddProviders.ClientID %>').value == "3") {
        document.getElementById("popupBtn").disabled = false;
    document.getElementById('<%=txtPin.ClientID %>').style.borderColor = "green";
                    document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
}
                if (document.getElementById('<%=txtPin.ClientID %>').value.length < 3 && document.getElementById('<%=ddProviders.ClientID %>').value == "3") {
        document.getElementById("popupBtn").disabled = true;
    document.getElementById('<%=txtPin.ClientID %>').style.borderColor = "red";
                    document.getElementById('<%=lbInfo.ClientID %>').style.borderColor = "red";
                    document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "Boost pin needs to be 4 digits";
}

                if (document.getElementById('<%=txtPin.ClientID %>').value.length == 3 && document.getElementById('<%=ddProviders.ClientID %>').value == "3") {
        document.getElementById("popupBtn").disabled = false;
    document.getElementById('<%=txtPin.ClientID %>').style.borderColor = "green";
                    document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "";
}

               if (document.getElementById('<%=txtPin.ClientID %>').value.length != 3 && document.getElementById('<%=ddProviders.ClientID %>').value == "3") {
        document.getElementById("popupBtn").disabled = true;
    document.getElementById('<%=txtPin.ClientID %>').style.borderColor = "red";
                    document.getElementById('<%=lbInfo.ClientID %>').style.borderColor = "red";
                    document.getElementById('<%=lbInfo.ClientID %>').innerHTML = "Boost pin needs to be 4 digits";
}
e = e || window.event;
var charCode = (typeof e.which == "number") ? e.which : e.keyCode;

// Allow non-printable keys
                if (!charCode || charCode == 8 /* Backspace */) {
                    return ;
}

var typedChar = String.fromCharCode(charCode);

// Allow numeric characters
                if (/\d/.test(typedChar)) {
                    return ;
}

// Allow the minus sign (-) if the user enters it first
                if (typedChar == "-" && this.value == "") {
                    return ;
}



// In all other cases, suppress the event
return false;
};




}


        function isNumberKey(evt) {

          var input = document.getElementById('<%=txtAmount.ClientID %>');

            input.onkeypress = function (e) {
        e = e || window.event;
    var charCode = (typeof e.which == "number") ? e.which : e.keyCode;

    // Allow non-printable keys
                if (!charCode || charCode == 8 /* Backspace */) {
                    return ;
}

var typedChar = String.fromCharCode(charCode);

// Allow numeric characters
                if (/\d/.test(typedChar)) {
                    return ;
}

// Allow the minus sign (-) if the user enters it first
                if (typedChar == "-" && this.value == "") {
                    return ;
}

// In all other cases, suppress the event
return false;
};


var charCode = (evt.which) ? evt.which : evt.keyCode;
if (charCode != 46 && charCode > 31
              && (charCode < 48 || charCode > 57))
      return false;

  return true;
}
        function USNumber (controlID) {
            var controlVal = $(controlID).val();
            if (controlVal != null && controlVal != '') {
                var text = controlVal.replace(/[^0-9]+/g, '');
    var textLength = text.length;

                switch (true) {
                    case (textLength < 3 || textLength == 3):
        $(controlID).val(text);
                        document.getElementById('<%=txtUSNumber.ClientID %>').style.borderColor = "red";
    document.getElementById("popupBtn").disabled = true;
    break;
                    case (textLength > 3 && textLength < 7 || textLength == 7):
        $(controlID).val(text.substr(0, 3) + text.substr(3, textLength));
                        document.getElementById('<%=txtUSNumber.ClientID %>').style.borderColor = "red";
    document.getElementById("popupBtn").disabled = true;
    break;
case (textLength == 10):
    $(controlID).val('(' + text.substr(0, 3) + ')' + text.substr(3, 3) + '-' + text.substr(6, textLength));
                        document.getElementById('<%=txtUSNumber.ClientID %>').style.borderColor = "green";
    document.getElementById("popupBtn").disabled = true;
    break;
case (textLength > 10):
    $(controlID).val('' + text.substr(0, 3) + text.substr(3, 3) + text.substr(6, 4));
                        document.getElementById('<%=txtUSNumber.ClientID %>').style.borderColor = "red";
    document.getElementById("popupBtn").disabled = true;
    break;
default:
    break;
}
}
}

        function PhoneNumberConf(controlID) {
            var controlVal = $(controlID).val();
            if (controlVal != null && controlVal != '') {
                var text = controlVal.replace(/[^0-9]+/g, '');
    var textLength = text.length;

                switch (true) {
                    case (textLength < 3 || textLength == 3):
        $(controlID).val(text);
        break;
                    case (textLength > 3 && textLength < 7 || textLength == 7):
        $(controlID).val(text.substr(0, 3) + text.substr(3, textLength));
        break;
    case (textLength == 10):
        $(controlID).val('(' + text.substr(0, 3) + ')' + text.substr(3, 3) + '-' + text.substr(6, textLength));
        break;
    case (textLength > 10):
        $(controlID).val('' + text.substr(0, 3) + text.substr(3, 3) + text.substr(6, 4));
        break;
    default:
        break;
}

               
                    $(document).ready(function () {
        $("#<%=txtPhone.ClientID %>").autocomplete({
            source: function (request, response) {
                $.ajax({
                    url: '<%=ResolveUrl("~/WebService.asmx/GetNumber") %>',
                    data: "{ 'prefix': '" + request.term + "'}",
                    dataType: "json",
                    type: "POST",
                    contentType: "application/json; charset=utf-8",
                    success: function (data) {
                        $('#<%=hfLastPaid.ClientID %>').val(data.d);
                    },
                    error: function (response) {
                        alert(response.responseText + " Session has timed out. (log out)");
                    },
                    failure: function (response) {
                        alert(response.responseText + " Session has timed out. (log out)");
                    }
                });
            }

        });


    });
                if (document.getElementById('<%=txtPhoneConf.ClientID %>').value == document.getElementById('<%=txtPhone.ClientID %>').value)
                    {
        document.getElementById('<%=txtPhoneConf.ClientID %>').style.borderColor = "green";
    document.getElementById("popupBtn").disabled = false;
                         document.getElementById('<%=lbinto2.ClientID %>').innerHTML = document.getElementById('<%=hfLastPaid.ClientID %>').value;
                         document.getElementById('<%=txtAmount.ClientID %>').value = "";

                        if (document.getElementById('<%=hfLastPaid.ClientID %>').value == "--" || document.getElementById('<%=hfLastPaid.ClientID %>').value == "")
                        {
        //document.getElementById('<%=lbfee.ClientID %>').innerHTML = "4.00";
    }
    else
                        {
        document.getElementById('<%=lbfee.ClientID %>').innerHTML = "0.00";
    }
   
}
else
                    {
        document.getElementById('<%=txtPhoneConf.ClientID %>').style.borderColor = "red";
    document.getElementById("popupBtn").disabled = true;
    document.getElementById("popupBtn").setAttribute("disabled", "disabled");
                        document.getElementById('<%=lbinto2.ClientID %>').innerHTML = "";

}



                if (document.getElementById('<%=txtAmount.ClientID %>').value == '')
                    {
        document.getElementById("popupBtn").disabled = true;
    }
}
}
function getAmount()
        {

            var ddVal = document.getElementById('<%=ddAmount.ClientID %>').options[document.getElementById('<%=ddAmount.ClientID %>').selectedIndex].value;
            document.getElementById('<%=txtAmount.ClientID %>').value = ddVal;

    var fee;

            if (document.getElementById('<%=hfLastPaid.ClientID %>').value == "--" || document.getElementById('<%=hfLastPaid.ClientID %>').value == "")
            {
        fee = parseFloat(document.getElementById('<%=lbfee.ClientID %>').innerHTML);
    }
    else
            {
        fee = parseFloat(0.00);
    document.getElementById('<%=lbfee.ClientID %>').innerHTML = "0.00";
}

            if (document.getElementById('<%=ddProviders.ClientID %>').value == "6" || document.getElementById('<%=ddProviders.ClientID %>').value == "7" ||
                document.getElementById('<%=ddProviders.ClientID %>').value == "8" || document.getElementById('<%=ddProviders.ClientID %>').value == "9" ||
                document.getElementById('<%=ddProviders.ClientID %>').value == "10" || document.getElementById('<%=ddProviders.ClientID %>').value == "11" ||
                document.getElementById('<%=ddProviders.ClientID %>').value == "12" || document.getElementById('<%=ddProviders.ClientID %>').value == "13"||
                document.getElementById('<%=ddProviders.ClientID %>').value == "14" ||document.getElementById('<%=ddProviders.ClientID %>').value == "15" ||
                document.getElementById('<%=ddProviders.ClientID %>').value == "20" ||document.getElementById('<%=ddProviders.ClientID %>').value == "21" ||
                document.getElementById('<%=ddProviders.ClientID %>').value == "22" ||document.getElementById('<%=ddProviders.ClientID %>').value == "23" ||
                document.getElementById('<%=ddProviders.ClientID %>').value == "24" ||document.getElementById('<%=ddProviders.ClientID %>').value == "25" ||
                document.getElementById('<%=ddProviders.ClientID %>').value == "26" ||document.getElementById('<%=ddProviders.ClientID %>').value == "27" ||
                document.getElementById('<%=ddProviders.ClientID %>').value == "28" ||document.getElementById('<%=ddProviders.ClientID %>').value == "29" ||
                document.getElementById('<%=ddProviders.ClientID %>').value == "30" ||document.getElementById('<%=ddProviders.ClientID %>').value == "31" ||
                document.getElementById('<%=ddProviders.ClientID %>').value == "32" || document.getElementById('<%=ddProviders.ClientID %>').value == "35"||
                document.getElementById('<%=ddProviders.ClientID %>').value == "36" || document.getElementById('<%=ddProviders.ClientID %>').value == "37"||
                document.getElementById('<%=ddProviders.ClientID %>').value == "38" || document.getElementById('<%=ddProviders.ClientID %>').value == "39")
            {
        fee = parseFloat(0.00);
    document.getElementById('<%=lbfee.ClientID %>').innerHTML = "0.00";
}
else
            {
        document.getElementById('<%=lbfee.ClientID %>').innerHTML = document.getElementById('<%=hfFee.ClientID %>').value;
    }



            var billAmount =  parseFloat(document.getElementById('<%=txtAmount.ClientID %>').value);
    var total = fee + billAmount;
            document.getElementById('<%=lbamount.ClientID %>').innerHTML = billAmount;

            document.getElementById('<%=lbtotal.ClientID %>').innerHTML = total.toFixed(2);
   

            if (document.getElementById('<%=txtPhone.ClientID %>').value != '' && document.getElementById('<%=txtPhoneConf.ClientID %>').value != '')
            {
        document.getElementById('<%=txtAmount.ClientID %>').style.borderColor = "green";
    document.getElementById("popupBtn").disabled = false;
}
else
            {
        document.getElementById('<%=txtAmount.ClientID %>').style.borderColor = "red";
    document.getElementById("popupBtn").setAttribute("disabled", "disabled")
}

            if (document.getElementById('<%=txtPhoneConf.ClientID %>').value != document.getElementById('<%=txtPhone.ClientID %>').value) {
        document.getElementById("popupBtn").disabled = true;

    }
            if (document.getElementById('<%=txtPhone.ClientID %>').value != '')
            {
        document.getElementById("popupBtn").disabled = false;
    }

<%--            if (document.getElementById('<%=ddProviders.ClientID %>').value == "13" ||
                document.getElementById('<%=ddProviders.ClientID %>').value == "14" || document.getElementById('<%=ddProviders.ClientID %>').value == "15" ||
                document.getElementById('<%=ddProviders.ClientID %>').value == "16" || document.getElementById('<%=ddProviders.ClientID %>').value == "17" ||
                document.getElementById('<%=ddProviders.ClientID %>').value == "18" || document.getElementById('<%=ddProviders.ClientID %>').value == "19" ||
                document.getElementById('<%=ddProviders.ClientID %>').value == "20" || document.getElementById('<%=ddProviders.ClientID %>').value == "21" ||
                document.getElementById('<%=ddProviders.ClientID %>').value == "22" || document.getElementById('<%=ddProviders.ClientID %>').value == "23" ||
                document.getElementById('<%=ddProviders.ClientID %>').value == "24" || document.getElementById('<%=ddProviders.ClientID %>').value == "25" ||
                document.getElementById('<%=ddProviders.ClientID %>').value == "26" || document.getElementById('<%=ddProviders.ClientID %>').value == "27" ||
                document.getElementById('<%=ddProviders.ClientID %>').value == "28" || document.getElementById('<%=ddProviders.ClientID %>').value == "29" ||
                document.getElementById('<%=ddProviders.ClientID %>').value == "30" || document.getElementById('<%=ddProviders.ClientID %>').value == "31" ||
                document.getElementById('<%=ddProviders.ClientID %>').value == "32" || document.getElementById('<%=ddProviders.ClientID %>').value == "38" ||
                document.getElementById('<%=ddProviders.ClientID %>').value == "39")
            {

                if (document.getElementById('<%=txtUSNumber.ClientID %>').value == "" || document.getElementById('<%=txtUSNumber.ClientID %>').length != 10)
                {
        document.getElementById("popupBtn").disabled = true;
    }
}--%>


}
function getOtherService()
        {
            // tigo guatemala
            if(document.getElementById('<%=ddProviders.ClientID %>').value == "13" && document.getElementById('<%=ddOtherService.ClientID %>').value == "1")
            {
        document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
    var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
    select.add(new Option(7));
    select.add(new Option(10));
    select.add(new Option(12));
    select.add(new Option(14));
    select.add(new Option(15));
    select.add(new Option(20));
    select.add(new Option(25));
    select.add(new Option(30));
}
            else if (document.getElementById('<%=ddProviders.ClientID %>').value == "13" && document.getElementById('<%=ddOtherService.ClientID %>').value == "2")
            {
        document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
    var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
    select.add(new Option(7));
    select.add(new Option(10));

}
            else if (document.getElementById('<%=ddProviders.ClientID %>').value == "13" && document.getElementById('<%=ddOtherService.ClientID %>').value == "3")
            {
        document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
    var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
    select.add(new Option(10));
    select.add(new Option(14));
    select.add(new Option(20));
}

//tigo el salvador
            if(document.getElementById('<%=ddProviders.ClientID %>').value == "14" && document.getElementById('<%=ddOtherService.ClientID %>').value == "1")
            {
        document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
    var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
    select.add(new Option(5));
    select.add(new Option(6));
    select.add(new Option(7));
    select.add(new Option(9));
    select.add(new Option(10));
    select.add(new Option(12));
    select.add(new Option(14));
    select.add(new Option(15));
    select.add(new Option(20));
    select.add(new Option(22));
    select.add(new Option(25));
    select.add(new Option(30));
    select.add(new Option(40));
}
            else if (document.getElementById('<%=ddProviders.ClientID %>').value == "14" && document.getElementById('<%=ddOtherService.ClientID %>').value == "2")
            {
        document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
    var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
    select.add(new Option(7));
    select.add(new Option(10));
    select.add(new Option(14));
    select.add(new Option(20));
}

//tigo honduras
            if(document.getElementById('<%=ddProviders.ClientID %>').value == "15" && document.getElementById('<%=ddOtherService.ClientID %>').value == "1")
            {
        document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
    var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
    select.add(new Option(5));
    select.add(new Option(6));
    select.add(new Option(7));
    select.add(new Option(9));
    select.add(new Option(10));
    select.add(new Option(12));
    select.add(new Option(15));
    select.add(new Option(18));
    select.add(new Option(20));
    select.add(new Option(25));
    select.add(new Option(30));
}
            else if (document.getElementById('<%=ddProviders.ClientID %>').value == "15" && document.getElementById('<%=ddOtherService.ClientID %>').value == "2")
            {
        document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
    var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
    select.add(new Option(7));
    select.add(new Option(10));
    select.add(new Option(14));
    select.add(new Option(20));
}
 //Digicel Haiti
            if(document.getElementById('<%=ddProviders.ClientID %>').value == "21" && document.getElementById('<%=ddOtherService.ClientID %>').value == "1")
            {
        document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
    var i = 1;

                var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
                for (i = 1; i < 101; i++)
                {
        select.add(new Option(i));
    }
}
            else if (document.getElementById('<%=ddProviders.ClientID %>').value == "21" && document.getElementById('<%=ddOtherService.ClientID %>').value == "2")
            {
        document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
    var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
    select.add(new Option(15));
    select.add(new Option(20));
}
//Digicel El Salvador
            if(document.getElementById('<%=ddProviders.ClientID %>').value == "22" && document.getElementById('<%=ddOtherService.ClientID %>').value == "1")
            {
        document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
    var i = 1;
                var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
                for (i = 1; i < 101; i++)
                {
        select.add(new Option(i));

    }

}
            else if (document.getElementById('<%=ddProviders.ClientID %>').value == "22" && document.getElementById('<%=ddOtherService.ClientID %>').value == "2")
            {
        document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
    var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
    select.add(new Option(10));
    select.add(new Option(15));
    select.add(new Option(20));
    select.add(new Option(25));
}
//Claro Guatemala / El Salvador / Honduras
            if((document.getElementById('<%=ddProviders.ClientID %>').value == "26" || document.getElementById('<%=ddProviders.ClientID %>').value == "27" || document.getElementById('<%=ddProviders.ClientID %>').value == "28") && document.getElementById('<%=ddOtherService.ClientID %>').value == "1")
            {
        document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
    var i = 1;

                var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
    select.add(new Option(2));
    select.add(new Option(3));
    select.add(new Option(4));
    select.add(new Option(5));
    select.add(new Option(6));
    select.add(new Option(7));
    select.add(new Option(8));
    select.add(new Option(9));
    select.add(new Option(10));
    select.add(new Option(11));
    select.add(new Option(12));
    select.add(new Option(13));
    select.add(new Option(14));
    select.add(new Option(15));
    select.add(new Option(16));
    select.add(new Option(17));
    select.add(new Option(18));
    select.add(new Option(19));
    select.add(new Option(20));
    select.add(new Option(21));
    select.add(new Option(22));
    select.add(new Option(23));
    select.add(new Option(24));
    select.add(new Option(25));
    select.add(new Option(26));
    select.add(new Option(27));
    select.add(new Option(28));
    select.add(new Option(29));
    select.add(new Option(30));
    select.add(new Option(35));
    select.add(new Option(40));
    select.add(new Option(45));
    select.add(new Option(50));

}
            else if ((document.getElementById('<%=ddProviders.ClientID %>').value == "26" || document.getElementById('<%=ddProviders.ClientID %>').value == "27" || document.getElementById('<%=ddProviders.ClientID %>').value == "28")  && document.getElementById('<%=ddOtherService.ClientID %>').value == "2")
            {
        document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
    var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
    select.add(new Option(7));
    select.add(new Option(12));
    select.add(new Option(15));
}
            else if ((document.getElementById('<%=ddProviders.ClientID %>').value == "26" || document.getElementById('<%=ddProviders.ClientID %>').value == "27" || document.getElementById('<%=ddProviders.ClientID %>').value == "28")  && document.getElementById('<%=ddOtherService.ClientID %>').value == "3")
            {
        document.getElementById('<%=ddAmount.ClientID %>').options.length = 0;
    var select = $('#<%=ddAmount.ClientID %>')[0];
    select.add(new Option("--Select Amount--", 0));
    select.add(new Option(12));
    select.add(new Option(15));
    select.add(new Option(20));
}
}

 