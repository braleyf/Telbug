﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Diagnostics;
using System.Management.Automation;
using System.Net.Http;
using System.Threading.Tasks;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using System.Xml.Serialization;
using System.Net;
using System.Text;
using System.IO;

namespace MetroFastPay
{
    /// <summary>
    /// Summary description for Cricket
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
     [System.Web.Script.Services.ScriptService]
    public class Cricket : System.Web.Services.WebService
    {

        [WebMethod]
        public void PayCricket()
        {
            Payment();
       
        }


        [Serializable]
        public class CreditCardInfo
        {
            public CreditCardInfo()
            {
                cardNumber = "1231231231231323";
                cardName = "2.00";
                cardExpirationDate = "12345";
                cardType = "";
                securityCode = "123";
                paymentMethod = "CREDITCARD";
            }
            public string cardNumber { get; set; }
            public string cardName { get; set; }
            public string cardExpirationDate { get; set; }
            public string cardType { get; set; }
            public string securityCode { get; set; }
            public string paymentMethod { get; set; }
        }
        [Serializable]
        public class Data
        {

            public Data()
            {

                secureKey = "a697627915e1176cc642333d1f3b23f328a93ea64f1b8a3a82a7224c94e62f3a";
                amount = "2.00";
                postalCode = "32165";
                ctn = "5612311940";
                appId = "AMSS";
                creditCardInfo = new CreditCardInfo();
            }

            public string secureKey { get; set; }
            public string amount { get; set; }
            public string postalCode { get; set; }
            public CreditCardInfo creditCardInfo { get; set; }
            public string ctn { get; set; }
            public string appId { get; set; }
        }

        public  void Payment()
        {
            try
            {

                Data data = new Data();

                // this is what we are sending
                string post_data = data.ToString();

                // this is where we will send it
                string uri = "https://www.cricketwireless.com/selfservice/rest/quickpay/creditcard/";

                // create a request
                HttpWebRequest request = (HttpWebRequest)
                WebRequest.Create(uri);
                //request.KeepAlive = false;
                request.ProtocolVersion = HttpVersion.Version10;
                request.Method = "POST";

                // turn our request string into a byte stream
                byte[] postBytes = Encoding.ASCII.GetBytes(post_data);

                // this is important - make sure you specify type this way
                request.Accept = "application/json";
                request.ContentType = "application/json";
                request.Referer = "https://www.cricketwireless.com/myaccount.html";
                request.Host = "www.cricketwireless.com";
                request.ContentLength = postBytes.Length;
                Stream requestStream = request.GetRequestStream();

                // now send it
                requestStream.Write(postBytes, 0, postBytes.Length);
                requestStream.Close();

                // grab te response and print it out to the console along with the status code
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                Console.WriteLine(new StreamReader(response.GetResponseStream()).ReadToEnd());
                Console.WriteLine(response.StatusCode);
            }
            catch (Exception ex)
            {

            }
        }
    }
}
