﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net.Mail;
using System.Configuration;
using System.Web.UI.HtmlControls;
using System.Drawing;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using System.Net;
using MetroFastPayLibrary;

namespace MetroFastPay
{
    public partial class _default : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {


            HttpCookie UserCookie = HttpContext.Current.Request.Cookies["UserNameCookie"];
            if (Request.Cookies["UserNameCookie"] == null)
            {
                if (Request.Url.ToString().Contains("localhost"))
                {
                    Response.Redirect("login.aspx");
                }
                else
                {
                    Response.Redirect("https://www.telbug.com/login.aspx");
                }
                if (Request.Url.ToString().Contains("tellbug"))
                {
                    Response.Redirect("http://www.tellbug.com/login.aspx");
                    return;
                }
            }
            else
            {
                if (Request.Url.ToString().Contains("localhost"))
                {
                    Response.Redirect("Dashboard.aspx?Dashboard");
                }
                else
                {
                    Response.Redirect("https://www.telbug.com/Dashboard?Dashboard");
                }

                if (Request.Url.ToString().Contains("tellbug"))
                {
                    Response.Redirect("http://www.tellbug.com/Dashboard?Dashboard");
                }
            }

        }
      
    }
}