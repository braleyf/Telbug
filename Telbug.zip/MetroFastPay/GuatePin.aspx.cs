﻿using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Security.Principal;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.AspNet.Identity;
using System.Net.Mail;
using MetroFastPayLibrary;
using System.Net;
using RestSharp;
using System.Threading.Tasks;

namespace MetroFastPay
{
    public partial class GuatePin : System.Web.UI.Page
    {
        User oUser = new User();
        UserDAO oUserDAO = new UserDAO();
        protected void Page_Load(object sender, EventArgs e)
        {
           
        }
        protected async void SendReferral_Click(object sender, System.EventArgs e)
        {
            
            if (txtReferralNumber.Text != "" && txtReferralNumber.Text != Request.QueryString["ReferrerNumber"].ToString())
            {
                User getReferral = oUserDAO.RetrieveGuatePinReferral(txtReferralNumber.Text);
                if (getReferral.ReferralNumber == null)
                {
                    oUserDAO.InsertGuatePinReferrals(Request.QueryString["ReferrerNumber"].ToString(), txtReferralNumber.Text);

                    await sendShortCodes("https://api.trumpia.com/http/v2/sendverificationsms?apikey=e4d74191b6211d1fc9167ab0b921cc5f&mobile_number=" + txtReferralNumber.Text + "&message=Te recomendaron que uses http://GuatePin.com, La Recarga Guatemalteca\nVe a tu tienda local para recargar.");

                    lbReferral.ForeColor = System.Drawing.Color.Green;
                    lbReferral.Text = "Recomendación recibida, se agregará un dólar a su próxima recarga";
                }
                else
                {
                    User getPrevRecharge = oUserDAO.RetrieveGuatePinRecharge(txtReferralNumber.Text);
                    if (getPrevRecharge.PhoneNumber != "")
                    {
                        lbReferral.ForeColor = System.Drawing.Color.Red;
                        lbReferral.Text = "Este número ya esta en uso, por favor use un número diferente";
                    }
                    else
                    {
                        lbReferral.ForeColor = System.Drawing.Color.Red;
                        lbReferral.Text = "Este número ya ha sido referido, por favor use un número diferente";

                    }

                }
               
            }
            else
            {
                if (txtReferralNumber.Text == "")
                {
                    lbReferral.ForeColor = System.Drawing.Color.Red;
                    lbReferral.Text = "Entre un número ";
                }
                if (txtReferralNumber.Text == Request.QueryString["ReferrerNumber"].ToString())
                {
                    lbReferral.ForeColor = System.Drawing.Color.Red;
                    lbReferral.Text = "No puede ser tu número";
                }
            }

        }
        async Task sendShortCodes(string url)
        {

            ServicePointManager.Expect100Continue = true;
            ServicePointManager.DefaultConnectionLimit = 9999;
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12 | SecurityProtocolType.Ssl3;
            var client = new RestClient(url);
            var request = new RestRequest(Method.POST);
            IRestResponse response = client.Execute(request);
            var my = response.Content;
        }
    }
}