﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net.Mail;
using System.Configuration;
using System.Web.UI.HtmlControls;
using System.Drawing;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using System.Net;
using MetroFastPayLibrary;
using System.Text;
using System.Security.Cryptography;
using System.Threading.Tasks;
using RestSharp;

namespace MetroFastPay
{
    public partial class reset : System.Web.UI.Page
    {
        User oUser = new User();
        UserDAO oUserDAO = new UserDAO();
        protected void Page_Load(object sender, EventArgs e)
        {
            divPass.Attributes.Add("style", "display:none");
            divCode.Attributes.Add("style", "display:none");
            if (Request.Url.ToString().Contains("code"))
            {
                txtReset.Text = "Submit";
                divPhone.Attributes.Add("style", "display:none");
                divPass.Attributes.Add("style", "display:none");
                divCode.Attributes.Add("style", "display:block");
            }
            else
            {
                txtReset.Text = "Reset";
                divCode.Attributes.Add("style", "display:none");
                divPass.Attributes.Add("style", "display:none");
                divPhone.Attributes.Add("style", "display:block");
            }


            if (Request.Url.ToString().Contains("pass"))
            {
                txtReset.Text = "Reset Password";
                divPhone.Attributes.Add("style", "display:none");
                divCode.Attributes.Add("style", "display:none");
                divPass.Attributes.Add("style", "display:block");
            }

            if (lbInfo.Text == "Password has been changed!")
            {
                txtNewPass.Text = "";
                txtConfPass.Text = "";
                txtReset.Enabled = false;
            }
        }
        protected void ForgotPass_Click(object sender, System.EventArgs e)
        {

            if (Request.Url.ToString().Contains("code"))
            {
                string code = DAO.Decrypt(Request.QueryString["code"], ConfigurationManager.AppSettings["encryptionKey"]);
                if (txtCode.Text == code)
                {
                    Response.Redirect("Reset.aspx?pass&userid=" + Request.QueryString["userid"]);
                }
                else
                {
                    lbInfo.ForeColor = Color.Red;
                    lbInfo.Text = "Code is not correct.";
                }
            }
            else
            {
                oUser = oUserDAO.RetrieveUserByUserID(txtUser.Text);
                if (oUser.UserID == txtUser.Text && oUser.PhoneNumber.Trim() == txtPhone.Text)
                {
                    int code = GetRandomNumber(1111, 9999);

                    sendShortCodes("https://api.trumpia.com/http/v2/sendverificationsms?apikey=e4d74191b6211d1fc9167ab0b921cc5f&mobile_number=" + txtPhone.Text + "&message=Enter " + code + " to reset password");
                    Response.Redirect("Reset.aspx?code=" + DAO.Encrypt(code.ToString(), ConfigurationManager.AppSettings["encryptionKey"]) + "&userid=" + txtUser.Text);

                    
                }
                else
                {
                    lbInfo.ForeColor = Color.Red;
                    lbInfo.Text = "User name or phone number does not exist.";
                }
             
            }

            if (Request.Url.ToString().Contains("pass"))
            {
                if ((txtNewPass.Text == txtConfPass.Text) && txtConfPass.Text.Length > 0 && txtNewPass.Text.Length > 0)
                {
                    oUserDAO.UpdatePassword(DAO.Encrypt(txtConfPass.Text, ConfigurationManager.AppSettings["encryptionKey"]), Request.QueryString["userid"]);
                    lbInfo.ForeColor = Color.Green;
                    lbInfo.Text = "Password has been changed!";
                }
                else
                {
                    lbInfo.ForeColor = Color.Red;
                    lbInfo.Text = "Password do not match.";
                }

            }


          }
        //Function to get random number
        private static readonly Random getrandom = new Random();
        private static readonly object syncLock = new object();
        public static int GetRandomNumber(int min, int max)
        {
            lock (syncLock)
            { // synchronize
                return getrandom.Next(min, max);
            }
        }

        public void sendShortCodes(string url)
        {
            var client = new RestClient(url);
            var request = new RestRequest(Method.POST);
            IRestResponse response = client.Execute(request);
        }
    }
}