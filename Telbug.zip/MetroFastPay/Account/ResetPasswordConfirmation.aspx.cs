﻿using System.Web.UI;

namespace MetroFastPay.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}