﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net.Mail;
using System.Configuration;
using System.Web.UI.HtmlControls;
using System.Drawing;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using System.Net;
using MetroFastPayLibrary;
using System.Text;
using System.Security.Cryptography;

namespace MetroFastPay
{
    public partial class Login : System.Web.UI.Page
    {
        User oUser = new User();
        UserDAO oUserDAO = new UserDAO();
        HttpCookie GuatePinUserCookie = new HttpCookie("GuatePinUser");
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.Url.AbsoluteUri.Contains("guateUser"))
            {
                //imgLogo.Src = "Img/GuatePinLogo.png";
                //imgLogo.Style.Add("width", "99%");

                txtUserName.Text = Request.QueryString["guateUser"].ToString();
                txtPassword.Text = Request.QueryString["password"].ToString();
                HttpCookie httpCookie = GuatePinUserCookie;
                GuatePinUserCookie.Value = "GuatePinUser";
                GuatePinUserCookie.Expires = DateTime.Now.AddDays(1);
                Response.Cookies.Add(GuatePinUserCookie);

                Submit_Click(sender, e);
                //Response.Redirect("login.aspx");
            }
            else
            {

                //imgLogo.Src = "Img/logoWithName.png";
                //imgLogo.Style.Add("width", "99%");
                HttpCookie guatePinUserCookie = GuatePinUserCookie;
                Session.Abandon();
                GuatePinUserCookie.Expires = DateTime.Now.AddYears(-1);
                Response.Cookies.Add(GuatePinUserCookie);
            }

            if (Request.Url.AbsoluteUri.Contains("username"))
            {
                txtUserName.Text = Request.QueryString["username"].ToString();
            }

            if (Request.Url.AbsoluteUri.Contains("FastPayOnline"))
            {
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "btnFastPayOnlinePopup();", true);
            }
            if (Request.Url.AbsoluteUri.Contains("ConfirmEmail"))
            {
                txtUserName.Text = Request.QueryString["ConfirmEmail"].ToString();
                oUser = oUserDAO.RetrieveUserByUserID(Request.QueryString["ConfirmEmail"].ToString());
                oUserDAO.UpdateUser(oUser.UserID, oUser.FullName, oUser.PhoneNumber, oUser.Email, oUser.BusinessName, oUser.BusinessAddress, true, oUser.City, oUser.State, oUser.Zip, oUser.ResaleCert, oUser.EIN);
                lbDesc.ForeColor = Color.Green;
                lbDesc.Text = "Email has been confirmed!";
            }
        }
        protected void Submit_Click(object sender, System.EventArgs e)
        {

            oUser = oUserDAO.RetrieveUserByUserID(txtUserName.Text);
            string LowerUsername = "";
            string LowerUsername2 = txtUserName.Text.ToLower();
            if (oUser.UserID != null)
            {
                LowerUsername = oUser.UserID.ToLower();
                LowerUsername2 = txtUserName.Text.ToLower();
            }


            if (LowerUsername2 != LowerUsername)
            {
                lbDesc.Text = "Incorrect username";
                return;
            }
            else if (txtUserName.Text == "" && txtPassword.Text == "")
            {
                lbDesc.Text = "Incorrect username or password" + " | <a runat='server' ID='lbForgotpass' data-toggle='modal' data-target='#myModal' style='cursor:pointer; color:blue'>Forgot password</a>"; 
                return;
            }
            else
            {

                if (txtPassword.Text == DAO.Decrypt(oUser.Password, ConfigurationManager.AppSettings["encryptionKey"]) && LowerUsername2 == LowerUsername && oUser.Active == true)
                {
                    //Session["UserID"] = txtUserName.Text;
                    oUserDAO.InsertIP(txtUserName.Text, GetIPAddress(), 0);
                    HttpCookie UserCookie = new HttpCookie("UserNameCookie");
                    UserCookie.Value = txtUserName.Text;
                    UserCookie.Expires = DateTime.Now.AddDays(1);
                    Response.Cookies.Add(UserCookie);

                    Response.Redirect("default.aspx");

                }
                else
                {
                    lbDesc.ForeColor = Color.Red;
                    if (oUser.Active == false)
                    {
                        lbDesc.Text = "Account has been locked out, call 561-860-5276";
                    }
                    else
                    {
                        lbDesc.Text = "Incorrect username or password" + " | <a runat='server' ID='lbForgotpass' data-toggle='modal' data-target='#myModal' style='cursor:pointer; color:blue'>Forgot password</a>"; ;
                    }

                }


            }


        }
        //protected string GetIPAddress()
        //{
        //    System.Web.HttpContext context = System.Web.HttpContext.Current;
        //    string ipAddress = context.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];

        //    if (!string.IsNullOrEmpty(ipAddress))
        //    {
        //        string[] addresses = ipAddress.Split(',');
        //        if (addresses.Length != 0)
        //        {
        //            return addresses[0];
        //        }
        //    }

        //    return context.Request.ServerVariables["REMOTE_ADDR"];
        //}
        protected string GetIPAddress()
        {
            System.Web.HttpContext context = System.Web.HttpContext.Current;
            string ipAddress = context.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];

            if (!string.IsNullOrEmpty(ipAddress))
            {
                string[] addresses = ipAddress.Split(',');
                if (addresses.Length != 0)
                {
                    return addresses[0];
                }
            }

            return context.Request.ServerVariables["REMOTE_ADDR"];
        }

    }

}