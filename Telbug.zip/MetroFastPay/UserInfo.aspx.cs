﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net.Mail;
using System.Configuration;
using System.Web.UI.HtmlControls;
using System.Drawing;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using System.Net;
using MetroFastPayLibrary;
using System.Text;
using System.Security.Cryptography;
namespace MetroFastPay
{
    public partial class UserInfo : System.Web.UI.Page
    {
        User oUser = new User();
        UserDAO oUserDAO = new UserDAO();
        HttpCookie UserCookie = HttpContext.Current.Request.Cookies["UserNameCookie"];

        string dbCon = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
        protected void Page_Load(object sender, EventArgs e)
        {

            if (Request.Cookies["UserNameCookie"] == null)
            {
                //Session.Abandon();
                //UserCookie.Expires = DateTime.Now.AddYears(-1);
                //Response.Cookies.Add(UserCookie);
                Response.Redirect("out.aspx");

            }
            else
            {
                oUser = oUserDAO.RetrieveUserByUserID(UserCookie.Value);
                if (oUser.UserType == "Admin")
                {

                    DataTable dt3 = new DataTable();
                    BindUserGrid(dt3);

                    gvUserInfo.BottomPagerRow.Visible = false;

                    if (Request.Url.ToString().Contains("UserID="))
                    {
                        lbUser.Text = Request.QueryString["UserID"];
                        oUser = oUserDAO.RetrieveUserByUserID(Request.QueryString["UserID"]);
                        string fullName = oUser.FullName;
                        var names = fullName.Split(' ');
                        string firstName = names[0];
                        string lastName = txtLastNameUser.Text;
                        if (fullName.Contains(" "))
                        {
                            lastName = names[1];
                        }

                        gvUserInfo.PageSize = 10;


                        DataTable dt = new DataTable();
                        BindUserGrid(dt);

                        DataTable dt1 = new DataTable();
                        BindGridTrans(dt1, ddUser.SelectedItem.Value);

                        DataTable dt2 = new DataTable();
                        BindGridReport(dt2, ddUser.SelectedItem.Value);



                        if (!Page.IsPostBack)
                        {
                            ddUser.SelectedValue = Request.QueryString["UserID"];
                            txtFirstNameUser.Text = firstName;
                            txtLastNameUser.Text = lastName;
                            txtPhoneNumber.Text = oUser.PhoneNumber;
                            txtEmail.Text = oUser.Email;
                            txtBusinessName.Text = oUser.BusinessName;
                            txtBusinessAddress.Text = oUser.BusinessAddress;
                            txtCity.Text = oUser.City;
                            ddState.SelectedItem.Text = oUser.State;
                            txtZip.Text = oUser.Zip;
                            txtResaleCert.Text = oUser.ResaleCert;
                            txtEIN.Text = oUser.EIN;

                            ddActive.SelectedValue = oUser.Active.ToString();
                        }
                        // UpdatePanel3.Visible = false;
                        myModal.Attributes.Add("style", "display:block");

                    }
                }


            }

        }
        protected void cboUserFilter_OnSelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (Request.Cookies["UserNameCookie"] == null)
                {
                    Response.Redirect("login.aspx");
                }
                DataTable dt = new DataTable();
                //BindUserGrid(dt, ddUser.SelectedItem.Value);
                BindGridTrans(dt, ddUser.SelectedItem.Value);
                DataTable dt1 = new DataTable();
                BindGridReport(dt1, ddUser.SelectedItem.Value);
                myModal.Attributes.Add("style", "display:none");
                if (LastLoginTime(ddUser.SelectedItem.Value).ToString() == "1/1/0001 12:00:00 AM")
                {
                    lbLoggedIn.Text = "<b>Last log-in:</b> Never";
                }
                else
                {
                    lbLoggedIn.Text = "<b>Last log-in on:</b> " + LastLoginTime(ddUser.SelectedItem.Value).ToString();
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("login.aspx");
            }
        }
        private void BindUserGrid(DataTable dt3)

        {
            DataTable dtCount = new DataTable();
            List<User> aList = new List<User>();
            aList = new List<User>();


            if (ddUser.SelectedItem.Value != "")
            {
                aList = oUserDAO.PopulateUserInfobyUser(ddUser.SelectedItem.Value);

                decimal totalLastMonthPaymentsAmount = gettotalLastMonthPaymentsAmount(ddUser.SelectedItem.Value, false);
                decimal totalThisMonthPaymentsAmount = gettotalThisMonthPaymentsAmount(ddUser.SelectedItem.Value, false);
                decimal totalOverallPaymentsAmount = gettotalPaymentsAmount(ddUser.SelectedItem.Value, false);
                decimal totalPayments = gettotalPaymentsbyuserid(ddUser.SelectedItem.Value, false);
                decimal totalLastMonthPayments = gettotalLastMonthPayments(ddUser.SelectedItem.Value, false);
                decimal totalThisMonthPayments = gettotalThisMonthPayments(ddUser.SelectedItem.Value, false);
                decimal totalbalance = gettotalBalance(ddUser.SelectedItem.Value, false);
                decimal totalcredit = gettotalCredit(ddUser.SelectedItem.Value, false);

                decimal LastMonthAvg;
                decimal ThisMonthAvg;
                decimal OverallAvg;

                decimal metro;
                decimal boost;
                decimal cricket;
                decimal sinpin;

                decimal LastMonthProfitFee4 = getProfitCellPaymentsLastMonthFee4(ddUser.SelectedItem.Value, false);
                decimal ThisMonthProfitFee4 = getProfitCellPaymentsThisMonthFee4(ddUser.SelectedItem.Value, false);

                decimal LastMonthProfitFee3 = getProfitCellPaymentsLastMonthFee3(ddUser.SelectedItem.Value, false);
                decimal ThisMonthProfitFee3 = getProfitCellPaymentsThisMonthFee3(ddUser.SelectedItem.Value, false);

                decimal LastMonthSinPinProfit = getProfitSinPinLastMonth(ddUser.SelectedItem.Value, false);
                decimal ThisMonthSinPinProfit = getProfitSinPinThisMonth(ddUser.SelectedItem.Value, false);

                decimal LastMonthProfit = LastMonthProfitFee4 + LastMonthProfitFee3 + LastMonthSinPinProfit;
                decimal ThisMonthProfit = ThisMonthProfitFee4 + ThisMonthProfitFee3 + ThisMonthSinPinProfit;



                if (totalPayments == 0)
                {
                    LastMonthAvg = 0;
                    ThisMonthAvg = 0;
                    OverallAvg = 0;
                    metro = 0;
                    boost = 0;
                    cricket = 0;
                    sinpin = 0;

                    LastMonthProfitFee4 = 0;
                    ThisMonthProfitFee4 = 0;
                }
                else
                {
                    if (totalLastMonthPayments == 0)
                    {
                        LastMonthAvg = 0;
                    }
                    else
                    {
                        LastMonthAvg = (totalLastMonthPaymentsAmount / totalLastMonthPayments);
                    }

                    if (totalThisMonthPayments == 0)
                    {
                        ThisMonthAvg = 0;
                    }
                    else
                    {
                        ThisMonthAvg = (totalThisMonthPaymentsAmount / totalThisMonthPayments);
                    }

                    OverallAvg = (totalOverallPaymentsAmount / totalPayments);

                    metro = (gettotalMetroPaymentsbyuserid(ddUser.SelectedItem.Value, false) / totalPayments) * 100;
                    boost = (gettotalBoostPaymentsbyuserid(ddUser.SelectedItem.Value, false) / totalPayments) * 100;
                    cricket = (gettotalCricketPaymentsbyuserid(ddUser.SelectedItem.Value, false) / totalPayments) * 100;
                    sinpin = (gettotalSinPinPaymentsbyuserid(ddUser.SelectedItem.Value, false) / totalPayments) * 100;
                }



                lbLastMonthAvg.Text = string.Format("{0:0.00}", LastMonthAvg);
                lbThisMonthAvg.Text = string.Format("{0:0.00}", ThisMonthAvg);
                lbOverallAvg.Text = string.Format("{0:0.00}", OverallAvg);

                lbMetro.Text = string.Format("{0:0.00}", metro) + "%";
                lbBoost.Text = string.Format("{0:0.00}", boost) + "%";
                lbCricket.Text = string.Format("{0:0.00}", cricket) + "%";
                lbSinPin.Text = string.Format("{0:0.00}", sinpin) + "%";

                lbLastMonthProfit.Text = string.Format("{0:0.00}", LastMonthProfit);
                lbThisMonthProfit.Text = string.Format("{0:0.00}", ThisMonthProfit);

                lbLastMonthpayments.Text = totalLastMonthPayments.ToString();
                lbThisMonthPayments.Text = totalThisMonthPayments.ToString();
                lbTotal.Text = totalPayments.ToString();

                lbDeposits.Text = string.Format("{0:0.00}", totalcredit);
                lbHoldings.Text = string.Format("{0:0.00}", totalbalance);
            }
            else
            {
                aList = oUserDAO.PopulateUserInfo();
                decimal totalLastMonthPaymentsAmount = gettotalLastMonthPaymentsAmount(ddUser.SelectedItem.Value, true);
                decimal totalThisMonthPaymentsAmount = gettotalThisMonthPaymentsAmount(ddUser.SelectedItem.Value, true);
                decimal totalOverallPaymentsAmount = gettotalPaymentsAmount(ddUser.SelectedItem.Value, true);
                decimal totalPayments = gettotalPaymentsbyuserid(ddUser.SelectedItem.Value, true);
                decimal totalLastMonthPayments = gettotalLastMonthPayments(ddUser.SelectedItem.Value, true);
                decimal totalThisMonthPayments = gettotalThisMonthPayments(ddUser.SelectedItem.Value, true);
                decimal totalbalance = gettotalBalance(ddUser.SelectedItem.Value, true);
                decimal totalcredit = gettotalCredit(ddUser.SelectedItem.Value, true);

                decimal LastMonthAvg;
                decimal ThisMonthAvg;
                decimal OverallAvg;

                decimal metro;
                decimal boost;
                decimal cricket;
                decimal sinpin;

                decimal LastMonthProfitFee4 = getProfitCellPaymentsLastMonthFee4(ddUser.SelectedItem.Value, true);
                decimal ThisMonthProfitFee4 = getProfitCellPaymentsThisMonthFee4(ddUser.SelectedItem.Value, true);

                decimal LastMonthProfitFee3 = getProfitCellPaymentsLastMonthFee3(ddUser.SelectedItem.Value, true);
                decimal ThisMonthProfitFee3 = getProfitCellPaymentsThisMonthFee3(ddUser.SelectedItem.Value, true);

                decimal LastMonthSinPinProfit = getProfitSinPinLastMonth(ddUser.SelectedItem.Value, true);
                decimal ThisMonthSinPinProfit = getProfitSinPinThisMonth(ddUser.SelectedItem.Value, true);

                decimal LastMonthRewards = getRewardMetroPCSLastMonth(ddUser.SelectedItem.Value, true) + getRewardBoostCricketLastMonth(ddUser.SelectedItem.Value, true);
                decimal ThisMonthRewards = getRewardMetroPCSThisMonth(ddUser.SelectedItem.Value, true) + getRewardBoostCricketThisMonth(ddUser.SelectedItem.Value, true);

                decimal LastMonthProfit = LastMonthProfitFee4 + LastMonthProfitFee3 + LastMonthSinPinProfit + LastMonthRewards;
                decimal ThisMonthProfit = ThisMonthProfitFee4 + ThisMonthProfitFee3 + ThisMonthSinPinProfit + ThisMonthRewards;

                if (totalPayments == 0)
                {
                    LastMonthAvg = 0;
                    ThisMonthAvg = 0;
                    OverallAvg = 0;
                    metro = 0;
                    boost = 0;
                    cricket = 0;
                    sinpin = 0;
                }
                else
                {
                    LastMonthAvg = 0;
                    if (totalLastMonthPayments != 0)
                    {
                        LastMonthAvg = (totalLastMonthPaymentsAmount / totalLastMonthPayments);
                    }

                    //  ThisMonthAvg = (totalThisMonthPaymentsAmount / totalThisMonthPayments);
                    ThisMonthAvg = 8;
                    OverallAvg = (totalOverallPaymentsAmount / totalPayments);

                    metro = (gettotalMetroPaymentsbyuserid(ddUser.SelectedItem.Value, true) / totalPayments) * 100;
                    boost = (gettotalBoostPaymentsbyuserid(ddUser.SelectedItem.Value, true) / totalPayments) * 100;
                    cricket = (gettotalCricketPaymentsbyuserid(ddUser.SelectedItem.Value, true) / totalPayments) * 100;
                    sinpin = (gettotalSinPinPaymentsbyuserid(ddUser.SelectedItem.Value, true) / totalPayments) * 100;
                }


                lbLastMonthAvg.Text = string.Format("{0:0.00}", LastMonthAvg);
                lbThisMonthAvg.Text = string.Format("{0:0.00}", ThisMonthAvg);
                lbOverallAvg.Text = string.Format("{0:0.00}", OverallAvg);

                lbMetro.Text = string.Format("{0:0.00}", metro) + "%";
                lbBoost.Text = string.Format("{0:0.00}", boost) + "%";
                lbCricket.Text = string.Format("{0:0.00}", cricket) + "%";
                lbSinPin.Text = string.Format("{0:0.00}", sinpin) + "%";


                lbLastMonthProfit.Text = string.Format("{0:0.00}", LastMonthProfit) + "<br /><small> Additional: " + string.Format("{0:0.00}", LastMonthRewards) + "</small>";
                lbThisMonthProfit.Text = string.Format("{0:0.00}", ThisMonthProfit) + "<br /><small> Additional: " + string.Format("{0:0.00}", ThisMonthRewards) + "</small>";

                lbLastMonthpayments.Text = totalLastMonthPayments.ToString();
                lbThisMonthPayments.Text = totalThisMonthPayments.ToString();
                lbTotal.Text = totalPayments.ToString();

                lbDeposits.Text = string.Format("{0:0.00}", totalcredit);
                lbHoldings.Text = string.Format("{0:0.00}", totalbalance);
            }

            dtCount = new DataTable();
            dt3.Columns.AddRange(new DataColumn[8] { new DataColumn("UserID"), new DataColumn("Password"), new DataColumn("FullName"), new DataColumn("Phone Number"), new DataColumn("Email"), new DataColumn("Business Name"), new DataColumn("Business Address"), new DataColumn("Post") });
            foreach (User oUser in aList)
            {
                if (oUser.BusinessAddress.Contains("Resale"))
                {
                    dt3.Rows.Add(oUser.UserID, oUser.Password, oUser.FullName, oUser.PhoneNumber, oUser.Email, oUser.BusinessName, oUser.BusinessAddress.Substring(0, oUser.BusinessAddress.IndexOf(" |") + 1), oUser.Post);

                }
                else
                {
                    dt3.Rows.Add(oUser.UserID, oUser.Password, oUser.FullName, oUser.PhoneNumber, oUser.Email, oUser.BusinessName, oUser.BusinessAddress, oUser.Post);

                }

            }

            gvUserInfo.DataSource = dt3;
            gvUserInfo.DataBind();
        }
        public string LimitCharacters(string text, int length)
        {
            // If text in shorter or equal to length, just return it
            if (text.Length <= length)
            {
                return text;
            }

            // Text is longer, so try to find out where to cut
            char[] delimiters = new char[] { ' ', '.', ',', ':', ';' };
            int index = text.LastIndexOfAny(delimiters, length - 3);

            if (index > (length / 2))
            {
                return text.Substring(0, index) + "...";
            }
            else
            {
                return text.Substring(0, length - 3) + "...";
            }
        }
        protected void Update_Click(object sender, System.EventArgs e)
        {
            try
            {

                oUserDAO.UpdateUser(Request.QueryString["UserID"], txtFirstNameUser.Text + " " + txtLastNameUser.Text, txtPhoneNumber.Text, txtEmail.Text, txtBusinessName.Text, txtBusinessAddress.Text, Convert.ToBoolean(ddActive.SelectedValue), txtCity.Text, ddState.SelectedItem.Text, txtZip.Text, txtResaleCert.Text, txtEIN.Text);
                lbDesc.Text = "Account has been updated!";

                Response.Redirect("UserInfo.aspx");


            }
            catch (Exception ex)
            {
                lbDesc.ForeColor = Color.Red;
                lbDesc.Text = ex.Message;
            }
        }
        protected void x_Click(object sender, System.EventArgs e)
        {
            myModal.Attributes.Add("style", "display:none");
        }
        protected void LoadAll_Click(object sender, System.EventArgs e)
        {
            gvUserInfo.PageSize = 300;
            gvUserInfo.DataBind();
        }
        private void BindGridTrans(DataTable dt, string user)

        {
            DataTable dtCount = new DataTable();
            List<MetroFastPayLibrary.Account> aList = new List<MetroFastPayLibrary.Account>();
            aList = new List<MetroFastPayLibrary.Account>();

            aList = oUserDAO.PopulateAccountTransactionByUserID(user);

            dtCount = new DataTable();
            dt.Columns.AddRange(new DataColumn[4] { new DataColumn("ID"), new DataColumn("Amount"), new DataColumn("TransactionID"), new DataColumn("Date Added") });
            foreach (MetroFastPayLibrary.Account oAccount in aList)
            {

                dt.Rows.Add(oAccount.ID, string.Format("{0:0.00}", Convert.ToDecimal(oAccount.Amount)), oAccount.TransactionID, oAccount.CreatedDate);

            }

            gvTrans.DataSource = dt;
            gvTrans.DataBind();

            if (aList.Count == 0)
            {
                transH3.Visible = false;
            }
            else
            {
                transH3.Visible = true;
            }
        }
        private void BindGridReport(DataTable dt, string user)

        {
            if (IsPostBack)
            {
                DataTable dtCount = new DataTable();
                List<Payment> aList = new List<Payment>();
                aList = new List<Payment>();

                aList = oUserDAO.PopulateReportbyUserThisMonth(user);

                dtCount = new DataTable();
                dt.Columns.AddRange(new DataColumn[12] { new DataColumn("ID"), new DataColumn("UserID"), new DataColumn("Provider"), new DataColumn("Client#"), new DataColumn("Conf#"), new DataColumn("Code"), new DataColumn("Payment"), new DataColumn("Fees"), new DataColumn("Total"), new DataColumn("Comm."), new DataColumn("Rewards"), new DataColumn("Date Paid") });
                foreach (Payment oPayment in aList)
                {
                    User oFee = new User();
                    oFee = oUserDAO.RetrieveFeebyUserID(oPayment.UserID);
                    decimal cardcom;
                    string cardnum = DAO.Decrypt(oPayment.CCNumberUsed.Trim(), ConfigurationManager.AppSettings["encryptionKey"]).Remove(1, 15);

                    if (cardnum == "5" && oPayment.Provider.Substring(0, oPayment.Provider.LastIndexOf(" -") + 1).Trim() != "SinPin")
                    {
                        cardcom = Convert.ToDecimal(oPayment.AmountPaid) * Convert.ToDecimal(.02);
                        dt.Rows.Add(oPayment.ID, oPayment.UserID, oPayment.Provider.Substring(0, oPayment.Provider.LastIndexOf(" -") + 1).Trim(), oPayment.PhoneNumber, oPayment.Provider.Substring(oPayment.Provider.LastIndexOf(':') + 1), DAO.Decrypt(oPayment.CCNumberUsed.Trim(), ConfigurationManager.AppSettings["encryptionKey"]).Remove(0, 12), string.Format("{0:0.00}", Convert.ToDecimal(oPayment.AmountPaid)), string.Format("{0:0.00}", Convert.ToDecimal(oPayment.Fee)), string.Format("{0:0.00}", Convert.ToDecimal(oPayment.AmountPaid) + Convert.ToDecimal(oPayment.Fee)), string.Format("{0:0.00}", Convert.ToDecimal(oPayment.Fee - 2)), string.Format("{0:0.00}", cardcom), oPayment.CreatedDate);
                    }
                    else if (cardnum == "4" && oPayment.Provider.Substring(0, oPayment.Provider.LastIndexOf(" -") + 1).Trim() != "SinPin")
                    {
                        cardcom = Convert.ToDecimal(oPayment.AmountPaid) * Convert.ToDecimal(.01);
                        dt.Rows.Add(oPayment.ID, oPayment.UserID, oPayment.Provider.Substring(0, oPayment.Provider.LastIndexOf(" -") + 1).Trim(), oPayment.PhoneNumber, oPayment.Provider.Substring(oPayment.Provider.LastIndexOf(':') + 1), DAO.Decrypt(oPayment.CCNumberUsed.Trim(), ConfigurationManager.AppSettings["encryptionKey"]).Remove(0, 12), string.Format("{0:0.00}", Convert.ToDecimal(oPayment.AmountPaid)), string.Format("{0:0.00}", Convert.ToDecimal(oPayment.Fee)), string.Format("{0:0.00}", Convert.ToDecimal(oPayment.AmountPaid) + Convert.ToDecimal(oPayment.Fee)), string.Format("{0:0.00}", Convert.ToDecimal(oPayment.Fee - 2)), string.Format("{0:0.00}", cardcom), oPayment.CreatedDate);
                    }
                    else if (oPayment.Provider.Substring(0, oPayment.Provider.LastIndexOf(" -") + 1).Trim() == "SinPin")
                    {
                        dt.Rows.Add(oPayment.ID, oPayment.UserID, oPayment.Provider.Substring(0, oPayment.Provider.LastIndexOf(" -") + 1).Trim(), oPayment.PhoneNumber, oPayment.Provider.Substring(oPayment.Provider.LastIndexOf(':') + 1), DAO.Decrypt(oPayment.CCNumberUsed.Trim(), ConfigurationManager.AppSettings["encryptionKey"]).Remove(0, 12), string.Format("{0:0.00}", Convert.ToDecimal(oPayment.AmountPaid)), string.Format("{0:0.00}", Convert.ToDecimal(oPayment.Fee)), string.Format("{0:0.00}", Convert.ToDecimal(oPayment.AmountPaid) + Convert.ToDecimal(oPayment.Fee)), string.Format("{0:0.00}", Convert.ToDecimal(oPayment.Fee)), string.Format("{0:0.00}", 0), oPayment.CreatedDate);

                    }

                }

                gvUsers.DataSource = dt;
                gvUsers.DataBind();


                if (aList.Count == 0)
                {
                    paymentH3.Visible = false;
                }
                else
                {
                    paymentH3.Visible = true;
                }

            }
        }
        public int gettotalLastMonthPaymentsAmount(string user, bool all)
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                if (all == true)
                {
                    cmd.CommandText = @"select ISNULL(sum(AmountPaid), 0) from payments where Month(CreatedDate) = Month(Dateadd(M, -1, GetDate())) and Year(CreatedDate) = Year(GetDate())";
                }
                else
                {
                    cmd.CommandText = @"select ISNULL(sum(AmountPaid), 0)from payments where userid = '" + user + "' and Month(CreatedDate) = Month(Dateadd(M, -1, GetDate())) and Year(CreatedDate) = Year(GetDate())";
                }

                int Num = Convert.ToInt32(cmd.ExecuteScalar());
                return Num;
            }
        }
        public int gettotalThisMonthPaymentsAmount(string user, bool all)
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                if (all == true)
                {
                    cmd.CommandText = @"select ISNULL(sum(AmountPaid), 0) from payments where Month(CreatedDate) = Month(GetDate()) and Year(CreatedDate) = Year(GetDate())";
                }
                else
                {
                    cmd.CommandText = @"select ISNULL(sum(AmountPaid), 0) from payments where userid = '" + user + "' and Month(CreatedDate) = Month(GetDate()) and Year(CreatedDate) = Year(GetDate())";
                }
                int Num = Convert.ToInt32(cmd.ExecuteScalar());
                return Num;
            }
        }
        public int gettotalPaymentsAmount(string user, bool all)
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                if (all == true)
                {
                    cmd.CommandText = @"select ISNULL(sum(AmountPaid), 0) from payments";
                }
                else
                {
                    cmd.CommandText = @"select ISNULL(sum(AmountPaid), 0) from payments where userid = '" + user + "'";
                }
                int Num = Convert.ToInt32(cmd.ExecuteScalar());
                return Num;
            }
        }
        public int gettotalPaymentsbyuserid(string user, bool all)
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                if (all == true)
                {
                    cmd.CommandText = @"select count(*) from payments";
                }
                else
                {
                    cmd.CommandText = @"select count(*) from payments where userid = '" + user + "'";
                }
                int Num = Convert.ToInt32(cmd.ExecuteScalar());
                return Num;
            }
        }
        public int gettotalThisMonthPayments(string user, bool all)
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                if (all == true)
                {
                    cmd.CommandText = @"select count(*) from payments where Month(CreatedDate) = Month(GetDate()) and Year(CreatedDate) = Year(GetDate())";
                }
                else
                {
                    cmd.CommandText = @"select count(*) from payments where userid = '" + user + "' and Month(CreatedDate) = Month(GetDate()) and Year(CreatedDate) = Year(GetDate())";
                }
                int Num = Convert.ToInt32(cmd.ExecuteScalar());
                return Num;
            }
        }
        public int gettotalLastMonthPayments(string user, bool all)
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                if (all == true)
                {
                    cmd.CommandText = @"select count(*) from payments where Month(CreatedDate) = Month(Dateadd(M, -1, GetDate())) and Year(CreatedDate) = Year(GetDate())";
                }
                else
                {
                    cmd.CommandText = @"select count(*) from payments where userid = '" + user + "' and Month(CreatedDate) = Month(Dateadd(M, -1, GetDate())) and Year(CreatedDate) = Year(GetDate())";
                }
                int Num = Convert.ToInt32(cmd.ExecuteScalar());
                return Num;
            }
        }
        public int gettotalMetroPaymentsbyuserid(string user, bool all)
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                if (all == true)
                {
                    cmd.CommandText = @"select count(*) from payments where Provider like '%MetroPCS%'";
                }
                else
                {
                    cmd.CommandText = @"select count(*) from payments where userid = '" + user + "' and Provider like '%MetroPCS%'";
                }
                int Num = Convert.ToInt32(cmd.ExecuteScalar());
                return Num;
            }
        }
        public int gettotalBoostPaymentsbyuserid(string user, bool all)
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                if (all == true)
                {
                    cmd.CommandText = @"select count(*) from payments where Provider like '%Boost%'";
                }
                else
                {
                    cmd.CommandText = @"select count(*) from payments where userid = '" + user + "' and Provider like '%Boost%'";
                }
                int Num = Convert.ToInt32(cmd.ExecuteScalar());
                return Num;
            }
        }
        public int gettotalCricketPaymentsbyuserid(string user, bool all)
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                if (all == true)
                {
                    cmd.CommandText = @"select count(*) from payments where Provider like '%Cricket%'";
                }
                else
                {
                    cmd.CommandText = @"select count(*) from payments where userid = '" + user + "' and Provider like '%Cricket%'";
                }
                int Num = Convert.ToInt32(cmd.ExecuteScalar());
                return Num;
            }
        }
        public int gettotalSinPinPaymentsbyuserid(string user, bool all)
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                if (all == true)
                {
                    cmd.CommandText = @"select count(*) from payments where Provider like '%SinPin%'";
                }
                else
                {
                    cmd.CommandText = @"select count(*) from payments where userid = '" + user + "' and Provider like '%SinPin%'";
                }
                int Num = Convert.ToInt32(cmd.ExecuteScalar());
                return Num;
            }
        }

        public decimal gettotalBalance(string user, bool all)
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                if (all == true)
                {
                    cmd.CommandText = @"select ISNULL(sum(distinct credit), 0) from accounts";
                }
                else
                {
                    cmd.CommandText = @"select ISNULL(sum(credit), 0) from accounts where userid = '" + user + "'";
                }
                decimal Num = Convert.ToDecimal(cmd.ExecuteScalar());
                return Num;
            }
        }

        public decimal gettotalCredit(string user, bool all)
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                if (all == true)
                {
                    cmd.CommandText = @"select IsNULL(Sum(amount), 0) from credit";
                }
                else
                {
                    cmd.CommandText = @"select IsNULL(Sum(amount), 0) from credit where userid = '" + user + "'";
                }
                decimal Num = Convert.ToDecimal(cmd.ExecuteScalar());
                return Num;
            }
        }

        public int getProfitCellPaymentsLastMonthFee4(string user, bool all)
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                if (all == true)
                {
                    cmd.CommandText = @"select IsNULL(sum(fee - 2), 0) from payments where fee not like 0 and fee not like 3 and Provider not like '%SinPin%' and Month(CreatedDate) = Month(Dateadd(M, -1, GetDate())) and Year(CreatedDate) = Year(GetDate())";
                }
                else
                {
                    cmd.CommandText = @"select IsNULL(sum(fee - 2), 0) from payments where userid = '" + user + "'  and fee not like 0 and fee not like 3 and Provider not like '%SinPin%' and Month(CreatedDate) = Month(Dateadd(M, -1, GetDate())) and Year(CreatedDate) = Year(GetDate())";
                }
                int Num = Convert.ToInt32(cmd.ExecuteScalar());
                return Num;
            }
        }

        public int getProfitCellPaymentsThisMonthFee4(string user, bool all)
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                if (all == true)
                {
                    cmd.CommandText = @"select IsNULL(sum(fee - 2), 0) from payments where Provider not like '%SinPin%' and fee not like 0 and fee not like 3 and Month(CreatedDate) = Month(GetDate()) and Year(CreatedDate) = Year(GetDate())";
                }
                else
                {
                    cmd.CommandText = @"select IsNULL(sum(fee - 2), 0) from payments where userid = '" + user + "' and fee not like 0 and fee not like 3 and  Provider  not like '%SinPin%' and Month(CreatedDate) = Month(GetDate()) and Year(CreatedDate) = Year(GetDate())";
                }
                int Num = Convert.ToInt32(cmd.ExecuteScalar());
                return Num;
            }
        }

        public int getProfitCellPaymentsLastMonthFee3(string user, bool all)
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                if (all == true)
                {
                    cmd.CommandText = @"select IsNULL(sum(fee - 1), 0) from payments where fee not like 0 and fee not like 4 and Provider not like '%SinPin%' and Month(CreatedDate) = Month(Dateadd(M, -1, GetDate())) and Year(CreatedDate) = Year(GetDate())";
                }
                else
                {
                    cmd.CommandText = @"select IsNULL(sum(fee - 1), 0) from payments where userid = '" + user + "'  and fee not like 0 and fee not like 4 and Provider not like '%SinPin%' and Month(CreatedDate) = Month(Dateadd(M, -1, GetDate())) and Year(CreatedDate) = Year(GetDate())";
                }
                int Num = Convert.ToInt32(cmd.ExecuteScalar());
                return Num;
            }
        }

        public int getProfitCellPaymentsThisMonthFee3(string user, bool all)
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                if (all == true)
                {
                    cmd.CommandText = @"select IsNULL(sum(fee - 1), 0) from payments where Provider not like '%SinPin%' and fee not like 0 and fee not like 4 and Month(CreatedDate) = Month(GetDate()) and Year(CreatedDate) = Year(GetDate())";
                }
                else
                {
                    cmd.CommandText = @"select IsNULL(sum(fee - 1), 0) from payments where userid = '" + user + "' and fee not like 0 and fee not like 4 and  Provider  not like '%SinPin%' and Month(CreatedDate) = Month(GetDate()) and Year(CreatedDate) = Year(GetDate())";
                }
                int Num = Convert.ToInt32(cmd.ExecuteScalar());
                return Num;
            }
        }

        public decimal getProfitSinPinLastMonth(string user, bool all)
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                if (all == true)
                {
                    cmd.CommandText = @"select IsNULL(sum(AmountPaid  * .03), 0) from payments where Provider like '%SinPin%' and Month(CreatedDate) = Month(Dateadd(M, -1, GetDate())) and Year(CreatedDate) = Year(GetDate())";
                }
                else
                {
                    cmd.CommandText = @"select IsNULL(sum(AmountPaid * .03), 0) from payments where userid = '" + user + "' and Provider like '%SinPin%' and Month(CreatedDate) = Month(Dateadd(M, -1, GetDate())) and Year(CreatedDate) = Year(GetDate())";
                }
                decimal Num = Convert.ToDecimal(cmd.ExecuteScalar());
                return Num;
            }
        }
        public decimal getProfitSinPinThisMonth(string user, bool all)
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                if (all == true)
                {
                    cmd.CommandText = @"select IsNULL(sum(AmountPaid * .03), 0) from payments where Provider like '%SinPin%' and Month(CreatedDate) = Month(GetDate()) and Year(CreatedDate) = Year(GetDate())";
                }
                else
                {
                    cmd.CommandText = @"select IsNULL(sum(AmountPaid * .03), 0) from payments where userid = '" + user + "' and Provider like '%SinPin%' and Month(CreatedDate) = Month(GetDate()) and Year(CreatedDate) = Year(GetDate())";
                }
                decimal Num = Convert.ToDecimal(cmd.ExecuteScalar());
                return Num;
            }
        }
        public decimal getRewardMetroPCSLastMonth(string user, bool all)
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                if (all == true)
                {
                    cmd.CommandText = @"select IsNULL(sum(AmountPaid  * .02), 0) from payments where Provider like '%MetroPCS%' and Month(CreatedDate) = Month(Dateadd(M, -1, GetDate())) and Year(CreatedDate) = Year(GetDate())";
                }
                else
                {
                    cmd.CommandText = @"select IsNULL(sum(AmountPaid * .02), 0) from payments where userid = '" + user + "' and Provider like '%MetroPCS%' and Month(CreatedDate) = Month(Dateadd(M, -1, GetDate())) and Year(CreatedDate) = Year(GetDate())";
                }
                decimal Num = Convert.ToDecimal(cmd.ExecuteScalar());
                return Num;
            }
        }
        public decimal getRewardMetroPCSThisMonth(string user, bool all)
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                if (all == true)
                {
                    cmd.CommandText = @"select IsNULL(sum(AmountPaid * .02), 0) from payments where Provider like '%MetroPCS%' and Month(CreatedDate) = Month(GetDate()) and Year(CreatedDate) = Year(GetDate())";
                }
                else
                {
                    cmd.CommandText = @"select IsNULL(sum(AmountPaid * .02), 0) from payments where userid = '" + user + "' and Provider like '%MetroPCS%' and Month(CreatedDate) = Month(GetDate()) and Year(CreatedDate) = Year(GetDate())";
                }
                decimal Num = Convert.ToDecimal(cmd.ExecuteScalar());
                return Num;
            }
        }

        public decimal getRewardBoostCricketLastMonth(string user, bool all)
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                if (all == true)
                {
                    cmd.CommandText = @"select IsNULL(sum(AmountPaid  * .01), 0) from payments where Provider not like '%MetroPCS%' and Provider not like '%SinPin%' and Month(CreatedDate) = Month(Dateadd(M, -1, GetDate())) and Year(CreatedDate) = Year(GetDate())";
                }
                else
                {
                    cmd.CommandText = @"select IsNULL(sum(AmountPaid * .01), 0) from payments where userid = '" + user + "' and Provider not like '%MetroPCS%' and Provider not like '%SinPin%' and Month(CreatedDate) = Month(Dateadd(M, -1, GetDate())) and Year(CreatedDate) = Year(GetDate())";
                }
                decimal Num = Convert.ToDecimal(cmd.ExecuteScalar());
                return Num;
            }
        }
        public decimal getRewardBoostCricketThisMonth(string user, bool all)
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                if (all == true)
                {
                    cmd.CommandText = @"select IsNULL(sum(AmountPaid * .01), 0) from payments where Provider not like '%MetroPCS%' and Provider not like '%SinPin%' and Month(CreatedDate) = Month(GetDate()) and Year(CreatedDate) = Year(GetDate())";
                }
                else
                {
                    cmd.CommandText = @"select IsNULL(sum(AmountPaid * .01), 0) from payments where userid = '" + user + "' and Provider not like '%MetroPCS%' and Provider not like '%SinPin%' and Month(CreatedDate) = Month(GetDate()) and Year(CreatedDate) = Year(GetDate())";
                }
                decimal Num = Convert.ToDecimal(cmd.ExecuteScalar());
                return Num;
            }
        }
        public DateTime LastLoginTime(string user)
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                cmd.CommandText = @"select createddate from ipcapture where userid = '" + user + "' and PaymentID=0 order by createddate desc";
                DateTime Date = Convert.ToDateTime(cmd.ExecuteScalar());
                return Date;
            }
        }
    }
}