﻿using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Security.Principal;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.AspNet.Identity;
using System.Net.Mail;
using System.Configuration;
using System.Web.UI.HtmlControls;
using System.Drawing;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using System.Net;
using MetroFastPayLibrary;
using System.Text;
using System.Security.Cryptography;
using System.Runtime.InteropServices;
using System.ComponentModel;
using System.Web.Services;
using System.Diagnostics;
using System.Management.Automation;
using System.Net.Http;
using System.Threading.Tasks;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using RestSharp;
using MetroFastPay.com.dollarphone.www;

namespace MetroFastPay
{
    public partial class Stats : System.Web.UI.Page
    {
        User oUser = new User();
        UserDAO oUserDAO = new UserDAO();
        System.Web.HttpCookie UserCookie = HttpContext.Current.Request.Cookies["UserNameCookie"];
        private HttpClient _Client = new HttpClient();
        string dbCon = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
        protected async void Page_Load(object sender, EventArgs e)
        {
            if (Request.Cookies["UserNameCookie"] == null)
            {
                //Session.Abandon();
                //UserCookie.Expires = DateTime.Now.AddYears(-1);
                //Response.Cookies.Add(UserCookie);
                Response.Redirect("out.aspx");

            }
            else
            {
                if (!this.IsPostBack)
                {
                    try
                    {
                        oUser = oUserDAO.RetrieveUserByUserID(UserCookie.Value);

                        MetroFastPayLibrary.Account oAccount = new MetroFastPayLibrary.Account();
                        oAccount = oUserDAO.RetrieveAccount(UserCookie.Value);

                        if (oUser.UserType == "Admin")
                        {


                            decimal totalbalance = gettotalBalance(UserCookie.Value, true);
                            // lbBalance.Text = string.Format("{0:0.00}", totalbalance);
                            lbBalance.Text = "∞";
                            //await ReupAPIBalance();
                            //using (PinManager pm = new PinManager())
                            //{
                            //    pm.Credentials = new System.Net.NetworkCredential(ConfigurationManager.AppSettings["dpUser"], ConfigurationManager.AppSettings["dpPass"]);
                            //    decimal dpCredit = pm.GetAgentCreditLimit().AvailableCredit;
                            //    lbBalance.Text = dpCredit.ToString() + "/RM:" + Session["ReupBalance"].ToString();
                            //}
                            
                            decimal ThisMonthProfitFee4 = getProfitCellPaymentsThisMonthFee4(UserCookie.Value, true);
                            decimal ThisMonthProfitFee3 = getProfitCellPaymentsThisMonthFee3(UserCookie.Value, true);
                            decimal ThisMonthSinPinProfit = getProfitSinPinThisMonth(UserCookie.Value, true);
                            decimal reupProfit = getProfitCellPaymentReup(UserCookie.Value, true);
                            decimal ThisMonthProfit = ThisMonthProfitFee4 + ThisMonthProfitFee3 + ThisMonthSinPinProfit + reupProfit;
                            decimal ThisMonthRewards = getRewardMetroPCSThisMonth(UserCookie.Value, true) + getRewardBoostCricketThisMonth(UserCookie.Value, true);
                            lbCommision.Text = string.Format("{0:0.00}", ThisMonthProfit + ThisMonthRewards);

                            decimal totalPayments = gettotalThisMonthPayments(UserCookie.Value, true);
                            lbPayments.Text = totalPayments.ToString();

                            decimal totalUsers = gettotalUsers(UserCookie.Value, true, oUser.Post);
                            lbUsers.Text = totalUsers.ToString();


                        }
                        else
                        {


                            decimal totalbalance = gettotalBalance(UserCookie.Value, false);
                            lbBalance.Text = string.Format("{0:0.00}", totalbalance);

                            decimal ThisMonthProfitFee4 = getProfitCellPaymentsThisMonthFee4(UserCookie.Value, false);
                            decimal ThisMonthProfitFee3 = getProfitCellPaymentsThisMonthFee3(UserCookie.Value, false);
                            decimal ThisMonthSinPinProfit = getProfitSinPinThisMonth(UserCookie.Value, false);
                            decimal ThisMonthProfit = ThisMonthProfitFee4 + ThisMonthProfitFee3 + ThisMonthSinPinProfit;
                            decimal reupProfit = getProfitCellPaymentReup(UserCookie.Value, false);
                            lbCommision.Text = string.Format("{0:0.00}", ThisMonthProfit);

                            if (oUser.UserID == "Reup")
                            {
                                lbCommision.Text = string.Format("{0:0.00}", reupProfit);
                            }


                            decimal totalPayments = gettotalThisMonthPayments(UserCookie.Value, false);
                            lbPayments.Text = totalPayments.ToString();

                            decimal totalUsers = gettotalUsers(UserCookie.Value, false, oUser.Post);
                            lbUsers.Text = totalUsers.ToString();


                        }
                        if (Request.Url.AbsoluteUri.Contains("?Payment"))
                        {
                            lbPayments.Visible = true;
                        }
                        if (Request.Url.AbsoluteUri.Contains("?Users"))
                        {
                            lbUsers.Visible = true;
                        }
                        if (Request.Url.AbsoluteUri.Contains("?Commission"))
                        {
                            lbCommision.Visible = true;
                        }
                        if (Request.Url.AbsoluteUri.Contains("?Balance"))
                        {
                            lbBalance.Visible = true;
                        }

                        if (oAccount.Active == false )//&& oUser.UserType != "Admin")
                        {
                            lbBalance.Text = "∞";

                        }
                        //if (oUser.UserType == "Admin")
                        //{
                        //    using (PinManager pm = new PinManager())
                        //    {
                        //        pm.Credentials = new System.Net.NetworkCredential(ConfigurationManager.AppSettings["dpUser"], ConfigurationManager.AppSettings["dpPass"]);
                        //        decimal dpCredit = pm.GetAgentCreditLimit().AvailableCredit;
                        //        lbBalance.Text = dpCredit.ToString();
                        //    }
                        //}
                    }
                    catch (Exception ex)
                    {
                        Response.Redirect("out.aspx");
                    }

                }
            }
        }

        protected void GetTime(object sender, EventArgs e)
        {
            oUser = oUserDAO.RetrieveUserByUserID(UserCookie.Value);

            MetroFastPayLibrary.Account oAccount = new MetroFastPayLibrary.Account();
            oAccount = oUserDAO.RetrieveAccount(UserCookie.Value);

            if (oUser.UserType == "Admin")
            {


                decimal totalbalance = gettotalBalance(UserCookie.Value, true);
                //lbBalance.Text = totalbalance.ToString();

                using (PinManager pm = new PinManager())
                {
                    pm.Credentials = new System.Net.NetworkCredential(ConfigurationManager.AppSettings["dpUser"], ConfigurationManager.AppSettings["dpPass"]);
                    decimal dpCredit = pm.GetAgentCreditLimit().AvailableCredit;
                    lbBalance.Text = dpCredit.ToString();
                }

                decimal ThisMonthProfitFee4 = getProfitCellPaymentsThisMonthFee4(UserCookie.Value, true);
                decimal ThisMonthProfitFee3 = getProfitCellPaymentsThisMonthFee3(UserCookie.Value, true);
                decimal ThisMonthSinPinProfit = getProfitSinPinThisMonth(UserCookie.Value, true);
                decimal reupProfit = getProfitCellPaymentReup(UserCookie.Value, true);
                decimal ThisMonthProfit = ThisMonthProfitFee4 + ThisMonthProfitFee3 + ThisMonthSinPinProfit + reupProfit;
                decimal ThisMonthRewards = getRewardMetroPCSThisMonth(UserCookie.Value, true) + getRewardBoostCricketThisMonth(UserCookie.Value, true);
                lbCommision.Text = string.Format("{0:0.00}", ThisMonthProfit + ThisMonthRewards);

                decimal totalPayments = gettotalThisMonthPayments(UserCookie.Value, true);
                lbPayments.Text = totalPayments.ToString();

                decimal totalUsers = gettotalUsers(UserCookie.Value, true, oUser.Post);
                lbUsers.Text = totalUsers.ToString();

            }
            else
            {


                decimal totalbalance = gettotalBalance(UserCookie.Value, false);
                lbBalance.Text = totalbalance.ToString();

                decimal ThisMonthProfitFee4 = getProfitCellPaymentsThisMonthFee4(UserCookie.Value, false);
                decimal ThisMonthProfitFee3 = getProfitCellPaymentsThisMonthFee3(UserCookie.Value, false);
                decimal ThisMonthSinPinProfit = getProfitSinPinThisMonth(UserCookie.Value, false);
                decimal ThisMonthProfit = ThisMonthProfitFee4 + ThisMonthProfitFee3 + ThisMonthSinPinProfit;
                decimal reupProfit = getProfitCellPaymentReup(UserCookie.Value, false);
                lbCommision.Text = string.Format("{0:0.00}", ThisMonthProfit);

                if (oUser.UserID == "Reup")
                {
                    lbCommision.Text = string.Format("{0:0.00}", reupProfit);
                }

                decimal totalPayments = gettotalThisMonthPayments(UserCookie.Value, false);
                lbPayments.Text = totalPayments.ToString();

                decimal totalUsers = gettotalUsers(UserCookie.Value, false, oUser.Post);
                lbUsers.Text = totalUsers.ToString();

            }
            if (Request.Url.AbsoluteUri.Contains("?Payment"))
            {
                lbPayments.Visible = true;
            }
            if (Request.Url.AbsoluteUri.Contains("?Users"))
            {
                lbUsers.Visible = true;
            }
            if (Request.Url.AbsoluteUri.Contains("?Commission"))
            {
                lbCommision.Visible = true;
            }
            if (Request.Url.AbsoluteUri.Contains("?Balance"))
            {
                lbBalance.Visible = true;
            }

            if (oAccount.Active == false && oUser.UserType != "Admin")
            {
                lbBalance.Text = "∞";

            }
            if (oUser.UserType == "Admin")
            {
                using (PinManager pm = new PinManager())
                {
                    pm.Credentials = new System.Net.NetworkCredential(ConfigurationManager.AppSettings["dpUser"], ConfigurationManager.AppSettings["dpPass"]);
                    decimal dpCredit = pm.GetAgentCreditLimit().AvailableCredit;
                    lbBalance.Text = dpCredit.ToString();
                }
            }
        }
        protected void LogOut_Click(object sender, System.EventArgs e)
        {
            try
            {
                Session.Abandon();

                System.Web.HttpCookie UserCookie = new System.Web.HttpCookie("UserNameCookie");
                UserCookie.Expires = DateTime.Now.AddYears(-1);
                Response.Cookies.Add(UserCookie);
                Response.Redirect("login.aspx");
            }
            catch
            {
            }
        }

        public decimal gettotalBalance(string user, bool all)
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                if (all == true)
                {
                    cmd.CommandText = @"select ISNULL(sum(distinct credit), 0) from accounts";
                }
                else
                {
                    cmd.CommandText = @"select ISNULL(sum(credit), 0) from accounts where userid = '" + user + "'";
                }
                decimal Num = Convert.ToDecimal(cmd.ExecuteScalar());
                return Num;
            }
        }

        public decimal gettotalUsers(string user, bool all, string post)
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                if (all == true)
                {
                    cmd.CommandText = @"select count(*) from users ";
                }
                else
                {
                    cmd.CommandText = @"select count(*) from users where post ='" + post + "'";
                }
                decimal Num = Convert.ToDecimal(cmd.ExecuteScalar());
                return Num;
            }
        }

        public int gettotalThisMonthPayments(string user, bool all)
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                if (all == true)
                {
                    cmd.CommandText = @"select count(*) from payments where Month(CreatedDate) = Month(GetDate()) and Year(CreatedDate) = Year(GetDate())";
                }
                else
                {
                    cmd.CommandText = @"select count(*) from payments where userid = '" + user + "' and Month(CreatedDate) = Month(GetDate()) and Year(CreatedDate) = Year(GetDate())";
                }
                int Num = Convert.ToInt32(cmd.ExecuteScalar());
                return Num;
            }
        }

        public int getProfitCellPaymentsThisMonthFee4(string user, bool all)
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                if (all == true)
                {
                    cmd.CommandText = @"select IsNULL(sum(fee - 2), 0) from payments where Provider not like '%SinPin%' and fee not like 0 and fee not like 3 and user not like 'Reup' and Month(CreatedDate) = Month(GetDate()) and Year(CreatedDate) = Year(GetDate())";
                }
                else
                {
                    cmd.CommandText = @"select IsNULL(sum(fee - 2), 0) from payments where userid = '" + user + "' and fee not like 0 and fee not like 3 and  Provider  not like '%SinPin%' and Month(CreatedDate) = Month(GetDate()) and Year(CreatedDate) = Year(GetDate())";
                }
                int Num = Convert.ToInt32(cmd.ExecuteScalar());
                return Num;
            }
        }

        public int getProfitCellPaymentsThisMonthFee3(string user, bool all)
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                if (all == true)
                {
                    cmd.CommandText = @"select IsNULL(sum(fee - 1), 0) from payments where Provider not like '%SinPin%' and fee not like 0 and fee not like 4 and user not like 'Reup' and Month(CreatedDate) = Month(GetDate()) and Year(CreatedDate) = Year(GetDate())";
                }
                else
                {
                    cmd.CommandText = @"select IsNULL(sum(fee - 2), 0) from payments where userid = '" + user + "' and fee not like 0 and fee not like 4 and  Provider  not like '%SinPin%' and Month(CreatedDate) = Month(GetDate()) and Year(CreatedDate) = Year(GetDate())";
                }
                int Num = Convert.ToInt32(cmd.ExecuteScalar());
                return Num;
            }
        }
        public decimal getProfitSinPinThisMonth(string user, bool all)
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                if (all == true)
                {
                    cmd.CommandText = @"select IsNULL(sum(AmountPaid * .03), 0) from payments where Provider like '%SinPin%' and Month(CreatedDate) = Month(GetDate()) and Year(CreatedDate) = Year(GetDate())";
                }
                else
                {
                    cmd.CommandText = @"select IsNULL(sum(AmountPaid * .22), 0) from payments where userid = '" + user + "' and Provider like '%SinPin%' and Month(CreatedDate) = Month(GetDate()) and Year(CreatedDate) = Year(GetDate())";
                }
                decimal Num = Convert.ToDecimal(cmd.ExecuteScalar());
                return Num;
            }
        }

        public decimal getRewardMetroPCSThisMonth(string user, bool all)
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                if (all == true)
                {
                    cmd.CommandText = @"select IsNULL(sum(AmountPaid * .02), 0) from payments where Provider like '%MetroPCS%' and Month(CreatedDate) = Month(GetDate()) and Year(CreatedDate) = Year(GetDate())";
                }
                else
                {
                    cmd.CommandText = @"select IsNULL(sum(AmountPaid * .02), 0) from payments where userid = '" + user + "' and Provider like '%MetroPCS%' and Month(CreatedDate) = Month(GetDate()) and Year(CreatedDate) = Year(GetDate())";
                }
                decimal Num = Convert.ToDecimal(cmd.ExecuteScalar());
                return Num;
            }
        }

        public decimal getRewardBoostCricketThisMonth(string user, bool all)
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                if (all == true)
                {
                    cmd.CommandText = @"select IsNULL(sum(AmountPaid * .01), 0) from payments where Provider not like '%MetroPCS%' and Provider not like '%SinPin%' and Month(CreatedDate) = Month(GetDate()) and Year(CreatedDate) = Year(GetDate())";
                }
                else
                {
                    cmd.CommandText = @"select IsNULL(sum(AmountPaid * .01), 0) from payments where userid = '" + user + "' and Provider not like '%MetroPCS%' and Provider not like '%SinPin%' and Month(CreatedDate) = Month(GetDate()) and Year(CreatedDate) = Year(GetDate())";
                }
                decimal Num = Convert.ToDecimal(cmd.ExecuteScalar());
                return Num;
            }
        }
        public int gettotalMetroPaymentsbyuserid(string user, bool all)
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                if (all == true)
                {
                    cmd.CommandText = @"select count(*) from payments where Provider like '%MetroPCS%'";
                }
                else
                {
                    cmd.CommandText = @"select count(*) from payments where userid = '" + user + "' and Provider like '%MetroPCS%'";
                }
                int Num = Convert.ToInt32(cmd.ExecuteScalar());
                return Num;
            }
        }
        public int gettotalBoostPaymentsbyuserid(string user, bool all)
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                if (all == true)
                {
                    cmd.CommandText = @"select count(*) from payments where Provider like '%Boost%'";
                }
                else
                {
                    cmd.CommandText = @"select count(*) from payments where userid = '" + user + "' and Provider like '%Boost%'";
                }
                int Num = Convert.ToInt32(cmd.ExecuteScalar());
                return Num;
            }
        }
        public int gettotalCricketPaymentsbyuserid(string user, bool all)
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                if (all == true)
                {
                    cmd.CommandText = @"select count(*) from payments where Provider like '%Cricket%'";
                }
                else
                {
                    cmd.CommandText = @"select count(*) from payments where userid = '" + user + "' and Provider like '%Cricket%'";
                }
                int Num = Convert.ToInt32(cmd.ExecuteScalar());
                return Num;
            }
        }
        public int gettotalSinPinPaymentsbyuserid(string user, bool all)
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                if (all == true)
                {
                    cmd.CommandText = @"select count(*) from payments where Provider like '%SinPin%'";
                }
                else
                {
                    cmd.CommandText = @"select count(*) from payments where userid = '" + user + "' and Provider like '%SinPin%'";
                }
                int Num = Convert.ToInt32(cmd.ExecuteScalar());
                return Num;
            }
        }
        public int gettotalPaymentsbyuserid(string user, bool all)
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                if (all == true)
                {
                    cmd.CommandText = @"select count(*) from payments";
                }
                else
                {
                    cmd.CommandText = @"select count(*) from payments where userid = '" + user + "'";
                }
                int Num = Convert.ToInt32(cmd.ExecuteScalar());
                return Num;
            }
        }

        public int getTop5Payments()
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                cmd.CommandText = @"select top(5) payments.userid, count(*) as NumberofPay from payments where Month(CreatedDate) = Month(GetDate()) and Year(CreatedDate) = Year(GetDate()) group by userid order by NumberofPay desc ";
                int Num = Convert.ToInt32(cmd.ExecuteScalar());
                return Num;
            }
        }

        public int paymentsByQuarter(int quarter, string provider, bool all, string user)
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                if (all == true)
                {
                    if (quarter == 1)
                    {
                        cmd.CommandText = @"select count(*) from payments where Provider like '%" + provider + "%' and Month(CreatedDate) between '1' and '3' and Year(CreatedDate) = Year(getdate())";

                    }
                    if (quarter == 2)
                    {
                        cmd.CommandText = @"select count(*) from payments where Provider like '%" + provider + "%' and Month(CreatedDate) between '4' and '6' and Year(CreatedDate) = Year(getdate())";
                    }
                    if (quarter == 3)
                    {
                        cmd.CommandText = @"select count(*) from payments where Provider like '%" + provider + "%' and Month(CreatedDate) between '7' and '9' and Year(CreatedDate) = Year(getdate())";
                    }
                    if (quarter == 4)
                    {
                        cmd.CommandText = @"select count(*) from payments where Provider like '%" + provider + "%' and Month(CreatedDate) between '10' and '12' and Year(CreatedDate) = Year(getdate())";
                    }
                }
                else
                {
                    if (quarter == 1)
                    {
                        cmd.CommandText = @"select count(*) from payments where Provider like '%" + provider + "%' and Month(CreatedDate) between '1' and '3' and Year(CreatedDate) = Year(getdate()) and userid = '" + user + "'";

                    }
                    if (quarter == 2)
                    {
                        cmd.CommandText = @"select count(*) from payments where Provider like '%" + provider + "%' and Month(CreatedDate) between '4' and '6' and Year(CreatedDate) = Year(getdate()) and userid = '" + user + "'";
                    }
                    if (quarter == 3)
                    {
                        cmd.CommandText = @"select count(*) from payments where Provider like '%" + provider + "%' and Month(CreatedDate) between '7' and '9' and Year(CreatedDate) = Year(getdate()) and userid = '" + user + "'";
                    }
                    if (quarter == 4)
                    {
                        cmd.CommandText = @"select count(*) from payments where Provider like '%" + provider + "%' and Month(CreatedDate) between '10' and '12' and Year(CreatedDate) = Year(getdate()) and userid = '" + user + "'";
                    }
                }


                int Num = Convert.ToInt32(cmd.ExecuteScalar());
                return Num;
            }
        }

        public decimal getProfitCellPaymentReup(string user, bool all)
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                {
                    if (all == true)
                    {
                        cmd.CommandText = @"select isnull(sum(fee - 2.75), 0) from Payments where userid = 'Reup' and fee not like 0 and Month(CreatedDate) = Month(GetDate()) and Year(CreatedDate) = Year(GetDate())";
                    }
                    else
                    {
                        cmd.CommandText = @"select isnull(sum(fee - 2.75), 0) from Payments where userid = '" + user + "' and fee not like 0 and Month(CreatedDate) = Month(GetDate()) and Year(CreatedDate) = Year(GetDate())";
                    }
                }
                decimal Num = Convert.ToDecimal(cmd.ExecuteScalar());
                return Num;
            }
        }
        async Task ReupAPIBalance()
        {     
                //_Client = new HttpClient();
                //_Client.BaseAddress = new Uri("https://api.sandbox.reupmobile.com/");
                //_Client.DefaultRequestHeaders.Accept.Clear();
                //_Client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(Convert.ToBase64String(System.Text.ASCIIEncoding.ASCII.GetBytes(string.Format("{0}:{1}", "ffweb-api-user", "TzEQyoQY457cmPtMPdc8"))));
                //_Client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                //_Client.DefaultRequestHeaders.AcceptCharset.Add(new StringWithQualityHeaderValue("UTF-8"));

                var client = new RestClient("https://api.sandbox.reupmobile.com/api/query/balances");
                var request = new RestRequest(Method.GET);
                request.AddHeader("postman-token", "dae85a14-fc82-b012-56c7-4080970accc1");
                request.AddHeader("cache-control", "no-cache");
                request.AddHeader("dealer-id", "39881");
                request.AddHeader("contenttype", "application/json");
                request.AddHeader("authorization", "Basic ZmZ3ZWItYXBpLXVzZXI6VHpFUXlvUVk0NTdjbVB0TVBkYzg=");
                IRestResponse response = client.Execute(request);

                if (response.Content != "")
                {
                string s = response.Content;
                Session["ReupBalance"] = getBetween(s, "airtimeBalance\":\"", "\",\"spiffBalance\"");


            }
                else
                {

                    Session["error"] = "error3";
                    Session["conf"] = "";
                }

            }
        public static string getBetween(string strSource, string strStart, string strEnd)
        {
            int Start, End;
            if (strSource.Contains(strStart) && strSource.Contains(strEnd))
            {
                Start = strSource.IndexOf(strStart, 0) + strStart.Length;
                End = strSource.IndexOf(strEnd, Start);
                return strSource.Substring(Start, End - Start);
            }
            else
            {
                return "";
            }
        }
    }

}