﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net.Mail;
using System.Configuration;
using System.Web.UI.HtmlControls;
using System.Drawing;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using System.Net;
using MetroFastPayLibrary;
using System.Text;
using System.Security.Cryptography;
using Twilio;
using Twilio.Rest.Api.V2010.Account;

namespace MetroFastPay
{
    public partial class Signup : System.Web.UI.Page
    {
        User oUser = new User();
        UserDAO oUserDAO = new UserDAO();
        HttpCookie GuatePinUserCookie = new HttpCookie("GuatePinUser");
        string dbCon = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
        protected void Page_Load(object sender, EventArgs e)
        {

            try
            {
                if (Request.Url.AbsoluteUri.Contains("guateUser"))
                {
                    GuatePinUserCookie.Value = "GuatePinUser";
                    GuatePinUserCookie.Expires = DateTime.Now.AddDays(1);
                    Response.Cookies.Add(GuatePinUserCookie);

                    imgLogo.Src = "Img/GuatePinLogo.png";
                    //imgLogo.Width = 100;
                    imgLogo.Style.Add("width", "100%");
                }
                else
                {
                    Session.Abandon();
                    GuatePinUserCookie.Expires = DateTime.Now.AddYears(-1);
                    Response.Cookies.Add(GuatePinUserCookie);

                    imgLogo.Src = "Img/logoWithName.png";
                    //imgLogo.Width = 100;
                    imgLogo.Style.Add("width", "100%");
                }

                txtPassword.Attributes.Add("onkeyup", "Password();");
                txtConfPass.Attributes.Add("onkeyup", "ConfPasword();");
                txtEmail.Attributes.Add("onkeyup", "EmailAddress(this);");
                txtPhoneNumber.Attributes.Add("onkeyup", "PhoneNumber(this);");

            }
            catch (Exception ex)
            {
                Response.Redirect("login.aspx");
            }


        }



        protected void Submit_Click(object sender, System.EventArgs e)
        {
            try
            {
                if (Page.IsPostBack)
                {
                    int i = 0;
                    if (txtFirstName.Text == "") { i = 1; }
                    else if (txtLastName.Text == "") { i = 2; }
                    else if (txtPhoneNumber.Text == "") { i = 3; }
                    else if (txtUserName.Text == "") { i = 4; }
                    else if (txtPassword.Text == "") { i = 5; }
                    else if (txtEmail.Text == "") { i = 6; }
                    else if (txtBusinessName.Text == "") { i = 7; }
                    else if (txtAddress.Text == "") { i = 8; }
                    else if (txtCity.Text == "") { i = 8; }
                    else if (txtZip.Text == "") { i = 8; }
                    else if (txtResaleCert.Text == "") { i = 9; }
                    else if (txtEIN.Text == "") { i = 10; }
                    switch (i)
                    {
                        case 1: lbDesc.Text = "First name missing!"; break;
                        case 2: lbDesc.Text = "Last name missing!"; break;
                        case 3: lbDesc.Text = "Phone missing!"; break;
                        case 4: lbDesc.Text = "User Name missing!"; break;
                        case 5: lbDesc.Text = "Password missing!"; break;
                        case 6: lbDesc.Text = "Email missing!"; break;
                        case 7: lbDesc.Text = "Business Name missing!"; break;
                        case 8: lbDesc.Text = "Business Address/City/Zip missing!"; break;
                        case 9: lbDesc.Text = "Resale Certificate missing!"; break;
                        case 10: lbDesc.Text = "EIN missing!"; break;
                    }
                    lbDesc.ForeColor = Color.Red;
                    if (i == 0)
                    {
                        oUser = oUserDAO.RetrieveUserByUserID(txtUserName.Text);
                        if (oUser.UserID != null)
                        {
                            string LowerUsername = oUser.UserID.ToLower();
                            string LowerUsername2 = txtUserName.Text;

                            if (LowerUsername == LowerUsername2)
                            {
                                lbDesc.ForeColor = Color.Red;
                                lbDesc.Text = "ENG:Username already exists | SP:Usuario ya existe";
                                return;
                            }
                        }

                        string post = (LastPost() + 1).ToString();
                        //insert user
                        oUser = oUserDAO.InsertUser(txtUserName.Text, DAO.Encrypt(txtPassword.Text, ConfigurationManager.AppSettings["encryptionKey"]), txtFirstName.Text + " " + txtLastName.Text, txtPhoneNumber.Text, txtEmail.Text, txtBusinessName.Text, txtAddress.Text, post, "User", false, DateTime.Now, txtCity.Text, ddState.SelectedValue, txtZip.Text, txtResaleCert.Text, txtEIN.Text);
                        oUser = oUserDAO.InsertAccount(txtUserName.Text, post);
                        oUser = oUserDAO.InsertFee(txtUserName.Text, 4);

                        if (Request.Url.ToString().Contains("dealer"))
                        {
                            User dealer = new User();
                            dealer = oUserDAO.RetrieveSpiffUserID(Request.QueryString["dealer"]);
                            if (dealer.UserID != "")
                            {
                                oUser = oUserDAO.InsertDealerAgents(dealer.UserID, dealer.Post, post, Convert.ToDecimal(dealer.Fee));
                            }
                        }

                        ServicePointManager.Expect100Continue = true;
                        ServicePointManager.DefaultConnectionLimit = 9999;
                        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12 | SecurityProtocolType.Ssl3;

                        MailMessage message = new MailMessage();
                        SmtpClient smtpClient = new SmtpClient();
                        string msg = string.Empty;

                        MailAddress fromAddress = new MailAddress("support@telbug.com", "TelBug");
                        const string SERVER = "smtp.gmail.com";
                        MailMessage oMail = new System.Net.Mail.MailMessage();
                        oMail.From = fromAddress;
                        oMail.To.Add(txtEmail.Text);
                        oMail.Subject = "Account Created";
                        oMail.IsBodyHtml = true;
                        oMail.Body = "<a href='https://telbug.com/login?ConfirmEmail=" + txtUserName.Text + "'>CLICK HERE TO CONFIRM EMAIL</a><br /><br />Thank you for making Telbug a part of your business.<br /> Our goal is to make payment processing simple while giving you the best rates out there.<br /> <br /><h2>Features:</h2> We provide RTR payments for MetroPCS, Boost, and Cricket, three juggernauts in the prepaid wireless game. With more than 25 million customers combined your bonded to run into a Metro, Boost, or Cricket customer, so don’t be shy to let people know about your new payment options.<br /> <br /><h2>Offers:</h2>For our new agents that are willing to direct deposit to reload their accounts credit we have special rates, this allow you to charge your customers less while still keeping your commission high. For more information call: 561-860-5276<br /> <br /><h2>Add Credit:</h2>Without funds in your account you can’t begin to take advantage of our features. So what are you waiting for, add funds today and let Telbug make money for you. <br /> Wells Fargo Accoount#: 3054288380 | BAnk of America Account#: 898088507559 - Text image of depodit slip and username to 561-860-5276 <br /><br /> <a href='https://telbug.com/login?ConfirmEmail=" + txtUserName.Text + "'>CLICK HERE TO CONFIRM EMAIL</a>";
                        smtpClient.Host = SERVER;
                        smtpClient.Port = 587;
                        smtpClient.Credentials = new System.Net.NetworkCredential(DAO.Decrypt(ConfigurationManager.AppSettings["Email"], ConfigurationManager.AppSettings["encryptionKey"]), DAO.Decrypt(ConfigurationManager.AppSettings["pass"], ConfigurationManager.AppSettings["encryptionKey"]));
                        smtpClient.EnableSsl = true;
                        smtpClient.Send(oMail);
                        oMail = null;// free up resources

                        TextAndEmail("New Account Created", txtUserName.Text + " just created an account. | Name: " + txtFirstName.Text + " " + txtLastName.Text + " | Phone number " + txtPhoneNumber.Text + " | Email: " + txtEmail.Text);


                        Response.Redirect("error.aspx?ConfirmEmail=" + txtEmail.Text);

                        //lbDesc.ForeColor = Color.White;
                        //lbDesc.Text = "Confirm email to log on <br /> call 561-860-5276 for more information";
                        //txtFirstName.Text = "";
                        //txtLastName.Text = "";
                        //txtPhoneNumber.Text = "";
                        //txtUserName.Text = "";
                        //txtEmail.Text = "";
                        //txtBusinessName.Text = "";
                        //txtAddress.Text = "";



                    }

                }

            }
            catch (Exception ex)
            {
                lbDesc.Text = ex.Message;
            }


        }
        public int LastPost()
        {
            using (var conn = new SqlConnection(dbCon))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                cmd.CommandText = @"select top(1) post from users order by CreatedDate desc";
                int Post = Convert.ToInt32(cmd.ExecuteScalar());
                return Post;
            }
        }
        public void TextAndEmail(string subject, string body)
        {
            try
            {


                var accountSid = "ACf68d6c4ff981f1ff8962f266f81ced48";
                var authToken = "6550fa15290f0b119b3a4ab7466200f9";

                TwilioClient.Init(accountSid, authToken);

      
                var message = MessageResource.Create(
                from: new Twilio.Types.PhoneNumber("+15612204243"),
                body: subject + " - " + body,
                to: new Twilio.Types.PhoneNumber("5616674346"));
                


                var message2 = MessageResource.Create(
                    from: new Twilio.Types.PhoneNumber("+15612204243"),
                    body: subject + " - " + body,
                    to: new Twilio.Types.PhoneNumber("5612012168")
                );
            }
            catch (Exception ex)
            {
                oUserDAO.LogError("Portal TexT Error", "5616674346", "0", "Twilio Emails are failing, fix asap Braley");
            }

            //ServicePointManager.Expect100Continue = true;
            //ServicePointManager.DefaultConnectionLimit = 9999;
            //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12 | SecurityProtocolType.Ssl3;
            //MailMessage message = new MailMessage();
            //SmtpClient smtpClient = new SmtpClient();
            //string msg = string.Empty;

            //MailAddress fromAddress = new MailAddress("info@telbug.com", "TelBug");
            //const string SERVER = "smtp.gmail.com";
            //MailMessage oMail = new System.Net.Mail.MailMessage();
            //oMail.From = fromAddress;
            //if (textBraley == true)
            //{
            //    oMail.To.Add("5612012168@mymetropcs.com, 5616674346@mymetropcs.com");
            //}
            //else
            //{
            //    oMail.To.Add("5612012168@mymetropcs.com");
            //}

            //oMail.Subject = subject;
            //oMail.IsBodyHtml = true;
            //oMail.Body = body;
            //smtpClient.Host = SERVER;
            //smtpClient.Port = 587;
            //smtpClient.Credentials = new System.Net.NetworkCredential(DAO.Decrypt(ConfigurationManager.AppSettings["Email"], ConfigurationManager.AppSettings["encryptionKey"]), DAO.Decrypt(ConfigurationManager.AppSettings["pass"], ConfigurationManager.AppSettings["encryptionKey"]));
            //smtpClient.EnableSsl = true;
            //smtpClient.Send(oMail);
            //oMail = null;// free up resources

        }
    }
}