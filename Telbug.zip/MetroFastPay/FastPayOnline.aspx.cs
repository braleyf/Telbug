﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net.Mail;
using System.Configuration;
using System.Web.UI.HtmlControls;
using System.Drawing;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using System.Net;
using MetroFastPayLibrary;
using System.Text;
using System.Security.Cryptography;
using System.Web.Security;
using System.Security.Principal;
using System.Runtime.InteropServices;
using System.ComponentModel;
using System.Web.Services;
using System.Diagnostics;
using System.Management.Automation;
using System.Net.Http;
using System.Threading.Tasks;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using RestSharp;

namespace MetroFastPay
{
    public partial class FastPayOnline : System.Web.UI.Page
    {  
        protected void Page_Load(object sender, EventArgs e)
        {
           

        }
     
    }
}