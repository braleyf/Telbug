﻿using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Security.Principal;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.AspNet.Identity;
using System.Net.Mail;
using System.Configuration;
using System.Web.UI.HtmlControls;
using System.Drawing;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using System.Net;
using MetroFastPayLibrary;
using System.Text;
using System.Security.Cryptography;
using System.Runtime.InteropServices;
using System.ComponentModel;
using System.Web.Services;
using System.Diagnostics;
using System.Management.Automation;
using System.Net.Http;
using System.Threading.Tasks;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using RestSharp;
using MetroFastPay.com.dollarphone.www;

namespace MetroFastPay
{


    public partial class SiteMaster : MasterPage
    {

        User oUser = new User();
        UserDAO oUserDAO = new UserDAO();
        System.Web.HttpCookie UserCookie = HttpContext.Current.Request.Cookies["UserNameCookie"];
        System.Web.HttpCookie GuatePinUserCookie = HttpContext.Current.Request.Cookies["GuatePinUser"];
        private HttpClient _Client = new HttpClient();
        string dbCon = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
        protected void Page_Init(object sender, EventArgs e)
        {

        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (base.Request.Cookies["UserNameCookie"] == null || UserCookie.Value == "FastPay Online")
            {
                UserCookie = HttpContext.Current.Request.Cookies["UserNameCookie"];
                base.Session.Abandon();
                UserCookie.Expires = DateTime.Now.AddYears(-1);
                base.Response.Cookies.Add(UserCookie);
                base.Response.Redirect("login.aspx");
                return;
            }
            try
            {
                lbDate.Text = DateTime.Now.ToString();
                oUser = oUserDAO.RetrieveUserByUserID(UserCookie.Value);
                lbUser.Text = oUser.FullName;
                if (base.Request.Cookies["GuatePinUser"] == null)
                {
                    imgLogo.Src = "Img/logoWithName.png";
                    imgLogo.Width = 180;
                }
                else
                {
                    imgLogo.Src = "Img/GuatePinLogo.png";
                    imgLogo.Width = 180;
                }
                Account oAccount = new Account();
                oAccount = oUserDAO.RetrieveAccount(UserCookie.Value);
                Announcement announcement = new Announcement();
                announcement = oUserDAO.RetrieveAnnouncementByDate();
                lbAnnouncements.Text = announcement.AnnounceText;
                if (oUser.UserType != "Admin")
                {
                    liControlPanel.Attributes.Add("style", "display:none");
                    decimal totalbalance = gettotalBalance(UserCookie.Value, false);
                    lbBalance.Text = string.Format("{0:0.00}", totalbalance);
                    if (!oAccount.Active && oAccount.UserID == null)
                    {
                        lbBalance.Text = "∞";
                    }
                    decimal ThisMonthCellProfit = getProfitCellPayments(UserCookie.Value, false);
                    decimal ThisMonthATTProfit = getProfitATTThisMonth(UserCookie.Value, false);
                    decimal ThisMonthiFixmobileATTProfit = getDiscountProfitThisMonth(UserCookie.Value, false);
                    decimal ThisMonthInternational = new decimal();
                    decimal ThisMobileInternational = new decimal();
                    foreach (DataRow row in oUserDAO.Services().Rows)
                    {
                        string product = row["Product"].ToString();
                        decimal usercom = Convert.ToDecimal(row["UserCommission"]);
                        if (!(usercom == new decimal(2)) && !(usercom == decimal.One))
                        {
                            ThisMonthInternational = getInternationalThisMonth(UserCookie.Value, product) + ThisMonthInternational;
                        }
                        if (!(usercom == decimal.One) || !(product != "AT&T"))
                        {
                            continue;
                        }
                        ThisMobileInternational = getMobileThisMonth(UserCookie.Value, product) + ThisMobileInternational;
                    }
                    decimal ThisMonthProfit = (((ThisMonthCellProfit + ThisMobileInternational) + ThisMonthInternational) + ThisMonthATTProfit) + ThisMonthiFixmobileATTProfit;
                    lbCommision.Text = string.Format("{0:0.00}", ThisMonthProfit);
                    decimal totalPayments = gettotalThisMonthPayments(UserCookie.Value, false);
                    lbPayments.Text = totalPayments.ToString();
                    gettotalUsers(UserCookie.Value, false, oUser.Post);
                    lbUsers.Text = GetIPAddress().ToString();
                    decimal num = gettotalPaymentsbyuserid(UserCookie.Value, false);
                }
                else
                {
                    //lbBalance.Text = "<iframe src='SinPinBalance.aspx?DP style='background:transparent' allowtransparency='true' width='80px' height='25px' frameborder='0' scrolling='no'></iframe>";
                    lbBalance.Text = "∞";
                    decimal ThisMonthCellProfit = getProfitCellPayments(UserCookie.Value, true);
                    decimal ThisMonthDPMetroPCS = getProfitDPMetroPCS();
                    decimal ThisMonthATTProfit = getProfitATTThisMonth(UserCookie.Value, true);
                    decimal ThisMonthiFixmobileATTProfit = getDiscountProfitThisMonth(UserCookie.Value, true);
                    decimal ThisMonthInternational = new decimal();
                    decimal ThisMonthMobile = new decimal();
                    decimal ThisMonthRewards = new decimal();
                    foreach (DataRow dataRow in oUserDAO.Services().Rows)
                    {
                        string product = dataRow["Product"].ToString();
                        decimal usercom = Convert.ToDecimal(dataRow["UserCommission"]);
                        if (!(usercom == new decimal(2)) && !(usercom == decimal.One))
                        {
                            ThisMonthInternational = getInternationalThisMonth(UserCookie.Value, product) + ThisMonthInternational;
                        }
                        if (usercom == decimal.One && product != "AT&T")
                        {
                            ThisMonthMobile = getMobileThisMonth(UserCookie.Value, product) + ThisMonthMobile;
                        }
                        if (usercom != new decimal(2))
                        {
                            continue;
                        }
                        ThisMonthRewards = getRewardThisMonth(product) + ThisMonthRewards;
                    }
                    decimal ThisMonthProfit = (((ThisMonthCellProfit + ThisMonthMobile) + ThisMonthInternational) + ThisMonthATTProfit) + ThisMonthiFixmobileATTProfit;
                    lbCommision.Text = string.Format("{0:0.00}", (ThisMonthProfit + ThisMonthRewards) + ThisMonthDPMetroPCS);
                    decimal totalPayments = gettotalThisMonthPayments(UserCookie.Value, true);
                    lbPayments.Text = totalPayments.ToString();
                    gettotalUsers(UserCookie.Value, true, oUser.Post);
                    lbUsers.Text = GetIPAddress().ToString();
                    decimal num1 = gettotalPaymentsbyuserid(UserCookie.Value, true);
                }
            }
            catch (Exception exception)
            {
                base.Response.Redirect("login.aspx");
            }
        }
    
        private void gettimerworking()
        {
            oUser = oUserDAO.RetrieveUserByUserID(UserCookie.Value);
            Account oAccount = new Account();
            oAccount = oUserDAO.RetrieveAccount(UserCookie.Value);
            if (oUser.UserType != "Admin")
            {
                decimal totalbalance = gettotalBalance(UserCookie.Value, false);
                Label label = lbBalance;
                Label label1 = lbBalance;
                string str = string.Format("{0:0.00}", totalbalance);
                string str1 = str;
                label1.Text = str;
                label.Text = str1;
                decimal ThisMonthCellProfit = getProfitCellPayments(UserCookie.Value, false);
                decimal ThisMonthATTProfit = getProfitATTThisMonth(UserCookie.Value, false);
                decimal ThisMonthiFixmobileATTProfit = getDiscountProfitThisMonth(UserCookie.Value, false);
                decimal ThisMonthInternational = new decimal();
                decimal ThisMobileInternational = new decimal();
                foreach (DataRow row in oUserDAO.Services().Rows)
                {
                    string product = row["Product"].ToString();
                    decimal usercom = Convert.ToDecimal(row["UserCommission"]);
                    if (!(usercom == new decimal(2)) && !(usercom == decimal.One))
                    {
                        ThisMonthInternational = getInternationalThisMonth(UserCookie.Value, product) + ThisMonthInternational;
                    }
                    if (!(usercom == decimal.One) || !(product != "AT&T"))
                    {
                        continue;
                    }
                    ThisMobileInternational = getMobileThisMonth(UserCookie.Value, product) + ThisMobileInternational;
                }
                decimal ThisMonthProfit = (((ThisMonthCellProfit + ThisMobileInternational) + ThisMonthInternational) + ThisMonthATTProfit) + ThisMonthiFixmobileATTProfit;
                lbCommision.Text = string.Format("{0:0.00}", ThisMonthProfit);
                decimal totalPayments = gettotalThisMonthPayments(UserCookie.Value, false);
                lbPayments.Text = totalPayments.ToString();
                gettotalUsers(UserCookie.Value, false, oUser.Post);
                lbUsers.Text = GetIPAddress().ToString();
            }
            else
            {
                gettotalBalance(UserCookie.Value, true);
                decimal ThisMonthCellProfit = getProfitCellPayments(UserCookie.Value, true);
                decimal ThisMonthDPMetroPCS = getProfitDPMetroPCS();
                decimal ThisMonthATTProfit = getProfitATTThisMonth(UserCookie.Value, true);
                decimal ThisMonthiFixmobileATTProfit = getDiscountProfitThisMonth(UserCookie.Value, true);
                decimal ThisMonthInternational = new decimal();
                decimal ThisMobileInternational = new decimal();
                decimal ThisMonthRewards = new decimal();
                foreach (DataRow dataRow in oUserDAO.Services().Rows)
                {
                    string product = dataRow["Product"].ToString();
                    decimal usercom = Convert.ToDecimal(dataRow["UserCommission"]);
                    if (!(usercom == new decimal(2)) && !(usercom == decimal.One))
                    {
                        ThisMonthInternational = getInternationalThisMonth(UserCookie.Value, product) + ThisMonthInternational;
                    }
                    if (usercom == decimal.One && product != "AT&T")
                    {
                        ThisMobileInternational = getMobileThisMonth(UserCookie.Value, product) + ThisMobileInternational;
                    }
                    if (usercom != new decimal(2))
                    {
                        continue;
                    }
                    ThisMonthRewards = getRewardThisMonth(product) + ThisMonthRewards;
                }
                decimal ThisMonthProfit = (((ThisMonthCellProfit + ThisMobileInternational) + ThisMonthInternational) + ThisMonthATTProfit) + ThisMonthiFixmobileATTProfit;
                lbCommision.Text = string.Format("{0:0.00}", (ThisMonthProfit + ThisMonthRewards) + ThisMonthDPMetroPCS);
                decimal totalPayments = gettotalThisMonthPayments(UserCookie.Value, true);
                lbPayments.Text = totalPayments.ToString();
                gettotalUsers(UserCookie.Value, true, oUser.Post);
                lbUsers.Text = GetIPAddress().ToString();
            }
            if (!oAccount.Active && oAccount.UserID == null)
            {
                lbBalance.Text = "∞";
            }
            if (oUser.UserType == "Admin")
            {
                //lbBalance.Text = "<iframe src='SinPinBalance.aspx?ReupBalance style='background:transparent' allowtransparency='true' width='80px' height='25px' frameborder='0' scrolling='no'></iframe>";
                lbBalance.Text = "∞";
            }
        }
        protected void GetTime_Tick(object sender, EventArgs e)
        {
            if (ScriptManager1.IsInAsyncPostBack)
            {
                gettimerworking();
                UpdatePanel3.Update();
            }

        }

        protected void LogOut_Click(object sender, System.EventArgs e)
        {
            try
            {
                Session.Abandon();

                System.Web.HttpCookie UserCookie = new System.Web.HttpCookie("UserNameCookie");
                UserCookie.Expires = DateTime.Now.AddYears(-1);
                Response.Cookies.Add(UserCookie);
                Response.Redirect("login.aspx");
            }
            catch
            {
                Response.Redirect("login.aspx");
            }
        }

        public decimal getMobileThisMonth(string user, string services)
        {
            decimal num;
            using (SqlConnection conn = new SqlConnection(this.dbCon))
            {
                using (SqlCommand cmd = new SqlCommand("dbo.Mobileprofit", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@service", SqlDbType.VarChar).Value = services;
                    cmd.Parameters.Add("@userid", SqlDbType.VarChar).Value = user;
                    conn.Open();
                    decimal num1 = Convert.ToDecimal(cmd.ExecuteScalar());
                    conn.Dispose();
                    conn.Close();
                    num = num1;
                }
            }
            return num;
        }
        public decimal getDiscountProfitThisMonth(string user, bool all)
        {
            decimal num;
            decimal MetroNum = new decimal();
            decimal otherNum = new decimal();
            using (SqlConnection conn = new SqlConnection(this.dbCon))
            {
                using (SqlCommand cmd = conn.CreateCommand())
                {
                    conn.Open();
                    foreach (DataRow row in this.oUserDAO.GetDiscountTable().Rows)
                    {
                        this.oUser.ID = Convert.ToInt32(row["ProductID"]);
                        this.oUser.UserID = row["UserID"].ToString();
                        this.oUser.FullName = row["Product"].ToString();
                        this.oUser.UserCommission = Convert.ToDecimal(row["UserCommission"]);
                        User DiscItems = this.oUserDAO.RetrieveServiceActivity(this.oUser.ID, this.oUser.UserID, "");
                        User user1 = this.oUserDAO.RetrieveServiceActivity(this.oUser.ID, user, "");
                        User getPost = this.oUserDAO.RetrieveUserByUserID(this.oUser.UserID);
                        if (!user1.UserCommission.ToString().Contains(".") && !all)
                        {
                            continue;
                        }
                        if (DiscItems.FullName != "MetroPCS")
                        {
                            if (!all)
                            {
                                cmd.CommandText = string.Concat(new object[] { "select IsNULL(sum(AmountPaid * '", DiscItems.UserCommission, "'), 0) from payments where userid = '", user, "' and Provider like '%", DiscItems.FullName, "%' and post = '", getPost.Post, "' and Month(CreatedDate) = Month(GetDate()) and Year(CreatedDate) = Year(GetDate())" });
                            }
                            else
                            {
                                cmd.CommandText = string.Concat(new object[] { "select IsNULL(sum(AmountPaid * '", DiscItems.Commission - DiscItems.UserCommission, "'), 0) from payments where Provider like '%", DiscItems.FullName, "%' and post = '", getPost.Post, "' and Month(CreatedDate) = Month(GetDate()) and Year(CreatedDate) = Year(GetDate())" });
                            }
                            otherNum = Convert.ToDecimal(cmd.ExecuteScalar());
                        }
                        else
                        {
                            if (!all)
                            {
                                cmd.CommandText = string.Concat(new object[] { "select IsNULL(sum(fee - (fee - '", DiscItems.UserCommission, "')), 0) from payments where userid = '", this.oUser.UserID, "' and fee not like 0 and Provider not like '%SinPin%' and Month(CreatedDate) = Month(GetDate()) and Year(CreatedDate) = Year(GetDate())" });
                            }
                            else
                            {
                                cmd.CommandText = string.Concat(new object[] { "select IsNULL(sum(fee -  '", DiscItems.UserCommission, "'), 0) from payments where Provider not like '%SinPin%' and UserID = '", this.oUser.UserID, "' and fee not like 0 and Month(CreatedDate) = Month(GetDate()) and Year(CreatedDate) = Year(GetDate())" });
                            }
                            MetroNum = Convert.ToDecimal(cmd.ExecuteScalar());
                        }
                    }
                    decimal num1 = MetroNum + otherNum;
                    conn.Dispose();
                    conn.Close();
                    num = num1;
                }
            }
            return num;
        }

        public decimal getInternationalThisMonth(string user, string services)
        {
            decimal num;
            using (SqlConnection conn = new SqlConnection(this.dbCon))
            {
                using (SqlCommand cmd = new SqlCommand("dbo.Internationalprofit", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@service", SqlDbType.VarChar).Value = services;
                    cmd.Parameters.Add("@userid", SqlDbType.VarChar).Value = user;
                    conn.Open();
                    decimal num1 = Convert.ToDecimal(cmd.ExecuteScalar());
                    conn.Dispose();
                    conn.Close();
                    num = num1;
                }
            }
            return num;
        }

        public decimal getProfitATTThisMonth(string user, bool all)
        {
            decimal num;
            User ATT = this.oUserDAO.RetrieveServiceActivity(10, user, "");
            using (SqlConnection conn = new SqlConnection(this.dbCon))
            {
                using (SqlCommand cmd = conn.CreateCommand())
                {
                    conn.Open();
                    if (all)
                    {
                        cmd.CommandText = string.Concat(new object[] { "select IsNULL(sum((AmountPaid) * '", ATT.Commission, "') - (count(*) * 1), 0) from payments where Provider like '%", ATT.FullName, "%' and post <> 6 and Month(CreatedDate) = Month(GetDate()) and Year(CreatedDate) = Year(GetDate())" });
                    }
                    else if (!ATT.UserCommission.ToString().Contains("."))
                    {
                        cmd.CommandText = string.Concat(new string[] { "select IsNULL(count(AmountPaid) * 1, 0) from payments where userid = '", user, "' and Provider like '%", ATT.FullName, "%' and Month(CreatedDate) = Month(GetDate()) and Year(CreatedDate) = Year(GetDate())" });
                    }
                    else
                    {
                        cmd.CommandText = string.Concat(new string[] { "select IsNULL(0, 0) from payments where userid = '", user, "' and Provider like '%", ATT.FullName, "%' and Month(CreatedDate) = Month(GetDate()) and Year(CreatedDate) = Year(GetDate())" });
                    }
                    decimal num1 = Convert.ToDecimal(cmd.ExecuteScalar());
                    conn.Dispose();
                    conn.Close();
                    num = num1;
                }
            }
            return num;
        }

        public decimal getProfitCellPayments(string user, bool all)
        {
            decimal num;
            User DiscItems = this.oUserDAO.RetrieveServiceActivity(1, user, "");
            using (SqlConnection conn = new SqlConnection(this.dbCon))
            {
                using (SqlCommand cmd = new SqlCommand("dbo.CellMBCprofit", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@DiscItem", SqlDbType.VarChar).Value = DiscItems.UserCommission;
                    cmd.Parameters.Add("@userid", SqlDbType.VarChar).Value = user;
                    conn.Open();
                    decimal num1 = Convert.ToDecimal(cmd.ExecuteScalar());
                    conn.Dispose();
                    conn.Close();
                    num = num1;
                }
            }
            return num;
        }

        public int getProfitDPMetroPCS()
        {
            int num;
            using (SqlConnection conn = new SqlConnection(this.dbCon))
            {
                using (SqlCommand cmd = conn.CreateCommand())
                {
                    conn.Open();
                    cmd.CommandText = "select IsNULL(count(*), 0) from payments where Provider like '%MetroPCS%' and fee not like 0 and ccnumberused = 'p1U+X7SOkDLpOsgOfuoiwohqtF9Imk4oeifZ+yZ/OroTWqilU8IBxumOYi4Yu1DO' and Month(CreatedDate) = Month(GetDate()) and Year(CreatedDate) = Year(GetDate())";
                    int num1 = Convert.ToInt32(cmd.ExecuteScalar());
                    conn.Dispose();
                    conn.Close();
                    num = num1;
                }
            }
            return num;
        }

        public decimal getRewardThisMonth(string services)
        {
            decimal num;
            using (SqlConnection conn = new SqlConnection(this.dbCon))
            {
                using (SqlCommand cmd = new SqlCommand("dbo.Rewardsprofit", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@service", SqlDbType.VarChar).Value = services;
                    conn.Open();
                    decimal num1 = Convert.ToDecimal(cmd.ExecuteScalar());
                    conn.Dispose();
                    conn.Close();
                    num = num1;
                }
            }
            return num;
        }
        public decimal gettotalBalance(string user, bool all)
        {
            decimal num;
            using (SqlConnection conn = new SqlConnection(this.dbCon))
            {
                using (SqlCommand cmd = conn.CreateCommand())
                {
                    conn.Open();
                    if (!all)
                    {
                        cmd.CommandText = string.Concat("select ISNULL(sum(credit), 0) from accounts where userid = '", user, "'");
                    }
                    else
                    {
                        cmd.CommandText = "select ISNULL(sum(distinct credit), 0) from accounts";
                    }
                    num = Convert.ToDecimal(cmd.ExecuteScalar());
                }
            }
            return num;
        }

        public int gettotalPaymentsbyuserid(string user, bool all)
        {
            int num;
            using (SqlConnection conn = new SqlConnection(this.dbCon))
            {
                using (SqlCommand cmd = conn.CreateCommand())
                {
                    conn.Open();
                    if (!all)
                    {
                        cmd.CommandText = string.Concat("select count(*) from payments where userid = '", user, "'");
                    }
                    else
                    {
                        cmd.CommandText = "select count(*) from payments";
                    }
                    int num1 = Convert.ToInt32(cmd.ExecuteScalar());
                    conn.Dispose();
                    conn.Close();
                    num = num1;
                }
            }
            return num;
        }

        public int gettotalThisMonthPayments(string user, bool all)
        {
            int num;
            using (SqlConnection conn = new SqlConnection(this.dbCon))
            {
                using (SqlCommand cmd = conn.CreateCommand())
                {
                    conn.Open();
                    if (!all)
                    {
                        cmd.CommandText = string.Concat("select count(*) from payments where userid = '", user, "' and Month(CreatedDate) = Month(GetDate()) and Year(CreatedDate) = Year(GetDate())");
                    }
                    else
                    {
                        cmd.CommandText = "select count(*) from payments where Month(CreatedDate) = Month(GetDate()) and Year(CreatedDate) = Year(GetDate())";
                    }
                    int num1 = Convert.ToInt32(cmd.ExecuteScalar());
                    conn.Dispose();
                    conn.Close();
                    num = num1;
                }
            }
            return num;
        }

        public decimal gettotalUsers(string user, bool all, string post)
        {
            decimal num;
            using (SqlConnection conn = new SqlConnection(this.dbCon))
            {
                using (SqlCommand cmd = conn.CreateCommand())
                {
                    conn.Open();
                    if (!all)
                    {
                        cmd.CommandText = string.Concat("select count(*) from users where post ='", post, "'");
                    }
                    else
                    {
                        cmd.CommandText = "select count(*) from users ";
                    }
                    decimal num1 = Convert.ToDecimal(cmd.ExecuteScalar());
                    conn.Dispose();
                    conn.Close();
                    num = num1;
                }
            }
            return num;
        }

        protected string GetIPAddress()
        {
            System.Web.HttpContext context = System.Web.HttpContext.Current;
            string ipAddress = context.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];

            if (!string.IsNullOrEmpty(ipAddress))
            {
                string[] addresses = ipAddress.Split(',');
                if (addresses.Length != 0)
                {
                    return addresses[0];
                }
            }

            return context.Request.ServerVariables["REMOTE_ADDR"];
        }

    }

}