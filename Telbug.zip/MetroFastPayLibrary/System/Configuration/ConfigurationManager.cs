﻿namespace System.Configuration
{
    internal class ConfigurationManager
    {
    }
}