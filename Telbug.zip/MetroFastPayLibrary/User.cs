﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MetroFastPayLibrary
{
    public class User
    {
        public int ID;
        public string UserID;
        public string Password;
        public string FullName;
        public string PhoneNumber;
        public string ReferralNumber;
        public string Email;
        public string BusinessName;
        public string BusinessAddress;
        public string Post;
        public string UserType;
        public string Fee;
        public bool Active;
        public string IP;
        public decimal Commission;
        public decimal UserCommission;
        public decimal TelBugCommission;
        public int OfferingID;
        public string City;
        public string State;
        public string Zip;
        public string ResaleCert;
        public string EIN;
        public string Pin;

        public DateTime CreatedDate;
    }

    public class CC
    {
        public int ID;
        public string FirstName;
        public string LastName;
        public string Address;
        public string City;
        public string State;
        public string ZIP;
        public string CCNumber;
        public string ExpDate;
        public string ExpMonth;
        public string ExpYear;
        public string CVV;
        public string Code;
        public string Used;
        public bool Active;
        public DateTime DateModified;
    }

    public class Payment
    {
        public int ID;
        public string UserID;
        public string Post;
        public string PhoneNumber;
        public decimal AmountPaid;
        public decimal Fee;
        public string Provider;
        public string CCNumberUsed;
        public string SID;
        public bool IsManual;
        public DateTime CreatedDate;
    }

    public class Usage
    {
        public string CCName;
        public int MaxAmount;
        public int CurrentAmount;
        public bool Active;
        public DateTime CreatedDate;
        public DateTime DateModified;
    }

    public class Account
    {
        public int ID;
        public string UserID;
        public string Post;
        public decimal Amount;
        public decimal Credit;
        public bool Active;
        public DateTime CreatedDate;
        public DateTime ModifiedDate;

        public string TransactionID;
    }
    public class Announcement
    {
        public int AnnounceID;
        public string AnnounceText;
        public DateTime AnnouncementDate;
        public DateTime AnnouncementDateEnd;
        public DateTime CreatedDate;
        public bool Active;

    }

    public class MetroPCSSecurity
    {
        public string a;
        public string b;
        public string c;
        public string d;
        public string f;
        public string z;
        public string uniquestatekey;
        public string SID;
        public DateTime CreatedDate;

    }
}
