﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using MetroFastPayLibrary;

namespace MetroFastPayLibrary
{

    public class UserDAO
    {

        public User RetrieveUserByUserID(string userid)
        {
            User oUser = new User();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from TelBug.dbo.Users where userid ='" + userid + "'", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {

                            oUser.ID = Convert.ToInt32(rdr["ID"]);
                            oUser.UserID = rdr["UserID"].ToString();
                            oUser.Password = rdr["Password"].ToString();
                            oUser.Email = rdr["Email"].ToString();
                            oUser.BusinessName = rdr["BusinessName"].ToString();
                            oUser.BusinessAddress = rdr["Address"].ToString();
                            oUser.FullName = rdr["FullName"].ToString();
                            oUser.PhoneNumber = rdr["PhoneNumber"].ToString();
                            oUser.Post = rdr["Post"].ToString();
                            oUser.UserType = rdr["UserType"].ToString();
                            oUser.Active = Convert.ToBoolean(rdr["Active"]);
                            oUser.CreatedDate = Convert.ToDateTime(rdr["CreatedDate"]);
                            oUser.City = rdr["City"].ToString();
                            oUser.State = rdr["State"].ToString();
                            oUser.Zip = rdr["Zip"].ToString();
                            oUser.ResaleCert = rdr["ResaleCert"].ToString();
                            oUser.EIN = rdr["EIN"].ToString();
                            return oUser;
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
                return oUser;
            }

        }
        public User RetrieveFeebyUserID(string userid)
        {
            User oUser = new User();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from TelBug.dbo.Fees where userid ='" + userid + "'", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {

                            oUser.Fee = rdr["Fee"].ToString();
                            return oUser;
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
                return oUser;
            }

        }
        public User RetrieveSpiffUserID(string userid)
        {
            User oUser = new User();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from TelBug.dbo.Dealer where userid ='" + userid + "'", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {
                            oUser.UserID = rdr["UserID"].ToString();
                            oUser.Post = rdr["AgentPost"].ToString();
                            oUser.Fee = Convert.ToString(rdr["spiff"]);
                            return oUser;
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
                return oUser;
            }

        }
        public Payment RetrieveLastPayment(string userid)
        {
            Payment oPayment = new Payment();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select Top 1 * from Payments where  userid ='" + userid + "' order by createdDate desc", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {
                            oPayment.ID = Convert.ToInt32(rdr["ID"]);
                            oPayment.UserID = rdr["UserID"].ToString();
                            oPayment.Post = rdr["Post"].ToString();
                            oPayment.PhoneNumber = rdr["PhoneNumber"].ToString();
                            oPayment.AmountPaid = Convert.ToDecimal(rdr["AmountPaid"]);
                            oPayment.Fee = Convert.ToDecimal(rdr["Fee"]);
                            oPayment.Provider = rdr["Provider"].ToString();
                            oPayment.CCNumberUsed = rdr["CCNumberUsed"].ToString();
                            oPayment.CreatedDate = Convert.ToDateTime(rdr["CreatedDate"]);
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
                return oPayment;
            }

        }
        public Payment RetrieveLastPaymentByNumber(string number)
        {
            Payment oPayment = new Payment();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select Top 1 * from Payments where  PhoneNumber ='" + number + "' order by createdDate desc", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {
                            oPayment.ID = Convert.ToInt32(rdr["ID"]);
                            oPayment.UserID = rdr["UserID"].ToString();
                            oPayment.Post = rdr["Post"].ToString();
                            oPayment.PhoneNumber = rdr["PhoneNumber"].ToString();
                            oPayment.AmountPaid = Convert.ToDecimal(rdr["AmountPaid"]);
                            oPayment.Fee = Convert.ToDecimal(rdr["Fee"]);
                            oPayment.Provider = rdr["Provider"].ToString();
                            oPayment.CCNumberUsed = rdr["CCNumberUsed"].ToString();
                            oPayment.CreatedDate = Convert.ToDateTime(rdr["CreatedDate"]);
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
                return oPayment;
            }

        }
        public Payment RetrieveLastPaymentByNumberforMetro(string number, string amount)
        {
            Payment oPayment = new Payment();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select Top 1 * from Payments where  PhoneNumber ='" + number + "' and AmountPaid = '" + amount + "' and Provider like '%MetroPCS%'  order by createdDate desc", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {
                            oPayment.ID = Convert.ToInt32(rdr["ID"]);
                            oPayment.UserID = rdr["UserID"].ToString();
                            oPayment.Post = rdr["Post"].ToString();
                            oPayment.PhoneNumber = rdr["PhoneNumber"].ToString();
                            oPayment.AmountPaid = Convert.ToDecimal(rdr["AmountPaid"]);
                            oPayment.Fee = Convert.ToDecimal(rdr["Fee"]);
                            oPayment.Provider = rdr["Provider"].ToString();
                            oPayment.CCNumberUsed = rdr["CCNumberUsed"].ToString();
                            oPayment.CreatedDate = Convert.ToDateTime(rdr["CreatedDate"]);
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
                return oPayment;
            }

        }
        public Payment RetrievePaymentbyID(int id)
        {
            Payment oPayment = new Payment();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from Payments where  id ='" + id + "'", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {
                            oPayment.ID = Convert.ToInt32(rdr["ID"]);
                            oPayment.UserID = rdr["UserID"].ToString();
                            oPayment.Post = rdr["Post"].ToString();
                            oPayment.PhoneNumber = rdr["PhoneNumber"].ToString();
                            oPayment.AmountPaid = Convert.ToDecimal(rdr["AmountPaid"]);
                            oPayment.Fee = Convert.ToDecimal(rdr["Fee"]);
                            oPayment.Provider = rdr["Provider"].ToString();
                            oPayment.CCNumberUsed = rdr["CCNumberUsed"].ToString();
                            oPayment.CreatedDate = Convert.ToDateTime(rdr["CreatedDate"]);
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
                return oPayment;
            }

        }

        public Account RetrieveCreditbyID(int id)
        {
            Account oAccount = new Account();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from Credit where  id ='" + id + "'", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {

                            oAccount = new Account();
                            oAccount.ID = Convert.ToInt32(rdr["ID"]);
                            oAccount.UserID = rdr["UserID"].ToString();
                            oAccount.Post = rdr["Post"].ToString();
                            oAccount.Amount = Convert.ToDecimal(rdr["Amount"].ToString());
                            oAccount.TransactionID = rdr["TransactionID"].ToString();
                            oAccount.CreatedDate = Convert.ToDateTime(rdr["CreatedDate"]);
                        }
                        rdr.Close();

                    }
                    con.Dispose();
                    con.Close();
                }
                return oAccount;
            }

        }
        public Payment RetrievePaymentbyConfID(string confid)
        {
            Payment oPayment = new Payment();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from Payments where  Provider like '%" + confid + "%'", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {
                            oPayment.ID = Convert.ToInt32(rdr["ID"]);
                            oPayment.UserID = rdr["UserID"].ToString();
                            oPayment.Post = rdr["Post"].ToString();
                            oPayment.PhoneNumber = rdr["PhoneNumber"].ToString();
                            oPayment.AmountPaid = Convert.ToDecimal(rdr["AmountPaid"]);
                            oPayment.Fee = Convert.ToDecimal(rdr["Fee"]);
                            oPayment.Provider = rdr["Provider"].ToString();
                            oPayment.CCNumberUsed = rdr["CCNumberUsed"].ToString();
                            oPayment.CreatedDate = Convert.ToDateTime(rdr["CreatedDate"]);
                        }
                        rdr.Close();

                    }
                    con.Dispose();
                    con.Close();
                }
                return oPayment;
            }

        }
        public List<Payment> PopulateReportbyUser(string userid)
        {
            Payment oPayment = new Payment();
            List<Payment> oList = new List<Payment>();

            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from TelBug.dbo.Payments where userid ='" + userid + "'  order by CreatedDate desc", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {

                            oPayment = new Payment();
                            oPayment.ID = Convert.ToInt32(rdr["ID"]);
                            oPayment.UserID = rdr["UserID"].ToString();
                            oPayment.Post = rdr["Post"].ToString();
                            oPayment.PhoneNumber = rdr["PhoneNumber"].ToString();
                            oPayment.AmountPaid = Convert.ToDecimal(rdr["AmountPaid"]);
                            oPayment.Fee = Convert.ToDecimal(rdr["Fee"]);
                            oPayment.Provider = rdr["Provider"].ToString();
                            oPayment.CCNumberUsed = rdr["CCNumberUsed"].ToString();
                            oPayment.CreatedDate = Convert.ToDateTime(rdr["CreatedDate"]);

                            oList.Add(oPayment);
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
            }
            return oList;
        }
        public List<Payment> PopulateReportbyUserThisMonth(string userid)
        {
            Payment oPayment = new Payment();
            List<Payment> oList = new List<Payment>();

            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from TelBug.dbo.Payments where userid ='" + userid + "' and Month(CreatedDate) = Month(GetDate()) and Year(CreatedDate) = Year(GetDate()) order by CreatedDate desc", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {

                            oPayment = new Payment();
                            oPayment.ID = Convert.ToInt32(rdr["ID"]);
                            oPayment.UserID = rdr["UserID"].ToString();
                            oPayment.Post = rdr["Post"].ToString();
                            oPayment.PhoneNumber = rdr["PhoneNumber"].ToString();
                            oPayment.AmountPaid = Convert.ToDecimal(rdr["AmountPaid"]);
                            oPayment.Fee = Convert.ToDecimal(rdr["Fee"]);
                            oPayment.Provider = rdr["Provider"].ToString();
                            oPayment.CCNumberUsed = rdr["CCNumberUsed"].ToString();
                            oPayment.CreatedDate = Convert.ToDateTime(rdr["CreatedDate"]);

                            oList.Add(oPayment);
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
            }
            return oList;
        }
        public List<Payment> PopulateReportbyPost(string post)
        {
            Payment oPayment = new Payment();
            List<Payment> oList = new List<Payment>();

            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from TelBug.dbo.Payments where post ='" + post + "'  order by CreatedDate desc", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {

                            oPayment = new Payment();
                            oPayment.ID = Convert.ToInt32(rdr["ID"]);
                            oPayment.UserID = rdr["UserID"].ToString();
                            oPayment.Post = rdr["Post"].ToString();
                            oPayment.PhoneNumber = rdr["PhoneNumber"].ToString();
                            oPayment.AmountPaid = Convert.ToDecimal(rdr["AmountPaid"]);
                            oPayment.Fee = Convert.ToDecimal(rdr["Fee"]);
                            oPayment.Provider = rdr["Provider"].ToString();
                            oPayment.CCNumberUsed = rdr["CCNumberUsed"].ToString();
                            oPayment.CreatedDate = Convert.ToDateTime(rdr["CreatedDate"]);

                            oList.Add(oPayment);
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
            }
            return oList;
        }
        public List<Payment> PopulateReportbyPostandDate(string post, string date1, string date2)
        {
            Payment oPayment = new Payment();
            List<Payment> oList = new List<Payment>();

            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from TelBug.dbo.Payments where post ='" + post + "' and createddate between '" + date1 + "' and  DATEADD(DAY, 1, '" + date2 + "' )  order by CreatedDate desc", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {

                            oPayment = new Payment();
                            oPayment.ID = Convert.ToInt32(rdr["ID"]);
                            oPayment.UserID = rdr["UserID"].ToString();
                            oPayment.Post = rdr["Post"].ToString();
                            oPayment.PhoneNumber = rdr["PhoneNumber"].ToString();
                            oPayment.AmountPaid = Convert.ToDecimal(rdr["AmountPaid"]);
                            oPayment.Fee = Convert.ToDecimal(rdr["Fee"]);
                            oPayment.Provider = rdr["Provider"].ToString();
                            oPayment.CCNumberUsed = rdr["CCNumberUsed"].ToString();
                            oPayment.CreatedDate = Convert.ToDateTime(rdr["CreatedDate"]);

                            oList.Add(oPayment);
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
            }
            return oList;
        }

        public List<Payment> PopulateDealerView(string userid, string date1, string date2)
        {
            Payment oPayment = new Payment();
            List<Payment> oList = new List<Payment>();

            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select p.ID, p.UserID, p.Post, p.PhoneNumber, p.Provider, p.AmountPaid, p.Fee, p.CCNumberUsed, p.CreatedDate from Payments p inner join Dealer a ON p.Post = a.UserPost where a.UserID = '" + userid + "' and p.createddate between '" + date1 + "' and  DATEADD(DAY, 1, '" + date2 + "')  order by CreatedDate desc", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {

                            oPayment = new Payment();
                            oPayment.ID = Convert.ToInt32(rdr["ID"]);
                            oPayment.UserID = rdr["UserID"].ToString();
                            oPayment.Post = rdr["Post"].ToString();
                            oPayment.PhoneNumber = rdr["PhoneNumber"].ToString();
                            oPayment.AmountPaid = Convert.ToDecimal(rdr["AmountPaid"]);
                            oPayment.Fee = Convert.ToDecimal(rdr["Fee"]);
                            oPayment.Provider = rdr["Provider"].ToString();
                            oPayment.CCNumberUsed = rdr["CCNumberUsed"].ToString();
                            oPayment.CreatedDate = Convert.ToDateTime(rdr["CreatedDate"]);

                            oList.Add(oPayment);
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
            }
            return oList;
        }
        public User InsertDealerAgents(string userid, string DealerPost, string UserPost, decimal spiff)
        {
            User oUser = new User();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {

                con.Open();
                SqlCommand cmdSql = new SqlCommand();
                string sqlText = "INSERT INTO Telbug.dbo.Dealer (UserID, AgentPost, UserPost, Spiff, CreatedDate) VALUES (@UserID, @AgentPost, @UserPost, @Spiff, @CreatedDate)";
                var _with1 = cmdSql;
                _with1.CommandText = sqlText;
                _with1.Connection = con;
                _with1.Parameters.AddWithValue("@UserID", userid);
                _with1.Parameters.AddWithValue("@AgentPost", DealerPost);
                _with1.Parameters.AddWithValue("@UserPost", UserPost);
                _with1.Parameters.AddWithValue("@Spiff", spiff);
                _with1.Parameters.AddWithValue("@CreatedDate", DateTime.Now);
                _with1.ExecuteNonQuery();
                cmdSql.Dispose();
                con.Close();
                return oUser;
            }

        }
        public List<Payment> PopulateReportbydate(string userid, string date1, string date2)
        {
            Payment oPayment = new Payment();
            List<Payment> oList = new List<Payment>();

            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from TelBug.dbo.Payments where userid ='" + userid + "' and createddate between '" + date1 + "' and  DATEADD(DAY, 1, '" + date2 + "' ) order by CreatedDate desc", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {

                            oPayment = new Payment();
                            oPayment.ID = Convert.ToInt32(rdr["ID"]);
                            oPayment.UserID = rdr["UserID"].ToString();
                            oPayment.Post = rdr["Post"].ToString();
                            oPayment.PhoneNumber = rdr["PhoneNumber"].ToString();
                            oPayment.AmountPaid = Convert.ToDecimal(rdr["AmountPaid"]);
                            oPayment.Fee = Convert.ToDecimal(rdr["Fee"]);
                            oPayment.Provider = rdr["Provider"].ToString();
                            oPayment.CCNumberUsed = rdr["CCNumberUsed"].ToString();
                            oPayment.CreatedDate = Convert.ToDateTime(rdr["CreatedDate"]);

                            oList.Add(oPayment);
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
            }
            return oList;
        }
        public List<Payment> PopulateReportbydateAll(string date1, string date2)
        {
            Payment oPayment = new Payment();
            List<Payment> oList = new List<Payment>();

            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from TelBug.dbo.Payments where createddate between '" + date1 + "' and  DATEADD(DAY, 1, '" + date2 + "' )  order by CreatedDate desc", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {

                            oPayment = new Payment();
                            oPayment.ID = Convert.ToInt32(rdr["ID"]);
                            oPayment.UserID = rdr["UserID"].ToString();
                            oPayment.Post = rdr["Post"].ToString();
                            oPayment.PhoneNumber = rdr["PhoneNumber"].ToString();
                            oPayment.AmountPaid = Convert.ToDecimal(rdr["AmountPaid"]);
                            oPayment.Fee = Convert.ToDecimal(rdr["Fee"]);
                            oPayment.Provider = rdr["Provider"].ToString();
                            oPayment.CCNumberUsed = rdr["CCNumberUsed"].ToString();
                            oPayment.CreatedDate = Convert.ToDateTime(rdr["CreatedDate"]);

                            oList.Add(oPayment);
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
            }
            return oList;
        }
        public List<Payment> PopulateReportbyUserandProvider(string date1, string date2, string userid, string provider)
        {
            Payment oPayment = new Payment();
            List<Payment> oList = new List<Payment>();

            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from TelBug.dbo.Payments where createddate between '" + date1 + "' and  DATEADD(DAY, 1, '" + date2 + "' ) and userid = '" + userid + "' and provider like '%" + provider + "%' order by CreatedDate desc", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {

                            oPayment = new Payment();
                            oPayment.ID = Convert.ToInt32(rdr["ID"]);
                            oPayment.UserID = rdr["UserID"].ToString();
                            oPayment.Post = rdr["Post"].ToString();
                            oPayment.PhoneNumber = rdr["PhoneNumber"].ToString();
                            oPayment.AmountPaid = Convert.ToDecimal(rdr["AmountPaid"]);
                            oPayment.Fee = Convert.ToDecimal(rdr["Fee"]);
                            oPayment.Provider = rdr["Provider"].ToString();
                            oPayment.CCNumberUsed = rdr["CCNumberUsed"].ToString();
                            oPayment.CreatedDate = Convert.ToDateTime(rdr["CreatedDate"]);

                            oList.Add(oPayment);
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
            }
            return oList;
        }
        public List<Payment> PopulateReportbyPostandProvider(string date1, string date2, string post, string provider)
        {
            Payment oPayment = new Payment();
            List<Payment> oList = new List<Payment>();

            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from TelBug.dbo.Payments where createddate between '" + date1 + "' and  DATEADD(DAY, 1, '" + date2 + "' ) and post = '" + post + "' and provider like '%" + provider + "%' order by CreatedDate desc", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {

                            oPayment = new Payment();
                            oPayment.ID = Convert.ToInt32(rdr["ID"]);
                            oPayment.UserID = rdr["UserID"].ToString();
                            oPayment.Post = rdr["Post"].ToString();
                            oPayment.PhoneNumber = rdr["PhoneNumber"].ToString();
                            oPayment.AmountPaid = Convert.ToDecimal(rdr["AmountPaid"]);
                            oPayment.Fee = Convert.ToDecimal(rdr["Fee"]);
                            oPayment.Provider = rdr["Provider"].ToString();
                            oPayment.CCNumberUsed = rdr["CCNumberUsed"].ToString();
                            oPayment.CreatedDate = Convert.ToDateTime(rdr["CreatedDate"]);

                            oList.Add(oPayment);
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
            }
            return oList;
        }
        public List<Payment> PopulateReportbyProviderandDate(string provide, string date1, string date2)
        {
            Payment oPayment = new Payment();
            List<Payment> oList = new List<Payment>();

            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from TelBug.dbo.Payments where provider like ('%" + provide + "%') and createddate between '" + date1 + "' and  DATEADD(DAY, 1, '" + date2 + "' )  order by CreatedDate desc", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {

                            oPayment = new Payment();
                            oPayment.ID = Convert.ToInt32(rdr["ID"]);
                            oPayment.UserID = rdr["UserID"].ToString();
                            oPayment.Post = rdr["Post"].ToString();
                            oPayment.PhoneNumber = rdr["PhoneNumber"].ToString();
                            oPayment.AmountPaid = Convert.ToDecimal(rdr["AmountPaid"]);
                            oPayment.Fee = Convert.ToDecimal(rdr["Fee"]);
                            oPayment.Provider = rdr["Provider"].ToString();
                            oPayment.CCNumberUsed = rdr["CCNumberUsed"].ToString();
                            oPayment.CreatedDate = Convert.ToDateTime(rdr["CreatedDate"]);

                            oList.Add(oPayment);
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
            }
            return oList;
        }
        public List<Payment> PopulateReportbyUserbyProviderandDate(string provide, string date1, string date2, string post)
        {
            Payment oPayment = new Payment();
            List<Payment> oList = new List<Payment>();

            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from TelBug.dbo.Payments where post = '" + post + "' and provider like ('%" + provide + "%') and createddate between '" + date1 + "' and  DATEADD(DAY, 1, '" + date2 + "' )  order by CreatedDate desc", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {

                            oPayment = new Payment();
                            oPayment.ID = Convert.ToInt32(rdr["ID"]);
                            oPayment.UserID = rdr["UserID"].ToString();
                            oPayment.Post = rdr["Post"].ToString();
                            oPayment.PhoneNumber = rdr["PhoneNumber"].ToString();
                            oPayment.AmountPaid = Convert.ToDecimal(rdr["AmountPaid"]);
                            oPayment.Fee = Convert.ToDecimal(rdr["Fee"]);
                            oPayment.Provider = rdr["Provider"].ToString();
                            oPayment.CCNumberUsed = rdr["CCNumberUsed"].ToString();
                            oPayment.CreatedDate = Convert.ToDateTime(rdr["CreatedDate"]);

                            oList.Add(oPayment);
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
            }
            return oList;
        }
        public List<Account> PopulateAccountTransByDate(string date1, string date2)
        {
            Account oAccount = new Account();
            List<Account> oList = new List<Account>();

            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from TelBug.dbo.Credit where createddate between '" + date1 + "' and  DATEADD(DAY, 1, '" + date2 + "' )  order by CreatedDate desc", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {

                            oAccount = new Account();
                            oAccount.ID = Convert.ToInt32(rdr["ID"]);
                            oAccount.UserID = rdr["UserID"].ToString();
                            oAccount.Post = rdr["Post"].ToString();
                            oAccount.Amount = Convert.ToDecimal(rdr["Amount"].ToString());
                            oAccount.TransactionID = rdr["TransactionID"].ToString();
                            oAccount.CreatedDate = Convert.ToDateTime(rdr["CreatedDate"]);

                            oList.Add(oAccount);
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
            }
            return oList;
        }

        public List<Account> PopulateAccountTransactionByUser(string userid)
        {
            Account oAccount = new Account();
            List<Account> oList = new List<Account>();

            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from TelBug.dbo.Credit where userid ='" + userid + "'  order by CreatedDate desc", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {

                            oAccount = new Account();
                            oAccount.ID = Convert.ToInt32(rdr["ID"]);
                            oAccount.UserID = rdr["UserID"].ToString();
                            oAccount.Post = rdr["Post"].ToString();
                            oAccount.Amount = Convert.ToDecimal(rdr["Amount"].ToString());
                            oAccount.TransactionID = rdr["TransactionID"].ToString();
                            oAccount.CreatedDate = Convert.ToDateTime(rdr["CreatedDate"]);

                            oList.Add(oAccount);
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
            }
            return oList;
        }

        public List<Account> PopulateAccountTransactionAll()
        {
            Account oAccount = new Account();
            List<Account> oList = new List<Account>();

            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select TOP (100) * from TelBug.dbo.Credit order by CreatedDate desc", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {

                            oAccount = new Account();
                            oAccount.ID = Convert.ToInt32(rdr["ID"]);
                            oAccount.UserID = rdr["UserID"].ToString();
                            oAccount.Post = rdr["Post"].ToString();
                            oAccount.Amount = Convert.ToDecimal(rdr["Amount"].ToString());
                            oAccount.TransactionID = rdr["TransactionID"].ToString();
                            oAccount.CreatedDate = Convert.ToDateTime(rdr["CreatedDate"]);

                            oList.Add(oAccount);
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
            }
            return oList;
        }
        public List<Account> PopulateAccountTransactionByPost(string post)
        {
            Account oAccount = new Account();
            List<Account> oList = new List<Account>();

            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from TelBug.dbo.Credit where post ='" + post + "'  order by CreatedDate desc", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {

                            oAccount = new Account();
                            oAccount.ID = Convert.ToInt32(rdr["ID"]);
                            oAccount.UserID = rdr["UserID"].ToString();
                            oAccount.Post = rdr["Post"].ToString();
                            oAccount.Amount = Convert.ToDecimal(rdr["Amount"].ToString());
                            oAccount.TransactionID = rdr["TransactionID"].ToString();
                            oAccount.CreatedDate = Convert.ToDateTime(rdr["CreatedDate"]);

                            oList.Add(oAccount);
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
            }
            return oList;
        }
        public List<Account> PopulateAccountTransactionByUserID(string user)
        {
            Account oAccount = new Account();
            List<Account> oList = new List<Account>();

            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from TelBug.dbo.Credit where userid ='" + user + "'  order by CreatedDate desc", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {

                            oAccount = new Account();
                            oAccount.ID = Convert.ToInt32(rdr["ID"]);
                            oAccount.UserID = rdr["UserID"].ToString();
                            oAccount.Post = rdr["Post"].ToString();
                            oAccount.Amount = Convert.ToDecimal(rdr["Amount"].ToString());
                            oAccount.TransactionID = rdr["TransactionID"].ToString();
                            oAccount.CreatedDate = Convert.ToDateTime(rdr["CreatedDate"]);

                            oList.Add(oAccount);
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
            }
            return oList;
        }
        public List<Account> PopulateAccountTransactionID(string id)
        {
            Account oAccount = new Account();
            List<Account> oList = new List<Account>();

            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from TelBug.dbo.Credit where id =" + id + "  order by CreatedDate desc", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {

                            oAccount = new Account();
                            oAccount.ID = Convert.ToInt32(rdr["ID"]);
                            oAccount.UserID = rdr["UserID"].ToString();
                            oAccount.Post = rdr["Post"].ToString();
                            oAccount.Amount = Convert.ToDecimal(rdr["Amount"].ToString());
                            oAccount.TransactionID = rdr["TransactionID"].ToString();
                            oAccount.CreatedDate = Convert.ToDateTime(rdr["CreatedDate"]);

                            oList.Add(oAccount);
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
            }
            return oList;
        }

        public List<Usage> PopulateCCusage()
        {
            Usage oUsage = new Usage();
            List<Usage> oList = new List<Usage>();

            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from TelBug.dbo.CCUsage", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {

                            oUsage = new Usage();
                            oUsage.CCName = rdr["CCName"].ToString();
                            oUsage.MaxAmount = Convert.ToInt32(rdr["MaxAmount"]);
                            oUsage.CurrentAmount = Convert.ToInt32(rdr["CurrentAmount"]);
                            oUsage.Active = Convert.ToBoolean(rdr["Active"]);
                            oUsage.DateModified = Convert.ToDateTime(rdr["DateModified"]);

                            oList.Add(oUsage);
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
            }
            return oList;
        }

        public List<Payment> PopulateErrorLog()
        {
            Payment oPayments = new Payment();
            List<Payment> oList = new List<Payment>();

            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from TelBug.dbo.ErrorLog where createddate between DATEADD(day, -7, getdate()) and DATEADD(day, 1, getdate()) order by CreatedDate desc", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {

                            oPayments = new Payment();
                            oPayments.UserID = rdr["UserID"].ToString();
                            oPayments.PhoneNumber = rdr["PhoneNumber"].ToString();
                            oPayments.CCNumberUsed = rdr["CC"].ToString();
                            oPayments.Provider = rdr["Error"].ToString();
                            oPayments.CreatedDate = Convert.ToDateTime(rdr["CreatedDate"]);

                            oList.Add(oPayments);
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
            }
            return oList;
        }
        public List<User> PopulateUserInfo()
        {
            User oUser = new User();
            List<User> oList = new List<User>();

            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from TelBug.dbo.Users order by CreatedDate desc", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {

                            oUser = new User();
                            oUser.UserID = rdr["UserID"].ToString();
                            oUser.Password = rdr["Password"].ToString();
                            oUser.PhoneNumber = rdr["PhoneNumber"].ToString();
                            oUser.FullName = rdr["FullName"].ToString();
                            oUser.Email = rdr["Email"].ToString();
                            oUser.BusinessName = rdr["BusinessName"].ToString();
                            oUser.BusinessAddress = rdr["Address"].ToString();
                            oUser.Post = rdr["Post"].ToString();
                            oUser.Email = rdr["Email"].ToString();
                            oUser.CreatedDate = Convert.ToDateTime(rdr["CreatedDate"]);

                            oList.Add(oUser);
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
            }
            return oList;
        }
        public List<User> PopulateUserInfobyUser(string user)
        {
            User oUser = new User();
            List<User> oList = new List<User>();

            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from TelBug.dbo.Users where userid = '" + user + "'", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {

                            oUser = new User();
                            oUser.UserID = rdr["UserID"].ToString();
                            oUser.Password = rdr["Password"].ToString();
                            oUser.PhoneNumber = rdr["PhoneNumber"].ToString();
                            oUser.FullName = rdr["FullName"].ToString();
                            oUser.Email = rdr["Email"].ToString();
                            oUser.BusinessName = rdr["BusinessName"].ToString();
                            oUser.BusinessAddress = rdr["Address"].ToString();
                            oUser.Post = rdr["Post"].ToString();
                            oUser.Email = rdr["Email"].ToString();
                            oUser.CreatedDate = Convert.ToDateTime(rdr["CreatedDate"]);

                            oList.Add(oUser);
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
            }
            return oList;
        }
        public List<Announcement> PopukateAnnouncement()
        {
            Announcement oAnnouncement = new Announcement();
            List<Announcement> oList = new List<Announcement>();

            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from TelBug.dbo.Announcement order by CreatedDate desc", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {

                            oAnnouncement = new Announcement();
                            oAnnouncement.AnnounceID = Convert.ToInt32(rdr["ID"]);
                            oAnnouncement.AnnounceText = rdr["Text"].ToString();
                            oAnnouncement.AnnouncementDate = Convert.ToDateTime(rdr["AnnouncementDate"]);
                            oAnnouncement.AnnouncementDateEnd = Convert.ToDateTime(rdr["AnnouncementDateEnd"]);
                            oAnnouncement.CreatedDate = Convert.ToDateTime(rdr["CreatedDate"]);

                            oList.Add(oAnnouncement);
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
            }
            return oList;
        }
        public List<MetroPCSSecurity> PopulateMS()
        {
            MetroPCSSecurity oMetroPCSSecurity = new MetroPCSSecurity();
            List<MetroPCSSecurity> oList = new List<MetroPCSSecurity>();

            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from TelBug.dbo.MetroPCSSecurityFix order by CreatedDate asc", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {

                            oMetroPCSSecurity = new MetroPCSSecurity();
                            oMetroPCSSecurity.a = rdr["a"].ToString();
                            oMetroPCSSecurity.b = rdr["b"].ToString();
                            oMetroPCSSecurity.c = rdr["c"].ToString(); 
                            oMetroPCSSecurity.d = rdr["d"].ToString();
                            oMetroPCSSecurity.f = rdr["f"].ToString();
                            oMetroPCSSecurity.z = rdr["z"].ToString();
                            oMetroPCSSecurity.CreatedDate = Convert.ToDateTime(rdr["CreatedDate"]);

                            oList.Add(oMetroPCSSecurity);
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
            }
            return oList;
        }
        public User InsertUser(string userid, string passowrd, string fullname, string phonenumber, string email, string businessname, string address, string post, string usertype, bool active, DateTime createddate, string city, string state, string zip, string resaleCert, string EIN)
        {
            User oUser = new User();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                //using (SqlCommand cmd = new SqlCommand("INSERT INTO Users ADXInterfaceManager.dbo.Users (UserID, Password, FullName, PhoneNumber, Post, UserType, Active, CreatedDate)" + "VALUE (@UserID, @Password, @FullName, @PhoneNumber, @Post, @UserType, @Active, @CreatedDate)", con))
                //{
                con.Open();
                SqlCommand cmdSql = new SqlCommand();
                string sqlText = "INSERT INTO Telbug.dbo.Users (UserID, Password, FullName, PhoneNumber, Email, BusinessName, Address, Post, UserType, Active, CreatedDate, City, State, Zip, ResaleCert, EIN) VALUES (@UserID, @Password, @FullName, @PhoneNumber, @Email, @BusinessName, @Address, @Post, @UserType, @Active, @CreatedDate, @City, @State, @Zip, @ResaleCert, @EIN)";
                var _with1 = cmdSql;
                _with1.CommandText = sqlText;
                _with1.Connection = con;
                _with1.Parameters.AddWithValue("@UserID", userid);
                _with1.Parameters.AddWithValue("@Password", passowrd);
                _with1.Parameters.AddWithValue("@FullName", fullname);
                _with1.Parameters.AddWithValue("@PhoneNumber", phonenumber);
                _with1.Parameters.AddWithValue("@Email", email);
                _with1.Parameters.AddWithValue("@BusinessName", businessname);
                _with1.Parameters.AddWithValue("@Address", address);
                _with1.Parameters.AddWithValue("@Post", post);
                _with1.Parameters.AddWithValue("@UserType", usertype);
                _with1.Parameters.AddWithValue("@Active", active);
                _with1.Parameters.AddWithValue("@CreatedDate", createddate);
                _with1.Parameters.AddWithValue("@City", city);
                _with1.Parameters.AddWithValue("@State", state);
                _with1.Parameters.AddWithValue("@Zip", zip);
                _with1.Parameters.AddWithValue("@ResaleCert", resaleCert);
                _with1.Parameters.AddWithValue("@EIN", EIN);
                _with1.ExecuteNonQuery();
                cmdSql.Dispose();
                con.Close();
                //}
                return oUser;
            }

        }
        public User InsertFee(string userid, int fee)
        {
            User oUser = new User();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                //using (SqlCommand cmd = new SqlCommand("INSERT INTO Users ADXInterfaceManager.dbo.Users (UserID, Password, FullName, PhoneNumber, Post, UserType, Active, CreatedDate)" + "VALUE (@UserID, @Password, @FullName, @PhoneNumber, @Post, @UserType, @Active, @CreatedDate)", con))
                //{
                con.Open();
                SqlCommand cmdSql = new SqlCommand();
                string sqlText = "INSERT INTO Telbug.dbo.Fees (UserID, Fee) VALUES (@UserID, @Fee)";
                var _with1 = cmdSql;
                _with1.CommandText = sqlText;
                _with1.Connection = con;
                _with1.Parameters.AddWithValue("@UserID", userid);
                _with1.Parameters.AddWithValue("@fee", fee);
                _with1.ExecuteNonQuery();
                cmdSql.Dispose();
                con.Close();
                //}
                return oUser;
            }

        }
        public List<CC> PopulateCCs()
        {
            CC oCC = new CC();
            List<CC> oList = new List<CC>();

            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from TelBug.dbo.CC order by DateModified desc", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {

                            oCC = new CC();

                            oCC.ID = Convert.ToInt32(rdr["ID"]);
                            oCC.FirstName = rdr["FirstName"].ToString();
                            oCC.LastName = rdr["LastName"].ToString();
                            oCC.Address = rdr["Address"].ToString();
                            oCC.ZIP = rdr["ZIP"].ToString();
                            oCC.CCNumber = rdr["CCNumber"].ToString();
                            oCC.ExpDate = rdr["ExpDate"].ToString();
                            oCC.ExpMonth = rdr["ExpMonth"].ToString();
                            oCC.ExpYear = rdr["ExpYear"].ToString();
                            oCC.CVV = rdr["CVV"].ToString();
                            oCC.Used = rdr["Used"].ToString();
                            oCC.Active = Convert.ToBoolean(rdr["Active"]);
                            oCC.DateModified = Convert.ToDateTime(rdr["DateModified"]);
                            oList.Add(oCC);
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
            }
            return oList;
        }
        public CC RetrieveCCByCC(string cc)
        {
            CC oCC = new CC();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from Telbug.dbo.CC where CCNumber = '" + cc + "'", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {

                            oCC.ID = Convert.ToInt32(rdr["ID"]);
                            oCC.FirstName = rdr["FirstName"].ToString();
                            oCC.LastName = rdr["LastName"].ToString();
                            oCC.Address = rdr["Address"].ToString();
                            oCC.ZIP = rdr["ZIP"].ToString();
                            oCC.CCNumber = rdr["CCNumber"].ToString();
                            oCC.ExpDate = rdr["ExpDate"].ToString();
                            oCC.ExpMonth = rdr["ExpMonth"].ToString();
                            oCC.ExpYear = rdr["ExpYear"].ToString();
                            oCC.CVV = rdr["CVV"].ToString();
                            oCC.Used = rdr["Used"].ToString();
                            oCC.Active = Convert.ToBoolean(rdr["Active"]);
                            return oCC;
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
                return oCC;
            }

        }
        public CC RetrieveCCByAddress(string address)
        {
            CC oCC = new CC();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from Telbug.dbo.CC where Address = '" + address + "'", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {

                            oCC.ID = Convert.ToInt32(rdr["ID"]);
                            oCC.FirstName = rdr["FirstName"].ToString();
                            oCC.LastName = rdr["LastName"].ToString();
                            oCC.Address = rdr["Address"].ToString();
                            oCC.ZIP = rdr["ZIP"].ToString();
                            oCC.CCNumber = rdr["CCNumber"].ToString();
                            oCC.ExpDate = rdr["ExpDate"].ToString();
                            oCC.ExpMonth = rdr["ExpMonth"].ToString();
                            oCC.ExpYear = rdr["ExpYear"].ToString();
                            oCC.CVV = rdr["CVV"].ToString();
                            oCC.Used = rdr["Used"].ToString();
                            oCC.Active = Convert.ToBoolean(rdr["Active"]);
                            return oCC;
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
                return oCC;
            }

        }
        public CC RetrieveCC()
        {
            CC oCC = new CC();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from Telbug.dbo.CC where Active = 1 and Used < 1 and SUBSTRING(FirstName, 1, 1) <> 'P' and SUBSTRING(LastName, 1, 1) <> 'A' and SUBSTRING(FirstName, 1, 1) <> 'D' and SUBSTRING(LastName, 1, 1) <> 'B'", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {

                            oCC.ID = Convert.ToInt32(rdr["ID"]);
                            oCC.FirstName = rdr["FirstName"].ToString();
                            oCC.LastName = rdr["LastName"].ToString();
                            oCC.Address = rdr["Address"].ToString();
                            oCC.ZIP = rdr["ZIP"].ToString();
                            oCC.CCNumber = rdr["CCNumber"].ToString();
                            oCC.ExpDate = rdr["ExpDate"].ToString();
                            oCC.ExpMonth = rdr["ExpMonth"].ToString();
                            oCC.ExpYear = rdr["ExpYear"].ToString();
                            oCC.CVV = rdr["CVV"].ToString();
                            oCC.Used = rdr["Used"].ToString();
                            oCC.Active = Convert.ToBoolean(rdr["Active"]);
                            return oCC;
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
                return oCC;
            }

        }

        public CC RetrieveCC2()
        {
            CC oCC = new CC();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from Telbug.dbo.CC where Active = 1 and Used < 2 and SUBSTRING(FirstName, 1, 1) <> 'P' and SUBSTRING(LastName, 1, 1) <> 'A' and SUBSTRING(FirstName, 1, 1) <> 'D' and SUBSTRING(LastName, 1, 1) <> 'B'", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {

                            oCC.ID = Convert.ToInt32(rdr["ID"]);
                            oCC.FirstName = rdr["FirstName"].ToString();
                            oCC.LastName = rdr["LastName"].ToString();
                            oCC.Address = rdr["Address"].ToString();
                            oCC.ZIP = rdr["ZIP"].ToString();
                            oCC.CCNumber = rdr["CCNumber"].ToString();
                            oCC.ExpDate = rdr["ExpDate"].ToString();
                            oCC.ExpMonth = rdr["ExpMonth"].ToString();
                            oCC.ExpYear = rdr["ExpYear"].ToString();
                            oCC.CVV = rdr["CVV"].ToString();
                            oCC.Used = rdr["Used"].ToString();
                            oCC.Active = Convert.ToBoolean(rdr["Active"]);
                            return oCC;
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
                return oCC;
            }

        }

        public CC RetrieveCC3()
        {
            CC oCC = new CC();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from Telbug.dbo.CC where Active = 1 and Used < 3 and SUBSTRING(FirstName, 1, 1) <> 'P' and SUBSTRING(LastName, 1, 1) <> 'A' and SUBSTRING(FirstName, 1, 1) <> 'D' and SUBSTRING(LastName, 1, 1) <> 'B'", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {

                            oCC.ID = Convert.ToInt32(rdr["ID"]);
                            oCC.FirstName = rdr["FirstName"].ToString();
                            oCC.LastName = rdr["LastName"].ToString();
                            oCC.Address = rdr["Address"].ToString();
                            oCC.ZIP = rdr["ZIP"].ToString();
                            oCC.CCNumber = rdr["CCNumber"].ToString();
                            oCC.ExpDate = rdr["ExpDate"].ToString();
                            oCC.ExpMonth = rdr["ExpMonth"].ToString();
                            oCC.ExpYear = rdr["ExpYear"].ToString();
                            oCC.CVV = rdr["CVV"].ToString();
                            oCC.Used = rdr["Used"].ToString();
                            oCC.Active = Convert.ToBoolean(rdr["Active"]);
                            return oCC;
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
                return oCC;
            }

        }

        public CC RetrieveBoostCC()
        {
            CC oCC = new CC();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from Telbug.dbo.CC where Active = 1 and Used < 1 and SUBSTRING(FirstName, 1, 1) = 'P' and SUBSTRING(LastName, 1, 1) = 'A'", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {

                            oCC.ID = Convert.ToInt32(rdr["ID"]);
                            oCC.FirstName = rdr["FirstName"].ToString();
                            oCC.LastName = rdr["LastName"].ToString();
                            oCC.Address = rdr["Address"].ToString();
                            oCC.ZIP = rdr["ZIP"].ToString();
                            oCC.CCNumber = rdr["CCNumber"].ToString();
                            oCC.ExpDate = rdr["ExpDate"].ToString();
                            oCC.ExpMonth = rdr["ExpMonth"].ToString();
                            oCC.ExpYear = rdr["ExpYear"].ToString();
                            oCC.CVV = rdr["CVV"].ToString();
                            oCC.Used = rdr["Used"].ToString();
                            oCC.Active = Convert.ToBoolean(rdr["Active"]);
                            return oCC;
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
                return oCC;
            }

        }

        public CC RetrieveBoostCC2()
        {
            CC oCC = new CC();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from Telbug.dbo.CC where Active = 1 and Used < 2 and SUBSTRING(FirstName, 1, 1) = 'P' and SUBSTRING(LastName, 1, 1) = 'A'", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {

                            oCC.ID = Convert.ToInt32(rdr["ID"]);
                            oCC.FirstName = rdr["FirstName"].ToString();
                            oCC.LastName = rdr["LastName"].ToString();
                            oCC.Address = rdr["Address"].ToString();
                            oCC.ZIP = rdr["ZIP"].ToString();
                            oCC.CCNumber = rdr["CCNumber"].ToString();
                            oCC.ExpDate = rdr["ExpDate"].ToString();
                            oCC.ExpMonth = rdr["ExpMonth"].ToString();
                            oCC.ExpYear = rdr["ExpYear"].ToString();
                            oCC.CVV = rdr["CVV"].ToString();
                            oCC.Used = rdr["Used"].ToString();
                            oCC.Active = Convert.ToBoolean(rdr["Active"]);
                            return oCC;
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
                return oCC;
            }

        }

        public CC RetrieveBoostCC3()
        {
            CC oCC = new CC();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from Telbug.dbo.CC where Active = 1 and Used < 3 and SUBSTRING(FirstName, 1, 1) = 'P' and SUBSTRING(LastName, 1, 1) = 'A'", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {

                            oCC.ID = Convert.ToInt32(rdr["ID"]);
                            oCC.FirstName = rdr["FirstName"].ToString();
                            oCC.LastName = rdr["LastName"].ToString();
                            oCC.Address = rdr["Address"].ToString();
                            oCC.ZIP = rdr["ZIP"].ToString();
                            oCC.CCNumber = rdr["CCNumber"].ToString();
                            oCC.ExpDate = rdr["ExpDate"].ToString();
                            oCC.ExpMonth = rdr["ExpMonth"].ToString();
                            oCC.ExpYear = rdr["ExpYear"].ToString();
                            oCC.CVV = rdr["CVV"].ToString();
                            oCC.Used = rdr["Used"].ToString();
                            oCC.Active = Convert.ToBoolean(rdr["Active"]);
                            return oCC;
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
                return oCC;
            }

        }
        public CC RetrieveBoostCCDP()
        {
            CC oCC = new CC();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from Telbug.dbo.CCDP where Active = 1 and Used < 1", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {

                            oCC.ID = Convert.ToInt32(rdr["ID"]);
                            oCC.CCNumber = rdr["CCNumber"].ToString();
                            oCC.ExpDate = rdr["ExpDate"].ToString();
                            oCC.CVV = rdr["CVV"].ToString();
                            oCC.ZIP = rdr["ZIP"].ToString();
                            oCC.Code = rdr["Code"].ToString();
                            oCC.Used = rdr["Used"].ToString();
                            oCC.Active = Convert.ToBoolean(rdr["Active"]);
                            return oCC;
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
                return oCC;
            }

        }

        public CC RetrieveCricketCC()
        {
            CC oCC = new CC();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from Telbug.dbo.CC where Active = 1 and Used < 1 and SUBSTRING(FirstName, 1, 1) = 'D' and SUBSTRING(LastName, 1, 1) = 'B'", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {

                            oCC.ID = Convert.ToInt32(rdr["ID"]);
                            oCC.FirstName = rdr["FirstName"].ToString();
                            oCC.LastName = rdr["LastName"].ToString();
                            oCC.Address = rdr["Address"].ToString();
                            oCC.ZIP = rdr["ZIP"].ToString();
                            oCC.CCNumber = rdr["CCNumber"].ToString();
                            oCC.ExpDate = rdr["ExpDate"].ToString();
                            oCC.ExpMonth = rdr["ExpMonth"].ToString();
                            oCC.ExpYear = rdr["ExpYear"].ToString();
                            oCC.CVV = rdr["CVV"].ToString();
                            oCC.Used = rdr["Used"].ToString();
                            oCC.Active = Convert.ToBoolean(rdr["Active"]);
                            return oCC;
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
                return oCC;
            }

        }

        public CC RetrieveCricketCC2()
        {
            CC oCC = new CC();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from Telbug.dbo.CC where Active = 1 and Used < 2 and SUBSTRING(FirstName, 1, 1) = 'D' and SUBSTRING(LastName, 1, 1) = 'B'", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {

                            oCC.ID = Convert.ToInt32(rdr["ID"]);
                            oCC.FirstName = rdr["FirstName"].ToString();
                            oCC.LastName = rdr["LastName"].ToString();
                            oCC.Address = rdr["Address"].ToString();
                            oCC.ZIP = rdr["ZIP"].ToString();
                            oCC.CCNumber = rdr["CCNumber"].ToString();
                            oCC.ExpDate = rdr["ExpDate"].ToString();
                            oCC.ExpMonth = rdr["ExpMonth"].ToString();
                            oCC.ExpYear = rdr["ExpYear"].ToString();
                            oCC.CVV = rdr["CVV"].ToString();
                            oCC.Used = rdr["Used"].ToString();
                            oCC.Active = Convert.ToBoolean(rdr["Active"]);
                            return oCC;
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
                return oCC;
            }

        }

        public CC RetrieveCricketCC3()
        {
            CC oCC = new CC();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from Telbug.dbo.CC where Active = 1 and Used < 3 and SUBSTRING(FirstName, 1, 1) = 'D' and SUBSTRING(LastName, 1, 1) = 'B'", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {

                            oCC.ID = Convert.ToInt32(rdr["ID"]);
                            oCC.FirstName = rdr["FirstName"].ToString();
                            oCC.LastName = rdr["LastName"].ToString();
                            oCC.Address = rdr["Address"].ToString();
                            oCC.ZIP = rdr["ZIP"].ToString();
                            oCC.CCNumber = rdr["CCNumber"].ToString();
                            oCC.ExpDate = rdr["ExpDate"].ToString();
                            oCC.ExpMonth = rdr["ExpMonth"].ToString();
                            oCC.ExpYear = rdr["ExpYear"].ToString();
                            oCC.CVV = rdr["CVV"].ToString();
                            oCC.Used = rdr["Used"].ToString();
                            oCC.Active = Convert.ToBoolean(rdr["Active"]);
                            return oCC;
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
                return oCC;
            }

        }
        public CC RetrieveBackUpCC()
        {
            CC oCC = new CC();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from Telbug.dbo.CCBackUp where Active = 1 and Used < 1 ", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {

                            oCC.ID = Convert.ToInt32(rdr["ID"]);
                            oCC.FirstName = rdr["FirstName"].ToString();
                            oCC.LastName = rdr["LastName"].ToString();
                            oCC.Address = rdr["Address"].ToString();
                            oCC.ZIP = rdr["ZIP"].ToString();
                            oCC.CCNumber = rdr["CCNumber"].ToString();
                            oCC.ExpDate = rdr["ExpDate"].ToString();
                            oCC.ExpMonth = rdr["ExpMonth"].ToString();
                            oCC.ExpYear = rdr["ExpYear"].ToString();
                            oCC.CVV = rdr["CVV"].ToString();
                            oCC.Used = rdr["Used"].ToString();
                            oCC.Active = Convert.ToBoolean(rdr["Active"]);
                            return oCC;
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
                return oCC;
            }

        }

        public CC RetrieveBackUpCC2()
        {
            CC oCC = new CC();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from Telbug.dbo.CCBackUp where Active = 1 and Used < 2 ", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {

                            oCC.ID = Convert.ToInt32(rdr["ID"]);
                            oCC.FirstName = rdr["FirstName"].ToString();
                            oCC.LastName = rdr["LastName"].ToString();
                            oCC.Address = rdr["Address"].ToString();
                            oCC.ZIP = rdr["ZIP"].ToString();
                            oCC.CCNumber = rdr["CCNumber"].ToString();
                            oCC.ExpDate = rdr["ExpDate"].ToString();
                            oCC.ExpMonth = rdr["ExpMonth"].ToString();
                            oCC.ExpYear = rdr["ExpYear"].ToString();
                            oCC.CVV = rdr["CVV"].ToString();
                            oCC.Used = rdr["Used"].ToString();
                            oCC.Active = Convert.ToBoolean(rdr["Active"]);
                            return oCC;
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
                return oCC;
            }

        }

        public CC RetrieveBackUpCC3()
        {
            CC oCC = new CC();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from Telbug.dbo.CCBackUp where Active = 1 and Used < 3 ", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {

                            oCC.ID = Convert.ToInt32(rdr["ID"]);
                            oCC.FirstName = rdr["FirstName"].ToString();
                            oCC.LastName = rdr["LastName"].ToString();
                            oCC.Address = rdr["Address"].ToString();
                            oCC.ZIP = rdr["ZIP"].ToString();
                            oCC.CCNumber = rdr["CCNumber"].ToString();
                            oCC.ExpDate = rdr["ExpDate"].ToString();
                            oCC.ExpMonth = rdr["ExpMonth"].ToString();
                            oCC.ExpYear = rdr["ExpYear"].ToString();
                            oCC.CVV = rdr["CVV"].ToString();
                            oCC.Used = rdr["Used"].ToString();
                            oCC.Active = Convert.ToBoolean(rdr["Active"]);
                            return oCC;
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
                return oCC;
            }

        }
        public CC RetrieveCCs()
        {
            CC oCC = new CC();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select count (*) from Telbug.dbo.CC where Active = 1", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {

                            oCC.ID = Convert.ToInt32(rdr["ID"]);
                            oCC.FirstName = rdr["FirstName"].ToString();
                            oCC.LastName = rdr["LastName"].ToString();
                            oCC.Address = rdr["Address"].ToString();
                            oCC.ZIP = rdr["ZIP"].ToString();
                            oCC.CCNumber = rdr["CCNumber"].ToString();
                            oCC.ExpDate = rdr["ExpDate"].ToString();
                            oCC.ExpMonth = rdr["ExpMonth"].ToString();
                            oCC.ExpYear = rdr["ExpYear"].ToString();
                            oCC.CVV = rdr["CVV"].ToString();
                            oCC.Used = rdr["Used"].ToString();
                            oCC.Active = Convert.ToBoolean(rdr["Active"]);
                            return oCC;
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
                return oCC;
            }

        }
        public CC RetrieveCCbyID(int id)
        {
            CC oCC = new CC();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from Telbug.dbo.CC where ID = '" + id + "'", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {

                            oCC.ID = Convert.ToInt32(rdr["ID"]);
                            oCC.FirstName = rdr["FirstName"].ToString();
                            oCC.LastName = rdr["LastName"].ToString();
                            oCC.Address = rdr["Address"].ToString();
                            oCC.ZIP = rdr["ZIP"].ToString();
                            oCC.CCNumber = rdr["CCNumber"].ToString();
                            oCC.ExpDate = rdr["ExpDate"].ToString();
                            oCC.ExpMonth = rdr["ExpMonth"].ToString();
                            oCC.ExpYear = rdr["ExpYear"].ToString();
                            oCC.CVV = rdr["CVV"].ToString();
                            oCC.Used = rdr["Used"].ToString();
                            oCC.Active = Convert.ToBoolean(rdr["Active"]);
                            return oCC;
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
                return oCC;
            }

        }
        public CC RetrieveNUCC()
        {
            CC oCC = new CC();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from Telbug.dbo.CC where Active = 1 and Used < 1 and SUBSTRING(FirstName, 1, 1) = 'N' and SUBSTRING(LastName, 1, 1) = 'U'", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {

                            oCC.ID = Convert.ToInt32(rdr["ID"]);
                            oCC.FirstName = rdr["FirstName"].ToString();
                            oCC.LastName = rdr["LastName"].ToString();
                            oCC.Address = rdr["Address"].ToString();
                            oCC.ZIP = rdr["ZIP"].ToString();
                            oCC.CCNumber = rdr["CCNumber"].ToString();
                            oCC.ExpDate = rdr["ExpDate"].ToString();
                            oCC.ExpMonth = rdr["ExpMonth"].ToString();
                            oCC.ExpYear = rdr["ExpYear"].ToString();
                            oCC.CVV = rdr["CVV"].ToString();
                            oCC.Used = rdr["Used"].ToString();
                            oCC.Active = Convert.ToBoolean(rdr["Active"]);
                            return oCC;
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
                return oCC;
            }

        }

        public CC RetrieveNUCC2()
        {
            CC oCC = new CC();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from Telbug.dbo.CC where Active = 1 and Used < 2 and SUBSTRING(FirstName, 1, 1) = 'N' and SUBSTRING(LastName, 1, 1) = 'U'", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {

                            oCC.ID = Convert.ToInt32(rdr["ID"]);
                            oCC.FirstName = rdr["FirstName"].ToString();
                            oCC.LastName = rdr["LastName"].ToString();
                            oCC.Address = rdr["Address"].ToString();
                            oCC.ZIP = rdr["ZIP"].ToString();
                            oCC.CCNumber = rdr["CCNumber"].ToString();
                            oCC.ExpDate = rdr["ExpDate"].ToString();
                            oCC.ExpMonth = rdr["ExpMonth"].ToString();
                            oCC.ExpYear = rdr["ExpYear"].ToString();
                            oCC.CVV = rdr["CVV"].ToString();
                            oCC.Used = rdr["Used"].ToString();
                            oCC.Active = Convert.ToBoolean(rdr["Active"]);
                            return oCC;
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
                return oCC;
            }

        }

        public CC RetrieveNUCC3()
        {
            CC oCC = new CC();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from Telbug.dbo.CC where Active = 1 and Used < 3 and SUBSTRING(FirstName, 1, 1) = 'N' and SUBSTRING(LastName, 1, 1) = 'U'", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {

                            oCC.ID = Convert.ToInt32(rdr["ID"]);
                            oCC.FirstName = rdr["FirstName"].ToString();
                            oCC.LastName = rdr["LastName"].ToString();
                            oCC.Address = rdr["Address"].ToString();
                            oCC.ZIP = rdr["ZIP"].ToString();
                            oCC.CCNumber = rdr["CCNumber"].ToString();
                            oCC.ExpDate = rdr["ExpDate"].ToString();
                            oCC.ExpMonth = rdr["ExpMonth"].ToString();
                            oCC.ExpYear = rdr["ExpYear"].ToString();
                            oCC.CVV = rdr["CVV"].ToString();
                            oCC.Used = rdr["Used"].ToString();
                            oCC.Active = Convert.ToBoolean(rdr["Active"]);
                            return oCC;
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
                return oCC;
            }

        }
        public User InsertPayments(string userid, string post, string phonenumber, decimal amountpaid, decimal fee, string provider, string ccnumberused, DateTime createddate)
        {
            User oUser = new User();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                con.Open();
                SqlCommand cmdSql = new SqlCommand();
                string sqlText = "INSERT INTO TelBug.dbo.Payments (UserID, Post, PhoneNumber, AmountPaid, Fee, Provider, CCNumberUsed, CreatedDate) VALUES (@UserID, @Post, @PhoneNumber, @AmountPaid, @Fee, @Provider,  @CCNumberUsed, @CreatedDate)";
                var _with1 = cmdSql;
                _with1.CommandText = sqlText;
                _with1.Connection = con;
                _with1.Parameters.AddWithValue("@UserID", userid);
                _with1.Parameters.AddWithValue("@Post", post);
                _with1.Parameters.AddWithValue("@PhoneNumber", phonenumber);
                _with1.Parameters.AddWithValue("@AmountPaid", amountpaid);
                _with1.Parameters.AddWithValue("@Fee", fee);
                _with1.Parameters.AddWithValue("@Provider", provider);
                _with1.Parameters.AddWithValue("@CCNumberUsed", ccnumberused);
                _with1.Parameters.AddWithValue("@CreatedDate", createddate);
                _with1.ExecuteNonQuery();
                cmdSql.Dispose();
                con.Close();
                return oUser;
            }

        }
        public User InsertCC(string firstname, string lastname, string address, string zip, string cc, string ExpDate, string cvv)
        {
            User oUser = new User();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                con.Open();
                SqlCommand cmdSql = new SqlCommand();
                string sqlText = "INSERT INTO TelBug.dbo.CC (FirstName, LastName, Address, Zip, CCNumber, ExpDate, ExpMonth, ExpYear, CVV, Used, Active, DateModified) VALUES (@FirstName, @LastName, @Address, @Zip, @CCNumber, @ExpDate, @ExpMonth, @ExpYear, @CVV, @Used, @Active, @DateModified)";
                var _with1 = cmdSql;
                _with1.CommandText = sqlText;
                _with1.Connection = con;
                _with1.Parameters.AddWithValue("@FirstName", firstname);
                _with1.Parameters.AddWithValue("@LastName", lastname);
                _with1.Parameters.AddWithValue("@Address", address);
                _with1.Parameters.AddWithValue("@Zip", zip);
                _with1.Parameters.AddWithValue("@CCNumber", cc);
                _with1.Parameters.AddWithValue("@ExpDate", ExpDate);
                _with1.Parameters.AddWithValue("@cvv", cvv);
                _with1.Parameters.AddWithValue("@ExpMonth", ExpDate.Split('/').First());
                _with1.Parameters.AddWithValue("@ExpYear", ExpDate.Split('/').Last());
                _with1.Parameters.AddWithValue("@Used", 0);
                _with1.Parameters.AddWithValue("@Active", 1);
                _with1.Parameters.AddWithValue("@DateModified", DateTime.Now);
                _with1.ExecuteNonQuery();
                cmdSql.Dispose();
                con.Close();
                return oUser;
            }

        }
        public User InsertCCDP(string cc, string ExpDate, string cvv, string zip, string code)
        {
            User oUser = new User();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                con.Open();
                SqlCommand cmdSql = new SqlCommand();
                string sqlText = "INSERT INTO TelBug.dbo.CCDP (CCNumber, ExpDate, CVV, Zip, Code, Used, Active, DateModified, CreatedDate) VALUES (@CCNumber, @ExpDate, @CVV, @Zip, @Code, @Used, @Active, @DateModified, @CreatedDate)";
                var _with1 = cmdSql;
                _with1.CommandText = sqlText;
                _with1.Connection = con;
                _with1.Parameters.AddWithValue("@CCNumber", cc);
                _with1.Parameters.AddWithValue("@ExpDate", ExpDate);
                _with1.Parameters.AddWithValue("@cvv", cvv);
                _with1.Parameters.AddWithValue("@Zip", zip);
                _with1.Parameters.AddWithValue("@code", code);
                _with1.Parameters.AddWithValue("@Used", 0);
                _with1.Parameters.AddWithValue("@Active", 1);
                _with1.Parameters.AddWithValue("@DateModified", DateTime.Now);
                _with1.Parameters.AddWithValue("@CreatedDate", DateTime.Now);
                _with1.ExecuteNonQuery();
                cmdSql.Dispose();
                con.Close();
                return oUser;
            }

        }
        public User UpdateCCUsage(string used, string cc)
        {
            User oUser = new User();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                con.Open();
                SqlCommand cmdSql = new SqlCommand();
                string sqlText = "UPDATE TelBug.dbo.CC SET Used = '" + used + "', DateModified = '" + DateTime.Now + "' where CCNumber ='" + cc + "'";
                var _with1 = cmdSql;
                _with1.CommandText = sqlText;
                _with1.Connection = con;
                _with1.Parameters.AddWithValue("@Used", used);
                _with1.Parameters.AddWithValue("@CCNumber", cc);
                _with1.ExecuteNonQuery();
                cmdSql.Dispose();
                con.Close();
                return oUser;
            }

        }
        public User UpdateCCUsageBackUp(string used, string cc)
        {
            User oUser = new User();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                con.Open();
                SqlCommand cmdSql = new SqlCommand();
                string sqlText = "UPDATE TelBug.dbo.CCBackUp SET Used = '" + used + "', DateModified = '" + DateTime.Now + "' where CCNumber ='" + cc + "'";
                var _with1 = cmdSql;
                _with1.CommandText = sqlText;
                _with1.Connection = con;
                _with1.Parameters.AddWithValue("@Used", used);
                _with1.Parameters.AddWithValue("@CCNumber", cc);
                _with1.ExecuteNonQuery();
                cmdSql.Dispose();
                con.Close();
                return oUser;
            }

        }
        public User UpdateAllCCUsage()
        {
            User oUser = new User();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                con.Open();
                SqlCommand cmdSql = new SqlCommand();
                string sqlText = "UPDATE Telbug.dbo.CC SET Used = '0', DateModified = '" + DateTime.Now + "' where Active = 1";
                var _with1 = cmdSql;
                _with1.CommandText = sqlText;
                _with1.Connection = con;
                _with1.Parameters.AddWithValue("@Used", "0");
                _with1.ExecuteNonQuery();
                cmdSql.Dispose();
                con.Close();
                return oUser;
            }

        }
        public User UpdateCCbyID(int id, string first, string last, string used, bool active)
        {
            User oUser = new User();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                con.Open();
                SqlCommand cmdSql = new SqlCommand();
                string sqlText = "UPDATE Telbug.dbo.CC SET FirstName = '" + first + "',  LastName = '" + last + "',  Used = '" + used + "', Active = '" + active + "', DateModified = '" + DateTime.Now + "' where ID = '" + id + "'";
                var _with1 = cmdSql;
                _with1.CommandText = sqlText;
                _with1.Connection = con;
                _with1.Parameters.AddWithValue("@FirstName", first);
                _with1.Parameters.AddWithValue("@LastName", last);
                _with1.Parameters.AddWithValue("@Used", used);
                _with1.Parameters.AddWithValue("@Active", active);
                _with1.ExecuteNonQuery();
                cmdSql.Dispose();
                con.Close();
                return oUser;
            }

        }
        public User UpdateCCUsageByName(string firstname, string lastname)
        {
            User oUser = new User();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                con.Open();
                SqlCommand cmdSql = new SqlCommand();
                string sqlText = "UPDATE Telbug.dbo.CC SET Active = 0, DateModified = '" + DateTime.Now + "' where SUBSTRING(FirstName, 1,1) = '" + firstname + "' and SUBSTRING(LastName, 1,1) = '" + lastname + "'";
                var _with1 = cmdSql;
                _with1.CommandText = sqlText;
                _with1.Connection = con;
                _with1.Parameters.AddWithValue("@Active", 0);
                _with1.ExecuteNonQuery();
                cmdSql.Dispose();
                con.Close();
                return oUser;
            }

        }

        public User UpdateCConANDoff(string firstname, string lastname, bool on)
        {
            User oUser = new User();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                con.Open();
                SqlCommand cmdSql = new SqlCommand();
                if (on == false)
                {
                    string sqlText = "UPDATE Telbug.dbo.CC SET Active = 0 where SUBSTRING(FirstName, 1,1) = '" + firstname + "' and SUBSTRING(LastName, 1,1) = '" + lastname + "'";
                    var _with1 = cmdSql;
                    _with1.CommandText = sqlText;
                    _with1.Connection = con;
                    _with1.Parameters.AddWithValue("@Active", 0);
                    _with1.ExecuteNonQuery();
                    cmdSql.Dispose();
                }
                else
                {

                    string sqlText = "UPDATE Telbug.dbo.CC SET Active = 1 where used <> 2 and SUBSTRING(FirstName, 1,1) = '" + firstname + "' and SUBSTRING(LastName, 1,1) = '" + lastname + "'";
                    var _with1 = cmdSql;
                    _with1.CommandText = sqlText;
                    _with1.Connection = con;
                    _with1.Parameters.AddWithValue("@Active", 1);
                    _with1.ExecuteNonQuery();
                    cmdSql.Dispose();
                }
                con.Close();
                return oUser;
            }

        }
        public User DisableAccount(string userid, bool active)
        {
            User oUser = new User();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                con.Open();
                SqlCommand cmdSql = new SqlCommand();
                string sqlText = "UPDATE Telbug.dbo.Users SET Active = '" + active + "' where userid = '" + userid + "'";
                var _with1 = cmdSql;
                _with1.CommandText = sqlText;
                _with1.Connection = con;
                _with1.Parameters.AddWithValue("@Active", active);
                _with1.ExecuteNonQuery();
                cmdSql.Dispose();
                con.Close();
                return oUser;
            }

        }

        public CC DisableCard(string ccnumber, bool active)
        {
            CC oUser = new CC();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                con.Open();
                SqlCommand cmdSql = new SqlCommand();
                string sqlText = "UPDATE Telbug.dbo.CC SET Active = '" + active + "' where CCnumber = '" + ccnumber + "'";
                var _with1 = cmdSql;
                _with1.CommandText = sqlText;
                _with1.Connection = con;
                _with1.Parameters.AddWithValue("@Active", active);
                _with1.ExecuteNonQuery();
                cmdSql.Dispose();
                con.Close();
                return oUser;
            }

        }
        public CC DisableCardBackUp(string ccnumber, bool active)
        {
            CC oUser = new CC();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                con.Open();
                SqlCommand cmdSql = new SqlCommand();
                string sqlText = "UPDATE Telbug.dbo.CCBackup SET Active = '" + active + "', datemodified = '" + DateTime.Now + "'  where CCnumber = '" + ccnumber + "'";
                var _with1 = cmdSql;
                _with1.CommandText = sqlText;
                _with1.Connection = con;
                _with1.Parameters.AddWithValue("@Active", active);
                _with1.ExecuteNonQuery();
                cmdSql.Dispose();
                con.Close();
                return oUser;
            }

        }
        public User UpdateCCAmountUsed(string ccname, int currentamount)
        {
            User oUser = new User();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                con.Open();
                SqlCommand cmdSql = new SqlCommand();
                string sqlText = "UPDATE TelBug.dbo.CCUsage SET CurrentAmount = '" + currentamount + "', DateModified = '" + DateTime.Now + "' where CCName ='" + ccname + "'";
                var _with1 = cmdSql;
                _with1.CommandText = sqlText;
                _with1.Connection = con;
                _with1.Parameters.AddWithValue("@CCName", ccname);
                _with1.ExecuteNonQuery();
                cmdSql.Dispose();
                con.Close();
                return oUser;
            }

        }
        public User UpdateCCUsageToFalse(string ccname, bool on)
        {
            User oUser = new User();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                con.Open();
                SqlCommand cmdSql = new SqlCommand();
                if (on == false)
                {
                    string sqlText = "UPDATE TelBug.dbo.CCUsage SET Active = 0 where CCName ='" + ccname + "'";
                    var _with1 = cmdSql;
                    _with1.CommandText = sqlText;
                    _with1.Connection = con;
                    _with1.Parameters.AddWithValue("@Active", 0);
                    _with1.ExecuteNonQuery();
                    cmdSql.Dispose();
                }
                else
                {
                    string sqlText = "UPDATE TelBug.dbo.CCUsage SET Active = 1 , DateModified = '" + DateTime.Now + "' where CCName ='" + ccname + "'";
                    var _with1 = cmdSql;
                    _with1.CommandText = sqlText;
                    _with1.Connection = con;
                    _with1.Parameters.AddWithValue("@Active", 1);
                    _with1.ExecuteNonQuery();
                    cmdSql.Dispose();
                }
                con.Close();
                return oUser;
            }

        }
        public User DeleteCCsByName(string firstname, string lastname)
        {
            User oUser = new User();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                con.Open();
                SqlCommand cmdSql = new SqlCommand();

                string sqlText = "delete TelBug.dbo.cc where SUBSTRING(FirstName, 1,1) = '" + firstname + "' and SUBSTRING(LastName, 1,1) = '" + lastname + "'";
                var _with1 = cmdSql;
                _with1.CommandText = sqlText;
                _with1.Connection = con;
                _with1.ExecuteNonQuery();
                cmdSql.Dispose();

                con.Close();
                return oUser;
            }

        }
        public User DeleteCCsEqualToFalse()
        {
            User oUser = new User();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                con.Open();
                SqlCommand cmdSql = new SqlCommand();

                string sqlText = "delete TelBug.dbo.cc where Active = 'False'";
                var _with1 = cmdSql;
                _with1.CommandText = sqlText;
                _with1.Connection = con;
                _with1.ExecuteNonQuery();
                cmdSql.Dispose();

                con.Close();
                return oUser;
            }

        }
        public Usage RetrieveCCAmountUsed(string ccname)
        {
            Usage oUsage = new Usage();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from CCUsage where CCname ='" + ccname + "' order by DateCreated desc", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {
                            oUsage.CCName = rdr["CCName"].ToString();
                            oUsage.MaxAmount = Convert.ToInt32(rdr["MaxAmount"]);
                            oUsage.CurrentAmount = Convert.ToInt32(rdr["CurrentAmount"]);
                            oUsage.Active = Convert.ToBoolean(rdr["Active"]);
                            oUsage.CreatedDate = Convert.ToDateTime(rdr["DateCreated"]);
                            oUsage.DateModified = Convert.ToDateTime(rdr["DateModified"]);
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
                return oUsage;
            }

        }


        public User InsertAccount(string UserID, string Post)
        {
            User oUser = new User();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                con.Open();
                SqlCommand cmdSql = new SqlCommand();
                string sqlText = "INSERT INTO TelBug.dbo.Accounts(UserID, Post, Credit, Active, CreatedDate, ModifiedDate) VALUES (@UserID, @Post, @Credit, @Active, @CreatedDate, @ModifiedDate)";
                var _with1 = cmdSql;
                _with1.CommandText = sqlText;
                _with1.Connection = con;
                _with1.Parameters.AddWithValue("@UserID", UserID);
                _with1.Parameters.AddWithValue("@Post", Post);
                _with1.Parameters.AddWithValue("@Credit", 0);
                _with1.Parameters.AddWithValue("@Active", 1);
                _with1.Parameters.AddWithValue("@CreatedDate", DateTime.Now);
                _with1.Parameters.AddWithValue("@ModifiedDate", DateTime.Now);
                _with1.ExecuteNonQuery();
                cmdSql.Dispose();
                con.Close();
                return oUser;
            }

        }
        public Account UpdateAccount(decimal Credit, string UserID)
        {
            Account oAccount = new Account();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                con.Open();
                SqlCommand cmdSql = new SqlCommand();
                string sqlText = "UPDATE TelBug.dbo.Accounts SET Credit = '" + Credit + "', ModifiedDate = '" + DateTime.Now + "' where UserID ='" + UserID + "'";
                var _with1 = cmdSql;
                _with1.CommandText = sqlText;
                _with1.Connection = con;
                _with1.Parameters.AddWithValue("@Credit", Credit);
                _with1.Parameters.AddWithValue("@UserID", UserID);
                _with1.ExecuteNonQuery();
                cmdSql.Dispose();
                con.Close();
                return oAccount;
            }

        }
        public Account UpdateAccountbyPost(decimal Credit, string Post)
        {
            Account oAccount = new Account();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                con.Open();
                SqlCommand cmdSql = new SqlCommand();
                string sqlText = "UPDATE TelBug.dbo.Accounts SET Credit = '" + Credit + "', ModifiedDate = '" + DateTime.Now + "' where Post ='" + Post + "'";
                var _with1 = cmdSql;
                _with1.CommandText = sqlText;
                _with1.Connection = con;
                _with1.Parameters.AddWithValue("@Credit", Credit);
                _with1.Parameters.AddWithValue("@Post", Post);
                _with1.ExecuteNonQuery();
                cmdSql.Dispose();
                con.Close();
                return oAccount;
            }

        }
        public Account RetrieveAccount(string UserID)
        {
            Account oAccount = new Account();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from Telbug.dbo.Accounts where UserID = '" + UserID + "'", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {
                            oAccount.UserID = rdr["UserID"].ToString();
                            oAccount.Post = rdr["Post"].ToString();
                            oAccount.Credit = Convert.ToDecimal(rdr["Credit"]);
                            oAccount.Active = Convert.ToBoolean(rdr["Active"]);
                            return oAccount;
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
                return oAccount;
            }

        }
        public Account InsertCredit(string UserID, string Post, string TransactionID, decimal Amount)
        {
            Account oAccount = new Account();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                con.Open();
                SqlCommand cmdSql = new SqlCommand();
                string sqlText = "INSERT INTO TelBug.dbo.Credit(UserID, Post, Amount, TransactionID, CreatedDate) VALUES (@UserID, @Post, @Amount, @TransactionID, @CreatedDate)";
                var _with1 = cmdSql;
                _with1.CommandText = sqlText;
                _with1.Connection = con;
                _with1.Parameters.AddWithValue("@UserID", UserID);
                _with1.Parameters.AddWithValue("@Post", Post);
                _with1.Parameters.AddWithValue("@TransactionID", TransactionID);
                _with1.Parameters.AddWithValue("@Amount", Amount);
                _with1.Parameters.AddWithValue("@CreatedDate", DateTime.Now);
                _with1.ExecuteNonQuery();
                cmdSql.Dispose();
                con.Close();
                return oAccount;
            }

        }

        public User LogError(string userid, string phonenumber, string CC, string error)
        {
            User oUser = new User();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                con.Open();
                SqlCommand cmdSql = new SqlCommand();
                string sqlText = "INSERT INTO Telbug.dbo.ErrorLog (UserID, PhoneNumber, CC, Error, CreatedDate) VALUES (@UserID, @PhoneNumber, @CC, @Error, @CreatedDate)";
                var _with1 = cmdSql;
                _with1.CommandText = sqlText;
                _with1.Connection = con;
                _with1.Parameters.AddWithValue("@UserID", userid);
                _with1.Parameters.AddWithValue("@PhoneNumber", phonenumber);
                _with1.Parameters.AddWithValue("@CC", CC);
                _with1.Parameters.AddWithValue("@Error", error);
                _with1.Parameters.AddWithValue("@CreatedDate", DateTime.Now);
                _with1.ExecuteNonQuery();
                cmdSql.Dispose();
                con.Close();
                return oUser;
            }

        }
        public Account UpdatePassword(string pass, string user)
        {
            Account oAccount = new Account();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                con.Open();
                SqlCommand cmdSql = new SqlCommand();
                string sqlText = "UPDATE TelBug.dbo.Users SET Password = '" + pass + "' where userid = '" + user + "'";
                var _with1 = cmdSql;
                _with1.CommandText = sqlText;
                _with1.Connection = con;
                _with1.Parameters.AddWithValue("@Password", pass);
                _with1.ExecuteNonQuery();
                cmdSql.Dispose();
                con.Close();
                return oAccount;
            }

        }

        public Account UpdateUser(string user, string fullname, string phonenumber, string email, string businessname, string address, bool active, string city, string state, string zip, string resaleCert, string EIN)
        {
            Account oAccount = new Account();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                con.Open();
                SqlCommand cmdSql = new SqlCommand();
                string sqlText = "UPDATE TelBug.dbo.Users SET FullName = '" + fullname + "', PhoneNumber = '" + phonenumber + "', Email = '" + email + "', BusinessName = '" + businessname + "', Address = '" + address + "', Active = '" + active + "', City = '" + city + "', State = '" + state + "', Zip = '" + zip + "', ResaleCert = '" + resaleCert + "', EIN = '" + EIN + "' where userid = '" + user + "'";
                var _with1 = cmdSql;
                _with1.CommandText = sqlText;
                _with1.Connection = con;
                _with1.Parameters.AddWithValue("@FullName", fullname);
                _with1.Parameters.AddWithValue("@PhoneNumber", phonenumber);
                _with1.Parameters.AddWithValue("@Email", email);
                _with1.Parameters.AddWithValue("@BusinessName", businessname);
                _with1.Parameters.AddWithValue("@Address", address);
                _with1.Parameters.AddWithValue("@Active", active);
                _with1.Parameters.AddWithValue("@City", city);
                _with1.Parameters.AddWithValue("@State", state);
                _with1.Parameters.AddWithValue("@Zip", zip);
                _with1.Parameters.AddWithValue("@ResaleCert", resaleCert);
                _with1.Parameters.AddWithValue("@EIN", EIN);
                _with1.ExecuteNonQuery();
                cmdSql.Dispose();
                con.Close();
                return oAccount;
            }

        }

        public Account UpdateFee(string fee, string user)
        {
            Account oAccount = new Account();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                con.Open();
                SqlCommand cmdSql = new SqlCommand();
                string sqlText = "UPDATE TelBug.dbo.fees SET fee = '" + fee + "' where userid = '" + user + "'";
                var _with1 = cmdSql;
                _with1.CommandText = sqlText;
                _with1.Connection = con;
                _with1.Parameters.AddWithValue("@Fee", fee);
                _with1.ExecuteNonQuery();
                cmdSql.Dispose();
                con.Close();
                return oAccount;
            }

        }
        public Account DeletePayment(int ID)
        {
            Account oAccount = new Account();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                con.Open();
                SqlCommand cmdSql = new SqlCommand();
                string sqlText = "DELETE From TelBug.dbo.Payments where id = '" + ID + "'";
                var _with1 = cmdSql;
                _with1.CommandText = sqlText;
                _with1.Connection = con;
                _with1.Parameters.AddWithValue("@id ", ID);
                _with1.ExecuteNonQuery();
                cmdSql.Dispose();
                con.Close();
                return oAccount;
            }

        }

        public Account DeleteCreditTrans(int ID)
        {
            Account oAccount = new Account();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                con.Open();
                SqlCommand cmdSql = new SqlCommand();
                string sqlText = "DELETE From TelBug.dbo.Credit where id = '" + ID + "'";
                var _with1 = cmdSql;
                _with1.CommandText = sqlText;
                _with1.Connection = con;
                _with1.Parameters.AddWithValue("@id ", ID);
                _with1.ExecuteNonQuery();
                cmdSql.Dispose();
                con.Close();
                return oAccount;
            }

        }

        public CC DeleteCC(int ID)
        {
            CC oCC = new CC();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                con.Open();
                SqlCommand cmdSql = new SqlCommand();
                string sqlText = "DELETE From TelBug.dbo.CC where id = '" + ID + "'";
                var _with1 = cmdSql;
                _with1.CommandText = sqlText;
                _with1.Connection = con;
                _with1.Parameters.AddWithValue("@id ", ID);
                _with1.ExecuteNonQuery();
                cmdSql.Dispose();
                con.Close();
                return oCC;
            }

        }
        public Announcement DeleteAnnoucement(int ID)
        {
            Announcement oAnnouncement = new Announcement();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                con.Open();
                SqlCommand cmdSql = new SqlCommand();
                string sqlText = "DELETE From TelBug.dbo.Announcement where id = '" + ID + "'";
                var _with1 = cmdSql;
                _with1.CommandText = sqlText;
                _with1.Connection = con;
                _with1.Parameters.AddWithValue("@id ", ID);
                _with1.ExecuteNonQuery();
                cmdSql.Dispose();
                con.Close();
                return oAnnouncement;
            }
        }
        public MetroPCSSecurity DeleteMS(string b)
        {
            MetroPCSSecurity oMetroPCSSecurity = new MetroPCSSecurity();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                con.Open();
                SqlCommand cmdSql = new SqlCommand();
                string sqlText = "DELETE From TelBug.dbo.MetroPCSSecurityFix where b = '" + b + "'";
                var _with1 = cmdSql;
                _with1.CommandText = sqlText;
                _with1.Connection = con;
                _with1.Parameters.AddWithValue("@b", b);
                _with1.ExecuteNonQuery();
                cmdSql.Dispose();
                con.Close();
                return oMetroPCSSecurity;
            }
        }
        public User RetrieveServiceActivity(int id, string UserID = "", string paymentdate = "")
        {
            User oUser = new User();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {

                // for reports 
                if (paymentdate != "")
                {
                    paymentdate = Convert.ToDateTime(paymentdate).ToShortDateString();
                    using (SqlCommand cmd = new SqlCommand("select distinct ID, Product, OfferingID, Commission, (select case when EXISTS(select UserCommission from UserDiscoutRate where ProductID = '" + id + "' and UserID = '" + UserID + "' and '" + paymentdate + "' between CreatedDate and EndDate) then( select UserCommission from UserDiscoutRate where ProductID = '" + id + "' and UserID = '" + UserID + "' and '" + paymentdate + "' between CreatedDate and EndDate) Else (select UserCommission from TelBug.dbo.Services where ID = '" + id + "' ) End ) as UserCommission, TelBugCommission, Active from TelBug.dbo.Services where id = '" + id + "'", con))
                    {
                        con.Open();
                        using (SqlDataReader rdr = cmd.ExecuteReader())
                        {

                            while (rdr.Read())
                            {

                                oUser.ID = Convert.ToInt32(rdr["ID"]);
                                oUser.FullName = rdr["Product"].ToString();
                                oUser.OfferingID = Convert.ToInt32(rdr["OfferingID"]);
                                oUser.Commission = Convert.ToDecimal(rdr["Commission"]);
                                oUser.UserCommission = Convert.ToDecimal(rdr["UserCommission"]);
                                oUser.TelBugCommission = Convert.ToDecimal(rdr["TelBugCommission"]);
                                oUser.Active = Convert.ToBoolean(rdr["Active"]);
                                return oUser;
                            }
                            rdr.Close();

                        }
                    }
                }
                else
                {
                    using (SqlCommand cmd = new SqlCommand("select distinct ID, Product, OfferingID, Commission, (select case when EXISTS(select UserCommission from UserDiscoutRate where ProductID = '" + id + "' and UserID = '" + UserID + "') then( select UserCommission from UserDiscoutRate where ProductID = '" + id + "' and UserID = '" + UserID + "') Else (select UserCommission from TelBug.dbo.Services where ID = '" + id + "' ) End ) as UserCommission, TelBugCommission, Active from TelBug.dbo.Services where id = '" + id + "'", con))
                    {
                        con.Open();
                        using (SqlDataReader rdr = cmd.ExecuteReader())
                        {

                            while (rdr.Read())
                            {

                                oUser.ID = Convert.ToInt32(rdr["ID"]);
                                oUser.FullName = rdr["Product"].ToString();
                                oUser.OfferingID = Convert.ToInt32(rdr["OfferingID"]);
                                oUser.Commission = Convert.ToDecimal(rdr["Commission"]);
                                oUser.UserCommission = Convert.ToDecimal(rdr["UserCommission"]);
                                oUser.TelBugCommission = Convert.ToDecimal(rdr["TelBugCommission"]);
                                oUser.Active = Convert.ToBoolean(rdr["Active"]);
                                return oUser;
                            }
                            rdr.Close();

                        }
                    }
                }

                con.Dispose();
                con.Close();
                return oUser;
            }

        }

        public User RetrieveServiceActivityByProduct(string name, string UserID = "")
        {
            User oUser = new User();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                //using (SqlCommand cmd = new SqlCommand("select * from TelBug.dbo.Services where product ='" + name + "'", con))
                using (SqlCommand cmd = new SqlCommand("select distinct ID, Product, OfferingID, Commission, (select case when EXISTS(select UserCommission from UserDiscoutRate where Product = '" + name + "' and UserID = '" + UserID + "' ) then( select UserCommission from UserDiscoutRate where Product = '" + name + "' and UserID = '" + UserID + "' ) Else (select UserCommission from TelBug.dbo.Services where Product = '" + name + "' ) End ) as UserCommission, TelBugCommission, Active from TelBug.dbo.Services where product = '" + name + "'", con))

                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {

                            oUser.ID = Convert.ToInt32(rdr["ID"]);
                            oUser.FullName = rdr["Product"].ToString();
                            oUser.OfferingID = Convert.ToInt32(rdr["OfferingID"]);
                            oUser.Commission = Convert.ToDecimal(rdr["Commission"]);
                            oUser.UserCommission = Convert.ToDecimal(rdr["UserCommission"]);
                            oUser.TelBugCommission = Convert.ToDecimal(rdr["TelBugCommission"]);
                            oUser.Active = Convert.ToBoolean(rdr["Active"]);
                            return oUser;
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
                return oUser;
            }

        }

        public Account UpdateServiceActivity(int id, bool active)
        {
            Account oAccount = new Account();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                con.Open();
                SqlCommand cmdSql = new SqlCommand();
                string sqlText = "UPDATE TelBug.dbo.Services SET Active = '" + active + "' where id = '" + id + "'";
                var _with1 = cmdSql;
                _with1.CommandText = sqlText;
                _with1.Connection = con;
                _with1.Parameters.AddWithValue("@Active", active);
                _with1.ExecuteNonQuery();
                cmdSql.Dispose();
                con.Close();
                return oAccount;
            }

        }

        public Account InsertIP(string UserID, string IP, int PaymentID)
        {
            Account oAccount = new Account();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                con.Open();
                SqlCommand cmdSql = new SqlCommand();
                string sqlText = "INSERT INTO TelBug.dbo.IPCapture(UserID, PaymentID, IPAddress, CreatedDate) VALUES (@UserID, @PaymentID, @IPAddress, @CreatedDate)";
                var _with1 = cmdSql;
                _with1.CommandText = sqlText;
                _with1.Connection = con;
                _with1.Parameters.AddWithValue("@UserID", UserID);
                _with1.Parameters.AddWithValue("@PaymentID", PaymentID);
                _with1.Parameters.AddWithValue("@IPAddress", IP);
                _with1.Parameters.AddWithValue("@CreatedDate", DateTime.Now);
                _with1.ExecuteNonQuery();
                cmdSql.Dispose();
                con.Close();
                return oAccount;
            }

        }
        public CC RetrieveUserCC(string userid)
        {
            CC oCC = new CC();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from Telbug.dbo.UserCC where userid = '" + userid + "'", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {

                            oCC.FirstName = rdr["FirstName"].ToString();
                            oCC.LastName = rdr["LastName"].ToString();
                            oCC.Address = rdr["Address"].ToString();
                            oCC.City = rdr["City"].ToString();
                            oCC.State = rdr["State"].ToString();
                            oCC.ZIP = rdr["ZIP"].ToString();
                            oCC.CCNumber = rdr["CC"].ToString();
                            oCC.ExpDate = rdr["ExpDate"].ToString();
                            oCC.CVV = rdr["CVV"].ToString();
                            oCC.Active = Convert.ToBoolean(rdr["Active"]);
                            return oCC;
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
                return oCC;
            }

        }
        public User InsertUserCC(string userid, string firstname, string lastname, string city, string state, string address, string zip, string cc, string ExpDate, string cvv, bool active)
        {
            User oUser = new User();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                con.Open();
                SqlCommand cmdSql = new SqlCommand();
                string sqlText = "INSERT INTO TelBug.dbo.UserCC (UserID, FirstName, LastName, Address, City, State, Zip, CC, ExpDate, CVV, DateCreated, Active) VALUES (@UserID, @FirstName, @LastName, @Address, @City, @State, @Zip, @CC, @ExpDate, @CVV, @DateCreated, @Active)";
                var _with1 = cmdSql;
                _with1.CommandText = sqlText;
                _with1.Connection = con;
                _with1.Parameters.AddWithValue("@UserID", userid);
                _with1.Parameters.AddWithValue("@FirstName", firstname);
                _with1.Parameters.AddWithValue("@LastName", lastname);
                _with1.Parameters.AddWithValue("@Address", address);
                _with1.Parameters.AddWithValue("@City", city);
                _with1.Parameters.AddWithValue("@State", state);
                _with1.Parameters.AddWithValue("@Zip", zip);
                _with1.Parameters.AddWithValue("@CC", cc);
                _with1.Parameters.AddWithValue("@ExpDate", ExpDate);
                _with1.Parameters.AddWithValue("@cvv", cvv);
                _with1.Parameters.AddWithValue("@DateCreated", DateTime.Now);
                _with1.Parameters.AddWithValue("@Active", active);
                _with1.ExecuteNonQuery();
                cmdSql.Dispose();
                con.Close();
                return oUser;
            }

        }

        public User UpdateUserCC(string userid, string firstname, string lastname, string address, string city, string state, string zip, string cc, string ExpDate, string cvv, bool active)
        {
            User oUser = new User();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                con.Open();
                SqlCommand cmdSql = new SqlCommand();
                string sqlText = "UPDATE Telbug.dbo.UserCC SET FirstName = '" + firstname + "', LastName = '" + lastname + "', Address = '" + address + "', City = '" + city + "', State = '" + state + "', Zip = '" + zip + "', CC = '" + cc + "', ExpDate = '" + ExpDate + "', Active  = '" + active + "' where UserID = '" + userid + "'";
                var _with1 = cmdSql;
                _with1.CommandText = sqlText;
                _with1.Connection = con;
                _with1.Parameters.AddWithValue("@FirstName", firstname);
                _with1.Parameters.AddWithValue("@LastName", lastname);
                _with1.Parameters.AddWithValue("@Address", address);
                _with1.Parameters.AddWithValue("@City", city);
                _with1.Parameters.AddWithValue("@State", state);
                _with1.Parameters.AddWithValue("@Zip", zip);
                _with1.Parameters.AddWithValue("@CCNumber", cc);
                _with1.Parameters.AddWithValue("@ExpDate", ExpDate);
                _with1.Parameters.AddWithValue("@cvv", cvv);
                _with1.Parameters.AddWithValue("@Active", active);
                _with1.ExecuteNonQuery();
                cmdSql.Dispose();
                con.Close();
                return oUser;
            }

        }

        public User DeleteUserCC(string userid)
        {
            User oUser = new User();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                con.Open();
                SqlCommand cmdSql = new SqlCommand();
                string sqlText = "DELETE From TelBug.dbo.UserCC where userid = '" + userid + "'";
                var _with1 = cmdSql;
                _with1.CommandText = sqlText;
                _with1.Connection = con;
                _with1.Parameters.AddWithValue("@UserID ", userid);
                _with1.ExecuteNonQuery();
                cmdSql.Dispose();
                con.Close();
                return oUser;
            }

        }
        public Announcement RetrieveAnnouncement()
        {
            Announcement announcement;
            Announcement str = new Announcement();
            using (SqlConnection sqlConnection = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand sqlCommand = new SqlCommand("select * from Telbug.dbo.Announcement", sqlConnection))
                {
                    sqlConnection.Open();
                    using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
                    {
                        if (sqlDataReader.Read())
                        {
                            str.AnnounceID = Convert.ToInt32(sqlDataReader["ID"]);
                            str.AnnounceText = sqlDataReader["Text"].ToString();
                            str.AnnouncementDate = Convert.ToDateTime(sqlDataReader["AnnouncementDate"]);
                            str.AnnouncementDateEnd = Convert.ToDateTime(sqlDataReader["AnnouncementDateEnd"]);
                            announcement = str;
                            return announcement;
                        }
                        else
                        {
                            sqlDataReader.Close();
                        }
                    }
                }
                announcement = str;
                sqlConnection.Dispose();
                sqlConnection.Close();
            }

            return announcement;
        }
        public Announcement RetrieveAnnouncementbyID(int id)
        {
            Announcement announcement;
            Announcement str = new Announcement();
            using (SqlConnection sqlConnection = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand sqlCommand = new SqlCommand("select * from Telbug.dbo.Announcement where id = " + id + "", sqlConnection))
                {
                    sqlConnection.Open();
                    using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
                    {
                        if (sqlDataReader.Read())
                        {
                            str.AnnounceID = Convert.ToInt32(sqlDataReader["ID"]);
                            str.AnnounceText = sqlDataReader["Text"].ToString();
                            str.AnnouncementDate = Convert.ToDateTime(sqlDataReader["AnnouncementDate"]);
                            str.AnnouncementDateEnd = Convert.ToDateTime(sqlDataReader["AnnouncementDateEnd"]);
                            announcement = str;
                            return announcement;
                        }
                        else
                        {
                            sqlDataReader.Close();
                        }
                    }
                }
                announcement = str;
                sqlConnection.Dispose();
                sqlConnection.Close();
            }

            return announcement;
        }
        public Announcement RetrieveAnnouncementByDate()
        {
            Announcement announcement;
            Announcement str = new Announcement();
            using (SqlConnection sqlConnection = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand sqlCommand = new SqlCommand("select *  from Announcement where AnnouncementDateEnd >= convert(varchar, getdate(), 1) and   convert(varchar, getdate(), 1) between AnnouncementDate and AnnouncementDateEnd", sqlConnection))
                {
                    sqlConnection.Open();
                    using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
                    {
                        if (sqlDataReader.Read())
                        {
                            str.AnnounceText = sqlDataReader["Text"].ToString();
                            announcement = str;
                            return announcement;
                        }
                        else
                        {
                            sqlDataReader.Close();
                        }
                    }
                }
                announcement = str;
                sqlConnection.Dispose();
                sqlConnection.Close();
            }

            return announcement;
        }
        public User InsertAnnouncement(string text, string announcementDate, string announcementDateEnd)
        {
            User oUser = new User();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                con.Open();
                SqlCommand cmdSql = new SqlCommand();
                string sqlText = "INSERT INTO TelBug.dbo.Announcement (Text, Active, AnnouncementDate, AnnouncementDateEnd, CreatedDate) VALUES (@Text, @Active, @AnnouncementDate, @AnnouncementDateEnd, @CreatedDate)";
                var _with1 = cmdSql;
                _with1.CommandText = sqlText;
                _with1.Connection = con;
                cmdSql.Parameters.AddWithValue("@Text", text);
                cmdSql.Parameters.AddWithValue("@Active", true);
                cmdSql.Parameters.AddWithValue("@AnnouncementDate", announcementDate);
                cmdSql.Parameters.AddWithValue("@AnnouncementDateEnd", announcementDateEnd);
                cmdSql.Parameters.AddWithValue("@CreatedDate", DateTime.Now);
                _with1.ExecuteNonQuery();
                cmdSql.Dispose();
                con.Close();
                return oUser;
            }

        }
        public Announcement UpdateAnnouncement(string text, string announcementDate, string announcementDateEnd)
        {
            Announcement announcement;
            Announcement announcement1 = new Announcement();
            using (SqlConnection sqlConnection = new SqlConnection(DAO.sDBConn))
            {
                sqlConnection.Open();
                SqlCommand sqlCommand = new SqlCommand();
                string str = string.Concat("UPDATE Telbug.dbo.Announcement SET Text = '" + text + "' where AnnouncementDate = '" + announcementDate + "'");
                SqlCommand sqlCommand1 = sqlCommand;
                sqlCommand1.CommandText = str;
                sqlCommand1.Connection = sqlConnection;
                sqlCommand1.Parameters.AddWithValue("@Text", text);
                sqlCommand1.Parameters.AddWithValue("@Active", true);
                sqlCommand1.Parameters.AddWithValue("@AnnouncementDate", announcementDate);
                sqlCommand1.Parameters.AddWithValue("@AnnouncementDateEnd", announcementDateEnd);
                sqlCommand1.Parameters.AddWithValue("@CreatedDate", DateTime.Now);
                sqlCommand1.ExecuteNonQuery();
                sqlCommand.Dispose();
                sqlConnection.Close();
                announcement = announcement1;
            }
            return announcement;
        }

        public MetroPCSSecurity RetrieveMSbyA()
        {
            MetroPCSSecurity ms;
            MetroPCSSecurity str = new MetroPCSSecurity();
            using (SqlConnection sqlConnection = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand sqlCommand = new SqlCommand(" select top(1) * from Telbug.dbo.MetroPCSSecurityFix order by CreatedDate asc", sqlConnection))
                {
                    sqlConnection.Open();
                    using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
                    {
                        if (sqlDataReader.Read())
                        {
                            str.a =sqlDataReader["a"].ToString();
                            str.b = sqlDataReader["b"].ToString();
                            str.c = sqlDataReader["c"].ToString();
                            str.d = sqlDataReader["d"].ToString();
                            str.f = sqlDataReader["f"].ToString();
                            str.z = sqlDataReader["z"].ToString();
                            //str.uniquestatekey  = sqlDataReader["uniquestatekey"].ToString();
                            ms = str;
                            return ms;
                        }
                        else
                        {
                            sqlDataReader.Close();
                        }
                    }
                }
                ms = str;
                sqlConnection.Dispose();
                sqlConnection.Close();
            }

            return ms;
        }
        public DataTable GetDiscountTable()
        {
            DataTable table = new DataTable(); // New data table.
            table.Columns.Add("ProductID", typeof(int));
            table.Columns.Add("UserID", typeof(string));
            table.Columns.Add("Product", typeof(string));
            table.Columns.Add("UserCommission", typeof(float));
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from UserDiscoutRate ", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {
                        while (rdr.Read())
                        {
                            table.Rows.Add(Convert.ToInt32(rdr["ProductID"]), rdr["UserID"].ToString(), rdr["Product"].ToString(), Convert.ToDecimal(rdr["UserCommission"]));

                        }
                        con.Dispose();
                        con.Close();
                        return table; // Return reference.
                    }
                }
            }

        }

        public User InsertUserPin(string number, string pin)
        {
            User oUser = new User();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                con.Open();
                SqlCommand cmdSql = new SqlCommand();
                string sqlText = "INSERT INTO TelBug.dbo.BoostPin (PhoneNumber, Pin) VALUES (@PhoneNumber, @Pin)";
                var _with1 = cmdSql;
                _with1.CommandText = sqlText;
                _with1.Connection = con;
                _with1.Parameters.AddWithValue("@PhoneNumber", number);
                _with1.Parameters.AddWithValue("@Pin", pin);
                _with1.ExecuteNonQuery();
                cmdSql.Dispose();
                con.Close();
                return oUser;
            }

        }
        public User InsertGuatePinReferrals(string ReferrerNumber, string ReferralNumber)
        {
            User oUser = new User();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                con.Open();
                SqlCommand cmdSql = new SqlCommand();
                string sqlText = "INSERT INTO TelBug.dbo.GuatePinReferrals (ReferrerNumber, ReferralNumber, WasReferred, CreatedDate) VALUES (@ReferrerNumber, @ReferralNumber, @WasReferred, @CreatedDate )";
                var _with1 = cmdSql;
                _with1.CommandText = sqlText;
                _with1.Connection = con;
                _with1.Parameters.AddWithValue("@ReferrerNumber", ReferrerNumber);
                _with1.Parameters.AddWithValue("@ReferralNumber", ReferralNumber);
                _with1.Parameters.AddWithValue("@WasReferred", false);
                _with1.Parameters.AddWithValue("@CreatedDate", DateTime.Now);
                _with1.ExecuteNonQuery();
                cmdSql.Dispose();
                con.Close();
                return oUser;
            }

        }
        public User RetrieveBoostPin(string number)
        {
            User oUser = new User();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                //using (SqlCommand cmd = new SqlCommand("select * from TelBug.dbo.Services where product ='" + name + "'", con))
                using (SqlCommand cmd = new SqlCommand("select * from  BoostPin where PhoneNumber = '" + number + "'", con))

                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {
                            oUser.Pin = Convert.ToString(rdr["Pin"]);
                            return oUser;
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
                return oUser;
            }

        }
        public User UpdatetGuatePinReferrals(string ReferralNumber, bool used)
        {
            int booltint = 0;
            if (used == true)
            {
                booltint = 1;
            }
            User oUser = new User();
            using (SqlConnection sqlConnection = new SqlConnection(DAO.sDBConn))
            {
                sqlConnection.Open();
                SqlCommand sqlCommand = new SqlCommand();
                string str = string.Concat("UPDATE Telbug.dbo.GuatePinReferrals SET WasReferred = " + booltint + " where ReferralNumber = '" + ReferralNumber + "'");
                SqlCommand sqlCommand1 = sqlCommand;
                sqlCommand1.CommandText = str;
                sqlCommand1.Connection = sqlConnection;
                sqlCommand1.Parameters.AddWithValue("@Active", booltint);
                sqlCommand1.Parameters.AddWithValue("@CreatedDate", DateTime.Now);
                sqlCommand1.ExecuteNonQuery();
                sqlCommand.Dispose();
                sqlConnection.Close();
            }
            return oUser;
        }
        public User RetrieveGuatePinReferral(string ReferralNumber)
        {
            User oUser = new User();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                //using (SqlCommand cmd = new SqlCommand("select * from TelBug.dbo.Services where product ='" + name + "'", con))
                using (SqlCommand cmd = new SqlCommand("select * from GuatePinReferrals where ReferralNumber = '" + ReferralNumber + "'", con))

                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {
                            oUser.ReferralNumber = Convert.ToString(rdr["ReferralNumber"]);
                            oUser.Active = Convert.ToBoolean(rdr["WasReferred"]);
                            return oUser;
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
                return oUser;
            }

        }
        public User RetrieveGuatePinReferrer(string ReferrerNumber)
        {
            User oUser = new User();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                //using (SqlCommand cmd = new SqlCommand("select * from TelBug.dbo.Services where product ='" + name + "'", con))
                using (SqlCommand cmd = new SqlCommand("select * from GuatePinReferrals where ReferrerNumber = '" + ReferrerNumber + "'", con))

                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {
                            oUser.PhoneNumber = Convert.ToString(rdr["ReferrerNumber"]);
                            oUser.ReferralNumber = Convert.ToString(rdr["ReferralNumber"]);
                            oUser.Active = Convert.ToBoolean(rdr["WasReferred"]);
                            return oUser;
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
                return oUser;
            }

        }
        public User RetrieveGuatePinRecharge(string ReferralNumber)
        {
            User oUser = new User();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                //using (SqlCommand cmd = new SqlCommand("select * from TelBug.dbo.Services where product ='" + name + "'", con))
                using (SqlCommand cmd = new SqlCommand("select * from payments where provider like '%GuatePin%' and PhoneNumber = '" + ReferralNumber + "'", con))

                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {
                            oUser.PhoneNumber = Convert.ToString(rdr["PhoneNumber"]);
                            return oUser;
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
                return oUser;
            }

        }

        public MetroPCSSecurity GetAllX49exvsbl()
        {
            MetroPCSSecurity oMetroPCSSecurity = new MetroPCSSecurity();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select top 1 * from MetroPCSSecurityFix order by createddate asc", con))

                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {
                            oMetroPCSSecurity.a = Convert.ToString(rdr["a"]);
                            oMetroPCSSecurity.b = Convert.ToString(rdr["b"]);
                            oMetroPCSSecurity.c = Convert.ToString(rdr["c"]);
                            oMetroPCSSecurity.d = Convert.ToString(rdr["d"]);
                            oMetroPCSSecurity.f = Convert.ToString(rdr["f"]);
                            oMetroPCSSecurity.z = Convert.ToString(rdr["z"]);
                           // oMetroPCSSecurity.uniquestatekey = Convert.ToString(rdr["uniquestatekey"]);
                            return oMetroPCSSecurity;
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
                return oMetroPCSSecurity;
            }

        }

        public MetroPCSSecurity InsertMetroPCSSecurity(string a, string b, string c, string d, string f, string z)
        {
            MetroPCSSecurity oMetroPCSSecurity = new MetroPCSSecurity();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                con.Open();
                SqlCommand cmdSql = new SqlCommand();
                string sqlText = "INSERT INTO TelBug.dbo.MetroPCSSecurityFix (a, b, c, d, f, z, CreatedDate) VALUES (@a, @b, @c, @d, @f, @z, @CreatedDate)";
                var _with1 = cmdSql;
                _with1.CommandText = sqlText;
                _with1.Connection = con;
                _with1.Parameters.AddWithValue("@a", a);
                _with1.Parameters.AddWithValue("@b", b);
                _with1.Parameters.AddWithValue("@c", c);
                _with1.Parameters.AddWithValue("@d", d);
                _with1.Parameters.AddWithValue("@f", f);
                _with1.Parameters.AddWithValue("@z", z);
                _with1.Parameters.AddWithValue("@CreatedDate", DateTime.Now);
                _with1.ExecuteNonQuery();
                cmdSql.Dispose();
                con.Close();
                return oMetroPCSSecurity;
            }

        }
         public DataTable Services()
        {
            DataTable dataTable;
            DataTable table = new DataTable();
            table.Columns.Add("ID", typeof(int));
            table.Columns.Add("Product", typeof(string));
            table.Columns.Add("OfferingID", typeof(int));
            table.Columns.Add("Commission", typeof(float));
            table.Columns.Add("UserCommission", typeof(float));
            table.Columns.Add("TelbugCommission", typeof(float));
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from Services", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {
                        while (rdr.Read())
                        {
                            table.Rows.Add(new object[] { Convert.ToInt32(rdr["ID"]), rdr["Product"].ToString(), Convert.ToInt32(rdr["OfferingID"]), Convert.ToDecimal(rdr["Commission"]), Convert.ToDecimal(rdr["UserCommission"]), Convert.ToDecimal(rdr["TelbugCommission"]) });
                        }
                        con.Dispose();
                        con.Close();
                        dataTable = table;
                    }
                }
            }
            return dataTable;
        }

        public Payment InsertSID(int paymentid, string sid)
        {
            Payment oPayment = new Payment();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                con.Open();
                SqlCommand cmdSql = new SqlCommand();
                string sqlText = "INSERT INTO TelBug.dbo.MetroPhoneCall (paymentid, sid, IsManual, CreatedDate) VALUES (@paymentid, @sid, @IsManual, @CreatedDate)";
                var _with1 = cmdSql;
                _with1.CommandText = sqlText;
                _with1.Connection = con;
                _with1.Parameters.AddWithValue("@paymentid", paymentid);
                _with1.Parameters.AddWithValue("@sid", sid);
                _with1.Parameters.AddWithValue("@IsManual", 0);
                _with1.Parameters.AddWithValue("@CreatedDate", DateTime.Now);
                _with1.ExecuteNonQuery();
                cmdSql.Dispose();
                con.Close();
                return oPayment;
            }

        }

        public Payment RetrieveSIDbyPaymentID(int id)
        {
            Payment oPayment = new Payment();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                using (SqlCommand cmd = new SqlCommand("select * from Telbug.dbo.MetroPhoneCall where PaymentID = '" + id + "'", con))
                {
                    con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {

                        while (rdr.Read())
                        {

                            oPayment.SID = rdr["SID"].ToString();
                            oPayment.IsManual = Convert.ToBoolean(rdr["IsManual"]);
                            oPayment.CreatedDate = Convert.ToDateTime(rdr["CreatedDate"]);
                            return oPayment;
                        }
                        rdr.Close();

                    }
                }
                con.Dispose();
                con.Close();
                return oPayment;
            }

        }

        public Payment DeleteSID(string paymentid)
        {
            Payment oPayment = new Payment();
            using (SqlConnection con = new SqlConnection(DAO.sDBConn))
            {
                con.Open();
                SqlCommand cmdSql = new SqlCommand();
                string sqlText = "DELETE From TelBug.dbo.MetroPhoneCall where paymentid = '" + paymentid + "'";
                var _with1 = cmdSql;
                _with1.CommandText = sqlText;
                _with1.Connection = con;
                _with1.Parameters.AddWithValue("@PaymentID ", paymentid);
                _with1.ExecuteNonQuery();
                cmdSql.Dispose();
                con.Close();
                return oPayment;
            }

        }
        public Payment UpdateSidIsManual(string SID, bool IsManual)
        {
            int booltint = 0;
            if (IsManual == true)
            {
                booltint = 1;
            }
            Payment oPayment = new Payment();
            using (SqlConnection sqlConnection = new SqlConnection(DAO.sDBConn))
            {
                sqlConnection.Open();
                SqlCommand sqlCommand = new SqlCommand();
                string str = string.Concat("UPDATE Telbug.dbo.MetroPhoneCall SET IsManual = " + booltint + " where SID = '" + SID + "'");
                SqlCommand sqlCommand1 = sqlCommand;
                sqlCommand1.CommandText = str;
                sqlCommand1.Connection = sqlConnection;
                sqlCommand1.Parameters.AddWithValue("@IsManual", booltint);
                sqlCommand1.Parameters.AddWithValue("@CreatedDate", DateTime.Now);
                sqlCommand1.ExecuteNonQuery();
                sqlCommand.Dispose();
                sqlConnection.Close();
            }
            return oPayment;
        }
    }

}
