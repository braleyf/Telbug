﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Security.Cryptography;
using System.Web;
using System.Net;
using System.IO;
using System.Collections;
using System.Net.Mail;
using System.Drawing;
using System.Data;
using MetroFastPayLibrary;

namespace MetroFastPayLibrary
{
    public class DAO
    {


        //public static string sDBConn = "Data Source=.;Initial Catalog=Telbug;Persist Security Info=True;User ID=sa;Password=";
        //public static string sDBConn = "Server=Telbug;Database=Telbug;Trusted_Connection=True;";
       // public static string sDBConn = "Data Source=.\\SQLExpress;Initial Catalog=Telbug;Persist Security Info=True;User ID=test;Password=Test!";
         public static string sDBConn = "Data Source=.;Initial Catalog=Telbug;Persist Security Info=True;User ID=sa;Password=FandF!";



        /// <summary>
        /// Params object for DAO defines name and value for parameters passed into the object
        /// </summary>
        /// <remarks></remarks>
        public class Params
        {
            /// <summary>
            /// The name of the parameter. DO NOT put a @ in front. This will be added.
            /// </summary>
            /// <remarks></remarks>
            public string sParamName;
            /// <summary>
            /// The value of the parameter.
            /// </summary>
            /// <remarks></remarks>

            public string sParamValue;

            public Params()
            {
            }
            /// <summary>
            /// Create a new Param
            /// </summary>
            /// <param name="sParamNameIn">The name of the parameter. DO NOT ADD @.</param>
            /// <param name="sParamValueIn">The value of the parameter</param>
            /// <remarks></remarks>
            public Params(string sParamNameIn, string sParamValueIn)
            {
                sParamName = sParamNameIn;
                sParamValue = sParamValueIn;
            }
        }

        /// <summary>
        /// Initializes the connection.
        /// </summary>
        /// <param name="sDatasourceIn">The data source to use. If this value is blank (default) then regular connection (dbConnection) is used.</param>
        /// <returns>The connection</returns>
        public static SqlConnection CreateConnection(string sDatasourceIn = "")
        {
            SqlConnection conn = default(SqlConnection);
            if (sDatasourceIn.Length == 0)
            {
                conn = new SqlConnection(sDBConn);
            }
            else
            {
                conn = new SqlConnection(sDatasourceIn);
            }
            return conn;
        }

        /// <summary>
        /// Cleans up database objects - command and connection.
        /// </summary>
        /// <param name="cmdIn">The command</param>
        /// <param name="connIn">The connection</param>
        public static void Cleanup(SqlCommand cmdIn, SqlConnection connIn)
        {
            cmdIn.Dispose();
            connIn.Close();
        }

        public static string Encrypt(string InputText, string KeyString)
        {

            MemoryStream memoryStream = null;
            CryptoStream cryptoStream = null;
            try
            {
                using (RijndaelManaged AES = new RijndaelManaged())
                {
                    AES.KeySize = 256;
                    AES.BlockSize = 128;
                    byte[] PlainText = System.Text.Encoding.Unicode.GetBytes(InputText);
                    PasswordDeriveBytes SecretKey = new PasswordDeriveBytes(KeyString, Encoding.ASCII.GetBytes(KeyString.Length.ToString()));
                    using (ICryptoTransform Encryptor = AES.CreateEncryptor(SecretKey.GetBytes(16), SecretKey.GetBytes(16)))
                    {
                        using (memoryStream = new MemoryStream())
                        {
                            using (cryptoStream = new CryptoStream(memoryStream, Encryptor, CryptoStreamMode.Write))
                            {
                                cryptoStream.Write(PlainText, 0, PlainText.Length);
                                cryptoStream.FlushFinalBlock();
                                return Convert.ToBase64String(memoryStream.ToArray());
                            }
                        }
                    }
                }

            }
            catch
            {
                throw;
            }
            finally
            {
                if (memoryStream != null)
                    memoryStream.Close();
                if (cryptoStream != null)
                    cryptoStream.Close();
            }
        }

        public static string Decrypt(string InputText, string KeyString)
        {
            MemoryStream memoryStream = null;
            CryptoStream cryptoStream = null;
            try
            {
                using (RijndaelManaged AES = new RijndaelManaged())
                {
                    AES.KeySize = 256;
                    AES.BlockSize = 128;
                    byte[] EncryptedData = Convert.FromBase64String(InputText);
                    PasswordDeriveBytes SecretKey = new PasswordDeriveBytes(KeyString, Encoding.ASCII.GetBytes(KeyString.Length.ToString()));
                    using (ICryptoTransform Decryptor = AES.CreateDecryptor(SecretKey.GetBytes(16), SecretKey.GetBytes(16)))
                    {
                        using (memoryStream = new MemoryStream(EncryptedData))
                        {
                            using (cryptoStream = new CryptoStream(memoryStream, Decryptor, CryptoStreamMode.Read))
                            {
                                byte[] PlainText = new byte[EncryptedData.Length];
                                return Encoding.Unicode.GetString(PlainText, 0, cryptoStream.Read(PlainText, 0, PlainText.Length));
                            }
                        }
                    }
                }

            }
            catch
            {
                throw;
            }
            finally
            {
                if (memoryStream != null)
                    memoryStream.Close();
                if (cryptoStream != null)
                    cryptoStream.Close();
            }
        }


    }


}
