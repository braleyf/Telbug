﻿using TelBugWebAPI.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Claims;
using System.Threading.Tasks;
using System.Web.Http;
using MetroFastPayLibrary;
using System.Web;
using System.Security.Cryptography;
using System.Text;
using System.Net.Mail;
using TelBugWebAPI.com.dollarphone.www;
using RestSharp;
using System.IO;


using TelBugWebAPI.Controllers;
using Twilio;
using Twilio.Rest.Api.V2010.Account;
using System.IO.Compression;

namespace TelBugWebAPI.Models
{


    [Route("")]
    [Route("api/products/{number}/{amount}/{provider}/{id}/{key}")]
    
    public class ProductsController : ApiController
    {
        User oUser = new User();
        UserDAO oUserDAO = new UserDAO();
        bool withouPin;
        private HttpClient _Client = new HttpClient();
        [Serializable]
        public class CreditCardInfo
        {
           
            public CreditCardInfo(string Cricketcc, string Cricketcardname, string CricketcardExpirationDate, string CricketsecurityCode)
            {
                cardNumber = Cricketcc;
                cardName = Cricketcardname;
                cardExpirationDate = CricketcardExpirationDate;
                if (Cricketcc.StartsWith("5"))
                {
                    cardType = "MC";
                }
                else
                {
                    cardType = "VISA";
                }

                securityCode = CricketsecurityCode;
                paymentMethod = "CREDITCARD";
            }
            public string cardNumber { get; set; }
            public string cardName { get; set; }
            public string cardExpirationDate { get; set; }
            public string cardType { get; set; }
            public string securityCode { get; set; }
            public string paymentMethod { get; set; }
        }

        [Serializable]
        public class Data
        {
            public Data(string Cricketamount, string Cricketpostalcode, long Cricketctn, string Cricketcc, string Cricketcardname, string CricketcardExpirationDate, string CricketsecurityCode)
            {

                secureKey = "a697627915e1176cc642333d1f3b23f328a93ea64f1b8a3a82a7224c94e62f3a";
                amount = Cricketamount;
                postalCode = Cricketpostalcode;
                creditCardInfo = new CreditCardInfo(Cricketcc, Cricketcardname, CricketcardExpirationDate, CricketsecurityCode);
                ctn = Cricketctn;
                appId = "AMSS";

            }

            public string secureKey { get; set; }
            public string amount { get; set; }
            public string postalCode { get; set; }
            public CreditCardInfo creditCardInfo { get; set; }
            public long ctn { get; set; }
            public string appId { get; set; }
        }


        [Serializable]
        public class CreditCardInfoBoost
        {

            public CreditCardInfoBoost(string Boostcc, string Boostcardname, string BoostcardExpirationDate, string BoostsecurityCode)
            {
                adhoc = new adhoc(Boostcc, Boostcardname, BoostcardExpirationDate, BoostsecurityCode);
            }

            public adhoc adhoc { get; set; }

        }
        [Serializable]
        public class adhoc
        {

            public adhoc(string Boostcc, string Boostcardname, string BoostcardExpirationDate, string BoostsecurityCode)
            {
                cardNumber = Boostcc;
                expirationDate = BoostcardExpirationDate;
                cvv = BoostsecurityCode;
                name = Boostcardname;
                address = new BoostAddress();
                if (Boostcc.StartsWith("5"))
                {
                    cardBrand = "MASTERCARD";
                }
                else
                {
                    cardBrand = "VISA";
                }
                cardType = "CREDIT";

            }
            public string cardNumber { get; set; }
            public string expirationDate { get; set; }
            public string cvv { get; set; }
            public string name { get; set; }
            public BoostAddress address { get; set; }
            public string cardBrand { get; set; }

            public string cardType { get; set; }



        }

        [Serializable]
        public class BoostAddress
        {


            public BoostAddress()
            {
                addressLine1 = "5047 Summit Blvd";
                addressLine2 = "";
                city = "West Palm Beach";
                state = "FL";
                zipCode = "33415";
                setAsMailingAddress = false;
            }

            public string addressLine1 { get; set; }
            public string addressLine2 { get; set; }
            public string city { get; set; }
            public string state { get; set; }
            public string zipCode { get; set; }
            public bool setAsMailingAddress { get; set; }

        }


        [Serializable]
        public class BoostautoPay
        {

            public BoostautoPay()
            {
                useForAutoPay = false;
            }

            public bool useForAutoPay { get; set; }


        }
        [Serializable]
        public class BoostDataGift
        {

            public BoostDataGift(double Boostamount, string Boostpostalcode, string Boostmnm, string Boostcc, string Boostcardname, string BoostcardExpirationDate, string BoostsecurityCode)
            {

                idField = "mdn";
                creditCard = new CreditCardInfoBoost(Boostcc, Boostcardname, BoostcardExpirationDate, BoostsecurityCode);
                amount = Convert.ToDouble(Boostamount);
                isAuthenticated = true;
                totalAmount = Convert.ToDouble(string.Format("{0:0.00}", Boostamount));
                registerCardUsedForPayment = false;
                autoPay = new BoostautoPay();
            }

            public string idField { get; set; }
            public CreditCardInfoBoost creditCard { get; set; }
            public double amount { get; set; }
            public bool isAuthenticated { get; set; }
            public double totalAmount { get; set; }
            public bool registerCardUsedForPayment { get; set; }
            public BoostautoPay autoPay { get; set; }

        }
        [Serializable]
        public class BoostData
        {

            public BoostData(double Boostamount, string Boostpostalcode, string Boostmnm, string Boostcc, string Boostcardname, string BoostcardExpirationDate, string BoostsecurityCode, string taxid)
            {

                idField = "mdn";
                creditCard = new CreditCardInfoBoost(Boostcc, Boostcardname, BoostcardExpirationDate, BoostsecurityCode);
                amount = Convert.ToDouble(Boostamount);
                isAuthenticated = true;
                //taxAmount = 0.00;
                totalAmount = Boostamount + .00;
                taxTxnId = taxid;
                registerCardUsedForPayment = false;
                autoPay = new BoostautoPay();
            }

            public string idField { get; set; }
            public CreditCardInfoBoost creditCard { get; set; }
            public double amount { get; set; }
            public bool isAuthenticated { get; set; }
            public double taxAmount { get; set; }
            public double totalAmount { get; set; }
            public string taxTxnId { get; set; }
            public bool registerCardUsedForPayment { get; set; }
            public BoostautoPay autoPay { get; set; }

        }
        [Serializable]
        public class getBoostLoginToken
        {

            public getBoostLoginToken(string number, string thepin)
            {

                mdn = number;
                pin = thepin;
                scope = "login_auth";

            }

            public string mdn { get; set; }
            public string pin { get; set; }
            public string scope { get; set; }

        }


        [Serializable]
        public class RetievePin
        {

            public RetievePin()
            {

                idField = "mdn";

            }

            public string idField { get; set; }
            public string pin { get; set; }
            public string scope { get; set; }

        }

        private int getUserbyID(int id)
        {
            using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString()))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                cmd.CommandText = @"select COUNT(*) from Users where ID = '" + id + "' and Active = 1";
                int tnumber = Convert.ToInt32(cmd.ExecuteScalar());
                return tnumber;
            }
        }

        private string getUserNamebyID(int id)
        {
            using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString()))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                cmd.CommandText = @"select UserID from Users where ID = '" + id + "' and Active = 1";

                if (cmd.ExecuteScalar() == null)
                {
                    return ("Error: Access denied");
                }
                string name = cmd.ExecuteScalar().ToString();
                return name;
            }
        }
        private string getPostbyID(int id)
        {
            using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString()))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                cmd.CommandText = @"select post from Users where ID = '" + id + "' and Active = 1";
                string name = cmd.ExecuteScalar().ToString();
                return name;
            }
        }
        private string getkey(int id)
        {
            using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString()))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                cmd.CommandText = @"select Password from Users where ID = '" + id + "' and Active = 1";
                string key = cmd.ExecuteScalar().ToString();
                return key;
            }
        }
        [AcceptVerbs("GET", "POST")]
        [HttpPost]
        public async Task<string> GetProduct(long number, string amount, int provider, string id, string key)
        {
            try
            {


                User metro = oUserDAO.RetrieveServiceActivity(1);
                User cricket = oUserDAO.RetrieveServiceActivity(2);
                User Boost = oUserDAO.RetrieveServiceActivity(3);

                if (id.Contains("-"))
                {
                    id = id.Replace("-", "/");
                }
                if (id.Contains("plus"))
                {
                    id = id.Replace("plus", "+");
                }
               
                string therealid = DAO.Decrypt(id, ConfigurationManager.AppSettings["encryptionKey"]);
                int intid = Convert.ToInt32(therealid);
                string userid = getUserNamebyID(intid);

                User oUserIn = new User();
                oUserIn = oUserDAO.RetrieveUserByUserID(userid);

                if (oUserIn.Active == false)
                {
                    return ("Error: We are currently unable to process payments at this time");
                }


                string keyin = getkey(intid);
                int Loggedin = getUserbyID(intid);



                //if (therealid == "363" || therealid == "362")
                //{
                //    if (GetIPAddress() != "216.48.176.5" || GetIPAddress() != "172.16.1.5")
                //    {
                //        return ("Error: Access denied from this IP address");
                //    }
                //}

                HttpContext.Current.Session["ErrorBeforeError"] = "Check Point 1";
                if (key.Contains("-"))
                {
                    key = key.Replace("-", "/");
                }
                if (key.Contains("plus"))
                {
                    key = key.Replace("plus", "+");
                }
                string pin = "";
                if (provider.ToString().Contains("-"))
                {
                    string thenum = number.ToString();
                    pin = thenum.Remove(2);
                }
                HttpContext.Current.Session["ErrorBeforeError"] = "Check Point 2";
                if (Loggedin == 1 && keyin == key)
                {
                    HttpContext.Current.Session["ErrorBeforeError"] = "Check Point 4";
                    CC oCC = new CC();
                    oCC = oUserDAO.RetrieveCC();
                    CC oCC2 = new CC();
                    oCC2 = oUserDAO.RetrieveCC2();
                    CC oCC3 = new CC();
                    oCC3 = oUserDAO.RetrieveCC3();

                    string thecc = "";
                    string thecvv = "";
                    string expDate = "";
                    string ZIP = "";
                    //string cardBrand = "";

                    string user = getUserNamebyID(intid);
                    HttpContext.Current.Session["userid"] = user;
                    HttpContext.Current.Session["ErrorBeforeError"] = "Check Point 4";
                    MetroFastPayLibrary.Account oAccount = new MetroFastPayLibrary.Account();
                    oAccount = oUserDAO.RetrieveAccount(user);

                    User oFee = new User();
                    oFee = oUserDAO.RetrieveFeebyUserID(user);
                    HttpContext.Current.Session["ErrorBeforeError"] = "Check Point 5";
                    int doublepay = getPreviousPayment(number.ToString());
                    if (oAccount.Active == true)
                    {
                        decimal total = oAccount.Credit - (Convert.ToInt32(amount) + (Convert.ToInt32(oFee.Fee) - 2));
                        if (total <= 0)
                        {
                            return ("Error: Not enough credit to make payment");
                        }
                    }
                    if (Convert.ToDouble(amount) < 5 && provider != 4)
                    {
                        return ("Error: Amount has to be greater than $5.00");
                    }
                    if (Convert.ToDouble(amount) < 1 && provider == 4)
                    {
                        return ("Error: Amount has to be greater than $1.00");
                    }
                    if (Convert.ToDouble(amount) > 200)
                    {
                        return ("Error: Amount has to be less than $200.00");
                    }
                    int doublepaypayment = getPreviousPaidPayment(number.ToString());
                    int prevAmountPaid = getPreviousPaymentAmount(number.ToString());
                    HttpContext.Current.Session["ErrorBeforeError"] = "Check Point 6";
                    //allow http request to go through with no issues
                    System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12 | SecurityProtocolType.Ssl3;

                    HttpContext.Current.Session["ErrorBeforeError"] = "Check Point 7";
                    if (provider == 1)
                    {
                        HttpContext.Current.Session["ErrorBeforeError"] = "Check Point 8";
                        if (metro.Active == false)
                        {
                            return ("Error: Metro by T-Mobile is under maintenance, please try back in an hour");
                        }

                        HttpContext.Current.Session["Provider"] = "MetroPCS";

                        if (number.ToString().Length > 10)
                        {
                            return ("Error: Phone number has to be 10 digits");
                        }
                        if (doublepaypayment >= 1 && prevAmountPaid.ToString() == amount)
                        {
                            return ("Error: This number has already been paid today in the amount of $" + amount);
                        }

                        HttpContext.Current.Session["ErrorBeforeError"] = "Check Point 9";
                        //var client = new RestClient("https://www.metropcs.com/apps/mpcs/servlet/genericservlet?inputReqParam={'serviceName':'profileManagementService','serviceProviderName':'applicationSpecific','requestParams':{'phoneNumber':'" + number + "'},'componentId':'getLimitedCustomerInfo','applicationId':'metropcs','siteId':'metropcs'}");
                        //var request = new RestRequest(Method.POST);
                        //request.AddHeader("postman-token", "a744fec0-2c03-8c52-33ac-875b59827bec");
                        //request.AddHeader("cache-control", "no-cache");
                        //request.AddHeader("referer", "https://www.metropcs.com/bill-pay.html");
                        //request.AddHeader("content-type", "application/x-www-form-urlencoded");
                        //request.AddParameter("multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW", "------WebKitFormBoundary7MA4YWxkTrZu0gW\r\nContent-Disposition: form-data; name=\"inputReqParam\"\r\n\r\n{\"serviceName\":\"profileManagementService\",\"serviceProviderName\":\"applicationSpecific\",\"requestParams\":{\"phoneNumber\":\"5612012168\"},\"componentId\":\"getLimitedCustomerInfo\",\"applicationId\":\"metropcs\",\"siteId\":\"metropcs\"}\r\n------WebKitFormBoundary7MA4YWxkTrZu0gW--", ParameterType.RequestBody);
                        //IRestResponse response = client.Execute(request);

                        //MetroFastPayLibrary.MetroPCSSecurity oMetroPCSSecurity = new MetroFastPayLibrary.MetroPCSSecurity();
                        //oMetroPCSSecurity = oUserDAO.GetAllX49exvsbl();

                        //var client = new RestClient("https://www.metrobyt-mobile.com/api/v1/billing/payment/validate-mdn");
                        //var request = new RestRequest(Method.POST);
                        //request.AddHeader("postman-token", "37ac1819-7324-0c2f-aee2-23e414fded1a");
                        //request.AddHeader("cache-control", "no-cache");
                        //request.AddHeader("mdn", number.ToString());
                        //request.AddHeader("x-7xh4mcgiye-a", oMetroPCSSecurity.a);// "ANuFt8xTVlHz1WjqgwDIaSO-Eqo-kHh5-wA-vHBf9mQ5Dvtw3dt-kwoMi8wwAEoMAUYNgHnqamSM_qHxolEJYEDwIJdnasa4LO9MmTuwhGkcVVx5oSJA88iM_USJ8lGcEPRZ-pz=A=aMwznJL8iFTqcwYlv=kwF=k29q2GdzIbjwtmouo8xWgoHxg8xZtNxXANoJ5S8ktVxy3qxO-2rZnxkkLo-egoTquGWZ_VoQAXXMwxjQYk9--bYwhvH6iqu5wlKJTUdywJG5Y24rkf-1AvjWlMLWl7X=_EjqAYor1SSMgsxZakQyYbEMkEowjBwGuNxBwjLHfNDQABjqg26_EChxa5f-pmSqzCLWycMwwUi=hBDHklrTA2LGDg1qaMiGgHL_k2Gy39aPuY4feJdWa8ix3bLFYTx-A23fINHcTqkygHLZk4qquNHv3=J6jztQkEYxwYjJQBiGYEx=hGhfN2GWi4t-54xqgwHGumwI_YH8tVxbwwKMwEUJ-cOJkswfabiwuRLmtVfZ_8sJulvxk2KMn2zfv46v_ChNaMiwhhxqawDoksj8EqnWxwYwk2L=3BuEwxx5sOHXrsM5AgowpzsM3WhfSgD=pYxxRS9quzxxv2EfNBjGAHQ5A=Oq3JkM-9QFAkBMIHi9-2gIuzL5wYxaAc9w_c9kksDfilQ=3MMm-3Qy_Mwh8BOQVsYx3QQH-oxTET2JioL9hBLFioHymvxq-9Q6uOD=Evbp-zxbVz4MGEoqAFxug8wM_cQUuldtjq_Yh8xFis9wLoTq-Nxy9ZkFaC=fAYD4Tax5EgHFhPtvuU4=zJBMnvoMuLDWm3Q-uWLznNfrx2OJao_m-sEE-xxWTfw4aULanYFv3NsMAU1=uVHqxUdFuTw2LBDO_mr6AbeJh8sMwMowgwyJSvnFkHOQgw9CnhsfuVsqECdb3CEGV2QEhCHt_Yxapsx5mbYvATxfalHFga-w_j9-TXyZgsHqf5xWmlrsk8xNaKGNo8xxILdWnVDZ32j6-otMlsLQ88xyulLGaTxO-2H539nFwWwhiHO_-sx6_VoQawH5GM4M_oYYzgH=gfWWvlc-i2z5-WhwulB--8xywxGyh9OMkq3fEgT2Vcax3CLfjCrvLlSfaHYvm2M4uldPTzvo_kHW3vIo=VDtwV48AGd5A5x=hPZwf2r-kmwwEBEMYpM-_mWXumx=v8o-Tw4xtlLH1=9Qac9ln4w1hdkqg22Mg9aMugoM-mSJ3-LX-fxWucMZa24OnCzNElEQLqDHhCdXpBDJ3M1li2nX-2-x3gwtifr53Udag2KMupivg26fVuX2A=nwhv4fnH3wcpDzkwx=ECL53Xkw3fwMe8xNAC45VlLIisXGa29MuIyw3=nG-sbQdXZsjCvM_EjvT4DrvU1s5onQAzcJFGT=-uuq_l3=uoTMeEGUa2Housi9go_p-4dXa8oJfwIBYNyOTsT4LBUrLBx5aUGUAVx6R=axg21FaVD55Y4xh2Zfs8ixL3iMHHi1AhDWLCXyL4s--EjmTMTMLXivu3cM341WuTD=ubTHg8fwgaHQ53yXeL9rw=a5YFDxAlKfw=OqbgHEpdiv_LcQuM4MYYKMwHSQlwOw-ELIuVxQnNx_psQFTHMj3=Q8pVwvwvyH1bT-hCn=YLbJ_jz1mcaYavR7i2zog2FE-woMYEOq_LxHulDEwLhw5T_vhgxcaN45umX5_EjW_X4o4UFvAbjZisaIjcd6-9Q5wVxc31LaEqtMuEeWkcnqisTM-3xF5VxEElF1g2GWkmwq-MXlYVo-L5xD-fwIuYBzEqWXwCFfwTEqwEY4e24I_GSwi8xaV4HHpCuQYEb-xaDWAo9hq1aMw2HxhvsMEgf2jEDWEGTMLCdW-oxQk8_vxbQ6hFkvw2dqTvw1Tzu=E5xZAUawa4x6k2TouX9--wHeg9avkLkNu3o-ox=Jk4IM-N9fYUKJ=VwVw8oM1S9MkwWQ42dcwoxZhgw-goxQvsT--2c-Eqwxpzxyj8edtCLIT82J3MsM1Uv8Lmxx_VxZxo4=ezvMhCHX_YDZhvx=tX1c_VDN3otwYSOe-8o-hSAqAziCuTZ4a8tJ_gwxYTxZkoOMwHny3vsJuEjNkfWQAwHxabjH-2WN_66WhvH=voHsrJKz-R3w-4sMtB9Mx29qAC46k2s-gnQGw4i5wqjsAELFw2LxvHjtL5WyuXwMtsnWLaEqLBLWg2Kqvow=-UzMwejFuMdXuI_4pc9Qa9Qyuc1ypc9Mg2mOBEnTifxruTDZg21quVxqg99jY3L6T2HkAF1Rgexoi9QNz9Mf3Uj53JoKECEYSCWwVOoJ-sMGuCbqV2ru_W_MwT8dll4yklQZi2A-_YDEhqivYoDC-fK-i2rru24vagxLk9nFksYwtNDpl9nF5l-Hwbiqoio-YZxfi4EgLsJQhCrawltQaWdsLSnF3=a=-2WIw3jY7mKQtNi=k49MLcoM_goHnZiCjHd1-2ED79MvaNDc-lSMkfx6T5xxYL3qJM9M-2swu5-d88tChFnb_JoMvlLv_mxF_UbowMa=3=AMumBMfgxs4sWEwUHzw2LH-mwwASMMesLFe4dFT4Ws-axzzv4w3wbMa2uZz9QN-aoQrXXtELG5AFiM-9QUasTeVonFu3x9a9nNukjWhCrEaOkUuTsraaQ5hgtJ3Zi4-EY3_1AujBe7uExzuYxr-9x53JwwAFjcaLk5EVw5glnJh5oYu8xvv2LQvXLDV2CJl2dxtCFi-2QXm=MxaC-4fL9MpYH=LGhfAhOMEFtqV8Hya2vzEIxEalssisoMhCtwi4LWuoxY1F6Gyv4Mi2KqjF4Shhrwk2QWostMvfdcobmZfoDeEPxWLBn=nl4ohBoqIM453OHyjmoqfNxVAJwj3Jx5u6QykwHSkooMTwINhFfJinyctvi4ulOd_mwf-mrZulLiuZjOFB_xu8xF29_4_Snz8FVJhCPzYHD_Egoq-a4f-4DUANwFgwjWIMIGkOoSuEiwIJG-hSMN-wfJA2tqdWSqDJxXtF6Qks9wuExW1WX_hFoMwNxWhvxrAOkywlzMPNA-_YnX5c9M-VyRgHFqk=nf-8DQlfxN2THsAJdz-HLFuYHNhqxq5HaMhBT-hSOMifoOLrHrAgx6jcash9vBu2DHkLdrv2LLxatqk8sM-Hb2_lLXLsjTisLc4TYM-4wM-4oqlbEqAC_MtXLJaXGE-lbMaLSQ=bYy3MHCL8wf-VxWuYTVylOMYYHL_VDUuYsMiffKk4QO-oxNesi=wwDHhBtqjz1tAFrHYCH=A28UhCnW-wT-ogHxpWd8v4vFY2YThhbJ3NfMpWdynCntwFLW3992-ax8EBoMVmQG_Vic-w6WV2dWjHdqezXMa4vMa84VnCKzaYa5_MQi_TsM_YxQg2uqkbi51lWQ4LhxhvHEx=9QTfWZTgxqtq_M_CSMv9nHhB9QvsY6nfGckHdX-fwB-akW-lzouliM-9nahqAv_5dQnNxL-2jsAbDaKTwu4oiMLG31VmM=w4zye=Qv-w9iACWtAEz4_JhfoYDseoDpn8w5kOixA2abmCKqhGSOgopJhBYqnMHF_TQQgw4syYTwhSwMA=M7SWtMi8wMh1QBtBtMsz=MTbpJAhA-pYHHgfJJiHhMi2L83OiFAOLF-2LO3UjQ-TH53sx-fULo-lLzuoxzhhNTwUEwaHax-9azpV4MhFEMaqxlASQx3MG7jJxvulE-_vH=lNspLCh=qsiMklsQkHSMaoaxaGE-_TuZa8iYVww583DclCv5ksXjwCSR-2rtgf-xawdNxsjXuYzw3NoMwM4vhFc-Yc9qj5bwwZiIAqIxVEcMvaoQ_z2RTgDGY2MfLsz45mdxkYjbkf3vkldHYmMvM8oM3qtM_Fu52CWZhvjQjVwRvULv_=avaCXqh5oM_OtMxmwfoMayESnWpgxJTSnWjmxqofOJuEz=VYxLvNwq_Us-1voQ5BtxnzHQp2rC3Wja_c9yemKst2KqA4E-AC9q9WyHTCKwAbDc1UKqLCr8-2hxvbtX-8w9Ehwi2fxyESaMSCq-vwQ7YVoMEZxQTsDNYlbx-cMM-cQ_-2EwuLhvEq_vwwHv-C-MuzLFumolEq6LaXHW_mfJ4vs-i9nXLfw1ECLs-sDwi2Wsust-hgxFtvWbAbDwi2XwDVxFhvwe3BWZ36iveWzFjEDO3Zx5ECzvYGnwEhyEuTsQ-oQH3WWaYULP_UhfV4HQpB8JuUzM-2hx3UiMgT8ICMDpLgwM_lz5azE-uYjOYHDvplWX3CLQ3MjFHmoqkw1pYcnya2_M_TDvtGSqeljFzF19mwwwu2uGzFLZ_Bjx-Hd5AvDFTYoZA9QF_Czf-8D6ieDaLo8K_S9qg26=k2Wsg2XYAgoM_2iP-wolaLk-3go-jVsQfC9MwmMqEPD=LLumACrcT9a=tBDVh5-M-eQcwGdmtULvwzE-YL-viwxyklgW-24MiawwECdUh8o-mgxFIX1WnbTwaSawhF65-B9qzqxWEvwMTOxWhPD=dOfOhUtwaVw5vO4=-2tQVTnWq=axl2BQEhbxnSM4wotQ_lLFA4kFARDBfgtqifomuzDFmYsUV46WA4afi29HustqaUEMk9ax3CB-plTw3U6tEEjXfNxm3X6Zn9IBEbtfgVHbhv4oy2SvjVxcbFcutVxwESSMnS9f-QKf");
                        //request.AddHeader("x-7xh4mcgiye-b", oMetroPCSSecurity.b);// -vua40
                        //request.AddHeader("x-7xh4mcgiye-c", oMetroPCSSecurity.c);// "A1H9CpNpAQAAwgoDTjdI-YLmksG1yqG39moTIEiq5M-XO1lUYHZbBzQarQNMAawUMfHhpsaNwH_zwTJd7LutHQ==");
                        //request.AddHeader("x-7xh4mcgiye-d", oMetroPCSSecurity.d);// "0");
                        //request.AddHeader("x-7xh4mcgiye-f", oMetroPCSSecurity.f);// "0");
                        //request.AddHeader("x-7xh4mcgiye-z", oMetroPCSSecurity.z);// "0");
                        //IRestResponse response = client.Execute(request);

                        //string my = response.Content;
                        //HttpContext.Current.Session["ErrorBeforeError"] = "Check Point 10";
                        //if (my.Length > 0)
                        //{
                        //    //do nothing
                        //}
                        //else
                        //{
                        //   // TextAndEmail("Telbug Error", "Change MetroPCS Security", true);

                        //    oMetroPCSSecurity = oUserDAO.RetrieveMSbyA();

                        //    if (oMetroPCSSecurity.b != null)
                        //    {
                        //        oUserDAO.DeleteMS(oMetroPCSSecurity.b);
                        //        OldTextAndEmail("Telbug Error", "MetroPCS security had been changed", true);
                        //        HttpContext.Current.Session["ErrorBeforeError"] = "Metro Security needs to be changed";
                        //    }
                        //    else
                        //    {
                        //        OldTextAndEmail("Telbug Error", "Change MetroPCS Security", true);
                        //        HttpContext.Current.Session["ErrorBeforeError"] = "Metro Security needs to be changed";
                        //    }
                        //}

                        //if (my.Contains("Transaction failed"))
                        //{
                        //    return ("Error: Not a MetroPCS number");
                        //}
                        //else
                        //{
                            if (doublepay == 3)
                            {
                                return ("Error: Number has been paid too many times");
                            }
                            string metrocc = "";
                            if (oCC.Used != null)
                            {
                                string cc = oCC.CCNumber;
                                HttpContext.Current.Session["cc"] = cc;
                                thecc = DAO.Decrypt(oCC.CCNumber, ConfigurationManager.AppSettings["encryptionKey"]).Trim();
                                thecvv = oCC.CVV.Trim();
                                expDate = oCC.ExpDate;
                                ZIP = oCC.ZIP;
                                metrocc = oCC.Address;
                            }
                            else if (oCC2.Used != null)
                            {
                                string cc = oCC2.CCNumber;
                                HttpContext.Current.Session["cc"] = cc;
                                thecc = DAO.Decrypt(oCC2.CCNumber, ConfigurationManager.AppSettings["encryptionKey"]).Trim();
                                thecvv = oCC2.CVV.Trim();
                                expDate = oCC2.ExpDate;
                                ZIP = oCC2.ZIP;
                                metrocc = oCC2.Address;

                            }
                            else if (oCC3.Used != null)
                            {
                                string cc = oCC3.CCNumber;
                                HttpContext.Current.Session["cc"] = cc;
                                thecc = DAO.Decrypt(oCC3.CCNumber, ConfigurationManager.AppSettings["encryptionKey"]).Trim();
                                thecvv = oCC3.CVV.Trim();
                                expDate = oCC3.ExpDate;
                                ZIP = oCC3.ZIP;
                                metrocc = oCC3.Address;
                            }

                            if (oCC3.Used == null && oCC2.Used == null && oCC.Used == null)
                            {
                                //text
                                TextAndEmail("Telbug Error", "no cards in the system for MetroPCS, switched to manual payments", true);
                                //Turn manual payments on
                                // oUserDAO.UpdateServiceActivity(1, false);

                                return ManualPayment(HttpContext.Current.Session["userid"].ToString(), "MetroPCS", number.ToString(), amount);
                            }
                            HttpContext.Current.Session["ErrorBeforeError"] = "Check Point 11";
                        //phone payment
                        await ManualMetroCall(user, "MetroPCS", number.ToString(), amount, thecc, expDate, thecvv, key, id);
                        return "Success:{Confirmationid : " + HttpContext.Current.Session["conf"].ToString() + "}";

                        //var client2 = new RestClient("https://www.metrobyt-mobile.com/apps/mpcs/servlet/paymentservlet?inputReqParam={'serviceName':'paymentManagementService','serviceProviderName':'applicationSpecific','expectedParams':{},'backupPaymentMode':'false','requestParams':{'authorizePaymentParams':{'mdn':'" + number + "','FirstName':'" + GenerateName(5) + "','LastName':'" + GenerateName(6) + "','CardNumber':'" + thecc + "','ExpirationDate':'" + expDate + "','ZipCode':'" + ZIP + "','clientId':'TMOBILE','CardVerificationCode':'" + thecvv + "','confirmationEmailAddress':'9874559@gmail.com','ServicePaymentAmountSG':'" + amount + "','isDebitPreferred':'true','cardType':'VISA'},'mdn':'" + number + "','subId':''},'componentId':'authorizePaymentAndSaveContact','applicationId':'metropcs','siteId':'metropcs'}");
                        //var request2 = new RestRequest(Method.POST);
                        //request2.AddHeader("postman-token", "a744fec0-2c03-8c52-33ac-875b59827bec");
                        //request2.AddHeader("cache-control", "no-cache");
                        //request2.AddHeader("origin", "https://www.metropcs.com");
                        //request2.AddHeader("referer", "https://www.metropcs.com/bill-pay.html");
                        //request2.AddHeader("content-type", "multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW");
                        //request2.AddParameter("multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW", "------WebKitFormBoundary7MA4YWxkTrZu0gW\r\nContent-Disposition: form-data; name=\"inputReqParam\"\r\n\r\n{\"serviceName\":\"profileManagementService\",\"serviceProviderName\":\"applicationSpecific\",\"requestParams\":{\"phoneNumber\":\"5612012168\"},\"componentId\":\"getLimitedCustomerInfo\",\"applicationId\":\"metropcs\",\"siteId\":\"metropcs\"}\r\n------WebKitFormBoundary7MA4YWxkTrZu0gW--", ParameterType.RequestBody);
                        //IRestResponse response2 = client2.Execute(request2);
                        //DateTime it = Convert.ToDateTime(expDate);
                        //string theDate = it.ToString("MM/yyyy");

                        //oMetroPCSSecurity = oUserDAO.GetAllX49exvsbl();

                        //decimal theamount = decimal.Parse(amount);
                        //string amountWithZero = theamount.ToString("0.00");
                        //var client2 = new RestClient("https://www.metrobyt-mobile.com/api/v1/billing/payment/authorize-anonymous");
                        //var request2 = new RestRequest(Method.POST);
                        //request2.AddHeader("postman-token", "ae4642d5-ee98-1be4-c367-dde748187d21");
                        //request2.AddHeader("cache-control", "no-cache");
                        //request2.AddHeader("x-7xh4mcgiye-a", oMetroPCSSecurity.a);// "ANuFt8xTVlHz1WjqgwDIaSO-Eqo-kHh5-wA-vHBf9mQ5Dvtw3dt-kwoMi8wwAEoMAUYNgHnqamSM_qHxolEJYEDwIJdnasa4LO9MmTuwhGkcVVx5oSJA88iM_USJ8lGcEPRZ-pz=A=aMwznJL8iFTqcwYlv=kwF=k29q2GdzIbjwtmouo8xWgoHxg8xZtNxXANoJ5S8ktVxy3qxO-2rZnxkkLo-egoTquGWZ_VoQAXXMwxjQYk9--bYwhvH6iqu5wlKJTUdywJG5Y24rkf-1AvjWlMLWl7X=_EjqAYor1SSMgsxZakQyYbEMkEowjBwGuNxBwjLHfNDQABjqg26_EChxa5f-pmSqzCLWycMwwUi=hBDHklrTA2LGDg1qaMiGgHL_k2Gy39aPuY4feJdWa8ix3bLFYTx-A23fINHcTqkygHLZk4qquNHv3=J6jztQkEYxwYjJQBiGYEx=hGhfN2GWi4t-54xqgwHGumwI_YH8tVxbwwKMwEUJ-cOJkswfabiwuRLmtVfZ_8sJulvxk2KMn2zfv46v_ChNaMiwhhxqawDoksj8EqnWxwYwk2L=3BuEwxx5sOHXrsM5AgowpzsM3WhfSgD=pYxxRS9quzxxv2EfNBjGAHQ5A=Oq3JkM-9QFAkBMIHi9-2gIuzL5wYxaAc9w_c9kksDfilQ=3MMm-3Qy_Mwh8BOQVsYx3QQH-oxTET2JioL9hBLFioHymvxq-9Q6uOD=Evbp-zxbVz4MGEoqAFxug8wM_cQUuldtjq_Yh8xFis9wLoTq-Nxy9ZkFaC=fAYD4Tax5EgHFhPtvuU4=zJBMnvoMuLDWm3Q-uWLznNfrx2OJao_m-sEE-xxWTfw4aULanYFv3NsMAU1=uVHqxUdFuTw2LBDO_mr6AbeJh8sMwMowgwyJSvnFkHOQgw9CnhsfuVsqECdb3CEGV2QEhCHt_Yxapsx5mbYvATxfalHFga-w_j9-TXyZgsHqf5xWmlrsk8xNaKGNo8xxILdWnVDZ32j6-otMlsLQ88xyulLGaTxO-2H539nFwWwhiHO_-sx6_VoQawH5GM4M_oYYzgH=gfWWvlc-i2z5-WhwulB--8xywxGyh9OMkq3fEgT2Vcax3CLfjCrvLlSfaHYvm2M4uldPTzvo_kHW3vIo=VDtwV48AGd5A5x=hPZwf2r-kmwwEBEMYpM-_mWXumx=v8o-Tw4xtlLH1=9Qac9ln4w1hdkqg22Mg9aMugoM-mSJ3-LX-fxWucMZa24OnCzNElEQLqDHhCdXpBDJ3M1li2nX-2-x3gwtifr53Udag2KMupivg26fVuX2A=nwhv4fnH3wcpDzkwx=ECL53Xkw3fwMe8xNAC45VlLIisXGa29MuIyw3=nG-sbQdXZsjCvM_EjvT4DrvU1s5onQAzcJFGT=-uuq_l3=uoTMeEGUa2Housi9go_p-4dXa8oJfwIBYNyOTsT4LBUrLBx5aUGUAVx6R=axg21FaVD55Y4xh2Zfs8ixL3iMHHi1AhDWLCXyL4s--EjmTMTMLXivu3cM341WuTD=ubTHg8fwgaHQ53yXeL9rw=a5YFDxAlKfw=OqbgHEpdiv_LcQuM4MYYKMwHSQlwOw-ELIuVxQnNx_psQFTHMj3=Q8pVwvwvyH1bT-hCn=YLbJ_jz1mcaYavR7i2zog2FE-woMYEOq_LxHulDEwLhw5T_vhgxcaN45umX5_EjW_X4o4UFvAbjZisaIjcd6-9Q5wVxc31LaEqtMuEeWkcnqisTM-3xF5VxEElF1g2GWkmwq-MXlYVo-L5xD-fwIuYBzEqWXwCFfwTEqwEY4e24I_GSwi8xaV4HHpCuQYEb-xaDWAo9hq1aMw2HxhvsMEgf2jEDWEGTMLCdW-oxQk8_vxbQ6hFkvw2dqTvw1Tzu=E5xZAUawa4x6k2TouX9--wHeg9avkLkNu3o-ox=Jk4IM-N9fYUKJ=VwVw8oM1S9MkwWQ42dcwoxZhgw-goxQvsT--2c-Eqwxpzxyj8edtCLIT82J3MsM1Uv8Lmxx_VxZxo4=ezvMhCHX_YDZhvx=tX1c_VDN3otwYSOe-8o-hSAqAziCuTZ4a8tJ_gwxYTxZkoOMwHny3vsJuEjNkfWQAwHxabjH-2WN_66WhvH=voHsrJKz-R3w-4sMtB9Mx29qAC46k2s-gnQGw4i5wqjsAELFw2LxvHjtL5WyuXwMtsnWLaEqLBLWg2Kqvow=-UzMwejFuMdXuI_4pc9Qa9Qyuc1ypc9Mg2mOBEnTifxruTDZg21quVxqg99jY3L6T2HkAF1Rgexoi9QNz9Mf3Uj53JoKECEYSCWwVOoJ-sMGuCbqV2ru_W_MwT8dll4yklQZi2A-_YDEhqivYoDC-fK-i2rru24vagxLk9nFksYwtNDpl9nF5l-Hwbiqoio-YZxfi4EgLsJQhCrawltQaWdsLSnF3=a=-2WIw3jY7mKQtNi=k49MLcoM_goHnZiCjHd1-2ED79MvaNDc-lSMkfx6T5xxYL3qJM9M-2swu5-d88tChFnb_JoMvlLv_mxF_UbowMa=3=AMumBMfgxs4sWEwUHzw2LH-mwwASMMesLFe4dFT4Ws-axzzv4w3wbMa2uZz9QN-aoQrXXtELG5AFiM-9QUasTeVonFu3x9a9nNukjWhCrEaOkUuTsraaQ5hgtJ3Zi4-EY3_1AujBe7uExzuYxr-9x53JwwAFjcaLk5EVw5glnJh5oYu8xvv2LQvXLDV2CJl2dxtCFi-2QXm=MxaC-4fL9MpYH=LGhfAhOMEFtqV8Hya2vzEIxEalssisoMhCtwi4LWuoxY1F6Gyv4Mi2KqjF4Shhrwk2QWostMvfdcobmZfoDeEPxWLBn=nl4ohBoqIM453OHyjmoqfNxVAJwj3Jx5u6QykwHSkooMTwINhFfJinyctvi4ulOd_mwf-mrZulLiuZjOFB_xu8xF29_4_Snz8FVJhCPzYHD_Egoq-a4f-4DUANwFgwjWIMIGkOoSuEiwIJG-hSMN-wfJA2tqdWSqDJxXtF6Qks9wuExW1WX_hFoMwNxWhvxrAOkywlzMPNA-_YnX5c9M-VyRgHFqk=nf-8DQlfxN2THsAJdz-HLFuYHNhqxq5HaMhBT-hSOMifoOLrHrAgx6jcash9vBu2DHkLdrv2LLxatqk8sM-Hb2_lLXLsjTisLc4TYM-4wM-4oqlbEqAC_MtXLJaXGE-lbMaLSQ=bYy3MHCL8wf-VxWuYTVylOMYYHL_VDUuYsMiffKk4QO-oxNesi=wwDHhBtqjz1tAFrHYCH=A28UhCnW-wT-ogHxpWd8v4vFY2YThhbJ3NfMpWdynCntwFLW3992-ax8EBoMVmQG_Vic-w6WV2dWjHdqezXMa4vMa84VnCKzaYa5_MQi_TsM_YxQg2uqkbi51lWQ4LhxhvHEx=9QTfWZTgxqtq_M_CSMv9nHhB9QvsY6nfGckHdX-fwB-akW-lzouliM-9nahqAv_5dQnNxL-2jsAbDaKTwu4oiMLG31VmM=w4zye=Qv-w9iACWtAEz4_JhfoYDseoDpn8w5kOixA2abmCKqhGSOgopJhBYqnMHF_TQQgw4syYTwhSwMA=M7SWtMi8wMh1QBtBtMsz=MTbpJAhA-pYHHgfJJiHhMi2L83OiFAOLF-2LO3UjQ-TH53sx-fULo-lLzuoxzhhNTwUEwaHax-9azpV4MhFEMaqxlASQx3MG7jJxvulE-_vH=lNspLCh=qsiMklsQkHSMaoaxaGE-_TuZa8iYVww583DclCv5ksXjwCSR-2rtgf-xawdNxsjXuYzw3NoMwM4vhFc-Yc9qj5bwwZiIAqIxVEcMvaoQ_z2RTgDGY2MfLsz45mdxkYjbkf3vkldHYmMvM8oM3qtM_Fu52CWZhvjQjVwRvULv_=avaCXqh5oM_OtMxmwfoMayESnWpgxJTSnWjmxqofOJuEz=VYxLvNwq_Us-1voQ5BtxnzHQp2rC3Wja_c9yemKst2KqA4E-AC9q9WyHTCKwAbDc1UKqLCr8-2hxvbtX-8w9Ehwi2fxyESaMSCq-vwQ7YVoMEZxQTsDNYlbx-cMM-cQ_-2EwuLhvEq_vwwHv-C-MuzLFumolEq6LaXHW_mfJ4vs-i9nXLfw1ECLs-sDwi2Wsust-hgxFtvWbAbDwi2XwDVxFhvwe3BWZ36iveWzFjEDO3Zx5ECzvYGnwEhyEuTsQ-oQH3WWaYULP_UhfV4HQpB8JuUzM-2hx3UiMgT8ICMDpLgwM_lz5azE-uYjOYHDvplWX3CLQ3MjFHmoqkw1pYcnya2_M_TDvtGSqeljFzF19mwwwu2uGzFLZ_Bjx-Hd5AvDFTYoZA9QF_Czf-8D6ieDaLo8K_S9qg26=k2Wsg2XYAgoM_2iP-wolaLk-3go-jVsQfC9MwmMqEPD=LLumACrcT9a=tBDVh5-M-eQcwGdmtULvwzE-YL-viwxyklgW-24MiawwECdUh8o-mgxFIX1WnbTwaSawhF65-B9qzqxWEvwMTOxWhPD=dOfOhUtwaVw5vO4=-2tQVTnWq=axl2BQEhbxnSM4wotQ_lLFA4kFARDBfgtqifomuzDFmYsUV46WA4afi29HustqaUEMk9ax3CB-plTw3U6tEEjXfNxm3X6Zn9IBEbtfgVHbhv4oy2SvjVxcbFcutVxwESSMnS9f-QKf");
                        //request2.AddHeader("x-7xh4mcgiye-b", oMetroPCSSecurity.b);// -vua40
                        //request2.AddHeader("x-7xh4mcgiye-c", oMetroPCSSecurity.c);// "A1H9CpNpAQAAwgoDTjdI-YLmksG1yqG39moTIEiq5M-XO1lUYHZbBzQarQNMAawUMfHhpsaNwH_zwTJd7LutHQ==");
                        //request2.AddHeader("x-7xh4mcgiye-d", oMetroPCSSecurity.d);// "0");
                        //request2.AddHeader("x-7xh4mcgiye-f", oMetroPCSSecurity.f);// "0");
                        //request2.AddHeader("x-7xh4mcgiye-z", oMetroPCSSecurity.z);// "0");
                        //request2.AddHeader("referer", "https://www.metrobyt-mobile.com/payment");
                        //request2.AddHeader("mdn", number.ToString());
                        //request2.AddHeader("content-type", "application/json");
                        //request2.AddParameter("application/json", "{\"emailAddress\":\"9874559@gmail.com\",\"marketingPreference\":false,\"paymentDetails\":{\"amount\":\"" + amount + "\",\"confirmationEmailAddress\":\"9874559@gmail.com\",\"isDebitPreferred\":false,\"paymentType\":10,\"sensitiveAuthorizedCardInfo\":{\"cardNumber\":\"" + metrocc + "\",\"firstName\":\"" + GenerateName(5) + "\",\"lastName\":\"" + GenerateName(6) + "\",\"expDate\":\"" + expDate + "\",\"verificationCode\":\"" + thecvv + "\",\"zipCode\":\"" + ZIP + "\",\"cardBrand\":\"MC\"},\"paymentMethodCode\":\"\"}}", ParameterType.RequestBody);
                        ////request2.AddParameter("application/json", "{\"emailAddress\":\"9874559@gmail.com\",\"marketingPreference\":false,\"paymentDetails\":{\"amount\":\"" + amountWithZero + "\",\"confirmationEmailAddress\":\"9874559@gmail.com\",\"isDebitPreferred\":false,\"paymentType\":10,\"sensitiveAuthorizedCardInfo\":{\"cardNumber\":\"" + thecc + "\",\"firstName\":\"" + GenerateName(5) + "\",\"lastName\":\"" + GenerateName(6) + "\",\"expDate\":\"" + expDate + "\",\"verificationCode\":\"" + thecvv + "\",\"zipCode\":\"" + ZIP + "\",\"cardBrand\":\"MC\"}}}", ParameterType.RequestBody);
                        //IRestResponse response2 = client2.Execute(request2);
                        //HttpContext.Current.Session["ErrorBeforeError"] = "Check Point 12";
                        //string mycontent2 = response2.Content;
                        //HttpContext.Current.Session["ErrorBeforeError"] = "Check Point 13";
                        //if (mycontent2.Contains("billingConfirmationId"))
                        //{
                        //    string conf = getBetween(mycontent2, "billingConfirmationId\":\"", "\",\"convenienceFee");
                        //    string post = getPostbyID(intid);

                        //    //update credit line
                        //    if (oAccount.Active == true)
                        //    {
                        //        if (doublepay >= 1)
                        //        {
                        //            oUserDAO.UpdateAccountbyPost(oAccount.Credit - Convert.ToInt32(amount), post);
                        //            //insert payments
                        //            oUserDAO.InsertPayments(userid, post, number.ToString(), Convert.ToDecimal(amount), 0, "MetroPCS" + " - Conf#:" + conf, HttpContext.Current.Session["cc"].ToString(), DateTime.Now);
                        //            //5 card warning
                        //            CCLeft();
                        //        }
                        //        else
                        //        {
                        //            oUserDAO.UpdateAccountbyPost(oAccount.Credit - (Convert.ToInt32(amount) + (Convert.ToInt32(oFee.Fee) - 2)), post);
                        //            //insert payments
                        //            oUserDAO.InsertPayments(userid, post, number.ToString(), Convert.ToDecimal(amount), Convert.ToDecimal(oFee.Fee), "MetroPCS" + " - Conf#:" + conf, HttpContext.Current.Session["cc"].ToString(), DateTime.Now);
                        //            //5 card warning
                        //            CCLeft();
                        //        }

                        //    }
                        //    else
                        //    {
                        //        if (doublepay >= 1)
                        //        {
                        //            //insert payments
                        //            oUserDAO.InsertPayments(userid, post, number.ToString(), Convert.ToDecimal(amount), 0, "MetroPCS" + " - Conf#:" + conf, HttpContext.Current.Session["cc"].ToString(), DateTime.Now);
                        //            //5 card warning
                        //            CCLeft();
                        //        }
                        //        else
                        //        {
                        //            //insert payments
                        //            oUserDAO.InsertPayments(userid, post, number.ToString(), Convert.ToDecimal(amount), Convert.ToDecimal(oFee.Fee), "MetroPCS" + " - Conf#:" + conf, HttpContext.Current.Session["cc"].ToString(), DateTime.Now);
                        //            //5 card warning
                        //            CCLeft();
                        //        }
                        //    }



                        //    if (oCC.Used != null)
                        //    {
                        //        int used = Convert.ToInt16(oCC.Used) + 1;
                        //        oUserDAO.UpdateCCUsage(Convert.ToString(used), oCC.CCNumber);

                        //        //CC oDisCC = new CC();
                        //        //oDisCC = oUserDAO.DisableCard(oCC.CCNumber, false);
                        //    }
                        //    if (oCC2.Used != null)
                        //    {
                        //        int used = Convert.ToInt16(oCC2.Used) + 1;
                        //        oUserDAO.UpdateCCUsage(Convert.ToString(used), oCC2.CCNumber);



                        //        //CC oDisCCMetro = new CC();
                        //        //oDisCCMetro = oUserDAO.DisableCard(oCC2.CCNumber, false);
                        //    }
                        //    else if (oCC3.Used != null)
                        //    {
                        //        int used = Convert.ToInt16(oCC3.Used) + 1;
                        //        oUserDAO.UpdateCCUsage(Convert.ToString(used), oCC3.CCNumber);


                        //        CC oDisCCMetro = new CC();
                        //        oDisCCMetro = oUserDAO.DisableCard(oCC3.CCNumber, false);
                        //    }

                        //    //TextAndEmail("API payment made", "$" + amount + " MetorPCS payment was made to " + number);
                        //    TextAndEmail("MetorPCS", "MetorPCS, API, " + amount + ", " + number, false);

                        //    //capture IP
                        //    Payment oPayment = new Payment();
                        //    oPayment = oUserDAO.RetrievePaymentbyConfID(conf);
                        //    oUserDAO.InsertIP(oPayment.UserID, GetIPAddress(), oPayment.ID);

                        //    return ("Success:{Confirmationid : " + conf + "}");

                        //}
                        //HttpContext.Current.Session["ErrorBeforeError"] = mycontent2;
                        //if (mycontent2.Contains("10000115"))
                        //{
                        //    oUserDAO.DisableCard(HttpContext.Current.Session["cc"].ToString(), false);
                        //    return ("Error: No Payment made, try again");

                        //}
                        //if (mycontent2.Contains("10000018") && mycontent2.Contains("Backend system error"))
                        //{
                        //    // return ("Error: No Payment made");
                        //    oCC = oUserDAO.RetrieveBackUpCC();
                        //    oCC2 = oUserDAO.RetrieveBackUpCC2();
                        //    oCC3 = oUserDAO.RetrieveBackUpCC3();


                        //    thecc = "";
                        //    thecvv = "";
                        //    expDate = "";
                        //    ZIP = "";

                        //    if (oCC3.Used == null)
                        //    {
                        //        return ("Error: No Payment made");
                        //    }

                        //    if (oCC.Used != null)
                        //    {
                        //        thecc = oCC.CCNumber;
                        //        HttpContext.Current.Session["cc"] = thecc;
                        //        thecc = DAO.Decrypt(oCC.CCNumber, ConfigurationManager.AppSettings["encryptionKey"]).Trim();
                        //        thecvv = oCC.CVV.Trim();
                        //        expDate = oCC.ExpDate;
                        //        ZIP = oCC.ZIP;
                        //        metrocc = oCC.Address;
                        //    }
                        //    else if (oCC2.Used != null)
                        //    {
                        //        thecc = oCC2.CCNumber;
                        //        HttpContext.Current.Session["cc"] = thecc;
                        //        thecc = DAO.Decrypt(oCC2.CCNumber, ConfigurationManager.AppSettings["encryptionKey"]).Trim();
                        //        thecvv = oCC2.CVV.Trim();
                        //        expDate = oCC2.ExpDate;
                        //        ZIP = oCC2.ZIP;
                        //        metrocc = oCC2.Address;
                        //    }
                        //    else if (oCC3.Used != null)
                        //    {
                        //        thecc = oCC3.CCNumber;
                        //        HttpContext.Current.Session["cc"] = thecc;
                        //        thecc = DAO.Decrypt(oCC3.CCNumber, ConfigurationManager.AppSettings["encryptionKey"]).Trim();
                        //        thecvv = oCC3.CVV.Trim();
                        //        expDate = oCC3.ExpDate;
                        //        ZIP = oCC3.ZIP;
                        //        metrocc = oCC3.Address;

                        //    }

                        //    client2 = new RestClient("https://www.metrobyt-mobile.com/api/v1/billing/payment/authorize-anonymous");
                        //    request2 = new RestRequest(Method.POST);
                        //    request2.AddHeader("postman-token", "d3b6a44d-37da-edc5-61e6-57865347cff9");
                        //    request2.AddHeader("cache-control", "no-cache");
                        //    request2.AddHeader("referer", "https://www.metrobyt-mobile.com/payment");
                        //    request2.AddHeader("mdn", number.ToString());
                        //    request2.AddHeader("content-type", "application/json");
                        //    request2.AddHeader("x-7xh4mcgiye-a", oMetroPCSSecurity.a);// "ANuFt8xTVlHz1WjqgwDIaSO-Eqo-kHh5-wA-vHBf9mQ5Dvtw3dt-kwoMi8wwAEoMAUYNgHnqamSM_qHxolEJYEDwIJdnasa4LO9MmTuwhGkcVVx5oSJA88iM_USJ8lGcEPRZ-pz=A=aMwznJL8iFTqcwYlv=kwF=k29q2GdzIbjwtmouo8xWgoHxg8xZtNxXANoJ5S8ktVxy3qxO-2rZnxkkLo-egoTquGWZ_VoQAXXMwxjQYk9--bYwhvH6iqu5wlKJTUdywJG5Y24rkf-1AvjWlMLWl7X=_EjqAYor1SSMgsxZakQyYbEMkEowjBwGuNxBwjLHfNDQABjqg26_EChxa5f-pmSqzCLWycMwwUi=hBDHklrTA2LGDg1qaMiGgHL_k2Gy39aPuY4feJdWa8ix3bLFYTx-A23fINHcTqkygHLZk4qquNHv3=J6jztQkEYxwYjJQBiGYEx=hGhfN2GWi4t-54xqgwHGumwI_YH8tVxbwwKMwEUJ-cOJkswfabiwuRLmtVfZ_8sJulvxk2KMn2zfv46v_ChNaMiwhhxqawDoksj8EqnWxwYwk2L=3BuEwxx5sOHXrsM5AgowpzsM3WhfSgD=pYxxRS9quzxxv2EfNBjGAHQ5A=Oq3JkM-9QFAkBMIHi9-2gIuzL5wYxaAc9w_c9kksDfilQ=3MMm-3Qy_Mwh8BOQVsYx3QQH-oxTET2JioL9hBLFioHymvxq-9Q6uOD=Evbp-zxbVz4MGEoqAFxug8wM_cQUuldtjq_Yh8xFis9wLoTq-Nxy9ZkFaC=fAYD4Tax5EgHFhPtvuU4=zJBMnvoMuLDWm3Q-uWLznNfrx2OJao_m-sEE-xxWTfw4aULanYFv3NsMAU1=uVHqxUdFuTw2LBDO_mr6AbeJh8sMwMowgwyJSvnFkHOQgw9CnhsfuVsqECdb3CEGV2QEhCHt_Yxapsx5mbYvATxfalHFga-w_j9-TXyZgsHqf5xWmlrsk8xNaKGNo8xxILdWnVDZ32j6-otMlsLQ88xyulLGaTxO-2H539nFwWwhiHO_-sx6_VoQawH5GM4M_oYYzgH=gfWWvlc-i2z5-WhwulB--8xywxGyh9OMkq3fEgT2Vcax3CLfjCrvLlSfaHYvm2M4uldPTzvo_kHW3vIo=VDtwV48AGd5A5x=hPZwf2r-kmwwEBEMYpM-_mWXumx=v8o-Tw4xtlLH1=9Qac9ln4w1hdkqg22Mg9aMugoM-mSJ3-LX-fxWucMZa24OnCzNElEQLqDHhCdXpBDJ3M1li2nX-2-x3gwtifr53Udag2KMupivg26fVuX2A=nwhv4fnH3wcpDzkwx=ECL53Xkw3fwMe8xNAC45VlLIisXGa29MuIyw3=nG-sbQdXZsjCvM_EjvT4DrvU1s5onQAzcJFGT=-uuq_l3=uoTMeEGUa2Housi9go_p-4dXa8oJfwIBYNyOTsT4LBUrLBx5aUGUAVx6R=axg21FaVD55Y4xh2Zfs8ixL3iMHHi1AhDWLCXyL4s--EjmTMTMLXivu3cM341WuTD=ubTHg8fwgaHQ53yXeL9rw=a5YFDxAlKfw=OqbgHEpdiv_LcQuM4MYYKMwHSQlwOw-ELIuVxQnNx_psQFTHMj3=Q8pVwvwvyH1bT-hCn=YLbJ_jz1mcaYavR7i2zog2FE-woMYEOq_LxHulDEwLhw5T_vhgxcaN45umX5_EjW_X4o4UFvAbjZisaIjcd6-9Q5wVxc31LaEqtMuEeWkcnqisTM-3xF5VxEElF1g2GWkmwq-MXlYVo-L5xD-fwIuYBzEqWXwCFfwTEqwEY4e24I_GSwi8xaV4HHpCuQYEb-xaDWAo9hq1aMw2HxhvsMEgf2jEDWEGTMLCdW-oxQk8_vxbQ6hFkvw2dqTvw1Tzu=E5xZAUawa4x6k2TouX9--wHeg9avkLkNu3o-ox=Jk4IM-N9fYUKJ=VwVw8oM1S9MkwWQ42dcwoxZhgw-goxQvsT--2c-Eqwxpzxyj8edtCLIT82J3MsM1Uv8Lmxx_VxZxo4=ezvMhCHX_YDZhvx=tX1c_VDN3otwYSOe-8o-hSAqAziCuTZ4a8tJ_gwxYTxZkoOMwHny3vsJuEjNkfWQAwHxabjH-2WN_66WhvH=voHsrJKz-R3w-4sMtB9Mx29qAC46k2s-gnQGw4i5wqjsAELFw2LxvHjtL5WyuXwMtsnWLaEqLBLWg2Kqvow=-UzMwejFuMdXuI_4pc9Qa9Qyuc1ypc9Mg2mOBEnTifxruTDZg21quVxqg99jY3L6T2HkAF1Rgexoi9QNz9Mf3Uj53JoKECEYSCWwVOoJ-sMGuCbqV2ru_W_MwT8dll4yklQZi2A-_YDEhqivYoDC-fK-i2rru24vagxLk9nFksYwtNDpl9nF5l-Hwbiqoio-YZxfi4EgLsJQhCrawltQaWdsLSnF3=a=-2WIw3jY7mKQtNi=k49MLcoM_goHnZiCjHd1-2ED79MvaNDc-lSMkfx6T5xxYL3qJM9M-2swu5-d88tChFnb_JoMvlLv_mxF_UbowMa=3=AMumBMfgxs4sWEwUHzw2LH-mwwASMMesLFe4dFT4Ws-axzzv4w3wbMa2uZz9QN-aoQrXXtELG5AFiM-9QUasTeVonFu3x9a9nNukjWhCrEaOkUuTsraaQ5hgtJ3Zi4-EY3_1AujBe7uExzuYxr-9x53JwwAFjcaLk5EVw5glnJh5oYu8xvv2LQvXLDV2CJl2dxtCFi-2QXm=MxaC-4fL9MpYH=LGhfAhOMEFtqV8Hya2vzEIxEalssisoMhCtwi4LWuoxY1F6Gyv4Mi2KqjF4Shhrwk2QWostMvfdcobmZfoDeEPxWLBn=nl4ohBoqIM453OHyjmoqfNxVAJwj3Jx5u6QykwHSkooMTwINhFfJinyctvi4ulOd_mwf-mrZulLiuZjOFB_xu8xF29_4_Snz8FVJhCPzYHD_Egoq-a4f-4DUANwFgwjWIMIGkOoSuEiwIJG-hSMN-wfJA2tqdWSqDJxXtF6Qks9wuExW1WX_hFoMwNxWhvxrAOkywlzMPNA-_YnX5c9M-VyRgHFqk=nf-8DQlfxN2THsAJdz-HLFuYHNhqxq5HaMhBT-hSOMifoOLrHrAgx6jcash9vBu2DHkLdrv2LLxatqk8sM-Hb2_lLXLsjTisLc4TYM-4wM-4oqlbEqAC_MtXLJaXGE-lbMaLSQ=bYy3MHCL8wf-VxWuYTVylOMYYHL_VDUuYsMiffKk4QO-oxNesi=wwDHhBtqjz1tAFrHYCH=A28UhCnW-wT-ogHxpWd8v4vFY2YThhbJ3NfMpWdynCntwFLW3992-ax8EBoMVmQG_Vic-w6WV2dWjHdqezXMa4vMa84VnCKzaYa5_MQi_TsM_YxQg2uqkbi51lWQ4LhxhvHEx=9QTfWZTgxqtq_M_CSMv9nHhB9QvsY6nfGckHdX-fwB-akW-lzouliM-9nahqAv_5dQnNxL-2jsAbDaKTwu4oiMLG31VmM=w4zye=Qv-w9iACWtAEz4_JhfoYDseoDpn8w5kOixA2abmCKqhGSOgopJhBYqnMHF_TQQgw4syYTwhSwMA=M7SWtMi8wMh1QBtBtMsz=MTbpJAhA-pYHHgfJJiHhMi2L83OiFAOLF-2LO3UjQ-TH53sx-fULo-lLzuoxzhhNTwUEwaHax-9azpV4MhFEMaqxlASQx3MG7jJxvulE-_vH=lNspLCh=qsiMklsQkHSMaoaxaGE-_TuZa8iYVww583DclCv5ksXjwCSR-2rtgf-xawdNxsjXuYzw3NoMwM4vhFc-Yc9qj5bwwZiIAqIxVEcMvaoQ_z2RTgDGY2MfLsz45mdxkYjbkf3vkldHYmMvM8oM3qtM_Fu52CWZhvjQjVwRvULv_=avaCXqh5oM_OtMxmwfoMayESnWpgxJTSnWjmxqofOJuEz=VYxLvNwq_Us-1voQ5BtxnzHQp2rC3Wja_c9yemKst2KqA4E-AC9q9WyHTCKwAbDc1UKqLCr8-2hxvbtX-8w9Ehwi2fxyESaMSCq-vwQ7YVoMEZxQTsDNYlbx-cMM-cQ_-2EwuLhvEq_vwwHv-C-MuzLFumolEq6LaXHW_mfJ4vs-i9nXLfw1ECLs-sDwi2Wsust-hgxFtvWbAbDwi2XwDVxFhvwe3BWZ36iveWzFjEDO3Zx5ECzvYGnwEhyEuTsQ-oQH3WWaYULP_UhfV4HQpB8JuUzM-2hx3UiMgT8ICMDpLgwM_lz5azE-uYjOYHDvplWX3CLQ3MjFHmoqkw1pYcnya2_M_TDvtGSqeljFzF19mwwwu2uGzFLZ_Bjx-Hd5AvDFTYoZA9QF_Czf-8D6ieDaLo8K_S9qg26=k2Wsg2XYAgoM_2iP-wolaLk-3go-jVsQfC9MwmMqEPD=LLumACrcT9a=tBDVh5-M-eQcwGdmtULvwzE-YL-viwxyklgW-24MiawwECdUh8o-mgxFIX1WnbTwaSawhF65-B9qzqxWEvwMTOxWhPD=dOfOhUtwaVw5vO4=-2tQVTnWq=axl2BQEhbxnSM4wotQ_lLFA4kFARDBfgtqifomuzDFmYsUV46WA4afi29HustqaUEMk9ax3CB-plTw3U6tEEjXfNxm3X6Zn9IBEbtfgVHbhv4oy2SvjVxcbFcutVxwESSMnS9f-QKf");
                        //    request2.AddHeader("x-7xh4mcgiye-b", oMetroPCSSecurity.b);// -vua40
                        //    request2.AddHeader("x-7xh4mcgiye-c", oMetroPCSSecurity.c);// "A1H9CpNpAQAAwgoDTjdI-YLmksG1yqG39moTIEiq5M-XO1lUYHZbBzQarQNMAawUMfHhpsaNwH_zwTJd7LutHQ==");
                        //    request2.AddHeader("x-7xh4mcgiye-d", oMetroPCSSecurity.d);// "0");
                        //    request2.AddHeader("x-7xh4mcgiye-f", oMetroPCSSecurity.f);// "0");
                        //    request2.AddHeader("x-7xh4mcgiye-z", oMetroPCSSecurity.z);// "0");
                        //    request2.AddParameter("application/json", "{\"emailAddress\":\"9874559@gmail.com\",\"marketingPreference\":false,\"paymentDetails\":{\"amount\":\"" + amountWithZero + "\",\"confirmationEmailAddress\":\"9874559@gmail.com\",\"isDebitPreferred\":false,\"paymentType\":10,\"sensitiveAuthorizedCardInfo\":{\"cardNumber\":\"" + metrocc + "\",\"firstName\":\"" + GenerateName(5) + "\",\"lastName\":\"" + GenerateName(6) + "\",\"expDate\":\"" + expDate + "\",\"verificationCode\":\"" + thecvv + "\",\"zipCode\":\"" + ZIP + "\",\"cardBrand\":\"MC\"}}}", ParameterType.RequestBody);
                        //    response2 = client2.Execute(request2);

                        //    mycontent2 = response2.Content;
                        //    HttpContext.Current.Session["ErrorBeforeError"] = "Check Point 15";
                        //    if (mycontent2.Contains("billingConfirmationId"))
                        //    {
                        //        string conf = getBetween(mycontent2, "billingConfirmationId\":\"", "\",\"convenienceFee");
                        //        string post = getPostbyID(intid);

                        //        //update credit line
                        //        if (oAccount.Active == true)
                        //        {
                        //            if (doublepay >= 1)
                        //            {
                        //                oUserDAO.UpdateAccountbyPost(oAccount.Credit - Convert.ToInt32(amount), post);
                        //                //insert payments
                        //                oUserDAO.InsertPayments(userid, post, number.ToString(), Convert.ToDecimal(amount), 0, "MetroPCS" + " - Conf#:" + conf, HttpContext.Current.Session["cc"].ToString(), DateTime.Now);
                        //                //5 card warning
                        //                CCLeft();
                        //            }
                        //            else
                        //            {
                        //                oUserDAO.UpdateAccountbyPost(oAccount.Credit - (Convert.ToInt32(amount) + (Convert.ToInt32(oFee.Fee) - 2)), post);
                        //                //insert payments
                        //                oUserDAO.InsertPayments(userid, post, number.ToString(), Convert.ToDecimal(amount), Convert.ToDecimal(oFee.Fee), "MetroPCS" + " - Conf#:" + conf, HttpContext.Current.Session["cc"].ToString(), DateTime.Now);
                        //                //5 card warning
                        //                CCLeft();
                        //            }

                        //        }
                        //        else
                        //        {
                        //            if (doublepay >= 1)
                        //            {
                        //                //insert payments
                        //                oUserDAO.InsertPayments(userid, post, number.ToString(), Convert.ToDecimal(amount), 0, "MetroPCS" + " - Conf#:" + conf, HttpContext.Current.Session["cc"].ToString(), DateTime.Now);
                        //                //5 card warning
                        //                CCLeft();
                        //            }
                        //            else
                        //            {
                        //                //insert payments
                        //                oUserDAO.InsertPayments(userid, post, number.ToString(), Convert.ToDecimal(amount), Convert.ToDecimal(oFee.Fee), "MetroPCS" + " - Conf#:" + conf, HttpContext.Current.Session["cc"].ToString(), DateTime.Now);
                        //                //5 card warning
                        //                CCLeft();
                        //            }
                        //        }



                        //        if (oCC.Used != null)
                        //        {
                        //            int used = Convert.ToInt16(oCC.Used) + 1;
                        //            oUserDAO.UpdateCCUsageBackUp(Convert.ToString(used), oCC.CCNumber);

                        //        }
                        //        if (oCC2.Used != null)
                        //        {
                        //            int used = Convert.ToInt16(oCC2.Used) + 1;
                        //            oUserDAO.UpdateCCUsageBackUp(Convert.ToString(used), oCC2.CCNumber);

                        //        }
                        //        else if (oCC3.Used != null)
                        //        {
                        //            int used = Convert.ToInt16(oCC3.Used) + 1;
                        //            oUserDAO.UpdateCCUsageBackUp(Convert.ToString(used), oCC3.CCNumber);


                        //            CC oDisCCMetro = new CC();
                        //            oDisCCMetro = oUserDAO.DisableCard(oCC3.CCNumber, false);
                        //        }

                        //        //TextAndEmail("API payment made", "$" + amount + " MetorPCS payment was made to " + number);
                        //        TextAndEmail("MetorPCS", "MetorPCS, API, " + amount + ", " + number, false);

                        //        //capture IP
                        //        Payment oPayment = new Payment();
                        //        oPayment = oUserDAO.RetrievePaymentbyConfID(conf);
                        //        oUserDAO.InsertIP(oPayment.UserID, GetIPAddress(), oPayment.ID);

                        //        return ("Success:{Confirmationid : " + conf + "}");

                        //    }
                        //    else
                        //    {
                        //        oUserDAO.DisableCard(HttpContext.Current.Session["cc"].ToString(), false);

                        //        oUserDAO.LogError(userid, number.ToString(), HttpContext.Current.Session["cc"].ToString(), "API Metro ($" + amount + ") -" + mycontent2.ToString());
                        //        return ("Error: This number cannot be paid using our system. Sorry for the inconvenience");
                        //    }

                        //}
                        //if (mycontent2.Contains("10000018") && mycontent2.Contains("Backend system error"))
                        //{

                        //    oCC = oUserDAO.RetrieveBackUpCC();
                        //    oCC2 = oUserDAO.RetrieveBackUpCC2();
                        //    oCC3 = oUserDAO.RetrieveBackUpCC3();


                        //    thecc = "";
                        //    thecvv = "";
                        //    expDate = "";
                        //    ZIP = "";
                        //    if (oCC3.Used == null)
                        //    {
                        //        return ("Error: No Payment made");
                        //    }

                        //    if (oCC.Used != null)
                        //    {
                        //        thecc = oCC.CCNumber;
                        //        HttpContext.Current.Session["cc"] = thecc;
                        //        thecc = DAO.Decrypt(oCC.CCNumber, ConfigurationManager.AppSettings["encryptionKey"]).Trim();
                        //        thecvv = oCC.CVV.Trim();
                        //        expDate = oCC.ExpDate;
                        //        ZIP = oCC.ZIP;
                        //        metrocc = oCC.Address;
                        //    }
                        //    else if (oCC2.Used != null)
                        //    {
                        //        thecc = oCC2.CCNumber;
                        //        HttpContext.Current.Session["cc"] = thecc;
                        //        thecc = DAO.Decrypt(oCC2.CCNumber, ConfigurationManager.AppSettings["encryptionKey"]).Trim();
                        //        thecvv = oCC2.CVV.Trim();
                        //        expDate = oCC2.ExpDate;
                        //        ZIP = oCC2.ZIP;
                        //        metrocc = oCC2.Address;

                        //    }
                        //    else if (oCC3.Used != null)
                        //    {
                        //        thecc = oCC3.CCNumber;
                        //        HttpContext.Current.Session["cc"] = thecc;
                        //        thecc = DAO.Decrypt(oCC3.CCNumber, ConfigurationManager.AppSettings["encryptionKey"]).Trim();
                        //        thecvv = oCC3.CVV.Trim();
                        //        expDate = oCC3.ExpDate;
                        //        ZIP = oCC3.ZIP;
                        //        metrocc = oCC3.Address;

                        //    }

                        //    client2 = new RestClient("https://www.metrobyt-mobile.com/api/v1/billing/payment/authorizeAnonymous");
                        //    request2 = new RestRequest(Method.POST);
                        //    request2.AddHeader("postman-token", "d3b6a44d-37da-edc5-61e6-57865347cff9");
                        //    request2.AddHeader("cache-control", "no-cache");
                        //    request2.AddHeader("referer", "https://www.metropcs.com/payment");
                        //    request2.AddHeader("mdn", number.ToString());
                        //    request2.AddHeader("content-type", "application/json");
                        //request.AddHeader("x-7xh4mcgiye-a", oMetroPCSSecurity.a);// "ANuFt8xTVlHz1WjqgwDIaSO-Eqo-kHh5-wA-vHBf9mQ5Dvtw3dt-kwoMi8wwAEoMAUYNgHnqamSM_qHxolEJYEDwIJdnasa4LO9MmTuwhGkcVVx5oSJA88iM_USJ8lGcEPRZ-pz=A=aMwznJL8iFTqcwYlv=kwF=k29q2GdzIbjwtmouo8xWgoHxg8xZtNxXANoJ5S8ktVxy3qxO-2rZnxkkLo-egoTquGWZ_VoQAXXMwxjQYk9--bYwhvH6iqu5wlKJTUdywJG5Y24rkf-1AvjWlMLWl7X=_EjqAYor1SSMgsxZakQyYbEMkEowjBwGuNxBwjLHfNDQABjqg26_EChxa5f-pmSqzCLWycMwwUi=hBDHklrTA2LGDg1qaMiGgHL_k2Gy39aPuY4feJdWa8ix3bLFYTx-A23fINHcTqkygHLZk4qquNHv3=J6jztQkEYxwYjJQBiGYEx=hGhfN2GWi4t-54xqgwHGumwI_YH8tVxbwwKMwEUJ-cOJkswfabiwuRLmtVfZ_8sJulvxk2KMn2zfv46v_ChNaMiwhhxqawDoksj8EqnWxwYwk2L=3BuEwxx5sOHXrsM5AgowpzsM3WhfSgD=pYxxRS9quzxxv2EfNBjGAHQ5A=Oq3JkM-9QFAkBMIHi9-2gIuzL5wYxaAc9w_c9kksDfilQ=3MMm-3Qy_Mwh8BOQVsYx3QQH-oxTET2JioL9hBLFioHymvxq-9Q6uOD=Evbp-zxbVz4MGEoqAFxug8wM_cQUuldtjq_Yh8xFis9wLoTq-Nxy9ZkFaC=fAYD4Tax5EgHFhPtvuU4=zJBMnvoMuLDWm3Q-uWLznNfrx2OJao_m-sEE-xxWTfw4aULanYFv3NsMAU1=uVHqxUdFuTw2LBDO_mr6AbeJh8sMwMowgwyJSvnFkHOQgw9CnhsfuVsqECdb3CEGV2QEhCHt_Yxapsx5mbYvATxfalHFga-w_j9-TXyZgsHqf5xWmlrsk8xNaKGNo8xxILdWnVDZ32j6-otMlsLQ88xyulLGaTxO-2H539nFwWwhiHO_-sx6_VoQawH5GM4M_oYYzgH=gfWWvlc-i2z5-WhwulB--8xywxGyh9OMkq3fEgT2Vcax3CLfjCrvLlSfaHYvm2M4uldPTzvo_kHW3vIo=VDtwV48AGd5A5x=hPZwf2r-kmwwEBEMYpM-_mWXumx=v8o-Tw4xtlLH1=9Qac9ln4w1hdkqg22Mg9aMugoM-mSJ3-LX-fxWucMZa24OnCzNElEQLqDHhCdXpBDJ3M1li2nX-2-x3gwtifr53Udag2KMupivg26fVuX2A=nwhv4fnH3wcpDzkwx=ECL53Xkw3fwMe8xNAC45VlLIisXGa29MuIyw3=nG-sbQdXZsjCvM_EjvT4DrvU1s5onQAzcJFGT=-uuq_l3=uoTMeEGUa2Housi9go_p-4dXa8oJfwIBYNyOTsT4LBUrLBx5aUGUAVx6R=axg21FaVD55Y4xh2Zfs8ixL3iMHHi1AhDWLCXyL4s--EjmTMTMLXivu3cM341WuTD=ubTHg8fwgaHQ53yXeL9rw=a5YFDxAlKfw=OqbgHEpdiv_LcQuM4MYYKMwHSQlwOw-ELIuVxQnNx_psQFTHMj3=Q8pVwvwvyH1bT-hCn=YLbJ_jz1mcaYavR7i2zog2FE-woMYEOq_LxHulDEwLhw5T_vhgxcaN45umX5_EjW_X4o4UFvAbjZisaIjcd6-9Q5wVxc31LaEqtMuEeWkcnqisTM-3xF5VxEElF1g2GWkmwq-MXlYVo-L5xD-fwIuYBzEqWXwCFfwTEqwEY4e24I_GSwi8xaV4HHpCuQYEb-xaDWAo9hq1aMw2HxhvsMEgf2jEDWEGTMLCdW-oxQk8_vxbQ6hFkvw2dqTvw1Tzu=E5xZAUawa4x6k2TouX9--wHeg9avkLkNu3o-ox=Jk4IM-N9fYUKJ=VwVw8oM1S9MkwWQ42dcwoxZhgw-goxQvsT--2c-Eqwxpzxyj8edtCLIT82J3MsM1Uv8Lmxx_VxZxo4=ezvMhCHX_YDZhvx=tX1c_VDN3otwYSOe-8o-hSAqAziCuTZ4a8tJ_gwxYTxZkoOMwHny3vsJuEjNkfWQAwHxabjH-2WN_66WhvH=voHsrJKz-R3w-4sMtB9Mx29qAC46k2s-gnQGw4i5wqjsAELFw2LxvHjtL5WyuXwMtsnWLaEqLBLWg2Kqvow=-UzMwejFuMdXuI_4pc9Qa9Qyuc1ypc9Mg2mOBEnTifxruTDZg21quVxqg99jY3L6T2HkAF1Rgexoi9QNz9Mf3Uj53JoKECEYSCWwVOoJ-sMGuCbqV2ru_W_MwT8dll4yklQZi2A-_YDEhqivYoDC-fK-i2rru24vagxLk9nFksYwtNDpl9nF5l-Hwbiqoio-YZxfi4EgLsJQhCrawltQaWdsLSnF3=a=-2WIw3jY7mKQtNi=k49MLcoM_goHnZiCjHd1-2ED79MvaNDc-lSMkfx6T5xxYL3qJM9M-2swu5-d88tChFnb_JoMvlLv_mxF_UbowMa=3=AMumBMfgxs4sWEwUHzw2LH-mwwASMMesLFe4dFT4Ws-axzzv4w3wbMa2uZz9QN-aoQrXXtELG5AFiM-9QUasTeVonFu3x9a9nNukjWhCrEaOkUuTsraaQ5hgtJ3Zi4-EY3_1AujBe7uExzuYxr-9x53JwwAFjcaLk5EVw5glnJh5oYu8xvv2LQvXLDV2CJl2dxtCFi-2QXm=MxaC-4fL9MpYH=LGhfAhOMEFtqV8Hya2vzEIxEalssisoMhCtwi4LWuoxY1F6Gyv4Mi2KqjF4Shhrwk2QWostMvfdcobmZfoDeEPxWLBn=nl4ohBoqIM453OHyjmoqfNxVAJwj3Jx5u6QykwHSkooMTwINhFfJinyctvi4ulOd_mwf-mrZulLiuZjOFB_xu8xF29_4_Snz8FVJhCPzYHD_Egoq-a4f-4DUANwFgwjWIMIGkOoSuEiwIJG-hSMN-wfJA2tqdWSqDJxXtF6Qks9wuExW1WX_hFoMwNxWhvxrAOkywlzMPNA-_YnX5c9M-VyRgHFqk=nf-8DQlfxN2THsAJdz-HLFuYHNhqxq5HaMhBT-hSOMifoOLrHrAgx6jcash9vBu2DHkLdrv2LLxatqk8sM-Hb2_lLXLsjTisLc4TYM-4wM-4oqlbEqAC_MtXLJaXGE-lbMaLSQ=bYy3MHCL8wf-VxWuYTVylOMYYHL_VDUuYsMiffKk4QO-oxNesi=wwDHhBtqjz1tAFrHYCH=A28UhCnW-wT-ogHxpWd8v4vFY2YThhbJ3NfMpWdynCntwFLW3992-ax8EBoMVmQG_Vic-w6WV2dWjHdqezXMa4vMa84VnCKzaYa5_MQi_TsM_YxQg2uqkbi51lWQ4LhxhvHEx=9QTfWZTgxqtq_M_CSMv9nHhB9QvsY6nfGckHdX-fwB-akW-lzouliM-9nahqAv_5dQnNxL-2jsAbDaKTwu4oiMLG31VmM=w4zye=Qv-w9iACWtAEz4_JhfoYDseoDpn8w5kOixA2abmCKqhGSOgopJhBYqnMHF_TQQgw4syYTwhSwMA=M7SWtMi8wMh1QBtBtMsz=MTbpJAhA-pYHHgfJJiHhMi2L83OiFAOLF-2LO3UjQ-TH53sx-fULo-lLzuoxzhhNTwUEwaHax-9azpV4MhFEMaqxlASQx3MG7jJxvulE-_vH=lNspLCh=qsiMklsQkHSMaoaxaGE-_TuZa8iYVww583DclCv5ksXjwCSR-2rtgf-xawdNxsjXuYzw3NoMwM4vhFc-Yc9qj5bwwZiIAqIxVEcMvaoQ_z2RTgDGY2MfLsz45mdxkYjbkf3vkldHYmMvM8oM3qtM_Fu52CWZhvjQjVwRvULv_=avaCXqh5oM_OtMxmwfoMayESnWpgxJTSnWjmxqofOJuEz=VYxLvNwq_Us-1voQ5BtxnzHQp2rC3Wja_c9yemKst2KqA4E-AC9q9WyHTCKwAbDc1UKqLCr8-2hxvbtX-8w9Ehwi2fxyESaMSCq-vwQ7YVoMEZxQTsDNYlbx-cMM-cQ_-2EwuLhvEq_vwwHv-C-MuzLFumolEq6LaXHW_mfJ4vs-i9nXLfw1ECLs-sDwi2Wsust-hgxFtvWbAbDwi2XwDVxFhvwe3BWZ36iveWzFjEDO3Zx5ECzvYGnwEhyEuTsQ-oQH3WWaYULP_UhfV4HQpB8JuUzM-2hx3UiMgT8ICMDpLgwM_lz5azE-uYjOYHDvplWX3CLQ3MjFHmoqkw1pYcnya2_M_TDvtGSqeljFzF19mwwwu2uGzFLZ_Bjx-Hd5AvDFTYoZA9QF_Czf-8D6ieDaLo8K_S9qg26=k2Wsg2XYAgoM_2iP-wolaLk-3go-jVsQfC9MwmMqEPD=LLumACrcT9a=tBDVh5-M-eQcwGdmtULvwzE-YL-viwxyklgW-24MiawwECdUh8o-mgxFIX1WnbTwaSawhF65-B9qzqxWEvwMTOxWhPD=dOfOhUtwaVw5vO4=-2tQVTnWq=axl2BQEhbxnSM4wotQ_lLFA4kFARDBfgtqifomuzDFmYsUV46WA4afi29HustqaUEMk9ax3CB-plTw3U6tEEjXfNxm3X6Zn9IBEbtfgVHbhv4oy2SvjVxcbFcutVxwESSMnS9f-QKf");
                        //request.AddHeader("x-7xh4mcgiye-b", oMetroPCSSecurity.b);// -vua40
                        //request.AddHeader("x-7xh4mcgiye-c", oMetroPCSSecurity.c);// "A1H9CpNpAQAAwgoDTjdI-YLmksG1yqG39moTIEiq5M-XO1lUYHZbBzQarQNMAawUMfHhpsaNwH_zwTJd7LutHQ==");
                        //request.AddHeader("x-7xh4mcgiye-d", oMetroPCSSecurity.d);// "0");
                        //request.AddHeader("x-7xh4mcgiye-f", oMetroPCSSecurity.f);// "0");
                        //request.AddHeader("x-7xh4mcgiye-z", oMetroPCSSecurity.z);// "0");
                        //    request2.AddParameter("application/json", "{\"emailAddress\":\"9874559@gmail.com\",\"marketingPreference\":false,\"paymentDetails\":{\"amount\":\"" + amountWithZero + "\",\"confirmationEmailAddress\":\"9874559@gmail.com\",\"isDebitPreferred\":false,\"paymentType\":10,\"sensitiveAuthorizedCardInfo\":{\"cardNumber\":\"" + metrocc + "\",\"firstName\":\"" + GenerateName(5) + "\",\"lastName\":\"" + GenerateName(6) + "\",\"expDate\":\"" + expDate + "\",\"verificationCode\":\"" + thecvv + "\",\"zipCode\":\"" + ZIP + "\",\"cardBrand\":\"MC\"}}}", ParameterType.RequestBody);
                        //    response2 = client2.Execute(request2);

                        //    mycontent2 = response2.Content;
                        //    HttpContext.Current.Session["ErrorBeforeError"] = "Check Point 15";
                        //    if (mycontent2.Contains("billingConfirmationId"))
                        //    {
                        //        string conf = getBetween(mycontent2, "billingConfirmationId\":\"", "\",\"convenienceFee");
                        //        string post = getPostbyID(intid);

                        //        //update credit line
                        //        if (oAccount.Active == true)
                        //        {
                        //            if (doublepay >= 1)
                        //            {
                        //                oUserDAO.UpdateAccountbyPost(oAccount.Credit - Convert.ToInt32(amount), post);
                        //                //insert payments
                        //                oUserDAO.InsertPayments(userid, post, number.ToString(), Convert.ToDecimal(amount), 0, "MetroPCS" + " - Conf#:" + conf, HttpContext.Current.Session["cc"].ToString(), DateTime.Now);
                        //                //5 card warning
                        //                CCLeft();
                        //            }
                        //            else
                        //            {
                        //                oUserDAO.UpdateAccountbyPost(oAccount.Credit - (Convert.ToInt32(amount) + (Convert.ToInt32(oFee.Fee) - 2)), post);
                        //                //insert payments
                        //                oUserDAO.InsertPayments(userid, post, number.ToString(), Convert.ToDecimal(amount), Convert.ToDecimal(oFee.Fee), "MetroPCS" + " - Conf#:" + conf, HttpContext.Current.Session["cc"].ToString(), DateTime.Now);
                        //                //5 card warning
                        //                CCLeft();
                        //            }

                        //        }
                        //        else
                        //        {
                        //            if (doublepay >= 1)
                        //            {
                        //                //insert payments
                        //                oUserDAO.InsertPayments(userid, post, number.ToString(), Convert.ToDecimal(amount), 0, "MetroPCS" + " - Conf#:" + conf, HttpContext.Current.Session["cc"].ToString(), DateTime.Now);
                        //                //5 card warning
                        //                CCLeft();
                        //            }
                        //            else
                        //            {
                        //                //insert payments
                        //                oUserDAO.InsertPayments(userid, post, number.ToString(), Convert.ToDecimal(amount), Convert.ToDecimal(oFee.Fee), "MetroPCS" + " - Conf#:" + conf, HttpContext.Current.Session["cc"].ToString(), DateTime.Now);
                        //                //5 card warning
                        //                CCLeft();
                        //            }
                        //        }



                        //        if (oCC.Used != null)
                        //        {
                        //            int used = Convert.ToInt16(oCC.Used) + 1;
                        //            oUserDAO.UpdateCCUsageBackUp(Convert.ToString(used), oCC.CCNumber);

                        //        }
                        //        if (oCC2.Used != null)
                        //        {
                        //            int used = Convert.ToInt16(oCC2.Used) + 1;
                        //            oUserDAO.UpdateCCUsageBackUp(Convert.ToString(used), oCC2.CCNumber);

                        //        }
                        //        else if (oCC3.Used != null)
                        //        {
                        //            int used = Convert.ToInt16(oCC3.Used) + 1;
                        //            oUserDAO.UpdateCCUsageBackUp(Convert.ToString(used), oCC3.CCNumber);


                        //            CC oDisCCMetro = new CC();
                        //            oDisCCMetro = oUserDAO.DisableCard(oCC3.CCNumber, false);
                        //        }

                        //        //TextAndEmail("API payment made", "$" + amount + " MetorPCS payment was made to " + number);
                        //        TextAndEmail("MetorPCS", "MetorPCS, API, " + amount + ", " + number, false);

                        //        //capture IP
                        //        Payment oPayment = new Payment();
                        //        oPayment = oUserDAO.RetrievePaymentbyConfID(conf);
                        //        oUserDAO.InsertIP(oPayment.UserID, GetIPAddress(), oPayment.ID);

                        //        return ("Success:{Confirmationid : " + conf + "}");

                        //    }
                        //    else
                        //    {
                        //        oUserDAO.DisableCard(HttpContext.Current.Session["cc"].ToString(), false);
                        //    }

                        //}
                        //if (mycontent2.Contains("10000018") && mycontent2.Contains("Backend system error"))
                        //{
                        //    oUserDAO.LogError(userid, number.ToString(), HttpContext.Current.Session["cc"].ToString(), "API Metro ($" + amount + ") -" + mycontent2.ToString());
                        //    return ("Error: This number cannot be paid using our system. Sorry for the inconvenience");
                        //}
                        //    if (mycontent2.Contains("10000017") && mycontent2.Contains("Backend system error"))
                        //    {
                        //        oUserDAO.LogError(userid, number.ToString(), HttpContext.Current.Session["cc"].ToString(), "API Metro ($" + amount + ") -" + mycontent2.ToString());
                        //        TextAndEmail(userid + "Error", "$" + amount + " MetroPCS payment was attempted to " + number + " Error:" + mycontent2.ToString(), true);
                        //        return ("Error: This number cannot be paid using our system. Sorry for the inconvenience");
                        //    }
                        //    if (mycontent2.Contains("10001099") && mycontent2.Contains("Backend system error"))
                        //    {
                        //        return ManualPayment(HttpContext.Current.Session["userid"].ToString(), "MetroPCS", number.ToString(), amount);
                        //    }

                        //    if (mycontent2.Contains("10000113") && mycontent2.Contains("Backend system error"))
                        //    {
                        //        return ("Error: Amount has to be greater that $5.00");
                        //    }
                        //    if (mycontent2.Contains("3006") && mycontent2.Contains("Backend system error"))
                        //    {
                        //        oUserDAO.LogError(userid , number.ToString(), HttpContext.Current.Session["cc"].ToString(), "API Metro ($" + amount + ") -" + mycontent2.ToString());
                        //        TextAndEmail(userid + "Error", "$" + amount + " MetroPCS payment was attempted to " + number + " Error:" + mycontent2.ToString(), true);
                        //        return ("Error: Contact support@telbug.com");
                        //    }

                        //    if (mycontent2.Contains("10000013") && mycontent2.Contains("Backend system error"))
                        //    {
                        //        oUserDAO.LogError(userid, number.ToString(), HttpContext.Current.Session["cc"].ToString(), "API Metro ($" + amount + ") -" + mycontent2.ToString());
                        //        //oUserDAO.DisableCard(HttpContext.Current.Session["cc"].ToString(), false);
                        //        TextAndEmail(userid + "Error", "$" + amount + " MetroPCS payment was attempted to " + number + " Error:" + mycontent2.ToString() + " sent over as manual", true);
                        //        //return ManualPayment(HttpContext.Current.Session["userid"].ToString(), "MetroPCS", number.ToString(), amount);

                        //    }
                        //    if (mycontent2.Contains("Backend system error"))
                        //    {
                        //        oUserDAO.LogError(userid, number.ToString(), HttpContext.Current.Session["cc"].ToString(), "API Metro ($" + amount + ") -" + mycontent2.ToString());
                        //        TextAndEmail(userid + "Error", "$" + amount + " MetroPCS payment was attempted to " + number + " Error:" + mycontent2.ToString(), true);
                        //        return ("Error: Contact support@telbug.com");
                        //    }

                        // }

                    }
                    else if (provider == 2)
                    {

                        if (cricket.Active == false)
                        {
                            return ("Error: Cricket is under maintenance, please try back in an hour");
                        }

                        HttpContext.Current.Session["Provider"] = "Cricket";

                        if (number.ToString().Length > 10)
                        {
                            return ("Error: Phone number has to be 10 digits ");
                        }
                        if (doublepay == 3)
                        {
                            return ("Error: Number has been paid too many times");
                        }

                        if (doublepaypayment >= 1 && prevAmountPaid.ToString() == amount)
                        {
                            return ("Error: This number has already been paid today in the amount of $" + amount);
                        }

                        CC oCCc = new CC();
                        oCCc = oUserDAO.RetrieveCricketCC();
                        CC oCC2c = new CC();
                        oCC2c = oUserDAO.RetrieveCricketCC();
                        CC oCC3c = new CC();
                        oCC3c = oUserDAO.RetrieveCricketCC();

                        if (oCCc.Used != null)
                        {
                            string cc = oCCc.CCNumber;
                            HttpContext.Current.Session["cc"] = cc;
                            thecc = DAO.Decrypt(oCCc.CCNumber, ConfigurationManager.AppSettings["encryptionKey"]).Trim();
                            thecvv = oCCc.CVV.Trim();
                            expDate = oCCc.ExpDate;
                            ZIP = oCCc.ZIP;


                        }
                        else if (oCC2c.Used != null)
                        {
                            string cc = oCC2c.CCNumber;
                            HttpContext.Current.Session["cc"] = cc;
                            thecc = DAO.Decrypt(oCC2c.CCNumber, ConfigurationManager.AppSettings["encryptionKey"]).Trim();
                            thecvv = oCC2c.CVV.Trim();
                            expDate = oCC2c.ExpDate;
                            ZIP = oCC2c.ZIP;

                        }
                        else if (oCC3c.Used != null)
                        {
                            string cc = oCC3c.CCNumber;
                            HttpContext.Current.Session["cc"] = cc;
                            thecc = DAO.Decrypt(oCC3c.CCNumber, ConfigurationManager.AppSettings["encryptionKey"]).Trim();
                            thecvv = oCC3c.CVV.Trim();
                            expDate = oCC3c.ExpDate;
                            ZIP = oCC3c.ZIP;
                        }
                        if (oCC3c.Used == null && oCC2c.Used == null && oCCc.Used == null)
                        {
                            //text
                            TextAndEmail("Telbug Error", "no cards in the system for Cricket, switched to manual payments", true);
                            //Turn manual payments on
                            // oUserDAO.UpdateServiceActivity(1, false);

                            return ManualPayment(HttpContext.Current.Session["userid"].ToString(), "Cricket", number.ToString(), amount);
                        }

                        _Client = new HttpClient();
                        _Client.BaseAddress = new Uri("https://www.cricketwireless.com");
                        _Client.DefaultRequestHeaders.Accept.Clear();
                        _Client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                        _Client.DefaultRequestHeaders.AcceptCharset.Add(new StringWithQualityHeaderValue("UTF-8"));



                        string CricketcardExpirationDate = expDate.Replace("/", "");
                        ZIP = "33415";
                        Data data = new Data(amount, ZIP, number, thecc, GenerateName(6), CricketcardExpirationDate, thecvv);

                        var myContent = JsonConvert.SerializeObject(data);
                        var buffer = System.Text.Encoding.UTF8.GetBytes(myContent);
                        var byteContent = new ByteArrayContent(buffer);
                        byteContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                        byteContent.Headers.ContentLength = myContent.Length;
                        byteContent.Headers.Add("ContentType", "application/json");


                        var response = await _Client.PostAsync("selfservice/rest/quickpay/creditcard/", byteContent);
                        HttpContent content = response.Content;
                        string mycontent2 = await content.ReadAsStringAsync();

                        if (response.IsSuccessStatusCode)
                        {
                            string s = response.Content.ReadAsStringAsync().Result;

                            HttpContext.Current.Session["conf"] = "";

                            if (s.Contains("1006") && s.Contains("failure"))
                            {
                                return ("Error: Not a Cricket number");
                            }
                            //if (s.Contains("5000") && s.Contains("failure"))
                            //{

                            //    string Cricketcc = DAO.Decrypt("JON3ludockZL+OfWGKrxV5Qx8J0KlaelHmTFakiDxcDQbZeog6gG8wBHx++fgaR/", ConfigurationManager.AppSettings["encryptionKey"]).Trim();
                            //    string CricketcardExpirationDate2 = "0920";
                            //    string cvv = "285";
                            //    string zip = "33463";

                            //    await CricketBackUpPayment(amount, zip, number, Cricketcc, GenerateName(6), CricketcardExpirationDate2, cvv);
                            //}
                            if (s.Contains("0002") && s.Contains("failure"))
                            {
                                oUserDAO.LogError(userid, number.ToString(), HttpContext.Current.Session["cc"].ToString(), "API Cricket ($" + amount + ") -" + s.ToString());
                                return ("Error: Contact support@telbug.com");
                            }
                            if (s.Contains("5000") && s.Contains("failure"))
                            {
                                oUserDAO.LogError(userid, number.ToString(), HttpContext.Current.Session["cc"].ToString(), "API Cricket ($" + amount + ") -" + s.ToString());

                                CC oDisCCCricket = new CC();
                                oDisCCCricket = oUserDAO.DisableCard(oCCc.CCNumber, false);
                                return ("Error: No payment made, please try again.");
                            }
                            if (s.Contains("confirmationId") || HttpContext.Current.Session["conf"].ToString().Length == 9)
                            {
                                string conf = getBetween(s, "confirmationId\":\"", "\",\"amountReceived\"");
                                string post = getPostbyID(intid);

                                if (HttpContext.Current.Session["conf"].ToString().Length == 9)
                                {
                                    conf = HttpContext.Current.Session["conf"].ToString();
                                }



                                //update credit line
                                if (oAccount.Active == true)
                                {
                                    if (doublepay >= 1)
                                    {
                                        oUserDAO.UpdateAccountbyPost(oAccount.Credit - Convert.ToInt32(amount), post);
                                        //insert payments
                                        oUserDAO.InsertPayments(userid, post, number.ToString(), Convert.ToDecimal(amount), 0, "Cricket" + " - Conf#:" + conf, HttpContext.Current.Session["cc"].ToString(), DateTime.Now);
                                        //5 card warning
                                        CricketCCLeft();
                                    }
                                    else
                                    {
                                        oUserDAO.UpdateAccountbyPost(oAccount.Credit - (Convert.ToInt32(amount) + (Convert.ToInt32(oFee.Fee) - 2)), post);
                                        //insert payments
                                        oUserDAO.InsertPayments(userid, post, number.ToString(), Convert.ToDecimal(amount), Convert.ToDecimal(oFee.Fee), "Cricket" + " - Conf#:" + conf, HttpContext.Current.Session["cc"].ToString(), DateTime.Now);
                                        //5 card warning
                                        CricketCCLeft();
                                    }

                                }
                                else
                                {
                                    if (doublepay >= 1)
                                    {
                                        //insert payments
                                        oUserDAO.InsertPayments(userid, post, number.ToString(), Convert.ToDecimal(amount), 0, "Cricket" + " - Conf#:" + conf, HttpContext.Current.Session["cc"].ToString(), DateTime.Now);
                                        //5 card warning
                                        CricketCCLeft();
                                    }
                                    else
                                    {
                                        //insert payments
                                        oUserDAO.InsertPayments(userid, post, number.ToString(), Convert.ToDecimal(amount), Convert.ToDecimal(oFee.Fee), "Cricket" + " - Conf#:" + conf, HttpContext.Current.Session["cc"].ToString(), DateTime.Now);
                                        //5 card warning
                                        CricketCCLeft();
                                    }
                                }



                                if (oCCc.Used != null)
                                {
                                    int used = Convert.ToInt16(oCCc.Used) + 1;
                                    oUserDAO.UpdateCCUsage(Convert.ToString(used), oCCc.CCNumber);

                                    //update ccusage
                                    //Usage oUsage = new Usage();
                                    //oUsage = oUserDAO.RetrieveCCAmountUsed(oCCc.FirstName.Substring(0, 1).ToUpper() + oCCc.LastName.Substring(0, 1).ToUpper());
                                    //oUserDAO.UpdateCCAmountUsed(oCCc.FirstName.Substring(0, 1).ToUpper() + oCCc.LastName.Substring(0, 1).ToUpper(), oUsage.CurrentAmount + Convert.ToInt32(amount));

                                    //if (oUsage.MaxAmount <= oUsage.CurrentAmount)
                                    //{
                                    //    oUserDAO.UpdateCCUsageByName(oCCc.FirstName.Substring(0, 1).ToUpper(), oCCc.LastName.Substring(0, 1).ToUpper());
                                    //    oUserDAO.UpdateCCUsageToFalse(oCCc.FirstName.Substring(0, 1).ToUpper() + oCCc.LastName.Substring(0, 1).ToUpper());
                                    //}

                                    CC oDisCCCricket = new CC();
                                    oDisCCCricket = oUserDAO.DisableCard(oCCc.CCNumber, false);
                                }
                                else if (oCC2c.Used != null)
                                {
                                    int used = Convert.ToInt16(oCC2c.Used) + 1;
                                    oUserDAO.UpdateCCUsage(Convert.ToString(used), oCC2c.CCNumber);

                                    //update ccusage
                                    //Usage oUsage = new Usage();
                                    //oUsage = oUserDAO.RetrieveCCAmountUsed(oCC2c.FirstName.Substring(0, 1).ToUpper() + oCC2c.LastName.Substring(0, 1).ToUpper());
                                    //oUserDAO.UpdateCCAmountUsed(oCC2c.FirstName.Substring(0, 1).ToUpper() + oCC2c.LastName.Substring(0, 1).ToUpper(), oUsage.CurrentAmount + Convert.ToInt32(amount));


                                    //if (oUsage.MaxAmount <= oUsage.CurrentAmount)
                                    //{
                                    //    oUserDAO.UpdateCCUsageByName(oCC2c.FirstName.Substring(0, 1).ToUpper(), oCC2c.LastName.Substring(0, 1).ToUpper());
                                    //    oUserDAO.UpdateCCUsageToFalse(oCC2c.FirstName.Substring(0, 1).ToUpper() + oCC2c.LastName.Substring(0, 1).ToUpper());
                                    //}


                                    CC oDisCCCricket = new CC();
                                    oDisCCCricket = oUserDAO.DisableCard(oCC2c.CCNumber, false);
                                }
                                else if (oCC3c.Used != null)
                                {
                                    int used = Convert.ToInt16(oCC3c.Used) + 1;
                                    oUserDAO.UpdateCCUsage(Convert.ToString(used), oCC3c.CCNumber);

                                    //update ccusage
                                    //Usage oUsage = new Usage();
                                    //oUsage = oUserDAO.RetrieveCCAmountUsed(oCC3c.FirstName.Substring(0, 1).ToUpper() + oCC3c.LastName.Substring(0, 1).ToUpper());
                                    //oUserDAO.UpdateCCAmountUsed(oCC3c.FirstName.Substring(0, 1).ToUpper() + oCC3c.LastName.Substring(0, 1).ToUpper(), oUsage.CurrentAmount + Convert.ToInt32(amount));

                                    //if (oUsage.MaxAmount <= oUsage.CurrentAmount)
                                    //{
                                    //    oUserDAO.UpdateCCUsageByName(oCC3c.FirstName.Substring(0, 1).ToUpper(), oCC3c.LastName.Substring(0, 1).ToUpper());
                                    //    oUserDAO.UpdateCCUsageToFalse(oCC3c.FirstName.Substring(0, 1).ToUpper() + oCC3c.LastName.Substring(0, 1).ToUpper());
                                    //}

                                    CC oDisCCCricket = new CC();
                                    oDisCCCricket = oUserDAO.DisableCard(oCC3c.CCNumber, false);
                                }

                                //TextAndEmail("API payment made", "$" + amount + " Cricket payment was made to " + number, false);
                                TextAndEmail("Cricket ", "Cricket, API, " + amount + ", " + number, false);

                                //capture IP
                                Payment oPayment = new Payment();
                                oPayment = oUserDAO.RetrievePaymentbyConfID(conf);
                                oUserDAO.InsertIP(oPayment.UserID, GetIPAddress(), oPayment.ID);

                                return ("Success:{Confirmationid : " + conf + "}");

                            }
                            if (s.Contains("failure"))
                            {
                                oUserDAO.LogError(userid, number.ToString(), HttpContext.Current.Session["cc"].ToString(), "API Cricket ($" + amount + ") -" + s.ToString());
                                return ("Error: No Payment made");
                            }
                        }
                    }
                    else if (provider == 3)
                    {


                        if (Boost.Active == false)
                        {
                            return ("Error: Boost Mobile is under maintenance, please try back in an hour");
                        }

                        HttpContext.Current.Session["Provider"] = "Boost";
                        //var boost = oUserDAO.RetrieveServiceActivity(3);

                        //pin only-------------------------------------------------------------------------------------
                        if (number.ToString().Length > 10)
                        {
                            pin = number.ToString().Substring(number.ToString().Length - 4, 4);

                            string removePin = number.ToString().Remove(10);
                            number = Convert.ToInt64(removePin);
                            withouPin = false;
                        }
                        else
                        {

                            if (pin == "")
                            {
                                return ("Error: Need Boost pin to make payment");
                            }

                            //continue with out pin
                            withouPin = true;
                        }
                        //-----------------------------------------------------------------------------------------------

                        if (doublepay == 3)
                        {
                            return ("Error: Number has been paid too many times");
                        }

                        if (doublepaypayment >= 1 && prevAmountPaid.ToString() == amount)
                        {
                            return ("Error: This number has already been paid today in the amount of $" + amount);
                        }


                        //await CheckBoost("https://aka-apiservices.boostmobile.com/api/prepaid/authentication/1.0/login", pin, number);
                        //if (HttpContext.Current.Session["error"].ToString() == "error1")
                        //{
                        //    return ("Error: Not a Boost number");
                        //}
                        //if (HttpContext.Current.Session["error"].ToString() == "error2")
                        //{
                        //    return ("Error: PIN is incorrect");
                        //}
                        //if (HttpContext.Current.Session["error"].ToString() == "errorLockedAccount")
                        //{
                        //    return ("Error: This account is locked");
                        //}

                        //pin only--------------------------------------------------------------------------------------------------------------------------
                        if (withouPin == false)
                        {
                            await CheckTokenIDBoost("https://aka-apiservices.boostmobile.com/api/prepaid/authentication/1.0/login", number.ToString(), pin);
                            if (HttpContext.Current.Session["error"].ToString() == "error1")
                            {
                                return ("Error: Not a Boost number");
                            }
                            if (HttpContext.Current.Session["error"].ToString() == "errorLockedAccount")
                            {
                                return ("Error: This account is locked");
                            }
                            if (HttpContext.Current.Session["error"].ToString() == "errorToken")
                            {
                                return ("Error: token failed");
                            }
                            if (HttpContext.Current.Session["error"].ToString() == "errorPin")
                            {
                                return ("Error: Incorrect Pin");
                            }
                            if (HttpContext.Current.Session["error"].ToString() == "errorLockBoost")
                            {
                                return ("Error: Too many failed pin attempts; locked for 1 hour");
                            }
                            if (HttpContext.Current.Session["error"].ToString() == "errorLockBoost2")
                            {
                                return ("Error: Too many failed pin attempts; locked for 24 hours");
                            }
                        }
                        //-------------------------------------------------------------------------------------------------------------------------------------


                        CC oCCb = new CC();
                        oCCb = oUserDAO.RetrieveBoostCC();
                        CC oCC2b = new CC();
                        oCC2b = oUserDAO.RetrieveBoostCC2();
                        CC oCC3b = new CC();
                        oCC3b = oUserDAO.RetrieveBoostCC3();

                        //DPCards
                        //CC oCCbDP = new CC();
                        //oCCbDP = oUserDAO.RetrieveBoostCCDP();


                        if (oCCb.Used != null)
                        {
                            string cc = oCCb.CCNumber;
                            HttpContext.Current.Session["cc"] = cc;
                            thecc = DAO.Decrypt(oCCb.CCNumber, ConfigurationManager.AppSettings["encryptionKey"]).Trim();
                            thecvv = oCCb.CVV.Trim();
                            expDate = oCCb.ExpDate;
                            ZIP = oCCb.ZIP;
                        }
                        else if (oCC2b.Used != null)
                        {
                            string cc = oCC2b.CCNumber;
                            HttpContext.Current.Session["cc"] = cc;
                            thecc = DAO.Decrypt(oCC2b.CCNumber, ConfigurationManager.AppSettings["encryptionKey"]).Trim();
                            thecvv = oCC2b.CVV.Trim();
                            expDate = oCC2b.ExpDate;
                            ZIP = oCC2b.ZIP;

                        }
                        else if (oCC3b.Used != null)
                        {
                            string cc = oCC3b.CCNumber;
                            HttpContext.Current.Session["cc"] = cc;
                            thecc = DAO.Decrypt(oCC3b.CCNumber, ConfigurationManager.AppSettings["encryptionKey"]).Trim();
                            thecvv = oCC3b.CVV.Trim();
                            expDate = oCC3b.ExpDate;
                            ZIP = oCC3b.ZIP;
                        }

                        if (oCC3b.Used == null && oCC2b.Used == null && oCCb.Used == null)
                        {
                            //text
                            TextAndEmail("Telbug Error", "no cards in the system for boost, switched to manual payments", true);
                            //Turn manual payments on
                            // oUserDAO.UpdateServiceActivity(1, false);

                            return ManualPayment(HttpContext.Current.Session["userid"].ToString(), "Boost", number.ToString(), amount, pin);
                            //return ManualPayment(HttpContext.Current.Session["userid"].ToString(), "Boost", number.ToString(), amount);
                        }

                        //backup phone payments
                        //string originalamount = amount;
                        //amount = amount + "00";
                        //expDate = expDate.Replace("/", "");
                        //PhoneController it = new PhoneController();
                        //await it.MakeCall(number.ToString(), pin, amount, thecc, expDate, thecvv);
                        //await it.MakeCallBackUp(number.ToString(), pin, amount, thecc, expDate, thecvv);

                        //if (oCCb.Used != null)
                        //{
                        //    //update card used
                        //    int used = Convert.ToInt16(oCCb.Used) + 1;
                        //    oUserDAO.UpdateCCUsage(Convert.ToString(used), oCCb.CCNumber);

                        //    CC oDisCC = new CC();
                        //    oDisCC = oUserDAO.DisableCard(oCCb.CCNumber, false);
                        //}
                        //else if (oCC2b.Used != null)
                        //{
                        //    //update card used
                        //    int used = Convert.ToInt16(oCC2b.Used) + 1;
                        //    oUserDAO.UpdateCCUsage(Convert.ToString(used), oCC2b.CCNumber);

                        //    CC oDisCC = new CC();
                        //    oDisCC = oUserDAO.DisableCard(oCC2b.CCNumber, false);
                        //}
                        //else if (oCC3b.Used != null)
                        //{
                        //    //update card used
                        //    int used = Convert.ToInt16(oCC3b.Used) + 1;
                        //    oUserDAO.UpdateCCUsage(Convert.ToString(used), oCC3b.CCNumber);

                        //    CC oDisCC = new CC();
                        //    oDisCC = oUserDAO.DisableCard(oCC3b.CCNumber, false);
                        //}

                       // ManualBoost(user, "Boost", number.ToString(), originalamount, thecc);

                        //update credit line
                        //oAccount = oUserDAO.RetrieveAccount(user);
                        //oFee = oUserDAO.RetrieveFeebyUserID(user);

                        //User oUser = new MetroFastPayLibrary.User();
                        //oUser = oUserDAO.RetrieveUserByUserID(user);
                        //string theccs = DAO.Encrypt(HttpContext.Current.Session["cc"].ToString(), ConfigurationManager.AppSettings["encryptionKey"]).Trim();

                        //doublepay = getPreviousPayment(number.ToString());
                        //double conf = getConf("Boost") + 1;

                        //if (oAccount.Active == true)
                        //{

                        //    if (doublepay >= 1)
                        //    {
                        //        oUserDAO.UpdateAccountbyPost(oAccount.Credit - Convert.ToInt32(amount), oUser.Post);
                        //        oUserDAO.InsertPayments(user, oUser.Post, number.ToString(), Convert.ToDecimal(originalamount), 0, provider + " - Conf#:" + conf, theccs, DateTime.Now);

                        //    }
                        //    else
                        //    {
                        //        oUserDAO.UpdateAccountbyPost(oAccount.Credit - (Convert.ToInt32(amount) + (Convert.ToInt32(oFee.Fee) - 2)), oUser.Post);
                        //        oUserDAO.InsertPayments(user, oUser.Post, number.ToString(), Convert.ToDecimal(originalamount), Convert.ToDecimal(oFee.Fee), provider + " - Conf#:" + conf, theccs, DateTime.Now);

                        //    }
                        //}
                        //else
                        //{
                        //    if (doublepay >= 1)
                        //    {
                        //        //insert payments
                        //        oUserDAO.InsertPayments(user, oUser.Post, number.ToString(), Convert.ToDecimal(originalamount), 0, number.ToString() + " - Conf#:" + conf, theccs, DateTime.Now);

                        //    }
                        //    else
                        //    {
                        //        //insert payments
                        //        oUserDAO.InsertPayments(user, oUser.Post, number.ToString(), Convert.ToDecimal(originalamount), Convert.ToDecimal(oFee.Fee), provider + " - Conf#:" + conf, theccs, DateTime.Now);

                        //    }
                        //}
                        ////ip capture
                        //Payment oPayment = new Payment();
                        //oPayment = oUserDAO.RetrievePaymentbyConfID(conf.ToString());
                        //oUserDAO.InsertIP(user, GetIPAddress(), oPayment.ID);
                        //oUserDAO.InsertUserPin(number.ToString(), pin);

                        //TextAndEmail("Payment being made by phone for " + provider, "#: " + number.ToString() + "| Pin: " + pin + "| Amount: " + originalamount + "| User: " + user, true);
                        //---------------------------------------------------------------------------------------------------------------------------------
                        //TextAndEmail("Make Payment for " + provider, "#: " + phone + "| Amount: " + amount + "| User: " + user, true);
                        //HttpContext.Current.Session["conf"] = conf;
                        //return "Success:{Confirmationid : " + conf + "}";

                        //BoostDataGift data = new BoostDataGift(Convert.ToDouble(amount), ZIP, number.ToString(), thecc, GenerateName(6), expDate, thecvv);

                        var client = new RestClient("https://aka-apiservices.boostmobile.com/api/prepaid/payments/1.0/accounts/" + number + "/funds/creditcard");
                        var request = new RestRequest(Method.POST);
                        request.AddHeader("cache-control", "no-cache");
                        request.AddHeader("Connection", "keep-alive");
                        request.AddHeader("content-length", "644");
                        request.AddHeader("accept-encoding", "gzip, deflate");
                        request.AddHeader("cookie", "TS01445ed9=017ea1d44c2eeb3d07dc331002d2d08ea522a0ac90fd7cffc97e25228ac8633ed1c28f6d35f9d93a3ac3384ba70f554f35a8aad4e4; TLTSID=CE16C9C04603EAC696581D09788A7468; TLTUID=EA7E651CE84710E81A748BF76EFD25E8; TS01b974ae=017ea1d44c790599498c16c15b59f02c3561a269f2ccee4eb88f656dfec48c835c4f7430d4f82994588278c8ed556e7ba2cb5e4f453c47ea208b867b5c93cdac5db96c27df6ff879a5f6294acc3d4989641a2a99ba; _abck=D956AF285F68641440A9DD9CE6F937C81704F1A3556000006AF9A45CBF477C2C~-1~lxcGjohQldax/tJt0L9orphzyxiUONHYuym6wJa29h4=~-1~1-wmNLSooeFN-10000-100-3000; ak_bmsc=4AB7C4F8981B4AF132D69F0F8270A7BBB854F4E6191F00005FF1F25C90885D3D~pl/XOj+AOLb7pyVdNrpyF9LnF/Q4s/nfKnUEoe3RFVRKCjZ5oGSkztKZxjDUB0B1c6AHNPl2gS2JqmW46nAM0n/EAQVlmE3pVcxaS0GWTqoP9IjBBbI4yrzqzHYzUdtiwNB1drwn3nIB+6Jct4aqOD8dEyx+0P+Bv6BeUm8+V5YgPOhZ8Xm1SrmkI3lN6ACH9Tb8LjHThfTqEhctmyCrSAzu+VrAuMu8hbFtjwWKYsDVA=; bm_sz=7CCB5F4217BCBC844D96F5F6BE0E1988~YAAQ5vRUuJmejghrAQAA+tz+FAPUlL5miSPmo9xc7OceLXthO6ERk2VUPf/6kFmez3jhoIi3hxHEYnkpb87p8NbEY7t927z8p6t32e2rgSrDbKiLmNzMC2VufNeN0TFbiHXV6pQ09zVqfFg6Pbj+D00PIhtre2k1Dk/yXr8DyTr5CdNbEXmnJ4FGJ3oI1qCpfs5vyYc=; bm_sv=70E0F330D9089BAFDCFC413781B61EA9~oVyrdnRkYNYADV4GI/LYy+cAeqd+2B1GiV62mmBvlB2i43KQ/nl46p1wxyMPXnTtZuZqjlDfeq1mJrEp9fdqZzUNtZk9ePMMLzvRaXJt8qLVNiXkBDKGLgMhivdJaJhWg9DgxSIzWtjpo1bP86FaUWPMcrDYFFMRtgeqApXO1yQ=; akacd_aka_apiservices_boostmobile_com=3719678419~rv=51~id=9548d97159c8429372633cff9d1e1303");
                        request.AddHeader("Host", "aka-apiservices.boostmobile.com");
                        request.AddHeader("Postman-Token", "e10296b2-4cad-4ec5-bb8e-9a9e8c67abe0,4709e101-135b-4acf-8e50-a47a8fe61455");
                        request.AddHeader("Cache-Control", "no-cache");
                        request.AddHeader("Accept", "*/*");
                        request.AddHeader("User-Agent", "PostmanRuntime/7.11.0");
                        request.AddHeader("conversationId", "ACT");
                        request.AddHeader("consumerId", "PROD");
                        request.AddHeader("access_token", HttpContext.Current.Session["access_token"].ToString());
                        request.AddHeader("brandCode", "BST");
                        request.AddHeader("messageDateTimeStamp", string.Format("{0:yyyy-MM-ddTHH:mm:ssZ}", DateTime.Now));
                        request.AddHeader("enterpriseMessageId", "OWO266FMLy1GAJkCViDbqfbKc");
                        request.AddHeader("messageId", "266FMLy1GAJkCViDbqfbKc");
                        request.AddHeader("applicationId", "OWO");
                        request.AddHeader("content-type", "application/json");
                        request.AddParameter("application/json", "{\r\n  \"idField\": \"mdn\",\r\n  \"creditCard\": {\r\n    \"adhoc\": {\r\n      \"cardNumber\": \"" + thecc + "\",\r\n      \"expirationDate\": \"" + expDate + "\",\r\n      \"cvv\": \"" + thecvv + "\",\r\n      \"name\": \"" + GenerateName(6) + "" + GenerateName(8) + "\",\r\n      \"address\": {\r\n        \"addressLine1\": \"1234 " + GenerateName(5) + " st\",\r\n        \"addressLine2\": \"\",\r\n        \"city\": \"wpb\",\r\n        \"state\": \"FL\",\r\n        \"zipCode\": \"33415\",\r\n        \"setAsMailingAddress\": false\r\n      },\r\n      \"cardType\": \"CREDIT\",\r\n      \"cardBrand\": \"MASTERCARD\"\r\n    }\r\n  },\r\n  \"amount\": " + amount + ",\r\n  \"isAuthenticated\": true,\r\n  \"taxAmount\": 0,\r\n  \"totalAmount\": " + amount + ",\r\n  \"registerCardUsedForPayment\": false,\r\n  \"autoPay\": {\r\n    \"useForAutoPay\": false\r\n  }\r\n}", ParameterType.RequestBody);
                        IRestResponse response = client.Execute(request);
                        string s = response.Content;
                        if (s.Contains("error"))
                        {

                            if (s.Contains("704"))
                            {
                                //do nothing
                            }
                            else
                            {

                                oUserDAO.LogError(userid, number.ToString(), HttpContext.Current.Session["cc"].ToString(), "API Boost" + "-" + s.ToString());
                                TextAndEmail(userid + "Error", "$" + amount + " Boost payment was attempted to " + number + " Error:" + s.ToString(), true);
                                return ("Error: No payment made");
                            }
                        }

                        if (s.Contains("701") && s.Contains("errorCode"))
                        {
                            oUserDAO.LogError(userid, number.ToString(), HttpContext.Current.Session["cc"].ToString(), "API Boost" + "-" + s.ToString());
                            TextAndEmail(userid + "Error", "$" + amount + " Boost payment was attempted to " + number + " Error:" + s.ToString(), true);
                            return ("Error: No payment made");
                        }

                        if (s.Contains("270817") && s.Contains("errorCode"))
                        {
                            oUserDAO.LogError(userid, number.ToString(), HttpContext.Current.Session["cc"].ToString(), "API Boost" + "-" + s.ToString());
                            TextAndEmail(userid + "Error", "$" + amount + " Boost payment was attempted to " + number + " Error:" + s.ToString(), true);
                            return ("Error: No payment made");

                        }
                        if (s.Contains("230071") || s.Contains("270403") || s.Contains("470402"))
                        {
                            //makes cards in cc table false
                            oUserDAO.DisableCard(HttpContext.Current.Session["cc"].ToString(), false);

                            oUserDAO.LogError(userid, number.ToString(), HttpContext.Current.Session["cc"].ToString(), "API Boost" + "- (Bad Card) $" + amount + " " + s.ToString());
                            TextAndEmail(userid + "Error", "$" + amount + " Boost payment was attempted to " + number + " Error (Bad Card):" + s.ToString(), true);

                            return ("Error: No payment made");

                            //string cc = DAO.Decrypt("JON3ludockZL+OfWGKrxV5Qx8J0KlaelHmTFakiDxcDQbZeog6gG8wBHx++fgaR/", ConfigurationManager.AppSettings["encryptionKey"]).Trim();
                            //string ExpirationDate = "0920";
                            //string cvv = "285";
                            //string zip = "33463";

                            //await BoostBackUpPayment(amount, zip, number, cc, GenerateName(6), ExpirationDate, cvv);
                        }
                        if (s.Contains("270401"))
                        {
                            //makes cards in cc table false
                            oUserDAO.DisableCard(HttpContext.Current.Session["cc"].ToString(), false);

                            oUserDAO.LogError(userid, number.ToString(), HttpContext.Current.Session["cc"].ToString(), "API Boost" + "- (Bad Card) $" + amount + " " + s.ToString());
                            TextAndEmail(userid + "Error", "$" + amount + " Boost payment was attempted to " + number + " Error (Bad Card):" + s.ToString(), true);

                            return ("Error: No payment made");
                        }
                        if (s.Contains("270100") && s.Contains("errorCode"))
                        {
                            oUserDAO.LogError(userid, number.ToString(), HttpContext.Current.Session["cc"].ToString(), "API Boost" + "-" + s.ToString());
                            TextAndEmail(userid + "Error", "$" + amount + " Boost payment was attempted to " + number + " Error:" + s.ToString(), true);
                            return ("Error: No payment made");
                        }

                        if (s.Contains("errorCode"))
                        {
                            oUserDAO.LogError(userid, number.ToString(), HttpContext.Current.Session["cc"].ToString(), "API Boost" + "-" + s.ToString());
                            TextAndEmail(userid + "Error", "$" + amount + " Boost payment was attempted to " + number + " Error:" + s.ToString(), true);
                            return ("Error: No payment made");
                        }
                        if (s.Contains("billingConfirmationId"))
                        {
                            string conf = getBetween(s, "billingConfirmationId\": \"", "\",\n    \"externalId");
                            string post = getPostbyID(intid);

                            oUserDAO.InsertUserPin(number.ToString(), pin);

                            //update credit line
                            if (oAccount.Active == true)
                            {
                                if (doublepay >= 1)
                                {
                                    oUserDAO.UpdateAccountbyPost(oAccount.Credit - Convert.ToInt32(amount), post);
                                    // insert payments
                                    oUserDAO.InsertPayments(userid, post, number.ToString(), Convert.ToDecimal(amount), 0, "Boost" + " - Conf#:" + conf, HttpContext.Current.Session["cc"].ToString(), DateTime.Now);
                                    //5 card warning
                                    BoostCCLeft();
                                }
                                else
                                {
                                    oUserDAO.UpdateAccountbyPost(oAccount.Credit - (Convert.ToInt32(amount) + (Convert.ToInt32(oFee.Fee) - 2)), post);
                                    //insert payments
                                    oUserDAO.InsertPayments(userid, post, number.ToString(), Convert.ToDecimal(amount), Convert.ToDecimal(oFee.Fee), "Boost" + " - Conf#:" + conf, HttpContext.Current.Session["cc"].ToString(), DateTime.Now);
                                    //5 card warning
                                    BoostCCLeft();
                                }

                            }
                            else
                            {
                                if (doublepay >= 1)
                                {
                                    //insert payments
                                    oUserDAO.InsertPayments(userid, post, number.ToString(), Convert.ToDecimal(amount), 0, "Boost" + " - Conf#:" + conf, HttpContext.Current.Session["cc"].ToString(), DateTime.Now);
                                    //5 card warning
                                    BoostCCLeft();
                                }
                                else
                                {
                                    //insert payments
                                    oUserDAO.InsertPayments(userid, post, number.ToString(), Convert.ToDecimal(amount), Convert.ToDecimal(oFee.Fee), "Boost" + " - Conf#:" + conf, HttpContext.Current.Session["cc"].ToString(), DateTime.Now);
                                    //5 card warning
                                    BoostCCLeft();
                                }
                            }


                            if (oCCb.Used != null)
                            {
                                //update card used
                                int used = Convert.ToInt16(oCCb.Used) + 1;
                                oUserDAO.UpdateCCUsage(Convert.ToString(used), oCCb.CCNumber);

                                //CC oDisCC = new CC();
                                //oDisCC = oUserDAO.DisableCard(oCCb.CCNumber, false);
                            }
                            else if (oCC2b.Used != null)
                            {
                                //update card used
                                int used = Convert.ToInt16(oCC2b.Used) + 1;
                                oUserDAO.UpdateCCUsage(Convert.ToString(used), oCC2b.CCNumber);

                                CC oDisCC = new CC();
                                oDisCC = oUserDAO.DisableCard(oCC2b.CCNumber, false);
                            }
                            else if (oCC3b.Used != null)
                            {
                                //update card used
                                int used = Convert.ToInt16(oCC3b.Used) + 1;
                                oUserDAO.UpdateCCUsage(Convert.ToString(used), oCC3b.CCNumber);

                                CC oDisCC = new CC();
                                oDisCC = oUserDAO.DisableCard(oCC3b.CCNumber, false);
                            }


                            //TextAndEmail("API payment made", "$" + amount + " Boost payment was made to " + number, false);
                            TextAndEmail("Boost", "Boost, API, " + amount + ", " + number, false);
                            //capture IP
                            Payment oPayment = new Payment();
                            oPayment = oUserDAO.RetrievePaymentbyConfID(conf);
                            oUserDAO.InsertIP(oPayment.UserID, GetIPAddress(), oPayment.ID);

                            return ("Success:{Confirmationid : " + conf + "}");

                        }



                    }
                    else if (provider == 4)
                    {
                        HttpContext.Current.Session["provider"] = "GuatePin";
                        //GuatePin Recharge
                        await DPandGuatePinRecharge(HttpContext.Current.Session["userid"].ToString(), Convert.ToDecimal(amount), 30178480, number.ToString());
                        return ("Success:{Confirmationid : " + HttpContext.Current.Session["conf"].ToString() + "}");
                    }
                    //else if (provider == 5)
                    //{
                    //    //Dollar Phone Recharge
                    //    DPandGuatePinRecharge(HttpContext.Current.Session["userid"].ToString(), Convert.ToDecimal(amount), 30030280, number.ToString());
                    //}
                    if (HttpContext.Current.Session["cc"].ToString() == "" || HttpContext.Current.Session["cc"] == null)
                    {
                        HttpContext.Current.Session["cc"] = "no card";
                    }
                    oUserDAO.LogError(HttpContext.Current.Session["userid"].ToString(), number.ToString(), HttpContext.Current.Session["cc"].ToString(), "API ($" + amount + ") -" + HttpContext.Current.Session["ErrorBeforeError"].ToString());
                    return ("Error: No payment made");

                }
                else
                {
                    return ("Error: Access denied");
                }
        }
            catch (Exception ex)
            {

                oUserDAO.LogError("API", number.ToString(), HttpContext.Current.Session["cc"].ToString(), "API" + HttpContext.Current.Session["Provider"].ToString() + "-" + ex);
                TextAndEmail("API Error", "$" + amount + HttpContext.Current.Session["Provider"].ToString() + " payment was attempted to " + number + " Error:" + ex.ToString(), true);
                return ("Error: No payment made");


            }

        }


        async System.Threading.Tasks.Task CheckBoost(string url, string pin, long number)
        {
            try
            {

                var client = new RestClient(url);
                var request = new RestRequest(Method.POST);
                request.AddHeader("cache-control", "no-cache");
                request.AddHeader("Connection", "keep-alive");
                request.AddHeader("content-length", "73");
                request.AddHeader("accept-encoding", "gzip, deflate");
                request.AddHeader("cookie", "TS01445ed9=017ea1d44c6bb219fe01bcb2b36bbbfc4def9bb709d1ea2790672a0b4864e4aa9b87df28bb6f52cb58d05f77f616f29cca9dfaaa27; TLTSID=CE16C9C04603EAC696581D09788A7468; TLTUID=EA7E651CE84710E81A748BF76EFD25E8; TS01b974ae=017ea1d44c790599498c16c15b59f02c3561a269f2ccee4eb88f656dfec48c835c4f7430d4f82994588278c8ed556e7ba2cb5e4f453c47ea208b867b5c93cdac5db96c27df6ff879a5f6294acc3d4989641a2a99ba; _abck=D956AF285F68641440A9DD9CE6F937C81704F1A3556000006AF9A45CBF477C2C~-1~lxcGjohQldax/tJt0L9orphzyxiUONHYuym6wJa29h4=~-1~1-wmNLSooeFN-10000-100-3000; ak_bmsc=4AB7C4F8981B4AF132D69F0F8270A7BBB854F4E6191F00005FF1F25C90885D3D~pl/XOj+AOLb7pyVdNrpyF9LnF/Q4s/nfKnUEoe3RFVRKCjZ5oGSkztKZxjDUB0B1c6AHNPl2gS2JqmW46nAM0n/EAQVlmE3pVcxaS0GWTqoP9IjBBbI4yrzqzHYzUdtiwNB1drwn3nIB+6Jct4aqOD8dEyx+0P+Bv6BeUm8+V5YgPOhZ8Xm1SrmkI3lN6ACH9Tb8LjHThfTqEhctmyCrSAzu+VrAuMu8hbFtjwWKYsDVA=; bm_sz=7CCB5F4217BCBC844D96F5F6BE0E1988~YAAQ5vRUuJmejghrAQAA+tz+FAPUlL5miSPmo9xc7OceLXthO6ERk2VUPf/6kFmez3jhoIi3hxHEYnkpb87p8NbEY7t927z8p6t32e2rgSrDbKiLmNzMC2VufNeN0TFbiHXV6pQ09zVqfFg6Pbj+D00PIhtre2k1Dk/yXr8DyTr5CdNbEXmnJ4FGJ3oI1qCpfs5vyYc=; bm_sv=70E0F330D9089BAFDCFC413781B61EA9~oVyrdnRkYNYADV4GI/LYy+cAeqd+2B1GiV62mmBvlB2i43KQ/nl46p1wxyMPXnTtZuZqjlDfeq1mJrEp9fdqZzUNtZk9ePMMLzvRaXJt8qJdcfShyebJYR3qOU9SZJf4o/x66mCxPMwPoTIlji6dgDawWbcvdw5C9hWDZleXnQM=; akacd_aka_apiservices_boostmobile_com=3719678419~rv=51~id=9548d97159c8429372633cff9d1e1303");
                request.AddHeader("Host", "aka-apiservices.boostmobile.com");
                request.AddHeader("Postman-Token", "16156508-08bb-4258-8d5d-f34d4721e395,dc9b4fb8-1dac-42e8-b075-ba80f9b9456b");
                request.AddHeader("Cache-Control", "no-cache");
                request.AddHeader("Accept", "*/*");
                request.AddHeader("User-Agent", "PostmanRuntime/7.11.0");
                request.AddHeader("messageDateTimeStamp", "2019-06-01T21:42:15.342Z");
                request.AddHeader("enterpriseMessageId", "OWO266FMLy1GAJkCViDbqfbKc");
                request.AddHeader("messageId", "266FMLy1GAJkCViDbqfbKc");
                request.AddHeader("applicationId", "OWO");
                request.AddHeader("content-type", "application/json");
                request.AddParameter("application/json", "{\r\n  \"mdn\": \""+number+"\",\r\n  \"pin\": \""+pin+"\",\r\n  \"scope\": \"login_auth\"\r\n}\r\n", ParameterType.RequestBody);
                IRestResponse response = client.Execute(request);

                string s = response.Content;
                if (s.Contains("access_token"))
                {

                    if (pin != "")
                    {
                        oUserDAO.InsertUserPin(number.ToString(), pin);
                    }
                    HttpContext.Current.Session["conf"] = "no conf";
                    HttpContext.Current.Session["error"] = "";

                    if (s.Contains("701") && s.Contains("error"))
                    {
                        HttpContext.Current.Session["error"] = "error1";
                    }


                }
                else
                {
                    HttpContext.Current.Session["conf"] = "";
                    if (s.Contains("701") && s.Contains("error"))
                    {
                        HttpContext.Current.Session["error"] = "error1";
                    }
                    if(s.Contains("The phone number or PIN you entered does not match our records"))
                    {
                        HttpContext.Current.Session["error"] = "error2";
                    }
                    if (s.Contains("Sorry. We are unable to accept a payment on this account at this time"))
                    {
                        HttpContext.Current.Session["error"] = "errorLockedAccount";
                    }
                }

            }
            catch (Exception ex)
            {
               // TextAndEmail("Payment Error", "Boost threw an error when " + user + " tried to make payment. No payments was made");

            }
        }
        async System.Threading.Tasks.Task CheckTokenIDBoost(string url, string number, string pin)
        {
            try
            {

                _Client = new HttpClient();
                _Client.DefaultRequestHeaders.Accept.Clear();
                _Client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                getBoostLoginToken data = new getBoostLoginToken(number, pin);

                var myContent = JsonConvert.SerializeObject(data);
                var buffer = System.Text.Encoding.UTF8.GetBytes(myContent);
                var byteContent = new ByteArrayContent(buffer);
                byteContent.Headers.Add("Content-Type", "application/json");
                byteContent.Headers.Add("applicationId", "OWO");
                byteContent.Headers.Add("consumerId", "PROD");
                byteContent.Headers.Add("messageId", "uHZy7ZfWEREr5obrlk4OLP");
                byteContent.Headers.Add("enterpriseMessageId", "OWOuHZy7ZfWEREr5obrlk4OLP");
                byteContent.Headers.Add("conversationId", "PROD");
                byteContent.Headers.Add("brandCode", "BST");
                byteContent.Headers.Add("messageDateTimeStamp", string.Format("{0:yyyy-MM-ddTHH:mm:ssZ}", DateTime.Now));

                var response = await _Client.PostAsync(url, byteContent);
                HttpContent content = response.Content;
                string mycontent3 = await content.ReadAsStringAsync();
                if (response.IsSuccessStatusCode)
                {
                    string s = response.Content.ReadAsStringAsync().Result;

                    HttpContext.Current.Session["access_token"] = getBetween(s, "access_token\": \"", "\",\n");
                    HttpContext.Current.Session["error"] = "";
                    if (s.Contains("The phone number or PIN you entered does not match our records"))
                    {
                        HttpContext.Current.Session["error"] = "errorPin";
                    }
                    if (s.Contains("Your account has been locked because of too many incorrect login attempts. Please try again in 1 hour"))
                    {
                        HttpContext.Current.Session["error"] = "errorLockBoost";
                    }
                    if (s.Contains("Your account has been locked because of too many login attempts. Please try again in 24 hours."))
                    {
                        HttpContext.Current.Session["error"] = "errorLockBoost2";
                    }
                    if (s.Contains("701") && s.Contains("error"))
                    {
                        HttpContext.Current.Session["error"] = "error1";
                    }
                    if (s.Contains("Sorry. We are unable to accept a payment on this account at this time"))
                    {
                        HttpContext.Current.Session["error"] = "errorLockedAccount";
                    }
                }
                else
                {
                    if (mycontent3.Contains("token"))
                    {
                        HttpContext.Current.Session["error"] = "errorToken";
                    }
                    if (mycontent3.Contains("The phone number or PIN you entered does not match our records"))
                    {
                        HttpContext.Current.Session["error"] = "errorPin";
                    }
                    if (mycontent3.Contains("Your account has been locked because of too many incorrect login attempts. Please try again in 1 hour"))
                    {
                        HttpContext.Current.Session["error"] = "errorLockBoost";
                    }
                    if (mycontent3.Contains("Your account has been locked because of too many login attempts. Please try again in 24 hours."))
                    {
                        HttpContext.Current.Session["error"] = "errorLockBoost2";
                    }
                    if (mycontent3.Contains("Sorry. We are unable to accept a payment on this account at this time"))
                    {
                        HttpContext.Current.Session["error"] = "errorLockedAccount";
                    }
                }


            }
            catch (Exception ex)
            {
                //TextAndEmail("Payment Error", "Boost threw an error when " + UserCookie.Value + " tried to make payment. No payments was made");
                //Response.Redirect("Error.aspx");
            }
        }
        [AcceptVerbs("GET", "POST")]
        [HttpPost]
        [Route("api/products/paycricket/{amount}/{number}/{Cricketcc}/{cvv}/{expDate}")]
        public async Task<string> CricketBackUpPayment(string amount, long number, string Cricketcc, string cvv, string expDate)
        {
            _Client = new HttpClient();
            _Client.BaseAddress = new Uri("https://www.cricketwireless.com");
            _Client.DefaultRequestHeaders.Accept.Clear();
            _Client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            _Client.DefaultRequestHeaders.AcceptCharset.Add(new StringWithQualityHeaderValue("UTF-8"));


            string zip = "33415";
            Data data = new Data(amount, zip, number, Cricketcc, GenerateName(9), expDate, cvv);

            var myContent = JsonConvert.SerializeObject(data);
            var buffer = System.Text.Encoding.UTF8.GetBytes(myContent);
            var byteContent = new ByteArrayContent(buffer);
            byteContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");
            byteContent.Headers.ContentLength = myContent.Length;
            byteContent.Headers.Add("ContentType", "application/json");


            var response = await _Client.PostAsync("selfservice/rest/quickpay/creditcard/", byteContent);
            HttpContent content = response.Content;
            string mycontent2 = await content.ReadAsStringAsync();

            if (response.IsSuccessStatusCode)
            {
                string s = response.Content.ReadAsStringAsync().Result;

                if (s.Contains("confirmationId"))
                {
                    string conf = getBetween(s, "confirmationId\":\"", "\",\"amountReceived\"");
                    return ("Success:{Confirmationid : " + conf + "}");

                    //capture IP
                    //Payment oPayment = new Payment();
                    //oPayment = oUserDAO.RetrievePaymentbyConfID(conf);
                    //oUserDAO.InsertIP(oPayment.UserID, GetIPAddress(), oPayment.ID);
                }
                else
                {
                    return "Error: " + s.ToString();
                }
            }
            else
            {
                return "Error: Cricket backup API is off";
            }
        }
        public static string Compress(string s)
        {
            var bytes = Encoding.Unicode.GetBytes(s);
            using (var msi = new MemoryStream(bytes))
            using (var mso = new MemoryStream())
            {
                using (var gs = new GZipStream(mso, CompressionMode.Compress))
                {
                    msi.CopyTo(gs);
                }
                return Convert.ToBase64String(mso.ToArray());
            }
        }

        public static string Decompress(string s)
        {
            var bytes = Convert.FromBase64String(s);
            using (var msi = new MemoryStream(bytes))
            using (var mso = new MemoryStream())
            {
                using (var gs = new GZipStream(msi, CompressionMode.Decompress))
                {
                    gs.CopyTo(mso);
                }
                return Encoding.Unicode.GetString(mso.ToArray());
            }
        }
        [AcceptVerbs("GET", "POST")]
        [HttpPost]
        [Route("api/products/checknumbermetro/{number}")]
        public async Task<string> MetroCheckNumber(long number)
        {

            MetroFastPayLibrary.MetroPCSSecurity oMetroPCSSecurity = new MetroFastPayLibrary.MetroPCSSecurity();
            //oMetroPCSSecurity = oUserDAO.RetrieveMSbyA();
            oMetroPCSSecurity = oUserDAO.GetAllX49exvsbl();
            var client = new RestClient("https://www.metrobyt-mobile.com/api/v1/billing/payment/validate-mdn");
            var request = new RestRequest(Method.POST);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("Connection", "keep-alive");
            request.AddHeader("Content-Length", "");
            request.AddHeader("Accept-Encoding", "gzip, deflate");
            request.AddHeader("Cookie", "aKllSdae=AyNepmxsAQAAWWzURtCf6-tENH8BWfvDOcZpGDaEQHroMbbPnRyQKnPmcAFzAUn1-huucsmZwH8AAEB3AAAAAA==; incap_ses_544_2024593=jsgMAoQLIB9ajgXPIq2MB1vtSl0AAAAA8jK8A10jCqFC3REq0sadBQ==; sessionId=c423127b-bf66-4c41-915b-1e5091713fa6; AMFParams=dummy,true,true,false,false,false,nc,nc,nc,nc; AMFDetect=true; incap_ses_123_2024593=Mzl8TAelMDxY1Vsbkfy0AT7xSl0AAAAAsP7SHInJnYh3p9insqwtJw==; visid_incap_2024593=6KTX3LqGRuy7XJHvMnWfwU/xSl0AAAAAQUIPAAAAAACl8Hzlw4hRJDWUvT2RjjOr; incap_ses_284_2024593=uYoXdRYu3UsK2sQpQPrwA+oQS10AAAAAdlS0oHFarRkLr6UEn6fhbQ==; nlbi_2024593_1915696=rTRGUZwLIRTfxtrtXsGxtgAAAADbH8gfDArC7Og62Ht9CnFp; incap_ses_994_2024593=z7QiCbp2cCE5FQoJhGbLDT3eTV0AAAAANg3PoC8luSTPnLNeBjujvA==; incap_ses_538_2024593=QfCbN5b0jmO115n0Klx3B4LeTV0AAAAAaPMIw+4qnmJoKn8JwzDrdw==");
            request.AddHeader("Host", "www.metrobyt-mobile.com");
            request.AddHeader("Postman-Token", "b923554a-0522-41fe-821f-98f446d7d128,2f7e5e2b-3be8-48cc-a26c-7d3ff5e60828");
            request.AddHeader("Cache-Control", "no-cache");
            request.AddHeader("Accept", "*/*");
            request.AddHeader("User-Agent", "PostmanRuntime/7.15.2");
            request.AddHeader("x-7xh4mcgiye-z", "p");
            request.AddHeader("x-7xh4mcgiye-f", "AzE9LHhsAQAASho737a51Z8KHExszUI8EtFdPfdevAnEW_lGDUQfT_Kc_IHMAUn1-huucsmZwH8AAEB3AAAAAA==");
            request.AddHeader("x-7xh4mcgiye-d", "o_0");
            request.AddHeader("x-7xh4mcgiye-c", "AwgiK3hsAQAAGHRn7f89tr9eAUbPHsCrjgTEwcBSkAKODrzusNY15QRaeAzMAJzC7xXAf323guqiwn23");
            request.AddHeader("x-7xh4mcgiye-b", "mop67f");
            request.AddHeader("x-7xh4mcgiye-a", "DeegV_M77Gx5sxTV_gD0LxwXkjitudhRT61D0MtOTg4dG=BnLvMn6EeCtD6BjE_5M1RGx3goJWMr9089SHeEQfnmlEkDARZYM7cfdQY7lxN6_I72-7zec9Jzcr0p=OfNNnQww4Erc8MkJ-cBPHpdyFXNnvfJ6gk=HXI7fWMkzURGsjvY6k8HPohLg6JKYhfhxIdJ=vEINK_yIsHOZNu0JSH=JtyLjcsbOgb7HfE8rSHLW6yYkV1JFZq4127ExrGHCZUNsF7WeigeLXKZ5f36VOfSPC_NwbEoXmlZ_BU8vxW0_Uu78xNw74uRJ5x3f6vmzvyiR7C9-3WZn728fWZxCn=B_ORSUuGNXxFf7EZFkSGVOlt3e7cu_f3wdjhIRv-Cs6uG46ZdjTTSeN3w_OyBnzDtAbqfU1qZfYcmElLNI8p4qgeEbC48AnuS271b=3quqJMUWyCpS6vi=5CY6fS8d-n2muA6PXkkxP_xZI0lKGNIHELN_wOfx-QN8lZ1cfXp3CDEeY=2PosVovn3LyvzcUGk4X0H3fuVS22tSqWtI0O-SjNIlwcWH_98-v23zR8_O07TXUDUckMGD8PBp4H3uoxSvDl9g445TFwzQGCYL_SIMVQOcvpwFjzqFNhlnXvztRsPnm-0zTx4dJvDm6WoDQ=Ae2FoX-pdiP1kq-fMI-NdwriU1HYjGGPuB44GwZoiXwlm8Fk54g_p7XTfvSArBSk0VygflFX3JNyCeOghC==lfzTNAtkSJiBFPsLuQ47NIZcmhsKeQOjFLqKeqv_vjkA994i3EbiIKuumSTUjCJKHyOH4sQTSDAB5c9quS51DrAOOcZmx0cWodVgGgtz90quJxEe1SjpR4Sxw-WdrDnt2lS3DQE7oyeoFevdnugSPhR_XFKERmkKTOun7pnKtL42_htXBQdXlsTb5x1Uv7U1vk=en_BHufNlLYSj5bUh1BW6HgQzWTXidJwF3N38HN8SlQNeMGve5H9wrVhGiJDDeZIyvq6Np60ePoZQJyIYMpNu0dXV=4rgKh8137o1DgnTcOZ6unvRL=MDvEg8czl8xTYNJnj44UL=7KTOd0QTTFdOMbUEkPVWs7Ft4gxB6-zXJRzxgkJd2Qc5I=6gZ_ksgkYoHBcbkXU8ZuLLCAp_NzwK82PKB1xztNrWHYWHKuxws8HrPoTnSGype2WuMyHx5S-qj4AZ-F_Hdr7W6tfM_A_5CWnVQzD7XyEu9eqet7wJzIOJHIGvsD_KOxV0kGfMywZg5oE3tCQTBWoNTTYMGTFs8AdFRBUf74B41gMm81iYWzJQJO6WY43MfzL8E=M6ufZgbZ-LuUrRhx5hQWPtSt9ikwBBcgH3IimbrmiP4MyZmjEThikrs9ZS-yrvF7IyIY1X95qRv4AuZqD_9VRlBQifT5xD3RggP6vrJGr1XQvEdXpU6l8BCfEPkrw=HNZH2ltf01ZxUZ6NmIR8_LET9K80EGYGNyd5GOD8HylrElMnGmfTHvK6JP-0MWNT0xBNUtZXJn8P50HHlGGlK5lrws2D73lPiQ8r-WsfwLXuBe3L_i=6k6-BeDmb71QqLzGYSWh5ypiqxTp-Zf1MdjtTil6TgwNn9H2Of=yWZXnYD503s8u2gJFqAWm-U8IHYheKpHP94up3xCSd07qhOtvC4GhSmEZGf6cOt_CeQQqNcvCRLdPJBgDiTxPrirg8V4pYzLcDx3n-KFcTYyz1VGpg77zSEcAYkIJ-dyf9XohVqRSVTlTDQbk9494qI7BlCUCnknIBbotxnebme6Y-NyQh2Kww0eV4XI8bLpsh_=eSH_IAiHwebq5lXjLDdknDeiywFFOTq3RTtCihvGTwApdwRU1ItolCNDYUQK=-f8YyNPzVlq5SwKH95TdtgG-BYD=HorXIol2_gsTWBGCw52AFq51q_URVm0z_7mLdH39ufNlUDVK7bRYRdQNJdf=meWNxgiu83GlKUtVBPPrGt1kEglmXDOJoTIcpd9gEYMTzXYgi53D-JfXU1Ukogq_cRXMZqyh51AiJvmPE8RE-IuULMuwA5XFVerr0hxr6Eop7CyBipYGIiIb-l9GZ7OqXDE6YVddU16s=YPvmiG2s2Sq1-Fk1pKOVQQJDRtboAKtS4sc=VLF1B71FPyYn_xNmq3I-koqs55oA=yWClSZWtYohT7k9thStjKEtR9sWQ_A15-JbEtokbBZDdkyHxf3GNV2ltByXLMl_LKnw5VuLDtvHRFtc7MinbWPqQ9bxEvnpH_kFCT-hOcs6fuEPbhckb3-q9PLU=n3T3T-GqFFsFOGplVBpqGj5CwJfyw6OMPCwVw23WWQHvgihM6qyxtk5oV1vZD3pfM2DfgU5-Qk12TII-9q1KbYzIPQvjxql_KwxkszmQD0QfIqdD-xQBDfRO=Nt1d91GQi2I=cLKioxhEh=8PI678eS3VPkF7nPpECPJubFgdgQG4cBAkRQG0uDlR_0lf9RWkNPVWs8TC4u0cxDcBS=kkbGoqlzsbXKZV4tiA3euYt0SKbXHvvNSI1pAwqk2PUpM5Pe5KcrOI_LBXMD78NX07Isd9t4W3YhD=YFWK0qJEqmsu3W7iFAByn8rtYmisQPyLLWZwW0-c_iQDmCdA2-KqQQ0WASfp7CtP1jiusuQcUZThj31mRGhvnkusbPpnGARA4_b0BCxyg0cVjNkLi4bwRxvMOjqWcCeB=dSZ7onEUyEuKecc4vH7HJAoMncfLpmgeV=90q4RQe6G1Jim-rwsoLnYpmPcHwztNQSVHfktiBHntyUrf2i2QCgzwHLE8XWkHgwzeymogyR2bhjVVsfwdlVA3JgjmxllTtJ115GlRbMDPVQF4DeeFhzKNXONxR500kGPzltCfRNFCrCbVeA9AkiqlZ_=sfnGK0Z6NwA9JGsth4ZjvluhIGYhZ6Lp84vFOfXQ0OfbUcgnOSCjybP=gA324CTebW=x7tOmrMRA9cWbitWBtJIQ3GNC76tABSL=c0Tt3uZ9DGW6ADR67zBzXVGjcTB-Kj_qVN50n5NUwDwmhfXM0euycMyup1mF98TrMIdcQSnzdj9SLA4i7EuEVN=FZ4Z1b95rjKjyI0kkMF05g5VPnwQG0ENW0RMu3OWWAqODw70GbTfFcjH-R66O8_w4giMHtoNsqB217EDN2glG_IH3=KYCAWlhyvqZWosHg-rkooGNvuUWeMA7iLoDZTeMbfTnqzEpS3-dhbPyf4IjRPqYlo5JjNmJPBXt-=BOGu0SHf=KS1WcbKQUObMIFpFtSZwmHqJMn3yfm-yfkE7hv8YyuDfImKKoF9UpMmMdFh7UXHo1evKJAMdD2niH85rN2-qnLwC28M3h5qSuFUT4Bju_kBFkDmNGndpn-DocHPk1bT0uTAKBSHLC9uTJqx_2VXY=qHwqiC8=VpoOceX3VW9z7PGL_j=rq78e43zQlBL=mJIic8rlKhOi3fKzLQX5BptOTpvJqR13Gi60sQxzqYnm7ZQW-9HFXfpZGoGkJT7cLnR5gLU=HvszIT2gK1sbwUXw_0OpB6G5CCJGpt=y18K956vh77ckTvOSzM5xjUjvNm1kBOkDq_kI0_cGKLwlEw1jhWfLQ6q_7yAUXVkozMh=fgELEMEpS2okSG7ZJetwMBUcQcnNhyTgFUViHqi8xJ9edgvlvlX13E7WHXccI8CoJZR6jbV0DBMZ5RzY=icHLVo8PUjWOsrdKc9owP98-2_4SmAE1UFIUX57HK0c61ZmL6zss-__fFcG=i=PzLNtj2WIsrTncg933dJwO5=Tqnh6n0BqvgOOyhT8oMdmhO77zjU9c5ct0QCdsrHREQY-HKxQLFRguUi5Fp1uCQKj3XItUIIBFp2sbnwwqHRUP=sNcHkFTtR=WcNsTwDsCw88YA7i5JEA-SviJkYTFNBzLD=xwLH67g=MSACPlqUSb4Szpu79vq=mC1eCS5OgHbPVsVG3dXDEJXxd1-79wE5UGS5f-XSTUOXs16=C-VsfylMCYQ5Gr516UhTIWJQ3SQAVkVJnvldG5XuwuMMo-wUTgc9Y4ctvrxzY8pRNMyT0niZi0RzpUuMuBxjoThQUle=gZVKLI0dXKMtqdevGX-j7XchBBN41iq0PZtoXAE1wWMo4M9ydxilbmiRjw6WbbLC1pS9gCxfSLj9ukJyrhD5XoSOsVEWRJ_TMzlC7mvP-DftcQmL5c3pc1ISs7fYIf8UCpiX0BUPAJsROFUwkK1ucXCtqOsYDiJ8C1p9jC=7_tb5xrNdYerRWf1=gmzMUcj0AFUHD6MHlowx3YWuiCeYKbXCSLTIEYMlvKQdL1u8xK=vVOtlT3nQSefNM_mIMhmzOFDPce-FmPuRSKum1AuM2Omx39BZCi_vqoEfvAFcIAHrU1SBtDLCBe-wE4dyUYrymFrnB-6Y=RXScicKHH5V1I3TPGXk-M-vN4_kWP9RqqX=Yx96nprgzjZw7ydPzY64SqSOZYH357Qb-Oez_ZGoqgJbdG62zQ3hC4BgHl_WmJztnx_qj54WfxbegnNR9LGGxmV3zPmn4pMsFApxiVdZG0pFH8QsfE7GB1iuDm-ZHj3Gu-61ZY66ShF7is5X-B6Myeli-H7=VEE-oy9o8Fs6sdduMqBPL_gbbkVjXhg5CG8cpowrSgXSlxbPr1zLvtHLVkeUg0ZEUSR0vWqFgvAZgpU=79QKKYM1_TW9lDTfRkqNoSoWpFf2NqC0xsfoYjNHsADKBjWOo7pDNP23qHL0G_-Y20=YbyRV-qupUQ3T8gRQ4-4nfunLgHppmASJf3Rv0=l0-j8MxYPo0NNc7i05uVuSNSXf5GhHeZWulNw5KbVkpipWzym1jhB60ch2DExCZZvBIEohG-Kd4ZWWhdxEjGwsJnHxDNriLhtJ1t714Lyd6OeqLF=KfWJlP76L0cBC6KdC79m4CbJf01Ef-TtcqRzoe4A3lW3-D0_QHB-vus7VcGMS4XgVodJQXPYVjQZSXdUc1Weg9=V6_x9f3whBRnV=kTfxomRgE23K4s7nyxrHfsSPf1O0uVF9TD5UljLbKO7rksNy4-2sGWbPYw8WssEkJFQqTsfTYX-NmxpQqYvQ8jZH1Lb47QkRKqCJdhcR7D8B5v4r_WF20VNzEUw99h8jXIEbfjXF5-KgFtf8YhGw3VRLKiqdUwSqdiN0P3LNMf16iTlkB4v34dwfpWTTrkGCupygDsJiHN");
            request.AddHeader("referer", "https://www.metrobyt-mobile.com/payment");
            request.AddHeader("mdn", number.ToString());
            request.AddHeader("content-type", "application/json");
            IRestResponse response = client.Execute(request);

            string mycontent2 = response.Content;
            //if (response.IsSuccessful)
            //{
                if (mycontent2.Contains("true"))
                {
                   

                    return ("number is good");

                }
                else
                {

                    return "Error: " + mycontent2.ToString();

                }
            //}
            //else
            //{
            //    return "Error: Metro backup API is off " + response.IsSuccessful;
            //}

        }
        [AcceptVerbs("GET", "POST")]
        [HttpPost]
        [Route("api/products/paymetro/{amount}/{number}/{cc}/{metrocc}/{cvv}/{expDate}")]
        public async Task<string> MetroBackUpPayment(string amount, long number, string metrocc, string cc, string cvv, string expDate)
        {

            MetroFastPayLibrary.MetroPCSSecurity oMetroPCSSecurity = new MetroFastPayLibrary.MetroPCSSecurity();
            //oMetroPCSSecurity = oUserDAO.RetrieveMSbyA();
            oMetroPCSSecurity = oUserDAO.GetAllX49exvsbl();

            string ZIP = "33415";

            var client2 = new RestClient("https://www.metrobyt-mobile.com/api/v1/billing/payment/authorize-anonymous");
            var request2 = new RestRequest(Method.POST);

            request2.AddHeader("postman-token", "d3b6a44d-37da-edc5-61e6-57865347cff9");
            request2.AddHeader("cache-control", "no-cache");
            request2.AddHeader("referer", "https://www.metrobyt-mobile.com/payment");
            request2.AddHeader("mdn", number.ToString());
            request2.AddHeader("content-type", "application/json");
            request2.AddHeader("x-7xh4mcgiye-a", oMetroPCSSecurity.a);// "ANuFt8xTVlHz1WjqgwDIaSO-Eqo-kHh5-wA-vHBf9mQ5Dvtw3dt-kwoMi8wwAEoMAUYNgHnqamSM_qHxolEJYEDwIJdnasa4LO9MmTuwhGkcVVx5oSJA88iM_USJ8lGcEPRZ-pz=A=aMwznJL8iFTqcwYlv=kwF=k29q2GdzIbjwtmouo8xWgoHxg8xZtNxXANoJ5S8ktVxy3qxO-2rZnxkkLo-egoTquGWZ_VoQAXXMwxjQYk9--bYwhvH6iqu5wlKJTUdywJG5Y24rkf-1AvjWlMLWl7X=_EjqAYor1SSMgsxZakQyYbEMkEowjBwGuNxBwjLHfNDQABjqg26_EChxa5f-pmSqzCLWycMwwUi=hBDHklrTA2LGDg1qaMiGgHL_k2Gy39aPuY4feJdWa8ix3bLFYTx-A23fINHcTqkygHLZk4qquNHv3=J6jztQkEYxwYjJQBiGYEx=hGhfN2GWi4t-54xqgwHGumwI_YH8tVxbwwKMwEUJ-cOJkswfabiwuRLmtVfZ_8sJulvxk2KMn2zfv46v_ChNaMiwhhxqawDoksj8EqnWxwYwk2L=3BuEwxx5sOHXrsM5AgowpzsM3WhfSgD=pYxxRS9quzxxv2EfNBjGAHQ5A=Oq3JkM-9QFAkBMIHi9-2gIuzL5wYxaAc9w_c9kksDfilQ=3MMm-3Qy_Mwh8BOQVsYx3QQH-oxTET2JioL9hBLFioHymvxq-9Q6uOD=Evbp-zxbVz4MGEoqAFxug8wM_cQUuldtjq_Yh8xFis9wLoTq-Nxy9ZkFaC=fAYD4Tax5EgHFhPtvuU4=zJBMnvoMuLDWm3Q-uWLznNfrx2OJao_m-sEE-xxWTfw4aULanYFv3NsMAU1=uVHqxUdFuTw2LBDO_mr6AbeJh8sMwMowgwyJSvnFkHOQgw9CnhsfuVsqECdb3CEGV2QEhCHt_Yxapsx5mbYvATxfalHFga-w_j9-TXyZgsHqf5xWmlrsk8xNaKGNo8xxILdWnVDZ32j6-otMlsLQ88xyulLGaTxO-2H539nFwWwhiHO_-sx6_VoQawH5GM4M_oYYzgH=gfWWvlc-i2z5-WhwulB--8xywxGyh9OMkq3fEgT2Vcax3CLfjCrvLlSfaHYvm2M4uldPTzvo_kHW3vIo=VDtwV48AGd5A5x=hPZwf2r-kmwwEBEMYpM-_mWXumx=v8o-Tw4xtlLH1=9Qac9ln4w1hdkqg22Mg9aMugoM-mSJ3-LX-fxWucMZa24OnCzNElEQLqDHhCdXpBDJ3M1li2nX-2-x3gwtifr53Udag2KMupivg26fVuX2A=nwhv4fnH3wcpDzkwx=ECL53Xkw3fwMe8xNAC45VlLIisXGa29MuIyw3=nG-sbQdXZsjCvM_EjvT4DrvU1s5onQAzcJFGT=-uuq_l3=uoTMeEGUa2Housi9go_p-4dXa8oJfwIBYNyOTsT4LBUrLBx5aUGUAVx6R=axg21FaVD55Y4xh2Zfs8ixL3iMHHi1AhDWLCXyL4s--EjmTMTMLXivu3cM341WuTD=ubTHg8fwgaHQ53yXeL9rw=a5YFDxAlKfw=OqbgHEpdiv_LcQuM4MYYKMwHSQlwOw-ELIuVxQnNx_psQFTHMj3=Q8pVwvwvyH1bT-hCn=YLbJ_jz1mcaYavR7i2zog2FE-woMYEOq_LxHulDEwLhw5T_vhgxcaN45umX5_EjW_X4o4UFvAbjZisaIjcd6-9Q5wVxc31LaEqtMuEeWkcnqisTM-3xF5VxEElF1g2GWkmwq-MXlYVo-L5xD-fwIuYBzEqWXwCFfwTEqwEY4e24I_GSwi8xaV4HHpCuQYEb-xaDWAo9hq1aMw2HxhvsMEgf2jEDWEGTMLCdW-oxQk8_vxbQ6hFkvw2dqTvw1Tzu=E5xZAUawa4x6k2TouX9--wHeg9avkLkNu3o-ox=Jk4IM-N9fYUKJ=VwVw8oM1S9MkwWQ42dcwoxZhgw-goxQvsT--2c-Eqwxpzxyj8edtCLIT82J3MsM1Uv8Lmxx_VxZxo4=ezvMhCHX_YDZhvx=tX1c_VDN3otwYSOe-8o-hSAqAziCuTZ4a8tJ_gwxYTxZkoOMwHny3vsJuEjNkfWQAwHxabjH-2WN_66WhvH=voHsrJKz-R3w-4sMtB9Mx29qAC46k2s-gnQGw4i5wqjsAELFw2LxvHjtL5WyuXwMtsnWLaEqLBLWg2Kqvow=-UzMwejFuMdXuI_4pc9Qa9Qyuc1ypc9Mg2mOBEnTifxruTDZg21quVxqg99jY3L6T2HkAF1Rgexoi9QNz9Mf3Uj53JoKECEYSCWwVOoJ-sMGuCbqV2ru_W_MwT8dll4yklQZi2A-_YDEhqivYoDC-fK-i2rru24vagxLk9nFksYwtNDpl9nF5l-Hwbiqoio-YZxfi4EgLsJQhCrawltQaWdsLSnF3=a=-2WIw3jY7mKQtNi=k49MLcoM_goHnZiCjHd1-2ED79MvaNDc-lSMkfx6T5xxYL3qJM9M-2swu5-d88tChFnb_JoMvlLv_mxF_UbowMa=3=AMumBMfgxs4sWEwUHzw2LH-mwwASMMesLFe4dFT4Ws-axzzv4w3wbMa2uZz9QN-aoQrXXtELG5AFiM-9QUasTeVonFu3x9a9nNukjWhCrEaOkUuTsraaQ5hgtJ3Zi4-EY3_1AujBe7uExzuYxr-9x53JwwAFjcaLk5EVw5glnJh5oYu8xvv2LQvXLDV2CJl2dxtCFi-2QXm=MxaC-4fL9MpYH=LGhfAhOMEFtqV8Hya2vzEIxEalssisoMhCtwi4LWuoxY1F6Gyv4Mi2KqjF4Shhrwk2QWostMvfdcobmZfoDeEPxWLBn=nl4ohBoqIM453OHyjmoqfNxVAJwj3Jx5u6QykwHSkooMTwINhFfJinyctvi4ulOd_mwf-mrZulLiuZjOFB_xu8xF29_4_Snz8FVJhCPzYHD_Egoq-a4f-4DUANwFgwjWIMIGkOoSuEiwIJG-hSMN-wfJA2tqdWSqDJxXtF6Qks9wuExW1WX_hFoMwNxWhvxrAOkywlzMPNA-_YnX5c9M-VyRgHFqk=nf-8DQlfxN2THsAJdz-HLFuYHNhqxq5HaMhBT-hSOMifoOLrHrAgx6jcash9vBu2DHkLdrv2LLxatqk8sM-Hb2_lLXLsjTisLc4TYM-4wM-4oqlbEqAC_MtXLJaXGE-lbMaLSQ=bYy3MHCL8wf-VxWuYTVylOMYYHL_VDUuYsMiffKk4QO-oxNesi=wwDHhBtqjz1tAFrHYCH=A28UhCnW-wT-ogHxpWd8v4vFY2YThhbJ3NfMpWdynCntwFLW3992-ax8EBoMVmQG_Vic-w6WV2dWjHdqezXMa4vMa84VnCKzaYa5_MQi_TsM_YxQg2uqkbi51lWQ4LhxhvHEx=9QTfWZTgxqtq_M_CSMv9nHhB9QvsY6nfGckHdX-fwB-akW-lzouliM-9nahqAv_5dQnNxL-2jsAbDaKTwu4oiMLG31VmM=w4zye=Qv-w9iACWtAEz4_JhfoYDseoDpn8w5kOixA2abmCKqhGSOgopJhBYqnMHF_TQQgw4syYTwhSwMA=M7SWtMi8wMh1QBtBtMsz=MTbpJAhA-pYHHgfJJiHhMi2L83OiFAOLF-2LO3UjQ-TH53sx-fULo-lLzuoxzhhNTwUEwaHax-9azpV4MhFEMaqxlASQx3MG7jJxvulE-_vH=lNspLCh=qsiMklsQkHSMaoaxaGE-_TuZa8iYVww583DclCv5ksXjwCSR-2rtgf-xawdNxsjXuYzw3NoMwM4vhFc-Yc9qj5bwwZiIAqIxVEcMvaoQ_z2RTgDGY2MfLsz45mdxkYjbkf3vkldHYmMvM8oM3qtM_Fu52CWZhvjQjVwRvULv_=avaCXqh5oM_OtMxmwfoMayESnWpgxJTSnWjmxqofOJuEz=VYxLvNwq_Us-1voQ5BtxnzHQp2rC3Wja_c9yemKst2KqA4E-AC9q9WyHTCKwAbDc1UKqLCr8-2hxvbtX-8w9Ehwi2fxyESaMSCq-vwQ7YVoMEZxQTsDNYlbx-cMM-cQ_-2EwuLhvEq_vwwHv-C-MuzLFumolEq6LaXHW_mfJ4vs-i9nXLfw1ECLs-sDwi2Wsust-hgxFtvWbAbDwi2XwDVxFhvwe3BWZ36iveWzFjEDO3Zx5ECzvYGnwEhyEuTsQ-oQH3WWaYULP_UhfV4HQpB8JuUzM-2hx3UiMgT8ICMDpLgwM_lz5azE-uYjOYHDvplWX3CLQ3MjFHmoqkw1pYcnya2_M_TDvtGSqeljFzF19mwwwu2uGzFLZ_Bjx-Hd5AvDFTYoZA9QF_Czf-8D6ieDaLo8K_S9qg26=k2Wsg2XYAgoM_2iP-wolaLk-3go-jVsQfC9MwmMqEPD=LLumACrcT9a=tBDVh5-M-eQcwGdmtULvwzE-YL-viwxyklgW-24MiawwECdUh8o-mgxFIX1WnbTwaSawhF65-B9qzqxWEvwMTOxWhPD=dOfOhUtwaVw5vO4=-2tQVTnWq=axl2BQEhbxnSM4wotQ_lLFA4kFARDBfgtqifomuzDFmYsUV46WA4afi29HustqaUEMk9ax3CB-plTw3U6tEEjXfNxm3X6Zn9IBEbtfgVHbhv4oy2SvjVxcbFcutVxwESSMnS9f-QKf");
            request2.AddHeader("x-7xh4mcgiye-b", oMetroPCSSecurity.b);// -vua40
            request2.AddHeader("x-7xh4mcgiye-c", oMetroPCSSecurity.c);// "A1H9CpNpAQAAwgoDTjdI-YLmksG1yqG39moTIEiq5M-XO1lUYHZbBzQarQNMAawUMfHhpsaNwH_zwTJd7LutHQ==");
            request2.AddHeader("x-7xh4mcgiye-d", oMetroPCSSecurity.d);// "0");
            request2.AddHeader("x-7xh4mcgiye-f", oMetroPCSSecurity.f);// "0");
            request2.AddHeader("x-7xh4mcgiye-z", oMetroPCSSecurity.z);// "0");
            request2.AddParameter("application/json", "{\"emailAddress\":\"9874559@gmail.com\",\"marketingPreference\":false,\"paymentDetails\":{\"amount\":\"" + amount + "\",\"confirmationEmailAddress\":\"9874559@gmail.com\",\"isDebitPreferred\":false,\"paymentType\":10,\"sensitiveAuthorizedCardInfo\":{\"cardNumber\":\"" + metrocc + "\",\"firstName\":\"" + GenerateName(5) + "\",\"lastName\":\"" + GenerateName(6) + "\",\"expDate\":\"" + expDate + "\",\"verificationCode\":\"" + cvv + "\",\"zipCode\":\"" + ZIP + "\",\"cardBrand\":\"MC\"}}}", ParameterType.RequestBody);
            IRestResponse response2 = client2.Execute(request2);
            response2 = client2.Execute(request2);
            string mycontent2 = response2.Content;
           if(response2.IsSuccessful)
            {
                if (mycontent2.Contains("billingConfirmationId"))
                {
                    string conf = getBetween(mycontent2, "billingConfirmationId\":\"", "\",\"convenienceFee");

                    ////capture IP
                    //Payment oPayment = new Payment();
                    //oPayment = oUserDAO.RetrievePaymentbyConfID(conf);
                    //oUserDAO.InsertIP(oPayment.UserID, GetIPAddress(), oPayment.ID);

                    return ("Success:{Confirmationid : " + conf + "}");

                }
                else
                {

                    return "Error: " + mycontent2.ToString();

                }
            }
           else
            {
                return "Error: Metro backup API is off";
            }
           
        }

        async System.Threading.Tasks.Task BoostBackUpPayment(string amount, string ZIP, long number, string thecc, string name, string expDate, string thecvv)
        {
            _Client = new HttpClient();
            _Client.DefaultRequestHeaders.Accept.Clear();
            _Client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            BoostData data = new BoostData(Convert.ToDouble(amount), ZIP, number.ToString(), thecc, name, expDate, thecvv, HttpContext.Current.Session["taxid"].ToString());

            var myContent = JsonConvert.SerializeObject(data);
            var buffer = System.Text.Encoding.UTF8.GetBytes(myContent);
            var byteContent = new ByteArrayContent(buffer);
            byteContent.Headers.Add("Content-Type", "application/json");
            byteContent.Headers.Add("applicationId", "OWO");
            byteContent.Headers.Add("consumerId", " ");
            byteContent.Headers.Add("messageId", "sjmyY7Qe");
            byteContent.Headers.Add("enterpriseMessageId", " ");
            byteContent.Headers.Add("conversationId", "PROD");
            byteContent.Headers.Add("brandCode", "BST");

            var response = await _Client.PostAsync("https://aka-apiservices.boostmobile.com/api/prepaid/payments/1.0/accounts/" + number + "/guest/funds/creditcard", byteContent);
            HttpContent content = response.Content;
            string mycontent3 = await content.ReadAsStringAsync();

            if (response.IsSuccessStatusCode)
            {
                string s = response.Content.ReadAsStringAsync().Result;

                if (s.Contains("billingConfirmationId"))
                {
                    string conf = getBetween(s, "billingConfirmationId\": \"", "\",\n    \"externalId");
                    HttpContext.Current.Session["conf"] = conf;

                    //capture IP
                    Payment oPayment = new Payment();
                    oPayment = oUserDAO.RetrievePaymentbyConfID(conf);
                    oUserDAO.InsertIP(oPayment.UserID, GetIPAddress(), oPayment.ID);
                }
                else
                {
                    HttpContext.Current.Session["Error"] = "Error: No payment made";
                }
            }
        }
        [HttpGet]
        [Route("api/products/getpayment/{id}")]
        public IEnumerable<Payments> GetPayments(string id)
        {
            try
            {
                if (id.Contains("-"))
                {
                    id = id.Replace("-", "/");
                }
                if (id.Contains("plus"))
                {
                    id = id.Replace("plus", "+");
                }
                string therealid = DAO.Decrypt(id, ConfigurationManager.AppSettings["encryptionKey"]);
                string userid = getUserNamebyID(Convert.ToInt32(therealid));
                User oFee = new User();
                oFee = oUserDAO.RetrieveFeebyUserID(userid);
                Payments[] aryPayments = null;
                using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString()))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = conn;
                        cmd.CommandText = "SELECT Post, UserID, PhoneNumber, Provider, AmountPaid, CreatedDate FROM Payments where UserID = '" + userid + "'";
                        conn.Open();
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            List<Payments> lstPayments = new List<Payments>();
                            while (reader.Read())
                            {
                                lstPayments.Add(new Payments
                                {
                                    Post = reader["Post"].ToString(),
                                    UserID = reader["UserID"].ToString(),
                                    ClientNumber = reader["PhoneNumber"].ToString(),
                                    Conf = reader["Provider"].ToString(),
                                    AmountPaid = Convert.ToInt32(reader["AmountPaid"]) - Convert.ToInt32(oFee.Fee),
                                    DatePaid = Convert.ToDateTime(reader["CreatedDate"])
                                });
                                aryPayments = lstPayments.ToArray();
                            }
                        }
                    }
                }
                return aryPayments;
            }
            catch (Exception ex)
            {
                Payments[] error = null;
                return error;
            }
           

        }

       

        [HttpGet]
        [Route("api/products/getcredit/{id}")]
        public string GetCredit(string id)
        {
            try
            {

                if (id.Contains("-"))
                {
                    id = id.Replace("-", "/");
                }
                if (id.Contains("plus"))
                {
                    id = id.Replace("plus", "+");
                }
                string therealid = DAO.Decrypt(id, ConfigurationManager.AppSettings["encryptionKey"]);
                string userid = getUserNamebyID(Convert.ToInt32(therealid));
                using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString()))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = conn;
                        cmd.CommandText = "SELECT Credit FROM Accounts where UserID = '" + userid + "'";
                        conn.Open();


                        if (cmd.ExecuteScalar() != null)
                        {
                            return "Credit: $" + cmd.ExecuteScalar().ToString();
                        }
                        else
                        {
                            return "Error: Access denied";
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                return "Error: Access denied";
            }

          
        }

        [HttpGet]
        [Route("api/products/getBoostPin/{number}")]
        public async Task<string> GetBoostPin(string number)
        {
            try
            {
                HttpClient _Client = new HttpClient();
                _Client = new HttpClient();
                _Client.DefaultRequestHeaders.Accept.Clear();
                _Client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                RetievePin data = new RetievePin();

                var myContent = JsonConvert.SerializeObject(data);
                var buffer = System.Text.Encoding.UTF8.GetBytes(myContent);
                var byteContent = new ByteArrayContent(buffer);
                byteContent.Headers.Add("Content-Type", "application/json");
                byteContent.Headers.Add("applicationId", "OWO");
                byteContent.Headers.Add("consumerId", " ");
                byteContent.Headers.Add("messageId", "sjmyY7Qe");
                byteContent.Headers.Add("enterpriseMessageId", " ");
                byteContent.Headers.Add("conversationId", "PROD");
                byteContent.Headers.Add("brandCode", "BST");
                byteContent.Headers.Add("messageDateTimeStamp", string.Format("{0:yyyy-MM-ddTHH:mm:ssZ}", DateTime.Now));

                var response = await _Client.PostAsync("https://aka-apiservices.boostmobile.com/api/prepaid/1.0/accounts/" + number + "/retrievepin?idField=mdn", byteContent);
                HttpContent content = response.Content;
                string mycontent3 = await content.ReadAsStringAsync();
                if (response.IsSuccessStatusCode)
                {
                    string s = response.Content.ReadAsStringAsync().Result;


                    if (s.Contains("SUCCESS"))
                    {

                        return "Text sent to customer";

                    }
                    else
                    {
                        return "Number is not correct";
                    }

                }
                else
                {
                    return "Not a Boost number";
                }
            }
            catch (Exception ex)
            {
                return "Error: Access denied";
            }

        }

        private static string getBetween(string strSource, string strStart, string strEnd)
        {
            int Start, End;
            if (strSource.Contains(strStart) && strSource.Contains(strEnd))
            {
                Start = strSource.IndexOf(strStart, 0) + strStart.Length;
                End = strSource.IndexOf(strEnd, Start);
                return strSource.Substring(Start, End - Start);
            }
            else
            {
                return "";
            }
        }

        private static string GenerateName(int len)
        {
            Random r = new Random();
            string[] consonants = { "b", "c", "d", "f", "g", "h", "j", "k", "l", "m", "l", "n", "p", "q", "r", "s", "sh", "zh", "t", "v", "w", "x" };
            string[] vowels = { "a", "e", "i", "o", "u", "ae", "y" };
            string Name = "";
            Name += consonants[r.Next(consonants.Length)].ToUpper();
            Name += vowels[r.Next(vowels.Length)];
            int b = 2; //b tells how many times a new letter has been added. It's 2 right now because the first two letters are already in the name.
            while (b < len)
            {
                Name += consonants[r.Next(consonants.Length)];
                b++;
                Name += vowels[r.Next(vowels.Length)];
                b++;
            }

            return Name;
        }

        public int getPreviousPayment(string nummber)
        {
            using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString()))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                cmd.CommandText = @"select COUNT(*) from payments where PhoneNumber = '" + nummber + "' and createddate between  DATEADD(day, -3, CONVERT (date, getdate())) and getdate()";
                int tnumber = Convert.ToInt32(cmd.ExecuteScalar());
                return tnumber;
            }
        }
        public void OldTextAndEmail(string subject, string body, bool textBraley)
        {
            try
            {
                ServicePointManager.Expect100Continue = true;
                ServicePointManager.DefaultConnectionLimit = 9999;
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12 | SecurityProtocolType.Ssl3;
                MailMessage message = new MailMessage();
                SmtpClient smtpClient = new SmtpClient();
                string msg = string.Empty;

                MailAddress fromAddress = new MailAddress("info@telbug.com", "TelBug");
                const string SERVER = "smtp.gmail.com";
                MailMessage oMail = new System.Net.Mail.MailMessage();
                oMail.From = fromAddress;
                if (textBraley == true)
                {
                    oMail.To.Add("5612012168@mymetropcs.com, 5616674346@mymetropcs.com");
                }
                else
                {
                    oMail.To.Add("5612012168@mymetropcs.com");
                }

                oMail.Subject = subject;
                oMail.IsBodyHtml = true;
                oMail.Body = body;
                smtpClient.Host = SERVER;
                smtpClient.Port = 587;
                smtpClient.Credentials = new System.Net.NetworkCredential(DAO.Decrypt(ConfigurationManager.AppSettings["Email"], ConfigurationManager.AppSettings["encryptionKey"]), DAO.Decrypt(ConfigurationManager.AppSettings["pass"], ConfigurationManager.AppSettings["encryptionKey"]));
                smtpClient.EnableSsl = true;
                smtpClient.Send(oMail);
                oMail = null;// free up resources

            }
            catch (Exception ex)
            {
                oUserDAO.LogError("Portal TexT Error", "5616674346", "0", "Twilio Emails are failing, fix asap Braley");
            }



        }
        public void TextAndEmail(string subject, string body, bool textBraley)
        {
            try
            {

                var accountSid = "ACf68d6c4ff981f1ff8962f266f81ced48";
                var authToken = "6550fa15290f0b119b3a4ab7466200f9";

                TwilioClient.Init(accountSid, authToken);

                if (textBraley == true)
                {
                    var message = MessageResource.Create(
                   from: new Twilio.Types.PhoneNumber("+15612204243"),
                   body: subject + " - " + body,
                   to: new Twilio.Types.PhoneNumber("5616674346"));
                }

                var message2 = MessageResource.Create(
                    from: new Twilio.Types.PhoneNumber("+15612204243"),
                    body: subject + " - " + body,
                    to: new Twilio.Types.PhoneNumber("5612012168")
                );
            }
            catch (Exception ex)
            {
                oUserDAO.LogError("API Text Error", "5616674346", "0", "Twilio Emails are failing, fix asap Braley");
            }

            //MailMessage message = new MailMessage();
            //SmtpClient smtpClient = new SmtpClient();
            //string msg = string.Empty;

            //MailAddress fromAddress = new MailAddress("info@telbug.com", "TelBug");
            //const string SERVER = "smtp.gmail.com";
            //MailMessage oMail = new System.Net.Mail.MailMessage();
            //oMail.From = fromAddress;
            //if (textBraley == true)
            //{
            //    oMail.To.Add("5612012168@mymetropcs.com, 5616674346@mymetropcs.com");
            //}
            //else
            //{
            //    oMail.To.Add("5612012168@mymetropcs.com");
            //}
            //oMail.Subject = subject;
            //oMail.IsBodyHtml = true;
            //oMail.Body = body;
            //smtpClient.Host = SERVER;
            //smtpClient.Port = 587;
            //smtpClient.Credentials = new System.Net.NetworkCredential(DAO.Decrypt(ConfigurationManager.AppSettings["Email"], ConfigurationManager.AppSettings["encryptionKey"]), DAO.Decrypt(ConfigurationManager.AppSettings["pass"], ConfigurationManager.AppSettings["encryptionKey"]));
            //smtpClient.EnableSsl = true;
            //smtpClient.Send(oMail);
            //oMail = null;// free up resources

        }

        //protected string GetIPAddress()
        //{
        //    System.Web.HttpContext context = System.Web.HttpContext.Current;
        //    string ipAddress = context.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];

        //    if (!string.IsNullOrEmpty(ipAddress))
        //    {
        //        string[] addresses = ipAddress.Split(',');
        //        if (addresses.Length != 0)
        //        {
        //            return addresses[0];
        //        }
        //    }

        //    return context.Request.ServerVariables["REMOTE_ADDR"];
        //}
        protected string GetIPAddress()
        {
            System.Web.HttpContext context = System.Web.HttpContext.Current;
            string ipAddress = context.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];

            if (!string.IsNullOrEmpty(ipAddress))
            {
                string[] addresses = ipAddress.Split(',');
                if (addresses.Length != 0)
                {
                    return addresses[0];
                }
            }

            return context.Request.ServerVariables["REMOTE_ADDR"];
        }
        public int getPreviousPaidPayment(string nummber)
        {
            using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString()))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                cmd.CommandText = @"select COUNT(*) from payments where PhoneNumber = '" + nummber + "'  and LEFT(Provider, 6) <> 'SinPin'  and createddate between  DATEADD(day, -3, CONVERT (date, getdate())) and getdate()";
                int tnumber = Convert.ToInt32(cmd.ExecuteScalar());
                return tnumber;
            }
        }
        public int getPreviousPaymentAmount(string nummber)
        {
            using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString()))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                cmd.CommandText = @"select AmountPaid from payments where PhoneNumber = '" + nummber + "'  and LEFT(Provider, 6) <> 'SinPin'  and createddate between  DATEADD(day, -1, CONVERT (date, getdate())) and getdate() order by CreatedDate desc";
                int tnumber = Convert.ToInt32(cmd.ExecuteScalar());
                return tnumber;
            }
        }
        public string CCLeft()
        {
            using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString()))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                cmd.CommandText = @"select count(used) from CC where active = 1 and SUBSTRING(FirstName, 1, 1) <> 'P' and SUBSTRING(LastName, 1, 1) <> 'A' and SUBSTRING(FirstName, 1, 1) <> 'D' and SUBSTRING(LastName, 1, 1) <> 'B'";
                string Count = cmd.ExecuteScalar().ToString();
                if (Convert.ToInt32(Count) == 5)
                {
                    TextAndEmail("5 MetroPCS cards left in the system", "Add more cards into the system", false);
                }
                return Count;
            }
        }
        public string BoostCCLeft()
        {
            using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString()))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                cmd.CommandText = @"select count(used) from CC where active = 1 and SUBSTRING(FirstName, 1, 1) = 'P' and SUBSTRING(LastName, 1, 1) = 'A'";
                string Count = cmd.ExecuteScalar().ToString();
                if (Convert.ToInt32(Count) == 5)
                {
                    TextAndEmail("5 Boost cards left in the system", "Add more cards into the system", false);
                }
                return Count;
            }
        }
        public string CricketCCLeft()
        {
            using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString()))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                cmd.CommandText = @"select count(used) from CC where active = 1 and SUBSTRING(FirstName, 1, 1) = 'D' and SUBSTRING(LastName, 1, 1) = 'B'";
                string Count = cmd.ExecuteScalar().ToString();
                if (Convert.ToInt32(Count) == 5)
                {
                    TextAndEmail("5 Cricket cards left in the system", "Add more cards into the system", false);
                }
                return Count;
            }
        }
        public async Task<string> DPandGuatePinRecharge(string user, decimal provideramount, int offeringid, string phone)
        {
            try
            {
                Payment oPay = new Payment();
                oPay = oUserDAO.RetrieveLastPayment(user);
                User oDisUser = new User();
                User oFee = new User();
                oFee = oUserDAO.RetrieveFeebyUserID(user);
                if (oPay.AmountPaid == 204 && oPay.CreatedDate.ToString("dd/MM/yyyy") == DateTime.Now.ToString("dd/MM/yyyy"))
                {
                    oDisUser = oUserDAO.DisableAccount(user, false);
                }



                //recharge DP
                TopUpReqType tu = new TopUpReqType();
                TransResponseType ts = new TransResponseType();
                ActivateOrRechargeAccountType af = new ActivateOrRechargeAccountType();
                AccountInfo ai = new AccountInfo();

                using (PinManager pm = new PinManager())
                {
                    ServicePointManager.Expect100Continue = true;
                    ServicePointManager.DefaultConnectionLimit = 9999;
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12 | SecurityProtocolType.Ssl3;
                    pm.Credentials = new System.Net.NetworkCredential(ConfigurationManager.AppSettings["dpUser"], ConfigurationManager.AppSettings["dpPass"]);

                    af.Account = ai;
                    af.Account.Ani = phone;
                    af.Account.OfferingId = offeringid;
                    User getReferral = oUserDAO.RetrieveGuatePinReferral(phone);
                    User getReferrer = oUserDAO.RetrieveGuatePinReferrer(phone);
                    User getPrevRecharge = oUserDAO.RetrieveGuatePinRecharge(getReferrer.ReferralNumber);

                    if (getReferral.ReferralNumber != null)
                    {
                        //referal used / make it true
                        oUserDAO.UpdatetGuatePinReferrals(phone, true);

                        //add a dollar because of referral
                        af.Account.Balance = provideramount;
                    }
                    else if (getReferrer.Active == true && getPrevRecharge.PhoneNumber != null)
                    {
                        //add a dollar because of referral
                        provideramount = provideramount + 1;
                        HttpContext.Current.Session["providerAmount"] = provideramount;
                        af.Account.Balance = provideramount;
                    }
                    else
                    {
                        af.Account.Balance = provideramount;
                    }

                    ai = pm.ActivateOrRechargeAccount(af);


                    if ((ai.TransId > 0))
                    {

                        DateTime start = DateTime.Now;
                        for (
                        ; ((ts.Status == TransactionStatus.Pending) && ((DateTime.Now - start).TotalSeconds <= 180));
                        )
                        {
                            System.Threading.Thread.Sleep(3000);
                            ts = pm.TopupConfirm(Convert.ToInt32(ai.TransId));
                        }
                        switch (ts.Status)
                        {

                            case TransactionStatus.Success:


                                af.OrderId = ai.TransId.ToString();
                                HttpContext.Current.Session["conf"] = ai.TransId;
                                HttpContext.Current.Session["error"] = "";
                                HttpContext.Current.Session["cc"] = "6MJ26xFJGDeR5WNKLVU2MElxAq3lrfqJwpW9Ly8fLlEGl3/zUMrsfbyGVRonHF5G";

                                HttpContext.Current.Session["Balance"] = provideramount;
                                HttpContext.Current.Session["PrevBalance"] = pm.GetAccountInfoByAniOffering(phone, offeringid).Balance.ToString();


                                HttpContext.Current.Session["providerAmount"] = provideramount;
                                HttpContext.Current.Session["phone"] = phone;

                                //update credit line
                                MetroFastPayLibrary.Account oAccount = new MetroFastPayLibrary.Account();
                                oAccount = oUserDAO.RetrieveAccount(user);
                                oUser = oUserDAO.RetrieveUserByUserID(user);
                                if (oAccount.Active == true)
                                {
                                    decimal DPamount = Convert.ToDecimal(provideramount) * Convert.ToDecimal(HttpContext.Current.Session["UserComm"]);
                                    oUserDAO.UpdateAccountbyPost(oAccount.Credit - (Convert.ToDecimal(provideramount) - DPamount), oUser.Post);
                                    //insert payments
                                    oUserDAO.InsertPayments(user, oUser.Post, HttpContext.Current.Session["Phone"].ToString(), Convert.ToDecimal(HttpContext.Current.Session["provideramount"].ToString()), 0, HttpContext.Current.Session["provider"].ToString().Trim() + " - Conf#:" + HttpContext.Current.Session["conf"].ToString(), "6MJ26xFJGDeR5WNKLVU2MElxAq3lrfqJwpW9Ly8fLlEGl3/zUMrsfbyGVRonHF5G", DateTime.Now);

                                }
                                else
                                {
                                    //insert payments
                                    oUserDAO.InsertPayments(user, oUser.Post, HttpContext.Current.Session["Phone"].ToString(), Convert.ToDecimal(HttpContext.Current.Session["provideramount"].ToString()), 0, HttpContext.Current.Session["provider"].ToString().Trim() + " - Conf#:" + HttpContext.Current.Session["conf"].ToString(), "6MJ26xFJGDeR5WNKLVU2MElxAq3lrfqJwpW9Ly8fLlEGl3/zUMrsfbyGVRonHF5G", DateTime.Now);

                                }

                                if (HttpContext.Current.Session["provider"].ToString() == "GuatePin")
                                {
                                    //send recharge sc
                                    await sendShortCodes("https://api.trumpia.com/http/v2/sendverificationsms?apikey=e4d74191b6211d1fc9167ab0b921cc5f&mobile_number=" + phone + "&message=" + HttpContext.Current.Session["provider"].ToString() + " $" + string.Format("{0:0.00}", Convert.ToDecimal(provideramount)) + "\nTu recarga Guatemalteca \nNumero de acceso: 5612291367\nConf: " + ai.TransId + "\n");
                                    //send referral 
                                    await sendShortCodes("https://api.trumpia.com/http/v2/sendverificationsms?apikey=e4d74191b6211d1fc9167ab0b921cc5f&mobile_number=" + phone + "&message=GuatePin- Para recivir un dolar gratis haga clic aqui https://telbug.com/guatepin?ReferrerNumber=" + phone + " para referir a un amigo");
                                    //send sc for the referral 
                                    if (getReferrer.Active == true && getPrevRecharge.PhoneNumber != null)
                                    {
                                        oUserDAO.UpdatetGuatePinReferrals(getReferrer.ReferralNumber, false);
                                        //send short code
                                        await sendShortCodes("https://api.trumpia.com/http/v2/sendverificationsms?apikey=e4d74191b6211d1fc9167ab0b921cc5f&mobile_number=" + phone + "&message=GuatePin- Gracias por referir a un amigo, le dimos un dolar extra en su recarga.");
                                    }
                                }
                                //capture IP
                                Payment oPayment = new Payment();
                                oPayment = oUserDAO.RetrievePaymentbyConfID(HttpContext.Current.Session["conf"].ToString());
                                oUserDAO.InsertIP("API", GetIPAddress(), oPayment.ID);

                                break;
                            case TransactionStatus.Failed:
                                HttpContext.Current.Session["cc"] = "";
                                HttpContext.Current.Session["conf"] = "";
                                HttpContext.Current.Session["error"] = "error3";
                                oUserDAO.LogError(user, HttpContext.Current.Session["Phone"].ToString(), "6MJ26xFJGDeR5WNKLVU2MElxAq3lrfqJwpW9Ly8fLlEGl3/zUMrsfbyGVRonHF5G", HttpContext.Current.Session["provider"].ToString() + "($" + HttpContext.Current.Session["provideramount"].ToString() + ") - " + ts.ErrorCode);
                                break;
                            case TransactionStatus.Pending:
                                HttpContext.Current.Session["cc"] = "";
                                HttpContext.Current.Session["conf"] = "";
                                HttpContext.Current.Session["error"] = "error3";
                                oUserDAO.LogError(user, HttpContext.Current.Session["Phone"].ToString(), "6MJ26xFJGDeR5WNKLVU2MElxAq3lrfqJwpW9Ly8fLlEGl3/zUMrsfbyGVRonHF5G", HttpContext.Current.Session["provider"].ToString() + "($" + HttpContext.Current.Session["provideramount"].ToString() + ") - " + ts.ErrorCode);
                                break;
                        }
                    }
                    else
                    {
                        HttpContext.Current.Session["cc"] = "";
                        HttpContext.Current.Session["conf"] = "";
                        HttpContext.Current.Session["error"] = "error3";
                        oUserDAO.LogError(user, HttpContext.Current.Session["Phone"].ToString(), "6MJ26xFJGDeR5WNKLVU2MElxAq3lrfqJwpW9Ly8fLlEGl3/zUMrsfbyGVRonHF5G", HttpContext.Current.Session["provider"].ToString() + "($" + HttpContext.Current.Session["provideramount"].ToString() + ") - " + ts.ErrorCode);

                    }


                }

                if (HttpContext.Current.Session["conf"].ToString().Length <= 8)
                {
                    string conf = HttpContext.Current.Session["conf"].ToString();
                    string EN = "1-800-608-1305";
                    string SP = "1-888-279-6141";
                    if (HttpContext.Current.Session["provider"].ToString() == "GuatePin")
                    {
                        EN = "561-229-1367";
                        SP = "561-229-1367";
                    }
                    string Balance = HttpContext.Current.Session["Balance"].ToString();
                    string PrevBalance = HttpContext.Current.Session["PrevBalance"].ToString();


                    return ("Success:{Confirmationid : " + conf + "}");
                   
                }
                else
                {
                    return ("Error: No payment made");
                }




            }
            catch (Exception ex)
            {

                return ("Error: No recharge made" + ex);

            }
        }
        async System.Threading.Tasks.Task sendShortCodes(string url)
        {

            ServicePointManager.Expect100Continue = true;
            ServicePointManager.DefaultConnectionLimit = 9999;
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12 | SecurityProtocolType.Ssl3;
            var client = new RestClient(url);
            var request = new RestRequest(Method.POST);
            IRestResponse response = client.Execute(request);
            var my = response.Content;
        }
        async System.Threading.Tasks.Task DPMobilePayment(string user, string provider, string phone, string amount)
        {
            try
            {
                Payment oPay = new Payment();
                oPay = oUserDAO.RetrieveLastPayment(user);
                User oDisUser = new User();
                User oFee = new User();
                User oUser = new User();
                oUser = oUserDAO.RetrieveUserByUserID(user);
                oFee = oUserDAO.RetrieveFeebyUserID(user);
                if (oPay.AmountPaid == 204 && oPay.CreatedDate.ToString("dd/MM/yyyy") == DateTime.Now.ToString("dd/MM/yyyy"))
                {
                    oDisUser = oUserDAO.DisableAccount(user, false);
                }


               
                decimal totalamount = 0;
                decimal provideramount = 0;
                int offeringid = 0;
                if (amount == "")
                {
                    phone = HttpContext.Current.Session["phone"].ToString();
                    totalamount = Convert.ToDecimal(HttpContext.Current.Session["totalamount"]);
                    provideramount = Convert.ToDecimal(HttpContext.Current.Session["provideramount"]);
                }
                else
                {
                    totalamount = decimal.Parse(amount) + Convert.ToInt32(oFee.Fee);
                    provideramount = decimal.Parse(amount);
                    if (provideramount.ToString().Contains("."))
                    {

                    }
                    else
                    {
                        // provideramount = Convert.ToDecimal(string.Format("{0:0.00}", provideramount));
                    }

                    HttpContext.Current.Session["totalamount"] = totalamount;
                    HttpContext.Current.Session["providerAmount"] = provideramount;
                    HttpContext.Current.Session["provider"] = provider;
                    phone = phone.Replace("-", "").Replace("(", "").Replace(")", "");
                    HttpContext.Current.Session["phone"] = phone;
                    offeringid = Convert.ToInt32(HttpContext.Current.Session["offeringid"]);
                }

                //mobile DP
                MobileTopUpType tu = new MobileTopUpType();
                TopUpResp tr;
                TransResponseType ts = new TransResponseType();


                using (PinManager pm = new PinManager())
                {
                    pm.Credentials = new System.Net.NetworkCredential(ConfigurationManager.AppSettings["dpUser"], ConfigurationManager.AppSettings["dpPass"]);


                    tu.Ani = phone;
                    tu.OfferingId = offeringid;
                    tu.PhoneNumber = phone;
                    if (provider.Contains("MetroPCS"))
                    {
                        tu.Amount = Convert.ToDouble(provideramount + 4);
                    }
                    else
                    {
                        tu.Amount = Convert.ToDouble(provideramount);
                    }



                    tr = pm.MobileTopup(tu);
                    ts = pm.TopupConfirm(Convert.ToInt32(tr.TransId));
                    if (ts.ErrorCode == -401)
                    {
                        HttpContext.Current.Session["cc"] = "";
                        HttpContext.Current.Session["conf"] = "";
                        HttpContext.Current.Session["error"] = "error1";
                    }
                    else
                    {

                        if ((tr.TransId > 0))
                        {

                            DateTime start = DateTime.Now;
                            for (
                            ; ((ts.Status == TransactionStatus.Pending) && ((DateTime.Now - start).TotalSeconds <= 180));
                            )
                            {
                                System.Threading.Thread.Sleep(3000);
                                ts = pm.TopupConfirm(Convert.ToInt32(tr.TransId));
                            }
                            switch (ts.Status)
                            {

                                case TransactionStatus.Success:

                                    HttpContext.Current.Session["conf"] = tr.TransId;
                                    HttpContext.Current.Session["error"] = "";
                                    HttpContext.Current.Session["cc"] = "6MJ26xFJGDeR5WNKLVU2MElxAq3lrfqJwpW9Ly8fLlEGl3/zUMrsfbyGVRonHF5G";


                                    //update credit line
                                    MetroFastPayLibrary.Account oAccount = new MetroFastPayLibrary.Account();
                                    oAccount = oUserDAO.RetrieveAccount(user);
                                    int doublepay = getPreviousPayment(phone);

                                    if (oAccount.Active == true)
                                    {
                                        decimal SMamount = Convert.ToDecimal(amount) * Convert.ToDecimal(.045);
                                        if (doublepay >= 1)
                                        {
                                            oUserDAO.UpdateAccountbyPost(oAccount.Credit - (Convert.ToDecimal(amount)), oUser.Post);
                                            if (provider.Contains("MetroPCS"))
                                            {
                                                //insert payments
                                                oUserDAO.InsertPayments(user, oUser.Post, phone, Convert.ToDecimal(amount), 4, provider + " - Conf#:" + HttpContext.Current.Session["conf"].ToString(), "p1U+X7SOkDLpOsgOfuoiwohqtF9Imk4oeifZ+yZ/OroTWqilU8IBxumOYi4Yu1DO", DateTime.Now);

                                                HttpContext.Current.Session["error"] = "Success:{Confirmationid : " + HttpContext.Current.Session["conf"].ToString() + "}";
                                            }
                                            else
                                            {
                                                //insert payments
                                                oUserDAO.InsertPayments(user, oUser.Post, phone, Convert.ToDecimal(amount), 0, provider + " - Conf#:" + HttpContext.Current.Session["conf"].ToString(), HttpContext.Current.Session["cc"].ToString(), DateTime.Now);
                                                HttpContext.Current.Session["error"] = "Success:{Confirmationid : " + HttpContext.Current.Session["conf"].ToString() + "}";
                                            }
                                        }
                                        else
                                        {
                                            oUserDAO.UpdateAccountbyPost(oAccount.Credit - (Convert.ToDecimal(amount) - SMamount), oUser.Post);
                                            if (provider.Contains("MetroPCS"))
                                            {
                                                //insert payments
                                                oUserDAO.InsertPayments(user, oUser.Post, phone, Convert.ToDecimal(amount), 4, provider + " - Conf#:" + HttpContext.Current.Session["conf"].ToString(), "p1U+X7SOkDLpOsgOfuoiwohqtF9Imk4oeifZ+yZ/OroTWqilU8IBxumOYi4Yu1DO", DateTime.Now);
                                                HttpContext.Current.Session["error"] = "Success:{Confirmationid : " + HttpContext.Current.Session["conf"].ToString() + "}";
                                            }
                                            else
                                            {
                                                //insert payments
                                                oUserDAO.InsertPayments(user, oUser.Post, phone, Convert.ToDecimal(amount), 0,provider+ " - Conf#:" + HttpContext.Current.Session["conf"].ToString(), HttpContext.Current.Session["cc"].ToString(), DateTime.Now);
                                                HttpContext.Current.Session["error"] = "Success:{Confirmationid : " + HttpContext.Current.Session["conf"].ToString() + "}";
                                            }
                                        }

                                    }
                                    else
                                    {
                                        //insert payments
                                        if (HttpContext.Current.Session["provider"].ToString().Contains("MetroPCS"))
                                        {
                                            //insert payments
                                            oUserDAO.InsertPayments(user, oUser.Post, phone, Convert.ToDecimal(amount), 4, provider + " - Conf#:" + HttpContext.Current.Session["conf"].ToString(), "p1U+X7SOkDLpOsgOfuoiwohqtF9Imk4oeifZ+yZ/OroTWqilU8IBxumOYi4Yu1DO", DateTime.Now);
                                            HttpContext.Current.Session["error"] = "Success:{Confirmationid : " + HttpContext.Current.Session["conf"].ToString() + "}";
                                        }
                                        else
                                        {
                                            //insert payments
                                            oUserDAO.InsertPayments(user, oUser.Post, phone, Convert.ToDecimal(amount), 0, provider + " - Conf#:" + HttpContext.Current.Session["conf"].ToString(), HttpContext.Current.Session["cc"].ToString(), DateTime.Now);
                                            HttpContext.Current.Session["error"] = "Success:{Confirmationid : " + HttpContext.Current.Session["conf"].ToString() + "}";
                                        }

                                    }

                                    //capture IP
                                    //Payment oPayment = new Payment();
                                    //oPayment = oUserDAO.RetrievePaymentbyConfID(HttpContext.Current.Session["conf"].ToString());
                                    //oUserDAO.InsertIP(user, GetIPAddress(), oPayment.ID);

                                    //if (usesShortCode == true)
                                    //{
                                    //    if (txtUSNumber.Text == "" || txtUSNumber.Text.Length != 10)
                                    //    {
                                    //        lbInfo.Text = "US Number needed";
                                    //    }
                                    //    else
                                    //    {
                                    //        await sendShortCodes("https://api.trumpia.com/http/v2/sendverificationsms?apikey=e4d74191b6211d1fc9167ab0b921cc5f&mobile_number=" + txtUSNumber.Text + "&message=" + HttpContext.Current.Session["provider"].ToString() + " $" + Convert.ToDouble(provideramount) + "\nNumero: " + phone + "\nConf: " + tr.TransId + "\nGracias por usar TelBug\n");

                                    //    }
                                    //}

                                    break;
                                case TransactionStatus.Failed:
                                    if (ts.ErrorCode == -401 || ts.ErrorCode == -400)
                                    {
                                        HttpContext.Current.Session["cc"] = "";
                                        HttpContext.Current.Session["conf"] = "";
                                        HttpContext.Current.Session["error"] = "error1";
                                        oUserDAO.LogError(user, phone, "6MJ26xFJGDeR5WNKLVU2MElxAq3lrfqJwpW9Ly8fLlEGl3/zUMrsfbyGVRonHF5G", provider + "($" + amount + ") - " + ts.ErrorCode);
                                    }
                                    else if (ts.ErrorCode == -404 || ts.ErrorCode == -403)
                                    {
                                        HttpContext.Current.Session["cc"] = "";
                                        HttpContext.Current.Session["conf"] = "";
                                        HttpContext.Current.Session["error"] = "errorFunds";
                                        oUserDAO.LogError(user, phone, "6MJ26xFJGDeR5WNKLVU2MElxAq3lrfqJwpW9Ly8fLlEGl3/zUMrsfbyGVRonHF5G", provider + "($" + amount + ") - " + ts.ErrorCode);
                                    }
                                    else
                                    {
                                        HttpContext.Current.Session["cc"] = "";
                                        HttpContext.Current.Session["conf"] = "";
                                        HttpContext.Current.Session["error"] = "error3";
                                        oUserDAO.LogError(user, phone, "6MJ26xFJGDeR5WNKLVU2MElxAq3lrfqJwpW9Ly8fLlEGl3/zUMrsfbyGVRonHF5G", provider + "($" + amount + ") - " + ts.ErrorCode);
                                    }

                                    break;
                                case TransactionStatus.Pending:
                                    HttpContext.Current.Session["cc"] = "";
                                    HttpContext.Current.Session["conf"] = "";
                                    HttpContext.Current.Session["error"] = "error3";
                                    oUserDAO.LogError(user, phone, "6MJ26xFJGDeR5WNKLVU2MElxAq3lrfqJwpW9Ly8fLlEGl3/zUMrsfbyGVRonHF5G", provider + "($" + amount + ") - " + ts.ErrorCode);
                                    break;
                            }
                        }
                        else
                        {
                            if (tr.TransId == -404 || tr.TransId == -406)
                            {
                                HttpContext.Current.Session["cc"] = "";
                                HttpContext.Current.Session["conf"] = "";
                                HttpContext.Current.Session["error"] = "error1";
                                oUserDAO.LogError(user, phone, "6MJ26xFJGDeR5WNKLVU2MElxAq3lrfqJwpW9Ly8fLlEGl3/zUMrsfbyGVRonHF5G", provider + "($" + amount + ") - " + tr.TransId);
                            }
                            else
                            {
                                HttpContext.Current.Session["cc"] = "";
                                HttpContext.Current.Session["conf"] = "";
                                HttpContext.Current.Session["error"] = "error3";
                                oUserDAO.LogError(user, phone, "6MJ26xFJGDeR5WNKLVU2MElxAq3lrfqJwpW9Ly8fLlEGl3/zUMrsfbyGVRonHF5G", provider + "($" + amount + ") - " + tr.TransId);
                            }
                        }
                    }



                }


  

                //if (HttpContext.Current.Session["conf"].ToString().Length == 8)
                //{
                //    string conf = HttpContext.Current.Session["conf"].ToString();
                //    string EN = "954-414-1955";
                //    string SP = "954-414-1955";
                //    string Balance = "";
                //    Response.Redirect("Splash.aspx?Phone=" + phone.Replace("-", "") + "&datepaid=" + DateTime.Now + "&provider=" + HttpContext.Current.Session["provider"].ToString() + "&providerText=" + Session["providerText"].ToString() + "&cc=" + Session["cc"].ToString() + "&providerAmount=" + Session["providerAmount"].ToString() + "&error=" + Session["error"].ToString() + "&conf=" + conf + "&amount=" + Session["totalamount"].ToString() + "&EnglishNumber=" + EN + "&SpanishNumber=" + SP + "&Balance=" + Balance, false);
                //}

                if (HttpContext.Current.Session["error"].ToString().Contains("error1"))
                {
                    HttpContext.Current.Session["error"] = "Error: Not a " + provider + " number";
                    //Response.Redirect("Splash.aspx?Phone=" + phone.Replace("-", "") + "&datepaid=" + DateTime.Now + "&provider=" + Session["provider"].ToString() + "&providerText=" + Session["providerText"].ToString() + "&cc=" + Session["cc"].ToString() + "&providerAmount=" + Session["providerAmount"].ToString() + "&error=" + Session["error"].ToString() + "&conf=" + Session["conf"].ToString() + "&amount=" + Session["providerAmount"].ToString(), false);
                }

                if (HttpContext.Current.Session["error"].ToString().Contains("errorFunds"))
                {
                    HttpContext.Current.Session["error"] = "Error: Incorrect payment amount";
                    //Response.Redirect("Splash.aspx?Phone=" + phone.Replace("-", "") + "&datepaid=" + DateTime.Now + "&provider=" + Session["provider"].ToString() + "&providerText=" + Session["providerText"].ToString() + "&cc=" + Session["cc"].ToString() + "&providerAmount=" + Session["providerAmount"].ToString() + "&error=" + Session["error"].ToString() + "&conf=" + Session["conf"].ToString() + "&amount=" + Session["providerAmount"].ToString(), false);
                }

            }
            catch (Exception ex)
            {
                //lbInfo.Text = ddProviders.SelectedItem.Text + " is expiriencing technical difficulties, please call 786-471-5646" + ex;
                //lbInfo.ForeColor = Color.Red;
                HttpContext.Current.Session["error"] = "Error: No payment made";
            }
        }
        [HttpGet]
        [Route("api/products/VoidRecharge/{RechargeID}")]
        public async Task<string> VoidRecharge(int RechargeID)
        {
            ServicePointManager.Expect100Continue = true;
            ServicePointManager.DefaultConnectionLimit = 9999;
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12 | SecurityProtocolType.Ssl3;

            UserDAO oUserDAO = new UserDAO();
            Payment oPay = new Payment();
            MetroFastPayLibrary.Account oAccount = new MetroFastPayLibrary.Account();
            User getComm = oUserDAO.RetrieveServiceActivity(5);

            int payID = getPaymentIDbyConf(RechargeID);
            oPay = oUserDAO.RetrievePaymentbyID(payID);
            if (doubleTransPayment(RechargeID) > 1)
            {
                return "Error: This trasaction has already been voided";
            }
            if (oPay.CreatedDate <= DateTime.Now.AddDays(-7))
            {
                return "Error: This trasaction cannot be voided after 7 days";
            }
            if (oPay.Provider.Contains("DollarPhone") || oPay.Provider.Contains("GuatePin"))
            {
                TransResponseType ts = new TransResponseType();
                ActivateOrRechargeAccountType af = new ActivateOrRechargeAccountType();
                AccountInfo ai = new AccountInfo();

                using (PinManager pm = new PinManager())
                {
                    pm.Credentials = new System.Net.NetworkCredential(ConfigurationManager.AppSettings["dpUser"], ConfigurationManager.AppSettings["dpPass"]);

                    af.Account = ai;
                    af.Account.Ani = oPay.PhoneNumber;
                    if (oPay.Provider.Contains("GuatePin"))
                    {
                        getComm = oUserDAO.RetrieveServiceActivity(33);
                        af.Account.OfferingId = 30178480;
                    }
                    else
                    {
                        getComm = oUserDAO.RetrieveServiceActivity(5);
                        af.Account.OfferingId = 30030280;
                    }
                    af.Account.Balance = -oPay.AmountPaid;



                    ai = pm.ActivateOrRechargeAccount(af);


                    if ((ai.TransId > 0))
                    {

                        DateTime start = DateTime.Now;
                        for (
                        ; ((ts.Status == TransactionStatus.Pending) && ((DateTime.Now - start).TotalSeconds <= 180));
                        )
                        {
                            System.Threading.Thread.Sleep(3000);
                            ts = pm.TopupConfirm(Convert.ToInt32(ai.TransId));
                        }
                        switch (ts.Status)
                        {

                            case TransactionStatus.Success:

                                //update credit line
                                oAccount = oUserDAO.RetrieveAccount(oPay.UserID);

                                if (oAccount.Active == true)
                                {
                                    decimal DPamount = Convert.ToDecimal(-oPay.AmountPaid) * Convert.ToDecimal(getComm.UserCommission);
                                    oUserDAO.UpdateAccountbyPost(oAccount.Credit - (Convert.ToDecimal(-oPay.AmountPaid) - DPamount), oUser.Post);
                                }

                                //if (oUser.UserType == "Admin")
                                //{
                                //    MetroFastPayLibrary.Account oAccount3 = new MetroFastPayLibrary.Account();
                                //    oAccount3 = oUserDAO.RetrieveAccount(oPay.UserID);
                                //    decimal DPamount = Convert.ToDecimal(oPay.AmountPaid) * Convert.ToDecimal(getComm.UserCommission);
                                //    oUserDAO.UpdateAccountbyPost(oAccount3.Credit + (Convert.ToDecimal(oPay.AmountPaid) - DPamount), oPay.Post);
                                //}


                     
           
                                oUserDAO.InsertPayments(oPay.UserID, oPay.Post, oPay.PhoneNumber, -oPay.AmountPaid, -oPay.Fee, oPay.Provider, oPay.CCNumberUsed, DateTime.Now);


                                return "Voided: $" + string.Format("{0:0.00}", oPay.AmountPaid) + " for number " + oPay.PhoneNumber;

                                break;
                            case TransactionStatus.Failed:
                                break;
                            case TransactionStatus.Pending:
                                break;
                        }
                    }
                }
            }
            else
            {
                oAccount = oUserDAO.RetrieveAccount(oPay.UserID);
                string theid = oPay.Provider.Substring(oPay.Provider.LastIndexOf(':') + 1);
                string url = "https://webservice.sinpin.com/Agent/VoidRecharge/?Username=fandf.webapi&Password=Marcos2168!PB_561*!&apiKey=9e8roNDqY4Ssx6A607TxwYoJI0y246Ph&audit_id=" + theid;
                var client = new RestClient(url);
                var request = new RestRequest(Method.POST);
                IRestResponse response = client.Execute(request);
                try
                {

                    if (response.Content.Contains("Success"))
                    {

                        if (oAccount.Active == true)
                        {
                            decimal SinPinamount = Convert.ToDecimal(oPay.AmountPaid) * Convert.ToDecimal(.22);
                            oUserDAO.UpdateAccountbyPost(oAccount.Credit + (Convert.ToDecimal(oPay.AmountPaid) - SinPinamount), oPay.Post);

                            MetroFastPayLibrary.Account oAccount2 = new MetroFastPayLibrary.Account();
                            oAccount2 = oUserDAO.RetrieveAccount(oPay.UserID);

                            
                        }

                        if (oUser.UserType == "Admin")
                        {
                            MetroFastPayLibrary.Account oAccount3 = new MetroFastPayLibrary.Account();
                            oAccount3 = oUserDAO.RetrieveAccount(oPay.UserID);
                            decimal SinPinamount = Convert.ToDecimal(oPay.AmountPaid) * Convert.ToDecimal(.22);
                            oUserDAO.UpdateAccountbyPost(oAccount3.Credit + (Convert.ToDecimal(oPay.AmountPaid) - SinPinamount), oPay.Post);
                        }


                        oUserDAO.InsertPayments(oPay.UserID, oPay.Post, oPay.PhoneNumber, -oPay.AmountPaid, -oPay.Fee, oPay.Provider, oPay.CCNumberUsed, DateTime.Now);
                        return "Voided: $" + string.Format("{0:0.00}", oPay.AmountPaid) + " for number " + oPay.PhoneNumber;

                    }
                    else
                    {
                        return "Error: No recharge made";
                    }
                }
                catch (Exception ex)
                {
                    return "Error: No recharge made";
                }

            }
            return "Error: No recharge made";
        }

        public double getConf(string Provider)
        {
            using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString()))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                cmd.CommandText = @"select top(1) substring(provider, CHARINDEX(':', provider, 1)+1, CHARINDEX(':', provider, 1)) from payments where provider like '%" + Provider + "%' order by CreatedDate desc";
                double Num = Convert.ToDouble(cmd.ExecuteScalar());
                return Num;
            }
        }
        public int getPaymentIDbyConf(int conf)
        {
            using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString()))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                cmd.CommandText = @"select id from payments where substring(provider, CHARINDEX(':', provider, 1)+1, CHARINDEX(':', provider, 1)) = '" + conf + "'";
                int Num = Convert.ToInt32(cmd.ExecuteScalar());
                return Num;
            }
        }
        public int doubleTransPayment(int conf)
        {
            using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString()))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                cmd.CommandText = @"select Count(id) from payments where substring(provider, CHARINDEX(':', provider, 1)+1, CHARINDEX(':', provider, 1)) = '" + conf + "'";
                int Num = Convert.ToInt32(cmd.ExecuteScalar());
                return Num;
            }
        }
        public string ManualPayment(string user, string provider, string phone, string amount, string pin = "")
        {
            //update credit line
            MetroFastPayLibrary.Account oAccount = new MetroFastPayLibrary.Account();
            oAccount = oUserDAO.RetrieveAccount(user);

            User oFee = new User();
            oFee = oUserDAO.RetrieveFeebyUserID(user);

            User oUser = new MetroFastPayLibrary.User();
            oUser = oUserDAO.RetrieveUserByUserID(user);

            int doublepay = getPreviousPayment(phone);
            double conf = getConf(provider) + 1;
            string cc = "jNgIidwGeXIvGWnBgyr+VPaSRZ328OYRTL7VUmuNRPTve8ieKoTjk7upoZ3oicBb";
            //if (provider == "MetroPCS" || provider == "Boost")
            //{
            //    cc = "jNgIidwGeXIvGWnBgyr+VPaSRZ328OYRTL7VUmuNRPTve8ieKoTjk7upoZ3oicBb";
            //}
            //else
            //{
            //    cc = "7nqjU73xlX7XUPPicl4to8urStzwUH2jwrI6R+XvB1I42EKi55cDaMwoyEJ/gB95";
            //}
            if (oAccount.Active == true)
            {

                if (doublepay >= 1)
                {
                    oUserDAO.UpdateAccountbyPost(oAccount.Credit - Convert.ToInt32(amount), oUser.Post);
                    oUserDAO.InsertPayments(user, oUser.Post, phone, Convert.ToDecimal(amount), 0, provider + " - Conf#:" + conf, cc, DateTime.Now);

                }
                else
                {
                    oUserDAO.UpdateAccountbyPost(oAccount.Credit - (Convert.ToInt32(amount) + (Convert.ToInt32(oFee.Fee) - 2)), oUser.Post);
                    oUserDAO.InsertPayments(user, oUser.Post, phone, Convert.ToDecimal(amount), Convert.ToDecimal(oFee.Fee), provider + " - Conf#:" + conf, cc, DateTime.Now);

                }
            }
            else
            {
                if (doublepay >= 1)
                {
                    //insert payments
                    oUserDAO.InsertPayments(user, oUser.Post, phone, Convert.ToDecimal(amount), 0, provider + " - Conf#:" + conf, cc, DateTime.Now);

                }
                else
                {
                    //insert payments
                    oUserDAO.InsertPayments(user, oUser.Post, phone, Convert.ToDecimal(amount), Convert.ToDecimal(oFee.Fee), provider + " - Conf#:" + conf, cc, DateTime.Now);

                }
            }

            //pin only-----------------------------------------------------------------------------------------------------------------------------------------
            if (provider == "Boost")
            {
                TextAndEmail("Make Payment for " + provider, "#: " + phone + "| Pin: " + pin + "| Amount: " + amount + "| User: " + user, true);
            }
            else
            {
                TextAndEmail("Make Payment for " + provider, "#: " + phone + "| Amount: " + amount + "| User: " + user, true);
            }
            //---------------------------------------------------------------------------------------------------------------------------------
            //TextAndEmail("Make Payment for " + provider, "#: " + phone + "| Amount: " + amount + "| User: " + user, true);
            HttpContext.Current.Session["conf"] = conf;
            return "Success:{Confirmationid : " + conf + "}";
            //Response.Redirect("Splash.aspx?Phone=" + Session["Phone"].ToString().Replace("-", "") + "&datepaid=" + DateTime.Now + "&provider=" + Session["provider"].ToString() + "&providerText=" + Session["providerText"].ToString() + "&cc=" + cc + "&providerAmount=" + Session["providerAmount"].ToString() + "&error=&conf=" + conf + "&amount=" + Session["totalamount"].ToString());

        }
        [AcceptVerbs("GET", "POST")]
        [HttpPost]
        [Route("api/products/AddCC/{CC}/{ExpDate}/{CVV}/{Zip}/{Code}/{id}/{key}")]
        public async Task<string> AddCC(string cc, string expdate, string cvv, string zip, string code, string id, string key)
        {
            try
            {
                if (id.Contains("-"))
                {
                    id = id.Replace("-", "/");
                }
                if (id.Contains("plus"))
                {
                    id = id.Replace("plus", "+");
                }

                string therealid = DAO.Decrypt(id, ConfigurationManager.AppSettings["encryptionKey"]);
                int intid = Convert.ToInt32(therealid);
                string keyin = getkey(intid);
                int Loggedin = getUserbyID(intid);
                string userid = getUserNamebyID(intid);


                if (key.Contains("-"))
                {
                    key = key.Replace("-", "/");
                }
                if (key.Contains("plus"))
                {
                    key = key.Replace("plus", "+");
                }

                if (Loggedin == 1 && keyin == key)
                {
                    int i = 0;
                    if (cc == "") { i = 1; }
                    else if (expdate == "") { i = 2; }
                    else if (cvv == "") { i = 3; }
                    else if (zip == "") { i = 4; }
                    else if (code == "") { i = 5; }
                    switch (i)
                    {
                        case 1: HttpContext.Current.Session["error"] = "Error: CC missing"; break;
                        case 2: HttpContext.Current.Session["error"] = "Error: ExpDate missing"; break;
                        case 3: HttpContext.Current.Session["error"] = "Error: CVV missing"; break;
                        case 4: HttpContext.Current.Session["error"] = "Error: Zip missing"; break;
                        case 5: HttpContext.Current.Session["error"] = "Error: Code missing"; break;

                    }

                    if (i == 0)
                    {
                        string thecc = cc.Trim();
                        if (thecc.Replace(" ", "").Length == 16)
                        {

                            CC oCC = new CC();
                            oCC = oUserDAO.RetrieveCCByCC(DAO.Encrypt(cc, ConfigurationManager.AppSettings["encryptionKey"]));
                            string DBCC = oCC.CCNumber;
                            string CurrentCC = DAO.Encrypt(cc, ConfigurationManager.AppSettings["encryptionKey"]);

                            if (DBCC == null)
                            {
                                DBCC = "";
                            }
                            if (DBCC.Trim() == CurrentCC.Trim())
                            {
                                HttpContext.Current.Session["error"] = "CC Failed, there is a duplicate in the system";
                            }
                            else
                            {
                                //insert cc
                                oUser = oUserDAO.InsertCCDP(DAO.Encrypt(cc, ConfigurationManager.AppSettings["encryptionKey"]), expdate.Insert(2, "/"), cvv, zip, code);
                                return "CC Entered successfully";
                            }
                            return "Error:" + HttpContext.Current.Session["error"].ToString();
                        }
                        else
                        {
                            return "Error: CC field has to be 16 digits";
                        }
                    }
                    else
                    {
                        return "Error: " + HttpContext.Current.Session["error"].ToString();
                    }

                }
                else
                {
                    return ("Error: Access denied");
                }
            }
            catch (Exception ex)
            {
                return "Error: " + ex;
            }
        }
        [HttpGet]
        [Route("api/products/getErrorLog/{id}")]
        public IEnumerable<ErrorLog> GetErrorLog(string id)
        {
            try
            {
                if (id.Contains("-"))
                {
                    id = id.Replace("-", "/");
                }
                if (id.Contains("plus"))
                {
                    id = id.Replace("plus", "+");
                }
                string therealid = DAO.Decrypt(id, ConfigurationManager.AppSettings["encryptionKey"]);
                string userid = getUserNamebyID(Convert.ToInt32(therealid));
                User oFee = new User();
                oFee = oUserDAO.RetrieveFeebyUserID(userid);
                ErrorLog[] aryPayments = null;
                using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString()))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = conn;
                        cmd.CommandText = "SELECT UserID, PhoneNumber, CC, Error, CreatedDate FROM ErrorLog where UserID = '" + userid + "'";
                        conn.Open();
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            List<ErrorLog> lstPayments = new List<ErrorLog>();
                            while (reader.Read())
                            {
                                lstPayments.Add(new ErrorLog
                                {
                                    UserID = reader["UserID"].ToString(),
                                    ClientNumber = reader["PhoneNumber"].ToString(),
                                    Error = reader["Error"].ToString(),
                                    DatePaid = Convert.ToDateTime(reader["CreatedDate"])
                                });
                                aryPayments = lstPayments.ToArray();


                            }
                        }
                    }
                }
                return aryPayments;
            }
            catch (Exception ex)
            {
                ErrorLog[] error = null;
                return error;
            }


        }
        [HttpGet]
        [Route("api/products/getAllCards/{id}")]
        public IEnumerable<Cards> GetAllCards(string id)
        {
            try
            {
                if (id.Contains("-"))
                {
                    id = id.Replace("-", "/");
                }
                if (id.Contains("plus"))
                {
                    id = id.Replace("plus", "+");
                }
                string therealid = DAO.Decrypt(id, ConfigurationManager.AppSettings["encryptionKey"]);
                string userid = getUserNamebyID(Convert.ToInt32(therealid));
 
                Cards[] aryPayments = null;
                using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString()))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = conn;
                        cmd.CommandText = "SELECT CCNumber, ExpDate, CVV, Zip, Used, Active FROM CCDP";
                        conn.Open();
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            List<Cards> lstPayments = new List<Cards>();
                            while (reader.Read())
                            {

                                lstPayments.Add(new Cards
                                {
                                    CC = DAO.Decrypt(reader["CCNumber"].ToString(), ConfigurationManager.AppSettings["encryptionKey"]).Remove(0, 12),
                                    ExpDate = reader["ExpDate"].ToString(),
                                    CVV = reader["CVV"].ToString(),
                                    Zip = reader["Zip"].ToString(),
                                    Used = reader["Used"].ToString(),
                                    Active = Convert.ToBoolean(reader["Active"])
                                });
                                aryPayments = lstPayments.ToArray();


                            }
                        }
                    }
                }
                return aryPayments;
            }
            catch (Exception ex)
            {
                Cards[] error = null;
                return error;
            }


        }

        [HttpGet]
        [Route("api/products/getCardCount/{id}")]
        public string GetCardCount(string id)
        {
            try
            {

                if (id.Contains("-"))
                {
                    id = id.Replace("-", "/");
                }
                if (id.Contains("plus"))
                {
                    id = id.Replace("plus", "+");
                }
                string therealid = DAO.Decrypt(id, ConfigurationManager.AppSettings["encryptionKey"]);
                string userid = getUserNamebyID(Convert.ToInt32(therealid));
                using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString()))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = conn;
                        cmd.CommandText = "SELECT Count(*) from TelBug.dbo.ccdp where active = 1";
                        conn.Open();


                        if (cmd.ExecuteScalar() != null)
                        {
                            return userid + " card count: " + cmd.ExecuteScalar().ToString();
                        }
                        else
                        {
                            return "Error: Access denied";
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                return "Error: Access denied";
            }


        }

        [AcceptVerbs("GET", "POST")]
        [HttpPost]
        [Route("api/products/deleteAllCards/{id}/{key}")]
        public string DeleteAllCards(string id, string key)
        {
            try
            {

                if (id.Contains("-"))
                {
                    id = id.Replace("-", "/");
                }
                if (id.Contains("plus"))
                {
                    id = id.Replace("plus", "+");
                }
                string therealid = DAO.Decrypt(id, ConfigurationManager.AppSettings["encryptionKey"]);
                int intid = Convert.ToInt32(therealid);
                string keyin = getkey(intid);
                int Loggedin = getUserbyID(intid);
                string userid = getUserNamebyID(intid);


                if (key.Contains("-"))
                {
                    key = key.Replace("-", "/");
                }
                if (key.Contains("plus"))
                {
                    key = key.Replace("plus", "+");
                }

                if (Loggedin == 1 && keyin == key)
                {


                    using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString()))
                    {
                        using (SqlCommand cmd = new SqlCommand())
                        {
                            cmd.Connection = conn;
                            cmd.CommandText = "delete TelBug.dbo.ccdp";
                            conn.Open();



                            if (cmd.ExecuteScalar() != null)
                            {
                                return "No cards deleted from system";
                            }
                            else
                            {
                                
                                return "All cards deleted from system";
                            }



                        }
                    }
                }
                else
                {
                    return "Error: Access denied";
                }
            }
            catch (Exception ex)
            {
                return "Error:" + ex;
            }


        }

        public async System.Threading.Tasks.Task GetCityandState(string url)
        {
            try
            {
                HttpClient _Client = new HttpClient();
                _Client = new HttpClient();
                _Client.DefaultRequestHeaders.Accept.Clear();
                _Client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                RetievePin data = new RetievePin();

                var myContent = JsonConvert.SerializeObject(data);
                var buffer = System.Text.Encoding.UTF8.GetBytes(myContent);
                var byteContent = new ByteArrayContent(buffer);
                byteContent.Headers.Add("Content-Type", "application/json");

                var response = await _Client.PostAsync(url, byteContent);
                HttpContent content = response.Content;
                string mycontent3 = await content.ReadAsStringAsync();
                if (response.IsSuccessStatusCode)
                {
                    string s = response.Content.ReadAsStringAsync().Result;

                    HttpContext.Current.Session["City"] = getBetween(s, "\"city\":\"", "\"");
                    HttpContext.Current.Session["State"] = getBetween(s, "\"state\":\"", "\",");
                }
            }

            catch (Exception ex)
            {

               
            }
        }
        [AcceptVerbs("GET", "POST")]
        [HttpPost]
        [Route("api/products/MakeTheCall/{phonenumber}/{pin}/{amount}/{cc}/{expdate}/{cvv}/{id}/{key}")]
        public async Task<string> MakeTheCall(string phonenumber, string pin, string amount, string cc, string expdate, string cvv, string id, string key)
        {
            try
            {
                if (id.Contains("-"))
                {
                    id = id.Replace("-", "/");
                }
                if (id.Contains("plus"))
                {
                    id = id.Replace("plus", "+");
                }

                string therealid = DAO.Decrypt(id, ConfigurationManager.AppSettings["encryptionKey"]);
                int intid = Convert.ToInt32(therealid);
                string keyin = getkey(intid);
                int Loggedin = getUserbyID(intid);
                string userid = getUserNamebyID(intid);


                if (key.Contains("-"))
                {
                    key = key.Replace("-", "/");
                }
                if (key.Contains("plus"))
                {
                    key = key.Replace("plus", "+");
                }

                if (Loggedin == 1 && keyin == key)
                {
                    int i = 0;
                    if (phonenumber == "") { i = 1; }
                    else if (cc == "") { i = 2; }
                    else if (expdate == "") { i = 3; }
                    else if (cvv == "") { i = 4; }
                    switch (i)
                    {
                        case 1: HttpContext.Current.Session["error"] = "Error: Phone Number missing"; break;
                        case 2: HttpContext.Current.Session["error"] = "Error: CC missing"; break;
                        case 3: HttpContext.Current.Session["error"] = "Error: ExpDate missing"; break;
                        case 4: HttpContext.Current.Session["error"] = "Error: CVV missing"; break;

                    }

                    if (i == 0)
                    {
                        PhoneController it = new PhoneController();
                        await it.MakeCall(phonenumber, pin, amount, cc, expdate, cvv);
                        return "Payment Processing...";
                    }
                    else
                    {
                        return "Error: " + HttpContext.Current.Session["error"].ToString();
                    }

                }
                else
                {
                    return ("Error: Access denied");
                }
            }
            catch (Exception ex)
            {
                return "Error: " + ex;
            }
        }
        [AcceptVerbs("GET", "POST")]
        [HttpPost]
        [Route("api/products/MakeTheCallBackUp/{phonenumber}/{pin}/{amount}/{cc}/{expdate}/{cvv}/{id}/{key}")]
        public async Task<string> MakeTheCallBackUp(string phonenumber, string pin, string amount, string cc, string expdate, string cvv, string id, string key)
        {
            try
            {
                if (id.Contains("-"))
                {
                    id = id.Replace("-", "/");
                }
                if (id.Contains("plus"))
                {
                    id = id.Replace("plus", "+");
                }

                string therealid = DAO.Decrypt(id, ConfigurationManager.AppSettings["encryptionKey"]);
                int intid = Convert.ToInt32(therealid);
                string keyin = getkey(intid);
                int Loggedin = getUserbyID(intid);
                string userid = getUserNamebyID(intid);


                if (key.Contains("-"))
                {
                    key = key.Replace("-", "/");
                }
                if (key.Contains("plus"))
                {
                    key = key.Replace("plus", "+");
                }

                if (Loggedin == 1 && keyin == key)
                {
                    int i = 0;
                    if (phonenumber == "") { i = 1; }
                    else if (cc == "") { i = 2; }
                    else if (expdate == "") { i = 3; }
                    else if (cvv == "") { i = 4; }
                    switch (i)
                    {
                        case 1: HttpContext.Current.Session["error"] = "Error: Phone Number missing"; break;
                        case 2: HttpContext.Current.Session["error"] = "Error: CC missing"; break;
                        case 3: HttpContext.Current.Session["error"] = "Error: ExpDate missing"; break;
                        case 4: HttpContext.Current.Session["error"] = "Error: CVV missing"; break;

                    }

                    if (i == 0)
                    {
                        PhoneController it = new PhoneController();
                        await it.MakeCallBackUp(phonenumber, pin, amount, cc, expdate, cvv);
                        return "Payment Processing...";
                    }
                    else
                    {
                        return "Error: " + HttpContext.Current.Session["error"].ToString();
                    }

                }
                else
                {
                    return ("Error: Access denied");
                }
            }
            catch (Exception ex)
            {
                return "Error: " + ex;
            }
        }
        [AcceptVerbs("GET", "POST")]
        [HttpPost]
        [Route("api/products/SendPin/{phonenumber}")]
        public async Task<string> SendPin(string phonenumber)
        {
            try
            {
                PhoneController it = new PhoneController();
                await it.SendPin(phonenumber);
                return "Pin Sent";
            }
            catch (Exception ex)
            {
                return "Error: " + ex;
            }
        }
        [AcceptVerbs("GET", "POST")]
        [HttpPost]
        [Route("api/products/MakeTheCallNoPin/{phonenumber}/{amount}/{cc}/{expdate}/{cvv}/{id}/{key}")]
        public async Task<string> MakeTheCallNoPin(string phonenumber, string amount, string cc, string expdate, string cvv, string id, string key)
        {
            try
            {
                if (id.Contains("-"))
                {
                    id = id.Replace("-", "/");
                }
                if (id.Contains("plus"))
                {
                    id = id.Replace("plus", "+");
                }

                string therealid = DAO.Decrypt(id, ConfigurationManager.AppSettings["encryptionKey"]);
                int intid = Convert.ToInt32(therealid);
                string keyin = getkey(intid);
                int Loggedin = getUserbyID(intid);
                string userid = getUserNamebyID(intid);


                if (key.Contains("-"))
                {
                    key = key.Replace("-", "/");
                }
                if (key.Contains("plus"))
                {
                    key = key.Replace("plus", "+");
                }

                if (Loggedin == 1 && keyin == key)
                {
                    int i = 0;
                    if (phonenumber == "") { i = 1; }
                    else if (cc == "") { i = 2; }
                    else if (expdate == "") { i = 3; }
                    else if (cvv == "") { i = 4; }
                    switch (i)
                    {
                        case 1: HttpContext.Current.Session["error"] = "Error: Phone Number missing"; break;
                        case 2: HttpContext.Current.Session["error"] = "Error: CC missing"; break;
                        case 3: HttpContext.Current.Session["error"] = "Error: ExpDate missing"; break;
                        case 4: HttpContext.Current.Session["error"] = "Error: CVV missing"; break;

                    }

                    if (i == 0)
                    {
                        PhoneController it = new PhoneController();
                        await it.MakeCallNoPin(phonenumber, amount, cc, expdate, cvv);
                        return "Payment Processing...";
                    }
                    else
                    {
                        return "Error: " + HttpContext.Current.Session["error"].ToString();
                    }

                }
                else
                {
                    return ("Error: Access denied");
                }
            }
            catch (Exception ex)
            {
                return "Error: " + ex;
            }
        }
        [AcceptVerbs("GET", "POST")]
        [HttpPost]
        [Route("api/products/MakeTheCallSpanishBackUp/{phonenumber}/{pin}/{amount}/{cc}/{expdate}/{cvv}/{id}/{key}")]
        public async Task<string> MakeTheCallSpanishBackUp(string phonenumber, string pin, string amount, string cc, string expdate, string cvv, string id, string key)
        {
            try
            {
                if (id.Contains("-"))
                {
                    id = id.Replace("-", "/");
                }
                if (id.Contains("plus"))
                {
                    id = id.Replace("plus", "+");
                }

                string therealid = DAO.Decrypt(id, ConfigurationManager.AppSettings["encryptionKey"]);
                int intid = Convert.ToInt32(therealid);
                string keyin = getkey(intid);
                int Loggedin = getUserbyID(intid);
                string userid = getUserNamebyID(intid);


                if (key.Contains("-"))
                {
                    key = key.Replace("-", "/");
                }
                if (key.Contains("plus"))
                {
                    key = key.Replace("plus", "+");
                }

                if (Loggedin == 1 && keyin == key)
                {
                    int i = 0;
                    if (phonenumber == "") { i = 1; }
                    else if (cc == "") { i = 2; }
                    else if (expdate == "") { i = 3; }
                    else if (cvv == "") { i = 4; }
                    switch (i)
                    {
                        case 1: HttpContext.Current.Session["error"] = "Error: Phone Number missing"; break;
                        case 2: HttpContext.Current.Session["error"] = "Error: CC missing"; break;
                        case 3: HttpContext.Current.Session["error"] = "Error: ExpDate missing"; break;
                        case 4: HttpContext.Current.Session["error"] = "Error: CVV missing"; break;

                    }

                    if (i == 0)
                    {
                        PhoneController it = new PhoneController();
                        await it.MakeCallSpanishBackUp(phonenumber, pin, amount, cc, expdate, cvv);
                        return "Payment Processing...";
                    }
                    else
                    {
                        return "Error: " + HttpContext.Current.Session["error"].ToString();
                    }

                }
                else
                {
                    return ("Error: Access denied");
                }
            }
            catch (Exception ex)
            {
                return "Error: " + ex;
            }
        }
        [AcceptVerbs("GET", "POST")]
        [HttpPost]
        [Route("api/products/MakeMetroPaymentByCall/{phonenumber}/{amount}/{cc}/{expdate}/{cvv}/{id}/{key}")]
        public async Task<string> MakeMetroPaymentByCall(string phonenumber, string amount, string cc, string expdate, string cvv, string id, string key)
        {
            try
            {
                if (id.Contains("-"))
                {
                    id = id.Replace("-", "/");
                }
                if (id.Contains("plus"))
                {
                    id = id.Replace("plus", "+");
                }

                string therealid = DAO.Decrypt(id, ConfigurationManager.AppSettings["encryptionKey"]);
                int intid = Convert.ToInt32(therealid);
                string keyin = getkey(intid);
                int Loggedin = getUserbyID(intid);
                string userid = getUserNamebyID(intid);


                if (key.Contains("-"))
                {
                    key = key.Replace("-", "/");
                }
                if (key.Contains("plus"))
                {
                    key = key.Replace("plus", "+");
                }

                if (Loggedin == 1 && keyin == key)
                {
                    int i = 0;
                    if (phonenumber == "") { i = 1; }
                    else if (cc == "") { i = 2; }
                    else if (expdate == "") { i = 3; }
                    else if (cvv == "") { i = 4; }
                    switch (i)
                    {
                        case 1: HttpContext.Current.Session["error"] = "Error: Phone Number missing"; break;
                        case 2: HttpContext.Current.Session["error"] = "Error: CC missing"; break;
                        case 3: HttpContext.Current.Session["error"] = "Error: ExpDate missing"; break;
                        case 4: HttpContext.Current.Session["error"] = "Error: CVV missing"; break;

                    }

                    if (i == 0)
                    {
                        Payment oPayment = new Payment();
                        oPayment = oUserDAO.RetrieveLastPaymentByNumber(phonenumber);

                        PhoneController it = new PhoneController();
                        await it.MakeMetroCallBackUp(phonenumber, amount, cc, expdate, cvv, oPayment.ID);
                        return "Payment Processing...";
                    }
                    else
                    {
                        return "Error: " + HttpContext.Current.Session["error"].ToString();
                    }

                }
                else
                {
                    return ("Error: Access denied");
                }
            }
            catch (Exception ex)
            {
                return "Error: " + ex;
            }
        }
        public string ManualBoost(string user, string provider, string phone, string amount, string cc, string pin = "")
        {
            //update credit line
            MetroFastPayLibrary.Account oAccount = new MetroFastPayLibrary.Account();
            oAccount = oUserDAO.RetrieveAccount(user);

            User oFee = new User();
            oFee = oUserDAO.RetrieveFeebyUserID(user);

            User oUser = new MetroFastPayLibrary.User();
            oUser = oUserDAO.RetrieveUserByUserID(user);

            cc = DAO.Encrypt(cc, ConfigurationManager.AppSettings["encryptionKey"]).Trim();

            int doublepay = getPreviousPayment(phone);
            double conf = getConf(provider) + 1;

            if (oAccount.Active == true)
            {

                if (doublepay >= 1)
                {
                    oUserDAO.UpdateAccountbyPost(oAccount.Credit - Convert.ToInt32(amount), oUser.Post);
                    oUserDAO.InsertPayments(user, oUser.Post, phone, Convert.ToDecimal(amount), 0, provider + " - Conf#:" + conf, cc, DateTime.Now);

                }
                else
                {
                    oUserDAO.UpdateAccountbyPost(oAccount.Credit - (Convert.ToInt32(amount) + (Convert.ToInt32(oFee.Fee) - 2)), oUser.Post);
                    oUserDAO.InsertPayments(user, oUser.Post, phone, Convert.ToDecimal(amount), Convert.ToDecimal(oFee.Fee), provider + " - Conf#:" + conf, cc, DateTime.Now);

                }
            }
            else
            {
                if (doublepay >= 1)
                {
                    //insert payments
                    oUserDAO.InsertPayments(user, oUser.Post, phone, Convert.ToDecimal(amount), 0, phone + " - Conf#:" + conf, cc, DateTime.Now);

                }
                else
                {
                    //insert payments
                    oUserDAO.InsertPayments(user, oUser.Post, phone, Convert.ToDecimal(amount), Convert.ToDecimal(oFee.Fee), provider + " - Conf#:" + conf, cc, DateTime.Now);

                }
            }
            //ip capture
            Payment oPayment = new Payment();
            oPayment = oUserDAO.RetrievePaymentbyConfID(conf.ToString());
            oUserDAO.InsertIP(user, GetIPAddress(), oPayment.ID);
            oUserDAO.InsertUserPin(phone, pin);

            TextAndEmail("Payment being made by phone for " + provider, "#: " + phone + "| Pin: " + pin + "| Amount: " + amount + "| User: " + user, true);
            //---------------------------------------------------------------------------------------------------------------------------------
            //TextAndEmail("Make Payment for " + provider, "#: " + phone + "| Amount: " + amount + "| User: " + user, true);
            HttpContext.Current.Session["conf"] = conf;
            return "Success:{Confirmationid : " + conf + "}";
            //Response.Redirect("Splash.aspx?Phone=" + Session["Phone"].ToString().Replace("-", "") + "&datepaid=" + DateTime.Now + "&provider=" + Session["provider"].ToString() + "&providerText=" + Session["providerText"].ToString() + "&cc=" + cc + "&providerAmount=" + Session["providerAmount"].ToString() + "&error=&conf=" + conf + "&amount=" + Session["totalamount"].ToString());


        }
        public async Task ManualMetroCall(string user, string provider, string phone, string amount, string cc, string expDate, string cvv, string key, string id)
        {
            //update credit line
            MetroFastPayLibrary.Account oAccount = new MetroFastPayLibrary.Account();
            oAccount = oUserDAO.RetrieveAccount(user);

            User oFee = new User();
            oFee = oUserDAO.RetrieveFeebyUserID(user);

            User oUser = new MetroFastPayLibrary.User();
            oUser = oUserDAO.RetrieveUserByUserID(user);

            cc = DAO.Encrypt(cc, ConfigurationManager.AppSettings["encryptionKey"]).Trim();

            int doublepay = getPreviousPayment(phone);
            double conf = getConf(provider) + 1;

            if (oAccount.Active == true)
            {

                if (doublepay >= 1)
                {
                    oUserDAO.UpdateAccountbyPost(oAccount.Credit - Convert.ToInt32(amount), oUser.Post);
                    oUserDAO.InsertPayments(user, oUser.Post, phone, Convert.ToDecimal(amount), 0, provider + " - Conf#:" + conf, cc, DateTime.Now);

                }
                else
                {
                    oUserDAO.UpdateAccountbyPost(oAccount.Credit - (Convert.ToInt32(amount) + (Convert.ToInt32(oFee.Fee) - 2)), oUser.Post);
                    oUserDAO.InsertPayments(user, oUser.Post, phone, Convert.ToDecimal(amount), Convert.ToDecimal(oFee.Fee), provider + " - Conf#:" + conf, cc, DateTime.Now);

                }
            }
            else
            {
                if (doublepay >= 1)
                {
                    //insert payments
                    oUserDAO.InsertPayments(user, oUser.Post, phone, Convert.ToDecimal(amount), 0, provider + " - Conf#:" + conf, cc, DateTime.Now);

                }
                else
                {
                    //insert payments
                    oUserDAO.InsertPayments(user, oUser.Post, phone, Convert.ToDecimal(amount), Convert.ToDecimal(oFee.Fee), provider + " - Conf#:" + conf, cc, DateTime.Now);

                }
            }

            cc = DAO.Decrypt(cc, ConfigurationManager.AppSettings["encryptionKey"]).Trim();
            string theamount = amount + "00";
            expDate = expDate.Replace("/", "");
            await MakeMetroPaymentByCall(phone, theamount, cc, expDate, cvv, id, key);

            //ip capture
            Payment oPayment = new Payment();
            oPayment = oUserDAO.RetrievePaymentbyConfID(conf.ToString());
            oUserDAO.InsertIP(user, GetIPAddress(), oPayment.ID);

            Payment oPaySID = new Payment();
            oPaySID = oUserDAO.RetrieveSIDbyPaymentID(Convert.ToInt32(oPayment.ID));

            string pageurl = "https://telbug.com/getconf.aspx?CAsid=" + oPaySID.SID + "&amount=" + oPayment.AmountPaid + "&number=" + oPayment.PhoneNumber + "&paymentid=" + oPayment.ID + "&time=" + WebUtility.UrlEncode(oPayment.CreatedDate.ToString()) + "&user=" + oPayment.UserID;
            TextAndEmail("Payment made by phone for " + provider, "#: " + phone + "| Amount: " + amount + "| User: " + user + " | View: " + pageurl, true);
            //---------------------------------------------------------------------------------------------------------------------------------
            //TextAndEmail("Make Payment for " + provider, "#: " + phone + "| Amount: " + amount + "| User: " + user, true);
            HttpContext.Current.Session["conf"] = conf;
            //return "Success:{Confirmationid : " + conf + "}";
            //Response.Redirect("Splash.aspx?Phone=" + Session["Phone"].ToString().Replace("-", "") + "&datepaid=" + DateTime.Now + "&provider=" + Session["provider"].ToString() + "&providerText=" + Session["providerText"].ToString() + "&cc=" + cc + "&providerAmount=" + Session["providerAmount"].ToString() + "&error=&conf=" + conf + "&amount=" + Session["totalamount"].ToString());


        }
    }
}
