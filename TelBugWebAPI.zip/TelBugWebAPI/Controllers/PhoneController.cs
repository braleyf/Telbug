﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

using Twilio;
using Twilio.Rest.Api.V2010.Account;
using Twilio.AspNet.Mvc;
using Twilio.Types;

using Twilio.TwiML;
using Twilio.TwiML.Voice;
using System.Web.Mvc;
using System.Threading.Tasks;
using MetroFastPayLibrary;

namespace TelBugWebAPI.Controllers
{
    public class PhoneController : TwilioController
    {
        User oUser = new User();
        UserDAO oUserDAO = new UserDAO();
        public async Task<ActionResult> MakeCall(string phone, string pin, string amount, string cc, string expdate, string cvv)
        {
            var accountsid = "ACf68d6c4ff981f1ff8962f266f81ced48";
            var authToken = "6550fa15290f0b119b3a4ab7466200f9";
            TwilioClient.Init(accountsid, authToken);

            var to = new PhoneNumber("+18664027366");
            var from = new PhoneNumber("+15612204243");
            var call = await CallResource.CreateAsync(
                to: to,
                from: from,
                url: new Uri("http://twimlets.com/echo?Twiml=%3CResponse%3E%0A%3CPause%20length%3D%2218%22%2F%3E%0A%3CPlay%20digits%3D%22www" + phone + "%22%2F%3E%0A%3CPause%20length%3D%2215%22%2F%3E%0A%3CPlay%20digits%3D%22www1%22%2F%3E%0A%3CPause%20length%3D%222%22%2F%3E%0A%3CPlay%20digits%3D%22www2%22%2F%3E%0A%3CPause%20length%3D%222%22%2F%3E%0A%3CPlay%20digits%3D%22www" + pin + "%22%2F%3E%0A%3CPause%20length%3D%228%22%2F%3E%0A%3CPlay%20digits%3D%22www" + amount + "%22%2F%3E%0A%3CPause%20length%3D%228%22%2F%3E%0A%3CPlay%20digits%3D%22www1%22%2F%3E%0A%3CPause%20length%3D%223%22%2F%3E%0A%3CPlay%20digits%3D%22www" + cc + "%22%2F%3E%0A%3CPause%20length%3D%2218%22%2F%3E%0A%3CPlay%20digits%3D%22www1%22%2F%3E%0A%3CPause%20length%3D%226%22%2F%3E%0A%3CPlay%20digits%3D%22www" + expdate + "%22%2F%3E%0A%3CPause%20length%3D%227%22%2F%3E%0A%3CPlay%20digits%3D%22www1%22%2F%3E%0A%3CPause%20length%3D%224%22%2F%3E%0A%3CPlay%20digits%3D%22www" + cvv + "%22%2F%3E%0A%3CPause%20length%3D%2210%22%2F%3E%0A%3CPlay%20digits%3D%22www1%22%2F%3E%0A%3CPause%20length%3D%225%22%2F%3E%0A%3CPlay%20digits%3D%22www1%22%2F%3E%0A%3CPause%20length%3D%224%22%2F%3E%0A%3CSms%20from%3D%22%2B15612204243%22%20to%3D%22%2B15616674346%22%3E%23" + phone + "%20paid%20in%20the%20amount%20of%20" + amount + "%3C%2FSms%3E%0A%3CSms%20from%3D%22%2B15612204243%22%20to%3D%22%2B15618605276%22%3E%23" + phone + "%20paid%20in%20the%20amount%20of%20" + amount + "%3C%2FSms%3E%0A%3CHangup%2F%3E%0A%3C%2FResponse%3E&"));

            return Content(call.Sid);


        }
        public async Task<ActionResult> MakeCallBackUp(string phone, string pin, string amount, string cc, string expdate, string cvv)
        {
            var accountsid = "ACf68d6c4ff981f1ff8962f266f81ced48";
            var authToken = "6550fa15290f0b119b3a4ab7466200f9";
            TwilioClient.Init(accountsid, authToken);

            var to = new PhoneNumber("+18664027366");
            var from = new PhoneNumber("+15612204243");
            var call = await CallResource.CreateAsync(
                to: to,
                from: from,
                url: new Uri("http://twimlets.com/echo?Twiml=%3CResponse%3E%0A%3CPause%20length%3D%2218%22%2F%3E%0A%3CPlay%20digits%3D%22www" + phone + "%22%2F%3E%0A%3CPause%20length%3D%2210%22%2F%3E%0A%3CPlay%20digits%3D%22www" + pin + "%22%2F%3E%0A%3CPause%20length%3D%226%22%2F%3E%0A%3CPlay%20digits%3D%22www0%22%2F%3E%0A%3CPause%20length%3D%222%22%2F%3E%0A%3CPlay%20digits%3D%22www0%22%2F%3E%0A%3CPause%20length%3D%222%22%2F%3E%0A%3CPlay%20digits%3D%22www2%22%2F%3E%0A%3CPause%20length%3D%222%22%2F%3E%0A%3CPlay%20digits%3D%22www" + amount + "%22%2F%3E%0A%3CPause%20length%3D%228%22%2F%3E%0A%3CPlay%20digits%3D%22www1%22%2F%3E%0A%3CPause%20length%3D%223%22%2F%3E%0A%3CPlay%20digits%3D%22www" + cc + "%22%2F%3E%0A%3CPause%20length%3D%2218%22%2F%3E%0A%3CPlay%20digits%3D%22www1%22%2F%3E%0A%3CPause%20length%3D%226%22%2F%3E%0A%3CPlay%20digits%3D%22www" + expdate + "%22%2F%3E%0A%3CPause%20length%3D%227%22%2F%3E%0A%3CPlay%20digits%3D%22www1%22%2F%3E%0A%3CPause%20length%3D%224%22%2F%3E%0A%3CPlay%20digits%3D%22www" + cvv + "%22%2F%3E%0A%3CPause%20length%3D%2210%22%2F%3E%0A%3CPlay%20digits%3D%22www1%22%2F%3E%0A%3CPause%20length%3D%225%22%2F%3E%0A%3CPlay%20digits%3D%22www1%22%2F%3E%0A%3CPause%20length%3D%227%22%2F%3E%0A%3CHangup%2F%3E%0A%3C%2FResponse%3E&"));

            return Content(call.Sid);


        }
        public async Task<ActionResult> MakeCallNoPin(string phone, string amount, string cc, string expdate, string cvv)
        {
            var accountsid = "ACf68d6c4ff981f1ff8962f266f81ced48";
            var authToken = "6550fa15290f0b119b3a4ab7466200f9";
            TwilioClient.Init(accountsid, authToken);

            var to = new PhoneNumber("+18664027366");
            var from = new PhoneNumber("+15612204243");
            var call = await CallResource.CreateAsync(
                to: to,
                from: from,
                url: new Uri("http://twimlets.com/echo?Twiml=%3CResponse%3E%0A%3CPause%20length%3D%229%22%2F%3E%0A%3CPlay%20digits%3D%22www" + phone + "%22%2F%3E%0A%3CPause%20length%3D%2215%22%2F%3E%0A%3CPlay%20digits%3D%22www1%22%2F%3E%0A%3CPause%20length%3D%222%22%2F%3E%0A%3CPlay%20digits%3D%22www2%22%2F%3E%0A%3CPause%20length%3D%2230%22%2F%3E%0A%3CPlay%20digits%3D%22www2%22%2F%3E%0A%3CPause%20length%3D%228%22%2F%3E%0A%3CPlay%20digits%3D%22www" + amount + "%22%2F%3E%0A%3CPause%20length%3D%223%22%2F%3E%0A%3CPlay%20digits%3D%22www" + cc + "%22%2F%3E%0A%3CPause%20length%3D%2218%22%2F%3E%0A%3CPlay%20digits%3D%22www1%22%2F%3E%0A%3CPause%20length%3D%226%22%2F%3E%0A%3CPlay%20digits%3D%22www" + expdate + "%22%2F%3E%0A%3CPause%20length%3D%227%22%2F%3E%0A%3CPlay%20digits%3D%22www33415%22%2F%3E%0A%3CPause%20length%3D%224%22%2F%3E%0A%3CPlay%20digits%3D%22www" + cvv + "%22%2F%3E%0A%3CPause%20length%3D%225%22%2F%3E%0A%3CPlay%20digits%3D%22www1%22%2F%3E%0A%3CPause%20length%3D%225%22%2F%3E%0A%3CPlay%20digits%3D%22www1%22%2F%3E%0A%3CPause%20length%3D%225%22%2F%3E%0A%3CSms%20from%3D%22%2B15612204243%22%20to%3D%22%2B15616674346%22%3E%23" + phone + "%20paid%20in%20the%20amount%20of%20" + amount + "%3C%2FSms%3E%0A%3CHangup%2F%3E%0A%3C%2FResponse%3E&"));

            return Content(call.Sid);


        }
        public async Task<ActionResult> MakeCallSpanishBackUp(string phone, string pin, string amount, string cc, string expdate, string cvv)
        {
            var accountsid = "ACf68d6c4ff981f1ff8962f266f81ced48";
            var authToken = "6550fa15290f0b119b3a4ab7466200f9";
            TwilioClient.Init(accountsid, authToken);

            var to = new PhoneNumber("+18664027366");
            var from = new PhoneNumber("+15612204243");
            var call = await CallResource.CreateAsync(
                to: to,
                from: from,
                url: new Uri("http://twimlets.com/echo?Twiml=%3CResponse%3E%0A%3CPause%20length%3D%222%22%2F%3E%0A%3CPlay%20digits%3D%22www5%22%2F%3E%0A%3CPause%20length%3D%222%22%2F%3E%0A%3CPlay%20digits%3D%22www" + phone + "%22%2F%3E%0A%3CPause%20length%3D%2212%22%2F%3E%0A%3CPlay%20digits%3D%22www" + pin + "%22%2F%3E%0A%3CPause%20length%3D%2210%22%2F%3E%0A%3CPlay%20digits%3D%22www0%22%2F%3E%0A%3CPause%20length%3D%222%22%2F%3E%0A%3CPlay%20digits%3D%22www0%22%2F%3E%0A%3CPause%20length%3D%223%22%2F%3E%0A%3CPlay%20digits%3D%22www2%22%2F%3E%0A%3CPause%20length%3D%224%22%2F%3E%0A%3CPlay%20digits%3D%22www" + amount + "%22%2F%3E%0A%3CPause%20length%3D%227%22%2F%3E%0A%3CPlay%20digits%3D%22www2%22%2F%3E%0A%3CPause%20length%3D%224%22%2F%3E%0A%3CPlay%20digits%3D%22www" + cc + "%22%2F%3E%0A%3CPause%20length%3D%2218%22%2F%3E%0A%3CPlay%20digits%3D%22www1%22%2F%3E%0A%3CPause%20length%3D%224%22%2F%3E%0A%3CPlay%20digits%3D%22www" + expdate + "%22%2F%3E%0A%3CPause%20length%3D%2215%22%2F%3E%0A%3CPlay%20digits%3D%22www2%22%2F%3E%0A%3CPause%20length%3D%224%22%2F%3E%0A%3CPlay%20digits%3D%22www33415%22%2F%3E%0A%3CPause%20length%3D%224%22%2F%3E%0A%3CPlay%20digits%3D%22www" + cvv + "%22%2F%3E%0A%3CPause%20length%3D%2215%22%2F%3E%0A%3CPlay%20digits%3D%22www1%22%2F%3E%0A%3CPause%20length%3D%225%22%2F%3E%0A%3CSms%20from%3D%22%2B15612204243%22%20to%3D%22%2B15616674346%22%3E%23" + phone + "%20paid%20in%20the%20amount%20of%20" + amount + "%3C%2FSms%3E%0A%3CHangup%2F%3E%0A%3C%2FResponse%3E&"));

            return Content(call.Sid);


        }
        public async Task<ActionResult> SendPin(string phone)
        {
            var accountsid = "ACf68d6c4ff981f1ff8962f266f81ced48";
            var authToken = "6550fa15290f0b119b3a4ab7466200f9";
            TwilioClient.Init(accountsid, authToken);

            var to = new PhoneNumber("+18664027366");
            var from = new PhoneNumber("+15612204243");
            var call = await CallResource.CreateAsync(
                to: to,
                from: from,
                url: new Uri("http://twimlets.com/echo?Twiml=%3CResponse%3E%0A%3CPause%20length%3D%2214%22%2F%3E%0A%3CPlay%20digits%3D%22www" + phone + "%22%2F%3E%0A%3CPause%20length%3D%2218%22%2F%3E%0A%3CPlay%20digits%3D%22www5%22%2F%3E%0A%3CPause%20length%3D%222%22%2F%3E%0A%3CPlay%20digits%3D%22www5%22%2F%3E%0A%3CPause%20length%3D%223%22%2F%3E%0A%3CHangup%2F%3E%0A%3C%2FResponse%3E&"));

            return Content(call.Sid);


        }
        public async Task<ActionResult> MakeMetroCallBackUp(string phone, string amount, string cc, string expdate, string cvv, int paymentid)
        {
            var accountsid = "ACf68d6c4ff981f1ff8962f266f81ced48";
            var authToken = "6550fa15290f0b119b3a4ab7466200f9";
            TwilioClient.Init(accountsid, authToken);

            var to = new PhoneNumber("+18888638768");
            var from = new PhoneNumber("+15612204243");
            var call = await CallResource.CreateAsync(
                to: to,
                from: from,
                //working url
               // url: new Uri("http://twimlets.com/echo?Twiml=%3CResponse%3E%0A%3CPause%20length%3D%2215%22%2F%3E%0A%3CSay%20voice%3D%22woman%22%20language%3D%22en-US%22%3EPayment%3C%2FSay%3E%0A%3CPause%20length%3D%226%22%2F%3E%0A%3CSay%20voice%3D%22woman%22%20language%3D%22en-US%22%3EYes%3C%2FSay%3E%0A%3CPause%20length%3D%224%22%2F%3E%0A%3CPlay%20digits%3D%22www"+ phone +"%23%22%2F%3E%0A%3CPause%20length%3D%225%22%2F%3E%0A%3CSay%20voice%3D%22woman%22%20language%3D%22en-US%22%3EI%20do%20not%20know%20it%3C%2FSay%3E%0A%3CPause%20length%3D%2224%22%2F%3E%0A%3CSay%20voice%3D%22woman%22%20language%3D%22en-US%22%3EYes%3C%2FSay%3E%0A%3CPause%20length%3D%227%22%2F%3E%0A%3CPlay%20digits%3D%22www"+ amount +"%23%22%2F%3E%0A%3CPause%20length%3D%226%22%2F%3E%0A%3CSay%20voice%3D%22woman%22%20language%3D%22en-US%22%3EYes%3C%2FSay%3E%0A%3CPause%20length%3D%2220%22%2F%3E%0A%3CSay%20voice%3D%22woman%22%20language%3D%22en-US%22%3ECredit%3C%2FSay%3E%0A%3CPause%20length%3D%2213%22%2F%3E%0A%3CPlay%20digits%3D%22www"+ cc +"%23%22%2F%3E%0A%3CPause%20length%3D%223%22%2F%3E%0A%3CPlay%20digits%3D%22www"+ expdate +"%23%22%2F%3E%0A%3CPause%20length%3D%223%22%2F%3E%0A%3CPlay%20digits%3D%22www"+ cvv +"%23%22%2F%3E%0A%3CPause%20length%3D%223%22%2F%3E%0A%3CPlay%20digits%3D%22www33415%23%22%2F%3E%0A%3CPause%20length%3D%2227%22%2F%3E%0A%3CSay%20voice%3D%22woman%22%20language%3D%22en-US%22%3EYes%3C%2FSay%3E%0A%3CRecord%20timeout%3D%2210%22%20transcribe%3D%22true%22%2F%3E%0A%3CPause%20length%3D%2217%22%2F%3E%0A%3CHangup%2F%3E%0A%3C%2FResponse%3E&"));
              
                //test url
                url: new Uri("http://twimlets.com/echo?Twiml=%3CResponse%3E%0A%3CPause%20length%3D%2216%22%2F%3E%0A%3CSay%20voice%3D%22woman%22%20language%3D%22en-US%22%3EMake%20a%20Payment%3C%2FSay%3E%0A%3CPause%20length%3D%224%22%2F%3E%0A%3CPlay%20digits%3D%22www" + phone + "%23%22%2F%3E%0A%3CPause%20length%3D%225%22%2F%3E%0A%3CSay%20voice%3D%22woman%22%20language%3D%22en-US%22%3EI%20do%20not%20know%20it%3C%2FSay%3E%0A%3CPause%20length%3D%2224%22%2F%3E%0A%3CSay%20voice%3D%22woman%22%20language%3D%22en-US%22%3EYes%3C%2FSay%3E%0A%3CPause%20length%3D%223%22%2F%3E%0A%3CPlay%20digits%3D%22www" + amount + "%23%22%2F%3E%0A%3CPause%20length%3D%224%22%2F%3E%0A%3CSay%20voice%3D%22woman%22%20language%3D%22en-US%22%3EYes%3C%2FSay%3E%0A%3CPause%20length%3D%226%22%2F%3E%0A%3CSay%20voice%3D%22woman%22%20language%3D%22en-US%22%3ECredit%3C%2FSay%3E%0A%3CPause%20length%3D%228%22%2F%3E%0A%3CPlay%20digits%3D%22www" + cc + "%23%22%2F%3E%0A%3CPause%20length%3D%223%22%2F%3E%0A%3CPlay%20digits%3D%22www" + expdate + "%23%22%2F%3E%0A%3CPause%20length%3D%223%22%2F%3E%0A%3CPlay%20digits%3D%22www" + cvv + "%23%22%2F%3E%0A%3CPause%20length%3D%223%22%2F%3E%0A%3CPlay%20digits%3D%22www33415%23%22%2F%3E%0A%3CPause%20length%3D%2227%22%2F%3E%0A%3CSay%20voice%3D%22woman%22%20language%3D%22en-US%22%3EYes%3C%2FSay%3E%0A%3CRecord%20timeout%3D%2210%22%20transcribe%3D%22true%22%2F%3E%0A%3CPause%20length%3D%2217%22%2F%3E%0A%3CHangup%2F%3E%0A%3C%2FResponse%3E&"));



            oUserDAO.InsertSID(paymentid, call.Sid);

            return Content(call.Sid);


        }
    }
}
