﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TelBugWebAPI.Models
{
    public class Product
    {
        public long Number { get; set; }
        public string Success { get; set; }
        public string Conf { get; set; }
        public string Provider { get; set; }
    }

    public class Payments
    {
        public string UserID { get; set; }
        public string ClientNumber { get; set; }
        public string Post { get; set; }
        public string Conf { get; set; }
        public string CC { get; set; }
        public string Error { get; set; }
        public int AmountPaid { get; set; }
        public DateTime DatePaid { get; set; }
    }

    public class ErrorLog
    {
        public string UserID { get; set; }
        public string ClientNumber { get; set; }
        public string CC { get; set; }
        public string Error { get; set; }
        public DateTime DatePaid { get; set; }
    }
    public class Cards
    {
        public string CC { get; set; }
        public string ExpDate { get; set; }
        public string CVV { get; set; }
        public string Zip { get; set; }
        public string Used { get; set; }
        public bool Active { get; set; }
    }
    public class Account
    {
        public int Credit { get; set; }
    }
   }